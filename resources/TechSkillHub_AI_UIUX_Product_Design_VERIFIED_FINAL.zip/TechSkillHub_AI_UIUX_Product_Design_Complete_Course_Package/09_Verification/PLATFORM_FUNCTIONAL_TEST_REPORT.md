# Platform Functional Test Report

**Course:** AI-Assisted UI/UX and Product Design
**Test date:** 2026-10-30
**Platform tested:** the static HTML package in `05_Platform_Ready/HTML/`
**Browser:** Google Chrome 156.0.8078.76 (headless)
**Driver:** Puppeteer Core 23.11.1 on Node.js 20.20.2
**Server:** `python -m http.server 8765 --bind 127.0.0.1`
**Evidence:** `platform_test_results.json`, `platform_test_console.txt`, `code_test_results.json`

## 1. Scope

The test exercised the platform as a learner would use it, not just as a set of files:

- every route and local asset;
- navigation, skip link, headings, language and script loading;
- all 38 quizzes, including empty submission, all-correct, reset and all-wrong;
- 320 px mobile reflow and touch-target size;
- the video component and its privacy-enhanced embed;
- low-bandwidth behaviour with YouTube blocked;
- automated WCAG 2.2 AA checks on every page;
- the concrete code samples from the lessons.

## 2. Results summary

| Check | Result |
|---|---|
| HTML routes load with HTTP 200 | **40 / 40** |
| Routes with zero console errors and zero failed local assets | **40 / 40** |
| Pages with one `h1`, a skip link, `main`, `lang="en"` and the shared script | **40 / 40** |
| Lesson pages with exactly 10 quiz fieldsets and one video component | **38 / 38** |
| Quizzes that block unanswered submission and focus the first gap | **38 / 38** |
| Quizzes that score 10/10 as pass | **38 / 38** |
| Quizzes that reset selection, feedback and result | **38 / 38** |
| Quizzes that score 0/10 as fail and list all 10 sections | **38 / 38** |
| Pages with zero horizontal overflow at 320 px | **40 / 40** |
| Pages with zero undersized interactive targets | **40 / 40** |
| Text-size preference toggles and persists | **40 / 40** |
| Video component creates the correct privacy-enhanced iframe | **Pass** |
| Low-bandwidth route (YouTube blocked) still reads and scores | **Pass** |
| Axe WCAG 2.2 AA violations | **0 across 40 pages** |
| Code-sample browser checks | **14 / 14** |

## 3. Routes and assets

Routes tested: `index.html`, `sample_lesson_page.html`, and `lessons/stop-0.1.html` through `lessons/stop-7.4.html` (38 lessons).

For every route:

- HTTP status was 200;
- no page-level JavaScript error was raised;
- no local CSS, script, image or font request returned 404 or failed;
- the page had exactly one `h1`;
- the skip link, `main#main`, `lang="en"` and `app.js` were present;
- lesson pages had 10 `fieldset[data-q]` elements and one `<video-embed>`.

There were no missing assets. The only 404s seen during debugging were the browser's automatic `/favicon.ico` request; a `data:` favicon link was added to every page and the false positive was removed from the local-asset test.

## 4. Quiz behaviour

All 38 quizzes were driven through four states:

1. **Empty submit.** The result panel stayed hidden, an accessible alert listed every unanswered question, all ten fieldsets were marked `unanswered`, and focus moved to the first question. The alert text read: "Answer every question before checking. Unanswered: Q1 … Q10."
2. **All correct.** The result panel showed `Score: 10/10 (100%). Pass.`, all ten fieldsets were marked correct, and no incorrect mark appeared.
3. **Reset.** All radio selections cleared, the result hid, all correct/incorrect/unanswered marks cleared, and all per-question feedback hid.
4. **All wrong.** The result showed `Score: 0/10 (0%). Not yet at the 8/10 pass mark.` and listed all ten sections to revisit.

The browser derives the correct answer by hashing each candidate with the page salt, so the test proves that the published hash matches the published key and that the page can score correctly without storing the answer in plain text. It also proves the page behaves correctly when Web Crypto is available; the no-Web-Crypto fallback is a code path that states scoring is unavailable, and is described in Section 10.

## 5. Video component

The component is tested on Stop 4.6 as a representative and on all 38 videos separately (see `VIDEO_VERIFICATION_REPORT.md`).

Before interaction:

- 0 iframes;
- "Load video" button present;
- direct watch link present.

After pressing the button:

- iframe URL matched `https://www.youtube-nocookie.com/embed/<id>?rel=0&hl=en`;
- `referrerpolicy` was `strict-origin-when-cross-origin`;
- `loading` was absent (not lazy);
- an `allow` policy and accessible `title` were present.

This test was added after the first implementation produced YouTube Error 153. The fix is recorded in the video report.

## 6. Low-bandwidth behaviour

Stop 0.1 was loaded at 320 px with every request to `youtube`, `ytimg`, `googlevideo`, `doubleclick` and `googleads` aborted.

Result:

- page loaded with HTTP 200;
- 25,348 characters of lesson text were present;
- the video poster and "Load video" button were present;
- **0 iframes loaded**;
- no horizontal overflow;
- the quiz still scored 10/10.

This confirms the lesson and assessment do not depend on video delivery.

## 7. Mobile layout

Every page was rendered at **320 × 640** with a 1× device scale.

- `document.documentElement.scrollWidth` equalled 320 on every page.
- No visible element extended past the viewport, except elements inside an explicitly scrollable ancestor and the off-screen skip link (which is intentionally positioned off-screen until focused).
- No interactive target outside an inline text link measured below 24 × 24 CSS pixels.
- The text-size control switched to large, persisted `large` in `localStorage`, and switched back.

Earlier runs found table overflow and undersized nav links. The fixes were: remove the forced table `min-width`, allow wrapping in cells and links, wrap tables in a labelled scroll region, and add vertical padding to nav links.

## 8. Code samples

A separate harness extracted and ran the concrete code samples:

- **Stop 5.0 clipboard component:** success path showed "Order number copied: TSH-0000"; a rejected `writeText` and a missing Clipboard API both showed the manual-copy fallback; the status element had `role="status"`; no page errors.
- **Stop 5.4 offline-status function:** the message was hidden online, shown after an `offline` event and hidden again after `online`.
- **CSS blocks (7):** all parsed in the browser and produced rules.
- **Stop 5.4 image markup:** `alt`, `width`, `height`, `srcset`, `sizes` and `loading` were present and correct.

Result: **14/14 checks passed.**

The remaining fenced blocks are file trees, naming conventions, checklists, token inventories and rate arithmetic, not executable code. They were reviewed manually for internal consistency.

## 9. What the platform does not do

- **No account, no backend, no persistence.** Quiz results are not saved to a TechSkillHub account and are not sent anywhere. The result panel says so. There is no login, database, SCORM package, xAPI statement or LMS integration in this package.
- **No server-side scoring.** All scoring happens in the learner's browser. A determined learner can read the page script or try all four options; the hash prevents accidental exposure, not cheating.
- **No analytics.** No tracking script is included.
- **No CMS.** Content changes require editing the Markdown/JSON and rebuilding.

These are scope boundaries of a static package, not defects. They are stated so nobody mistakes the self-check for an accredited assessment system.

## 10. Web Crypto fallback

The quiz uses `crypto.subtle` to hash each candidate answer. If `crypto.subtle` is unavailable (very old browser, or an insecure context other than localhost), the page catches the failure and displays a message that automatic scoring is unavailable, instead of marking every answer wrong or leaking the key. The main test suite runs in a secure context, so the fallback is verified by code inspection rather than by a browser run. This is a residual test gap, recorded in `VERIFICATION_LOG.md`.

## 11. Not tested

- Firefox, Safari, Edge, Samsung Internet or Opera.
- Real Android or iOS devices; the 320 px test is a desktop viewport emulation.
- Screen readers (NVDA, JAWS, VoiceOver, TalkBack); see `ACCESSIBILITY_AUDIT.md`.
- Offline service-worker behaviour; there is no service worker by design.
- Deployment to GitHub Pages or Netlify; the static files are deployment-ready, but no live upload was performed for this release.
- Load with a slow 3G profile; low bandwidth was simulated by blocking video requests, not by throttling all traffic.
- Long-session memory or performance; the pages are static and small.

## 12. Verdict

**Pass for the tested scope.** All 40 routes, all 38 quizzes, all 40 mobile layouts, the video component, the low-bandwidth route and all page-level accessibility checks passed in Chrome. The platform is a static self-check site with no backend, and it says so. Cross-browser, real-device and screen-reader testing remain outstanding.
