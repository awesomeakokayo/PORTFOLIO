# Video Verification Report

**Course:** AI-Assisted UI/UX and Product Design
**Date of tests:** 2026-10-30
**Videos:** 38, one per stop
**Test environment:** Google Chrome (headless), Windows, `http://127.0.0.1:8765`, English locale
**Evidence file:** `video_verification.json` (build workspace) and `08_YouTube/YOUTUBE_VIDEO_MANIFEST.csv` (package)

## 1. What was tested

For each of the 38 recommended videos:

1. The watch page was fetched with an English locale and the title, channel, upload date, duration, playability status, available countries and caption tracks were read from the player metadata.
2. The video was loaded through the course video component in the **real lesson page**, by pressing the learner-facing button, so the privacy-enhanced embed URL, referrer policy and iframe creation were exercised.
3. Playback was confirmed from the page: the `HTMLVideoElement` reached `readyState 4`, `paused` was `false`, `currentTime` advanced, and the reported duration matched the video.
4. Direct watch-page content playback was attempted separately.
5. Content fit was judged against the stop outcome from the watch-page title and description, not from a full viewing.

## 2. Headline results

| Check | Result |
|---|---|
| Watch page reachable | 38 / 38 (`HTTP 200`) |
| Playability status `OK` | 38 / 38 |
| **Embedded playback in the real lesson** | **38 / 38 verified** |
| Direct watch-page content playback | 13 verified, 8 blocked by pre-roll ads, 17 not tested |
| English captions listed | 38 / 38 |
| Caption accuracy reviewed | 0 / 38 |
| Metadata lists Nigeria | 38 / 38 (249 countries listed) |
| Playback tested from a Nigerian network | 0 / 38 |
| Full content fit | 27 |
| Partial content fit | 10 |
| Peripheral content fit | 1 |
| Broken or replaced videos | 0 in this round; all 38 remain the reviewed recommendations |

## 3. What "verified" means here

**Embedded playback verified** means the actual lesson page created a `youtube-nocookie.com` iframe, the video element became ready, playback started and time advanced. It does **not** mean the whole video was watched, that every claim in it is accurate, that captions are correct, or that the same video will play on a Nigerian network.

**Direct watch-page verified** means content (not an advertisement) was observed playing on the YouTube watch page and `currentTime` advanced.

**Ad-blocked** means the watch page loaded and reported `OK`, but a pre-roll advertisement consumed the test window, so content playback was not observed. The embedded test still passed.

**Not tested** means direct watch-page playback was not attempted in this round because embedded playback already provided the required evidence and repeated ad interruptions were consuming the test window. It is not a failure.

## 4. Problem found and fixed

The first embedded test produced YouTube **Error 153**: the player refused to start because the embedding page did not send a usable referrer. The course component was changed to:

- set `referrerPolicy = "strict-origin-when-cross-origin"` **before** assigning `src`;
- remove `loading="lazy"` from the click-created iframe, because a lazy iframe created after a click can be deferred indefinitely;
- keep `youtube-nocookie.com` for privacy-enhanced mode and keep the direct watch link as the no-embed fallback.

After the fix, all 38 embeds played. The regression test is in `test_platform.js` and asserts the iframe URL, referrer policy and absence of lazy loading.

## 5. Per-stop results

| Stop | Video ID | Title | Creator | Fit | Embed | Direct watch | Captions |
|---|---|---|---|---|---|---|---|
| 0.1 | `BY1y_RQxIdg` | How to Organize Files and Folders in Windows for Beginners | LearnFree | Full | Verified | Verified | English listed; accuracy not reviewed |
| 0.2 | `hvBGy8ewZNc` | How to teach yourself UX Design (no bootcamps, no courses) | Andres The Designer | Peripheral | Verified | Verified | English listed; accuracy not reviewed |
| 0.3 | `EcbgbKtOELY` | Every UI/UX Concept Explained in Under 10 Minutes | Kole Jain | Full | Verified | Ad-blocked | English listed; accuracy not reviewed |
| 0.4 | `m3jNwwuvqx8` | ChatGPT Study Mode - Explained By A Learning Expert | Justin Sung | Partial | Verified | Verified | English listed; accuracy not reviewed |
| 0.5 | `jQ1sfKIl50E` | Figma Tutorial for Beginners (13-min crash course!) | Flux Academy | Partial | Verified | Ad-blocked | English listed; accuracy not reviewed |
| 1.1 | `LckQ4VVjHDs` | What EXACTLY is Product Design? 🤔 | Andres The Designer | Full | Verified | Verified | English listed; accuracy not reviewed |
| 1.2 | `5tVbFfGDQCk` | How To Conduct User Interviews Like A Pro (UX Design) | CareerFoundry | Full | Verified | Verified | English listed; accuracy not reviewed |
| 1.3 | `k01edeNOC_U` | What is Jobs to Be Done Theory? | Clayton Christensen Institute | Partial | Verified | Ad-blocked | English listed; accuracy not reviewed |
| 1.4 | `Vl0m3Y3hg80` | Competitive Analysis Guide for UX Designers | Pierluigi Giglio | Full | Verified | Verified | English listed; accuracy not reviewed |
| 2.1 | `cf95Z7Ngg8k` | Master Spacing in UI Design 💪 | Jesse Showalter | Full | Verified | Verified | English listed; accuracy not reviewed |
| 2.2 | `AXpxZMRM1EY` | The ULTIMATE Guide To Typography For Beginners | DesignSpo | Partial | Verified | Verified | English listed; accuracy not reviewed |
| 2.3 | `xCrhKzyxp0M` | 40 UI elements every designer needs to know | LogRocket | Full | Verified | Verified | English listed; accuracy not reviewed |
| 2.4 | `MUh3xyvEWDE` | Empty States in Application Design: 3 Guidelines | NNgroup | Partial | Verified | Verified | English listed; accuracy not reviewed |
| 2.5 | `5H1JGdqLrWo` | WCAG for beginners - What are the Web Content Accessibility Guidelines? - Web Accessibility | Silktide | Partial | Verified | Verified | English listed; accuracy not reviewed |
| 3.1 | `1SNZRCVNizg` | Free Figma Crash Course for Beginners 2026 \| UI/UX Design | DesignWithArash | Partial | Verified | Ad-blocked | English listed; accuracy not reviewed |
| 3.2 | `1odqpkfkDL8` | A Guide to Auto Layout: Best Practices, Tips & Tricks \| Figma | Figma | Full | Verified | Verified | English listed; accuracy not reviewed |
| 3.3 | `bnoPAezI6cw` | Figma Tutorial: Master Figma Components and Variants in 20 Minutes (Beginner Guide) | DesignWithArash | Partial | Verified | Ad-blocked | English listed; accuracy not reviewed |
| 3.4 | `1ucLq6JTxac` | Figma Prototype Tutorial for Beginners | Aliena Cai | Full | Verified | Ad-blocked | English listed; accuracy not reviewed |
| 3.5 | `_uva2dQPlV8` | Your First Design System in Figma (Beginner Tutorial) | Tim Gabe | Full | Verified | Ad-blocked | English listed; accuracy not reviewed |
| 4.1 | `2V3NoUcLV_4` | How to Use AI (ChatGPT) for UX Research Synthesis \| Evidence to Problem Definition! | AI Design Professor \| Nehmat Gereige | Full | Verified | Ad-blocked | English listed; accuracy not reviewed |
| 4.2 | `YYvZ2_TIcHA` | I Created Complete User Journeys in Minutes Using ChatGPT + Figma (No Manual Diagramming) | UX For AI | Partial | Verified | Verified | English listed; accuracy not reviewed |
| 4.3 | `j_ZPV10bu54` | Designing With AI: Claude, Codex, Figma \| Full Guide | UI Collective | Partial | Verified | Not tested | English listed; accuracy not reviewed |
| 4.4 | `sqi0-Lz_ZTY` | How to Conduct a Heuristic Evaluation | NNgroup | Full | Verified | Not tested | English listed; accuracy not reviewed |
| 4.5 | `ylx67a1v7_M` | Microcopy. Complete UX Writing Guide 🖊 | Maria Fetiskina | Full | Verified | Not tested | English listed; accuracy not reviewed |
| 4.6 | `cUUei_rH5Os` | How to Fact-Check AI: Verify Claims, Citations, and Sources \| AI Essentials 7 | Prof. Ghassemi | Full | Verified | Not tested | English listed; accuracy not reviewed |
| 4.7 | `Oo-5AWdQAt8` | Use AI Like a Senior Designer (3 Workflows) | UI Collective | Full | Verified | Not tested | English listed; accuracy not reviewed |
| 5.0 | `gT0Lh1eYk78` | HTML, CSS, JavaScript Explained [in 4 minutes for beginners] | Danielle Thé | Full | Verified | Not tested | English listed; accuracy not reviewed |
| 5.1 | `xCJsRuH7v9w` | Figma tutorial: Collaboration and handoff in Dev Mode | Figma | Full | Verified | Not tested | English listed; accuracy not reviewed |
| 5.2 | `aAS_pZ5cgPA` | Turn Any Figma Design Into Code with Claude (tutorial) | Ryan Hayward | Full | Verified | Not tested | English listed; accuracy not reviewed |
| 5.3 | `JyCmacSyDY4` | Tokens, variables, and styles - Update: Introduction to design systems | Figma | Full | Verified | Not tested | English listed; accuracy not reviewed |
| 5.4 | `x4u1yp3Msao` | A practical guide to responsive web design | Kevin Powell | Full | Verified | Not tested | English listed; accuracy not reviewed |
| 6.1 | `RhgUirqki50` | Usability Testing w. 5 Users: Design Process (video 1 of 3) | NNgroup | Full | Verified | Not tested | English listed; accuracy not reviewed |
| 6.2 | `UTNv6CNv82E` | 6 Key UX Metrics Explained | Eleken | Full | Verified | Not tested | English listed; accuracy not reviewed |
| 6.3 | `gklsUyD6RPE` | UX Design Prioritization Methods | NNgroup | Full | Verified | Not tested | English listed; accuracy not reviewed |
| 7.1 | `044MI9uH1c4` | How to create your first UX case study (2026 beginner tutorial) | Aliena Cai | Full | Verified | Not tested | English listed; accuracy not reviewed |
| 7.2 | `crAaxd30NMg` | How to Work with Product Managers as a Senior Designer \| Collaboration tips | femke.design | Full | Verified | Not tested | English listed; accuracy not reviewed |
| 7.3 | `PNG0Qvl-PdQ` | How I'd Build A JOB READY UI/UX Design Portfolio In 2026. [FULL GUIDE] | Saptarshi Prakash | Full | Verified | Not tested | English listed; accuracy not reviewed |
| 7.4 | `B7YjIGZiA-Q` | Freelance Pricing Secrets Every Designer Should Know | Rachel How | Full | Verified | Not tested | English listed; accuracy not reviewed |

## 6. Content-fit notes

A video is **full** fit when its stated topic covers the stop outcome and the lesson uses it as an optional overview. **Partial** fit means it covers part of the stop, or uses a different tool/version, and the lesson explicitly supplies the missing part. **Peripheral** means it is useful context but not a demonstration of the stop outcome.

- **0.2 — How to teach yourself UX Design (no bootcamps, no courses)** (Peripheral): Self-taught UX path and study habits. It does not explain this course's stop/gate/retry system, so it is a supplement only.
- **0.4 — ChatGPT Study Mode - Explained By A Learning Expert** (Partial): Explains ChatGPT Study Mode, a feature whose availability varies. The durable tutoring and verification idea is supported by the lesson, not proved by the video.
- **0.5 — Figma Tutorial for Beginners (13-min crash course!)** (Partial): A 13-minute Figma crash course. It covers more than the first-screen task and should be sampled, not watched end to end.
- **1.3 — What is Jobs to Be Done Theory?** (Partial): Jobs-to-be-done theory. The job-story template in this lesson is a course adaptation and is not shown in the video.
- **2.2 — The ULTIMATE Guide To Typography For Beginners** (Partial): Typography only. Colour, semantic colour systems and contrast are covered by the lesson and the WCAG sources.
- **2.4 — Empty States in Application Design: 3 Guidelines** (Partial): Covers empty states only, not the full loading/error/success/offline set required by the stop.
- **2.5 — WCAG for beginners - What are the Web Content Accessibility Guidelines? - Web Accessibility** (Partial): A 1:50 introduction to WCAG. It defines the standard but does not demonstrate an audit.
- **3.1 — Free Figma Crash Course for Beginners 2026 | UI/UX Design** (Partial): An 89-minute Figma crash course. It is comprehensive but too long for one stop; use named sections rather than watching all of it.
- **3.3 — Figma Tutorial: Master Figma Components and Variants in 20 Minutes (Beginner Guide)** (Partial): Components and variants are central; variables and token modes are not the focus.
- **4.2 — I Created Complete User Journeys in Minutes Using ChatGPT + Figma (No Manual Diagramming)** (Partial): A promotional ChatGPT + Figma journey workflow. It shows one tool chain, not a vendor-neutral critique method.
- **4.3 — Designing With AI: Claude, Codex, Figma | Full Guide** (Partial): An 87-minute broad AI design workflow. It does not demonstrate the stop's constrained prompt, import and review sequence end to end.

## 7. Remaining limitations

1. **Nigeria playback is unconfirmed.** Every video lists Nigeria in its available-country metadata, but no test was run from a Nigerian network. Region, mobile-carrier blocking, age restrictions or privacy settings could still prevent playback.
2. **Caption accuracy is unreviewed.** English tracks are listed for every video, but YouTube transcript endpoints returned empty or `FAILED_PRECONDITION` from this environment, and no human checked the captions line by line.
3. **Direct watch pages are ad-heavy.** 8 of 38 were blocked by pre-roll ads within the test window and 17 were not attempted directly. Embedded playback is verified for all 38, so the learner-facing path is tested.
4. **Content was not watched end to end.** Fit is judged from metadata and description; a video could contain an inaccurate claim that the lesson does not repeat.
5. **Timestamps were not used.** The lessons do not send learners to a timestamp, so no timestamp is claimed.
6. **Videos can change.** A creator can remove, privatise or edit a video after 2026-10-30. The manifest must be rechecked before a cohort.

## 8. Maintenance rule

If a video fails, do not invent a replacement ID. Mark it unavailable, keep the lesson text as the primary route, check the metadata and embedded playback of any proposed replacement, and update all of: the lesson Section 14, `YOUTUBE_VIDEO_MANIFEST.csv`, `video_verification.json`, this report and the file hashes.
