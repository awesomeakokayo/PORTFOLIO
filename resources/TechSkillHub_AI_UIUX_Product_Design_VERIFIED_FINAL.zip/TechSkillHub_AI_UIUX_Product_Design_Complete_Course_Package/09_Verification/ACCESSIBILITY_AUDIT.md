# Accessibility Audit

**Course:** AI-Assisted UI/UX and Product Design
**Date:** 2026-10-30
**Target:** WCAG 2.2 Level AA for the static HTML platform
**Automated engine:** axe-core 4.13.0, tags `wcag2a`, `wcag2aa`, `wcag21a`, `wcag21aa`, `wcag22aa`
**Browser:** Chrome 156 (headless), 1280 × 900 and 320 × 640
**Pages:** 40 (index, sample lesson, 38 lessons)
**Evidence:** `platform_test_results.json`, `accessibility_keyboard_results.json`

## 1. Headline result

| Check | Result |
|---|---|
| Pages with zero axe WCAG 2.2 AA violations | **40 / 40** |
| Total axe violation nodes | **0** |
| Violation types | **none** |
| Pages with a skip link | 40 / 40 |
| Pages with one `h1`, `lang="en"`, `main` landmark and labelled navigation | 40 / 40 |
| Pages with horizontal overflow at 320 px | **0 / 40** |
| Undersized interactive targets at 320 px | **0** |
| Keyboard focus visible on every tab stop tested | **Yes (24/24 on Stop 0.1)** |
| Skip link moves focus to `main` | **Yes** |
| Code samples and table regions reachable by keyboard | **Yes** |
| Text-size preference works and persists | **Yes** |

This is a strong automated and structural result. It is **not** a claim that the course is accessible to every disabled learner; see Section 7.

## 2. What was tested automatically

axe-core ran on every page after load, against the WCAG 2.0, 2.1 and 2.2 A/AA rule sets. It checks, among other things:

- document language and title;
- heading order and landmark structure;
- image alternatives;
- form labels and names;
- colour contrast of text and UI components;
- link and button names;
- ARIA role and attribute validity;
- duplicate IDs;
- scrollable region keyboard access;
- target size (where the rule applies).

Result: zero violations on all 40 pages, including all 38 lessons with quizzes, video components and tables.

## 3. Defects found and fixed

The audit was not clean on the first run. The following defects were found and corrected:

| Defect | Where found | Fix | Re-test |
|---|---|---|---|
| Scrollable `<pre>` blocks were not keyboard-focusable (`scrollable-region-focusable`) | 5 lessons with long code blocks | Added `tabindex="0"` and `aria-label="Code sample"` to every fenced code block | Pass |
| Tables forced a wide minimum width, causing horizontal overflow at 320 px | Lesson pages with comparison tables | Removed the forced `min-width`, allowed cell wrapping, added a labelled scroll region with `tabindex="0"` and `role="region"` | Pass |
| Long URLs and code tokens overflowed narrow screens | Several lessons | Added `overflow-wrap: anywhere` to links, inline code, cells and pre blocks | Pass |
| Navigation links were only 23 px high on mobile | All pages | Added vertical padding to nav links | Pass |
| Skip link scrolled to `main` but did not move keyboard focus | All pages | Added `tabindex="-1"` to `main#main`; verified focus lands on `main` after Enter | Pass |
| Browser requested a missing favicon, producing console noise | All pages | Added `<link rel="icon" href="data:,">` | Pass |

## 4. Manual keyboard check

On Stop 0.1, at 1280 × 900:

1. The first Tab revealed the "Skip to content" link at the top-left.
2. Enter moved focus to `main` (`document.activeElement.id === "main"`), not just the scroll position.
3. Tabbing then moved through the course link, the video button, the direct video link, the transcript disclosure, the table region, three code blocks, ten quiz radios, the check and clear buttons, the common-mistakes table, the next-stop link, and the footer links.
4. Every one of the 24 sampled tab stops had a visible `3px` solid outline.
5. The table region and code blocks received focus and exposed an accessible name.

This confirms the main keyboard path. It does not prove that every possible focus order in every lesson is logical; the pages share one template, so the Stop 0.1 result is representative but not exhaustive.

## 5. Reflow and target size

At **320 CSS pixels** wide:

- every page had `scrollWidth === 320`;
- no visible element extended past the viewport except content inside an explicitly scrollable region and the intentionally off-screen skip link;
- no interactive control outside an inline text link was smaller than 24 × 24 CSS pixels.

This addresses WCAG 2.2 SC 1.4.10 (Reflow) and SC 2.5.8 (Target Size, Minimum) for the tested viewport. The course also recommends 44 × 44 in its own teaching, which is stricter than the AA minimum.

## 6. WCAG 2.2 AA criteria relevant to this package

| Criterion | How the package addresses it | Evidence |
|---|---|---|
| 1.3.1 Info and Relationships | Semantic headings, landmarks, tables with headers, labelled form groups | axe pass; structure checks |
| 1.4.3 Contrast (Minimum) | Palette chosen for 4.5:1 body text; axe contrast rule | axe pass on 40 pages |
| 1.4.4 Resize Text | Text-size control plus browser zoom; no fixed-height text containers | text-size test |
| 1.4.10 Reflow | 320 px layout with wrapping and scroll regions | 40/40 mobile test |
| 1.4.11 Non-text Contrast | Focus outlines and control borders | axe pass; visual check |
| 2.1.1 Keyboard | Native links, buttons, radios, summaries; focusable code/table regions | keyboard walk |
| 2.2.2 Pause, Stop, Hide | No autoplaying video, carousel or animation | code review; video loads only on click |
| 2.4.1 Bypass Blocks | Skip link to `main` | keyboard test |
| 2.4.2 Page Titled | Unique descriptive titles | route test |
| 2.4.3 Focus Order | DOM order matches visual order; one template | keyboard walk |
| 2.4.7 Focus Visible | 3 px outline on every tested stop | keyboard test |
| 2.5.8 Target Size (Minimum) | No sub-24 px controls at 320 px | mobile test |
| 3.2.3 Consistent Navigation | Same header/nav/footer order on every page | template review |
| 3.3.1 Error Identification | Unanswered questions listed by number and marked | quiz test |
| 3.3.3 Error Suggestion | Each wrong answer names the section to revisit | quiz test |
| 4.1.2 Name, Role, Value | Native controls; labelled iframe and regions | axe pass |
| 4.1.3 Status Messages | Quiz result and copy status use live regions | quiz and code tests |

## 7. What this audit does not cover

1. **No disabled participants were involved.** The audit is automated plus an expert keyboard review. It is not a usability study with blind, low-vision, motor-impaired or cognitively diverse learners.
2. **No screen-reader testing.** NVDA, JAWS, VoiceOver and TalkBack were not run. Semantic HTML and axe results are encouraging but do not prove a good announcement experience, especially for the ten-question quiz feedback.
3. **No browser or device matrix.** Only Chrome 156 on Windows was tested. Safari/VoiceOver on iOS and Firefox/NVDA on Windows are the most important missing combinations.
4. **Video captions are not controlled by the course.** Every video lists an English caption track, but caption accuracy was not reviewed. The lesson text is the accessible route; the video is optional.
5. **No audio description review.** The videos are optional and the course does not depend on visual content in them, but no audio-description track was checked.
6. **Cognitive accessibility is only partially addressed.** Plain language, glossaries, consistent structure and chunking help, but no cognitive-accessibility specialist reviewed the course and no Easy Read version exists.
7. **The quiz has no time limit**, which is good for accessibility, but it also has no saved progress; a learner who reloads loses selections.
8. **No high-contrast or forced-colours mode test.** The palette is simple and semantic, but Windows High Contrast and `forced-colors` were not tested.
9. **No print stylesheet review.** Printing is possible but not designed.

## 8. Accessibility of the Markdown package

The Markdown files are plain UTF-8 text with real heading levels and table pipes. They can be read by a screen reader, converted to Braille or read in any editor. They do not depend on colour, JavaScript or a browser. The HTML is a rendering of the same content, not the only copy.

## 9. Verdict

**Pass at WCAG 2.2 AA for automated and structural checks, with significant manual-testing gaps.** All 40 pages pass axe with zero violations, 320 px reflow is clean, the keyboard path works, focus is visible and the skip link now moves focus correctly. The package has not been tested with disabled learners or screen readers, and that limitation should be stated wherever the course is marketed. Automated conformance is not the same as usability.
