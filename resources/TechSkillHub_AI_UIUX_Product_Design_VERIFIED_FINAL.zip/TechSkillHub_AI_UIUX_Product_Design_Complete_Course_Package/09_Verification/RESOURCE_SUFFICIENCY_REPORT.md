# Resource Sufficiency Report

**Course:** AI-Assisted UI/UX and Product Design
**Date checked:** 2026-10-30
**Current reading sources:** 66 unique URLs
**Original sources reviewed:** 54
**Stops covered:** 38 / 38
**Machine-readable evidence:** `06_Research/SOURCE_REGISTER.csv`, `07_Resources/RESOURCE_REVIEW.csv`, `07_Resources/ORIGINAL_RESOURCE_REVIEW.csv`, `07_Resources/RESOURCE_SUFFICIENCY_MATRIX.csv`

## 1. The question this report answers

For each of the 38 stops: does the learner have at least one free, readable source that supports the stop outcome, and is the gap between what the source covers and what the lesson requires stated honestly?

The answer recorded here is **sufficient with a stated gap for all 38 stops**. That is deliberately not the same as "perfect". Most sources are general references; the lesson supplies the beginner-specific demonstration, template, local context or task. The gap column names what the source does not provide.

## 2. Method

1. Every non-video URL cited in the final Section 14 of each lesson was extracted.
2. Duplicates were merged, giving 66 unique sources.
3. Each URL was requested with redirects followed; the final URL, HTTP status, content type and body text were recorded.
4. Each source was read. The review recorded: what part was read, beginner fit, cost, login requirement, currency and whether it is core, supporting or optional for the stop.
5. Each of the 54 sources in the original package was reviewed again against the same criteria; 49 were kept and 5 were removed or replaced.
6. For each stop, the matrix records reading count, primary reading, supplementary readings, video fit, coverage of concept / demonstration / guided practice / independent practice / assessment, beginner support, cost, login, currency, the remaining gap and a sufficiency status.

## 3. Results

| Measure | Result |
|---|---|
| Unique current sources | 66 |
| Stops with at least one reading source | 38 / 38 |
| Stops with 2 or more reading sources | 37 / 38 |
| Stops with 3 or more reading sources | 19 / 38 |
| Sources returning HTTP 200 | 62 |
| Sources returning HTTP 403 to scripted clients | 4 (W3C pages; readable in a browser) |
| Sources free to read | 66 / 66 |
| Sources requiring a paid subscription | 0 |
| Sources reviewed as High beginner fit | 17 |
| Medium beginner fit | 45 |
| Advanced / optional | 4 |
| Core lesson fit | 50 |
| Supporting | 14 |
| Optional | 2 |
| Original sources kept | 49 |
| Original sources removed or replaced | 5 |

The four HTTP 403 responses are W3C pages. W3C rejects the scripted client used for bulk checking, but the pages load normally in a browser and were reviewed there. The source register records the 403 rather than pretending it was a 200.

## 4. What changed from the original 54

The original list was not accepted wholesale. Five sources were removed or replaced because they were unreadable in this environment, too advanced, promotional, outdated or a poor fit. Several further stops gained a second, stronger reading instead of keeping a single adjacent-fit link.

| Stop | Change | Reason |
|---|---|---|
| 0.2 | Added Cornell LSC *Effective Study Strategies* | The original study advice was generic; this is a concrete, free study-method source. |
| 0.4 | Added IBM *What are AI hallucinations?*; replaced Google PAIR with Microsoft HAX | PAIR’s application shell could not be read reliably; HAX provides stable, citable human-AI interaction guidance. NIST remains as advanced/optional. |
| 1.1 | Added NN/g *UX roles and responsibilities* and the product/UX study guide | The original source described the field but not the role boundaries a beginner needs. |
| 1.3 | Added NN/g *Problem statements* | The original job-story source did not teach problem framing directly. |
| 1.4 | Added NN/g *Competitive usability evaluations* | The original source lacked a method for evidence-based comparison. |
| 2.4 | Added NN/g *Empty-state interface design* plus WCAG | The original reading did not cover empty states, the stop’s core outcome. |
| 3.4 | Added NN/g *Case study: iterative design prototyping* | Figma documentation explains mechanics, not what to test or why. |
| 4.1 | Added NN/g *Research with AI* plus NIST | The original AI source was too general for research synthesis. |
| 4.2 | Added NN/g *Journey mapping 101* plus GOV.UK patterns | The original source did not teach journey mapping. |
| 6.2 | Added Amplitude *North Star Playbook* | The original metric source was thin on choosing a primary metric. |
| 6.3 | Added NN/g *A/B testing* | The original prioritisation reading did not cover experiment limits. |
| 7.1 | Replaced with NN/g case-studies hub | Removed an agile link and a WebAIM link that did not serve the case-study outcome. |
| 7.2 | Added NN/g *Developer–designer relationship* | The original collaboration source was too generic. |
| 7.4 | Added Freelancers Union rate and proposal guides | Removed GOV.UK business support and ILO pages that were not a practical pricing method. |

The full 54-row decision record is `ORIGINAL_RESOURCE_REVIEW.csv`.

## 5. Stop-by-stop sufficiency

| Stop | Readings | Primary reading | Video fit | Gap the lesson must supply | Status |
|---|---|---|---|---|---|
| 0.1 | 2 | https://help.figma.com/hc/en-us/articles/360041539473-Frames-in-Figma-Design | full | Figma help assumes the interface is open; the lesson supplies the account, folder and screenshot steps. | Sufficient with stated gap |
| 0.2 | 1 | https://lsc.cornell.edu/how-to-study/studying-for-and-taking-exams/effective-study-strategies/ | peripheral | One study-skills source; no UX-specific study evidence, so the lesson supplies the course-specific habit task. | Sufficient with stated gap |
| 0.3 | 2 | https://www.nngroup.com/articles/ten-usability-heuristics/ | full | The heuristics and Material pages are broad; the lesson supplies the annotation task and the evidence rule. | Sufficient with stated gap |
| 0.4 | 3 | https://www.ibm.com/think/topics/ai-hallucinations | partial | NIST is advanced and optional; IBM explains hallucination but not how to evaluate a specific model. | Sufficient with stated gap |
| 0.5 | 2 | https://help.figma.com/hc/en-us/articles/360040451373-Guide-to-auto-layout-in-Figma | partial | Figma help pages are tool-specific; the lesson supplies the first-screen sequence and the free-plan boundary. | Sufficient with stated gap |
| 1.1 | 2 | https://www.nngroup.com/articles/ux-roles-responsibilities/ | full | The role article is agency-oriented; the lesson adapts the distinctions to a small or solo team. | Sufficient with stated gap |
| 1.2 | 2 | https://www.nngroup.com/articles/user-interviews/ | full | Two research sources; no Nigeria-specific recruitment or consent template, so the lesson supplies a script. | Sufficient with stated gap |
| 1.3 | 2 | https://www.nngroup.com/articles/problem-statements/ | partial | The problem-statement article is method guidance; the job-story wording is a course adaptation, not a quotation. | Sufficient with stated gap |
| 1.4 | 2 | https://www.nngroup.com/articles/competitive-usability-evaluations/ | full | The competitive-evaluation article is method guidance; the lesson supplies the evidence-log template. | Sufficient with stated gap |
| 2.1 | 2 | https://design-system.service.gov.uk/ | full | Material layout guidance is visual and tool-oriented; the lesson supplies the spacing and grid exercise. | Sufficient with stated gap |
| 2.2 | 3 | https://www.w3.org/TR/WCAG22/ | partial | WCAG is normative and WebAIM checks contrast pairs only; the lesson supplies the semantic-colour exercise. | Sufficient with stated gap |
| 2.3 | 2 | https://design-system.service.gov.uk/components/ | full | Component indexes are large; the lesson narrows the reading to three components and their states. | Sufficient with stated gap |
| 2.4 | 2 | https://www.nngroup.com/articles/empty-state-interface-design/ | partial | The empty-state article covers empty states only; the lesson covers loading, error, success and offline states. | Sufficient with stated gap |
| 2.5 | 4 | https://www.w3.org/TR/WCAG22/ | partial | WCAG is advanced; the lesson supplies the plain-language audit checklist and the keyboard test. | Sufficient with stated gap |
| 3.1 | 2 | https://help.figma.com/hc/en-us/articles/360038662654-Guide-to-components-in-Figma | partial | Figma help assumes a project already exists; the lesson supplies the first-file and layer task. | Sufficient with stated gap |
| 3.2 | 2 | https://help.figma.com/hc/en-us/articles/360040451373-Guide-to-auto-layout-in-Figma | full | Auto-layout documentation is tool mechanics; the lesson supplies the responsive decisions and the resize test. | Sufficient with stated gap |
| 3.3 | 3 | https://help.figma.com/hc/en-us/articles/360056440594-Create-and-use-variants | partial | Variants and variables pages are technical; the lesson demonstrates a minimal two-property, two-mode set first. | Sufficient with stated gap |
| 3.4 | 2 | https://help.figma.com/hc/en-us/articles/360040314193-Guide-to-prototyping-in-Figma | full | Prototyping documentation does not teach what to test; the lesson supplies the task, evidence rule and critique. | Sufficient with stated gap |
| 3.5 | 3 | https://help.figma.com/hc/en-us/articles/15339657135383-Guide-to-variables-in-Figma | full | Design-system sources are references; the lesson supplies the deliberately small first-system scope. | Sufficient with stated gap |
| 4.1 | 2 | https://www.nngroup.com/articles/research-with-ai/ | full | The AI research article is from 2024 and tool behaviour changes; the lesson requires source checking and a dated log. | Sufficient with stated gap |
| 4.2 | 2 | https://www.nngroup.com/articles/journey-mapping-101/ | partial | Journey Mapping 101 is conceptual; the lesson supplies the AI-assisted build and the critique checklist. | Sufficient with stated gap |
| 4.3 | 2 | https://www.microsoft.com/en-us/haxtoolkit/ai-guidelines/ | partial | Microsoft HAX is advanced and optional and is not a prompt tutorial; the lesson supplies the prompt constraints and import steps. | Sufficient with stated gap |
| 4.4 | 2 | https://www.nngroup.com/articles/ten-usability-heuristics/ | full | Heuristics and WCAG are general; the lesson supplies the four-step evaluation and the local evidence log. | Sufficient with stated gap |
| 4.5 | 2 | https://design-system.service.gov.uk/ | full | GOV.UK and WCAG supply content guidance; the lesson supplies the microcopy practice and the before/after test. | Sufficient with stated gap |
| 4.6 | 3 | https://www.w3.org/TR/WCAG22/ | full | Fact-checking guidance is general; the lesson supplies the claim, source and verdict table. | Sufficient with stated gap |
| 4.7 | 3 | https://www.microsoft.com/en-us/haxtoolkit/ai-guidelines/ | full | NIST, OECD and HAX are governance-level; the lesson supplies the workflow gates and the review log. | Sufficient with stated gap |
| 5.0 | 5 | https://developer.mozilla.org/en-US/docs/Learn_web_development/Getting_started/Your_first_website | full | MDN is long and code-first; the lesson supplies the smallest usable subset and the local preview step. | Sufficient with stated gap |
| 5.1 | 4 | https://help.figma.com/hc/en-us/articles/15023124644247-Guide-to-Dev-Mode-in-Figma | full | Dev Mode features are plan-dependent; the lesson gives a free manual handoff alternative. | Sufficient with stated gap |
| 5.2 | 4 | https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Accessibility/HTML | full | MDN and web.dev are code-first; the lesson starts with a visual breakpoint plan before code. | Sufficient with stated gap |
| 5.3 | 4 | https://help.figma.com/hc/en-us/articles/360038662654-Guide-to-components-in-Figma | full | Token documentation is technical; the lesson supplies the naming rule and the two-mode example. | Sufficient with stated gap |
| 5.4 | 5 | https://web.dev/articles/responsive-web-design-basics | full | Responsive sources are code-first; the lesson supplies the low-data image budget and the 320 px test. | Sufficient with stated gap |
| 6.1 | 4 | https://www.nngroup.com/articles/usability-testing-101/ | full | Usability Testing 101 is method guidance; there is no Nigeria-specific participant-recruitment source, so the lesson supplies a consent and recruitment script. | Sufficient with stated gap |
| 6.2 | 4 | https://www.gov.uk/service-manual/measuring-success | full | The HEART paper is advanced and Amplitude is vendor-authored; the lesson supplies the metric tree and the low-volume warning. | Sufficient with stated gap |
| 6.3 | 4 | https://www.nngroup.com/articles/ab-testing/ | full | The A/B testing article warns about low volume; the lesson supplies the prioritisation matrix and the decision rule. | Sufficient with stated gap |
| 7.1 | 3 | https://www.nngroup.com/videos/ux-design-portfolio-case-study/ | full | The case-study hub requires the learner to choose one example; the lesson supplies the seven-step structure and evidence check. | Sufficient with stated gap |
| 7.2 | 4 | https://www.nngroup.com/articles/design-critiques/ | full | Collaboration articles assume a team; the lesson adapts the habits to peer review and a solo project. | Sufficient with stated gap |
| 7.3 | 4 | https://www.nngroup.com/articles/ux-design-portfolios/ | full | Portfolio guides are advice, not a hiring guarantee; the lesson requires evidence and a stated role. | Sufficient with stated gap |
| 7.4 | 3 | https://www.nngroup.com/articles/ux-design-portfolios/ | full | The freelance sources are US-framed and dated (2014–2015); every figure and local rule must be replaced. | Sufficient with stated gap |

## 6. Beginner and cost notes

- Every source is free to read. Optional paid courses, Figma Dev Mode and paid AI tiers are never required to pass.
- 49 sources need no login to read. The remaining entries need an account only to *use* the tool (for example, a free Figma account to open a file, a GitHub account to publish) or to manage an optional service. No reading is behind a login.
- Four sources are marked advanced/optional and are never the only route through a stop: NIST AI RMF (0.4, 4.7), WCAG normative text (2.2, 2.5, 5.x) and the HEART paper (6.2). The lesson supplies a plain-language route.
- Currency was checked on 2026-10-30. Tool documentation and vendor blogs change; the review note records the risk where it matters.
- 7.4’s Freelancers Union sources are US-framed and dated 2014–2015. The lesson requires the learner to replace every figure with local research; the report marks this explicitly.

## 7. Residual gaps that remain after review

These are not hidden. They are the reason every row says “sufficient with stated gap” rather than “complete”.

1. **Local recruitment and consent.** There is no Nigeria-specific participant-recruitment or consent template in the source set; the lesson supplies a script and a consent checklist.
2. **Empty, loading, error and offline states.** The NN/g reading covers empty states only; the lesson covers the full state set.
3. **Prototyping decisions.** Figma documentation teaches the tool, not what to prototype; the lesson supplies the task and critique.
4. **AI tool volatility.** AI research guidance ages quickly; the lesson requires a dated log and source checking.
5. **Pricing.** Freelance rate guidance is foreign and old; learners must localise it and cannot treat it as financial advice.
6. **Video content.** A reading source can be fully reviewed; a video cannot be fully reviewed from metadata. See `VIDEO_VERIFICATION_REPORT.md`.

## 8. Verdict

**Pass with stated gaps.** All 38 stops have at least one free, relevant, reachable reading source and a lesson that supplies the missing demonstration or context. No stop relies on a paid, login-walled or unreadable source. The gaps are recorded per stop and are addressed by the lesson text, not waved away.

A future revision should add local Nigerian research-recruitment guidance, a current pricing source with a localisation worksheet, and a maintained list of beginner-safe AI tools.