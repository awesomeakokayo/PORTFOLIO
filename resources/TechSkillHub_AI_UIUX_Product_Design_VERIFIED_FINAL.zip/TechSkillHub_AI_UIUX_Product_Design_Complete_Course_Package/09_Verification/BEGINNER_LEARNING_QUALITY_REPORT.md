# Beginner Learning Quality Report

**Course:** AI-Assisted UI/UX and Product Design
**Review date:** 2026-10-30
**Review type:** structured expert review of the learner materials, plus automated text statistics
**Learner pilot:** **not run** — see Section 9

## 1. Purpose

This report asks a narrower question than "is the course good?":

> Can a motivated beginner with no design background, a free tool set, an intermittent connection and no AI subscription follow each stop from explanation to independent work without being misled?

The answer is recorded against the material as written. It is **not** a claim that beginners have used the course and succeeded; no cohort was run.

## 2. What every stop contains

All 38 lessons have the same 15 sections, verified programmatically:

| Section | Purpose | Stops with it |
|---|---|---|
| 1. What you will be able to do | Observable outcome, not a topic label | 38/38 |
| 2. New words in plain English | Glossary before the teaching | 38/38 |
| 3. Why this matters | Everyday relevance | 38/38 |
| 4. Before you start | Prerequisites, tools, privacy | 38/38 |
| 5. Teaching, step by step | Short numbered explanation | 38/38 |
| 6. Worked example (I do) | A completed example with reasoning | 38/38 |
| 7. We do it together | Guided practice with prompts | 38/38 |
| 8. Your turn (You do) | Independent task | 38/38 |
| 9. Comprehension check | 10 questions, 8/10 pass | 38/38 |
| 10. Practical task and pass criteria | Evidence the learner must produce | 38/38 |
| 11. Common mistakes and how to fix them | Error recovery, retry variant | 38/38 |
| 12. Proof artifact for your portfolio | What to keep and why | 38/38 |
| 13. Low-data and low-cost path | A route without video or paid tools | 38/38 |
| 14. Watch and read more | One optional video and free readings | 38/38 |
| 15. What comes next | Dependency and next stop | 38/38 |

This sequence is deliberate: vocabulary before explanation, a worked demonstration before guided practice, guided practice before independent work, and a retry route after the check.

## 3. Volume and reading load

| Measure | Result |
|---|---|
| Total learner lesson words | 128,602 |
| Shortest stop | 2,797 words |
| Longest stop | 4,556 words |
| Average stop | 3,384 words |
| Average glossary entries per stop | 33.1 (range 21–51) |
| Suggested time per stop | 40–150 minutes, with two-session options for the longest |
| Total suggested course time | roughly 120–180 hours including practice, gates and capstone |

A 3,000–4,500-word lesson is long for one sitting, which is why the longest stops explicitly offer a two-session split and every stop names a stopping point. The text is the primary teaching medium, not a transcript of a video.

## 4. Readability check

A simple Flesch reading-ease and grade-level estimate was run over the lesson bodies (a rough measure, not a literacy assessment):

| Measure | Result |
|---|---|
| Flesch reading ease, average | 66.9 ("plain English" band) |
| Range | 59.6 – 76.2 |
| Flesch–Kincaid grade, average | 6.6 |
| Range | 5.2 – 7.8 |

The hardest stops by this measure are 7.2 (developer–designer collaboration), 3.5 (design systems), 1.4 (competitive review), 4.1 (AI research synthesis), 2.5 (accessibility) and 4.4 (heuristic evaluation). All sit below grade 8 on the estimate, but the estimate ignores jargon density, which is a real load in a design course. The glossaries are the main mitigation: technical terms are defined in the stop where they first appear, in plain English, before the teaching uses them.

## 5. Beginner scaffolds that were checked

### 5.1 Defined terms

Every stop opens its vocabulary section before the teaching. The check confirmed a glossary table in all 38 lessons, averaging 33 entries. Definitions are course-authored; where a term comes from a standard (for example, "contrast ratio" or "reflow"), the lesson gives the plain meaning and cites the normative source in Section 14 rather than copying it.

### 5.2 Worked demonstration before independent work

Every stop has a completed example ("I do") and a guided step ("We do") before "Your turn". The review checked that the guided step is not merely an instruction to repeat the worked example: it asks the learner to make one decision with a prompt, then compare. This is the main defence against the common beginner failure of copying a layout without understanding the decision.

### 5.3 Practice is assessed on evidence, not confidence

Each stop's practical task names an artifact and pass criteria. The learner cannot pass on a statement of intent. Examples: a findings table with counts, a screenshot with an annotation legend, a live URL, a before/after measurement.

### 5.4 Error recovery

All 38 stops include common mistakes and a retry variant. The retry is a different task, not a repeat of the same one, so a learner who failed the check has to use the concept rather than memorise the answer.

### 5.5 Low-data and low-cost route

All 38 stops have a low-data path. The HTML site loads no YouTube iframe until the learner presses "Load video"; the quiz, lesson text and poster work with YouTube blocked. The browser test confirmed this on Stop 0.1 with all YouTube requests aborted: 10 quiz fields, 0 iframes, 10/10 scoring.

### 5.6 No-AI route

Stop 0.1 was corrected so that the AI account is optional. The stop now contains a genuine no-AI route through the tools, Steps 5 and 8, Section 13 and the pass criteria. The learner can complete the workspace, observation and first-screen evidence with lesson text and instructor feedback. The course does not require an AI subscription anywhere.

### 5.7 Privacy

Stop 0.1 no longer asks the learner to write an email address, and the readiness checklist explicitly says not to record an email or password. The AI route is optional and the privacy criterion covers the no-AI route. This matters for beginners, who are the most likely to paste account details into a template.

## 6. Language and tone

- Instructions are written in the second person and use short numbered steps.
- "Why this matters" uses an everyday example before the design vocabulary.
- The course distinguishes a rule from a judgment. Where a threshold is a course policy (80% mastery, 500 KB page budget), the text says so; where it is a standard (WCAG contrast), it cites the standard.
- The course avoids promises of employment, salary or clients. The career phase teaches evidence and pricing method, not guaranteed outcomes.
- Nigerian and wider African examples are used where relevant and labelled fictional.

## 7. Accessibility for beginners

Beginner accessibility is treated as part of the subject, not an add-on. Accessibility appears in the Phase 2 lessons, is revisited in Phase 5 and Phase 6, and is checked at Gates 2 and 5. The HTML platform adds skip links, visible focus, text-size controls, labelled code and table regions, and a video-free route. The detailed automated and manual results are in `ACCESSIBILITY_AUDIT.md`.

## 8. Problems found in this review and fixed

| Problem | Where | Fix |
|---|---|---|
| The setup stop asked learners to record email addresses and treated an AI account as required | 0.1 | Removed email recording; made AI optional; added a full no-AI route and a privacy criterion that covers it |
| The clipboard example claimed success and had no failure path | 5.0 | Added secure-context check, awaited `writeText`, caught failure and showed a manual-copy fallback with a live region |
| The quiz was described as eight questions and 7/8 in several documents | Course-wide | Corrected to 10 questions and 8/10; rebuilt quizzes, keys and documents |
| Answer keys gave generic distractor reasons | 380 questions | Rewrote every key so each distractor has an option-specific reason |
| Correct options were longer than distractors | 380 questions | Rebalanced every option set; average correct and distractor length are both 14.0 words; ratio 1.03 |
| Some videos were described as "not playback-tested" after testing had been done | 12 notes | Replaced stale text with the actual embedded-playback evidence |
| Code blocks and tables were not keyboard-focusable at 320 px | HTML platform | Added focusable code and table regions, wrapping and zero-overflow layout |

## 9. What was not done

**No beginner pilot was run.** This is the largest limitation in this report. The review is an expert review of the material, supported by automated structure and readability checks. It cannot tell you whether a real beginner became confused at Stop 3.5, how long the course actually takes, or whether the Nigerian examples land.

Other limits:

- The readability estimate is formulaic and does not measure jargon load.
- No learner interviews, diary study or usability test of the lesson pages were conducted.
- No comparison group or pre/post assessment was run, so no learning gain is claimed.
- No disabled learner tested the course with their own assistive technology.
- No evidence exists yet on completion rates or portfolio outcomes.

A credible next step is a small pilot with 8–12 beginners: one observed session at Stop 0.1, one at Stop 2.2 or 3.2, and one at Stop 5.0, with a think-aloud protocol, time-on-task, and a short recall check. That would test the three transitions most likely to break: setup, visual vocabulary and code.

## 10. Verdict

**Pass with a major stated limitation.** The materials are structurally complete, beginner-scaffolded, free to complete without AI, and readable at a plain-English level. The course has not been tested with real beginners, so claims about learning effectiveness, pacing and completion remain unproven. This report should be read as a quality review of the design of the learning experience, not as evidence of learner outcomes.
