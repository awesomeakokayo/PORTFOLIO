# Verification Log

**Course package:** TechSkillHub AI-Assisted UI/UX and Product Design
**Version:** 1.1 (verified final)
**Primary test date:** 2026-10-30
**Environment:** Windows; Node.js 20.20.2; Google Chrome 156.0.8078.76; Python 3 HTTP server; Puppeteer Core 23.11.1; axe-core 4.13.0
**Package root during tests:** `TechSkillHub_AI_UIUX_Product_Design_Complete_Course_Package`
**Local server:** `python -m http.server 8765 --bind 127.0.0.1`, run from `05_Platform_Ready/HTML`

This log records what was run, what passed, what failed, what was fixed, and what was not tested. It is a build record, not a marketing claim.

## 1. How to reproduce the checks

From the build workspace:

```text
node build_core.js          # parse sources, regenerate lessons, assessments, keys, JSON
node build_docs.js          # regenerate course map, index, achievement map, dependency graph
node build_rubrics.js       # regenerate 38 stop rubrics
node build_html.js          # regenerate 40 HTML pages
node build_research.js      # regenerate source register, reviews, matrix, video manifest
node audit_questions.js     # 380 questions, type mix, answer balance
node validate.js            # structure, links, keys, rubrics, resources, videos, HTML
node test_platform.js       # routes, quizzes, mobile, video, low bandwidth, axe
node test_code_samples.js   # run the concrete code samples in Chrome
node build_manifest.js      # SHA-256 manifest for every packaged file
node build_zip.js           # build and read back the release ZIP
```

`test_platform.js` requires the local server. The other Node checks read the package from disk. `validate.js` is standalone and can be run against an extracted copy by placing it beside the extracted package folder and running it there.

## 2. Static validation

Command: `node validate.js`

Result:

| Check | Count | Result |
|---|---|---|
| JSON files parsed | 39 | Pass |
| CSV files parsed with consistent columns | 6 | Pass |
| Learner lessons | 38 | Pass |
| Learner questions | 380 | Pass |
| Answer keys | 38 | Pass |
| Answer positions | A 95, B 95, C 95, D 95 | Pass |
| Question types | 152 applied, 114 problem, 76 best, 38 judgment | Pass |
| Correct-option length ratio | 1.03 | Pass |
| Assessment sheets | 38 | Pass |
| Rubrics | 38 | Pass |
| Platform Markdown | 38 | Pass |
| HTML pages | 40 | Pass |
| Sources | 66 | Pass |
| Resource reviews | 66 | Pass |
| Original resource reviews | 54 | Pass |
| Sufficiency matrix rows | 38 | Pass |
| Videos | 38 | Pass |
| Internal links | 172 | Pass |

Final static run: **0 errors, 1 expected warning** before the archive existed (“Final ZIP not built yet”). After the archive build, the warning is cleared and the archive is checked separately.

## 3. Question audit

Command: `node audit_questions.js`

Result:

```text
{
  total: 380,
  counts: { A: 95, B: 95, C: 95, D: 95 },
  types: { applied: 152, problem: 114, best: 76, judgment: 38 },
  problems: 0
}
```

Additional checks:

- 10 questions in every lesson;
- one best answer per question;
- four options per question;
- no duplicate stems;
- no duplicate option text within a question;
- every key has a correct letter, a `why`, a lesson reference and three distractor explanations;
- every distractor explanation is option-specific.

The length audit reports average correct option 14.0 words and average distractor 14.0 words.

## 4. Code samples

Command: `node audit_code.js` then `node test_code_samples.js`

- 35 fenced blocks found: 5 HTML, 7 CSS, 1 JavaScript, 22 non-code blocks (file trees, naming rules, checklists, token lists, rate arithmetic).
- 1 JavaScript syntax check: pass.
- 7 CSS blocks parsed in Chrome: pass.
- HTML tag balance: pass.
- No `document.write`, `XMLHttpRequest`, `eval`, unsafe `innerHTML` or password storage.
- The only clipboard block was inspected in detail because it is the riskiest sample.

Browser harness result:

| Check | Result |
|---|---|
| 5.0 successful copy message | Pass |
| 5.0 page errors | 0 |
| 5.0 live region | Pass |
| 5.0 rejected `writeText` fallback | Pass |
| 5.0 missing Clipboard API fallback | Pass |
| 5.4 offline indicator toggles | Pass |
| 7 CSS blocks parse | Pass (7/7) |
| 5.4 image `alt`, dimensions, `srcset`, `sizes` | Pass |
| **Total** | **14 / 14** |

## 5. Platform tests

Command: `node test_platform.js`

Result:

| Stage | Passed |
|---|---|
| Routes and assets | 40 / 40 |
| Quizzes | 38 / 38 |
| Mobile 320 px | 40 / 40 |
| Video component | Pass |
| Low bandwidth | Pass |
| axe WCAG 2.2 AA | 40 / 40, 0 violations |

Full detail: `09_Verification/PLATFORM_FUNCTIONAL_TEST_REPORT.md` and `09_Verification/ACCESSIBILITY_AUDIT.md`.

## 6. Video tests

Method: metadata fetch plus real-browser playback in the lesson embed.

| Check | Result |
|---|---|
| Watch pages HTTP 200 | 38 / 38 |
| Playability `OK` | 38 / 38 |
| Embedded playback (`readyState 4`, not paused, time advanced) | 38 / 38 |
| Direct watch-page content playback | 13 / 38 |
| Direct watch blocked by pre-roll ads | 8 / 38 |
| Direct watch not attempted | 17 / 38 |
| Nigeria listed in available countries | 38 / 38 |
| Nigeria playback actually tested | 0 / 38 |
| English captions listed | 38 / 38 |
| Caption accuracy reviewed | 0 / 38 |
| Full / partial / peripheral fit | 27 / 10 / 1 |

Full detail: `09_Verification/VIDEO_VERIFICATION_REPORT.md`.

## 7. Resource checks

Commands: `node audit_resources_node.js`, browser review, `node build_research.js`

| Check | Result |
|---|---|
| Unique current sources | 66 |
| HTTP 200 | 62 |
| HTTP 403 to scripted clients | 4 (W3C; readable in browser) |
| Original 54 reviewed | 54 |
| Kept / removed or replaced | 49 / 5 |
| Stops with at least one reading | 38 / 38 |
| Free to read | 66 / 66 |
| Paid subscription required | 0 |
| Sufficiency matrix | 38 rows × 20 columns |

Full detail: `09_Verification/RESOURCE_SUFFICIENCY_REPORT.md`.

## 8. Failures found during the build and their fixes

These are recorded because a clean final log should not hide the defects that were found.

| Date | Area | Failure | Fix | Re-test |
|---|---|---|---|---|
| 2026-10-30 | Video | YouTube **Error 153** in the embedded player | Set `referrerPolicy` before `src`; removed `loading="lazy"` from the click-created iframe | 38/38 embeds play |
| 2026-10-30 | Quizzes | Real mouse clicks on submit/reset were intermittently occluded; wait timed out | Used programmatic clicks for repeated reset/submit loops; separately verified real mouse clicks on a sample | 38/38 pass |
| 2026-10-30 | Answer keys | 4.4 Q2 keyed C but the explanation supported A | Corrected key to A | Browser 10/10 |
| 2026-10-30 | Answer keys | 4.6 Q7 keyed D but the explanation supported A | Corrected key to A | Browser 10/10 |
| 2026-10-30 | Questions | Three duplicate stems (6.2 Q4, 4.5 Q2, 5.3 Q1) | Rewrote stems | Duplicate check 0 |
| 2026-10-30 | Questions | Correct answers were longer than distractors | Rebalanced all 380 option sets | Ratio 1.03 |
| 2026-10-30 | Content | Stop 0.2 said 39 stops and 8 questions | Corrected to 38 and 10 | Text scan clean |
| 2026-10-30 | Content | A key explanation said seven phases | Corrected to eight | Text scan clean |
| 2026-10-30 | Accessibility | `scrollable-region-focusable` on long `<pre>` blocks | Added `tabindex="0"` and `aria-label` to code blocks | axe 0 |
| 2026-10-30 | Mobile | Tables forced 28–34 rem width and overflowed at 320 px | Removed `min-width`; added wrapping and labelled scroll region | 40/40 no overflow |
| 2026-10-30 | Mobile | Nav links were 23 px high | Added vertical padding | 0 small targets |
| 2026-10-30 | Accessibility | Skip link scrolled but did not move focus | Added `tabindex="-1"` to `main` | Focus lands on `main` |
| 2026-10-30 | Assets | Browser requested a missing favicon | Added `data:` favicon | 0 console errors |
| 2026-10-30 | Validation | Validator flagged `data:,` favicon as a broken link | Excluded `data:` URLs from local-link checks | 0 errors |
| 2026-10-30 | Validation | Placeholder-text check flagged a legitimate use of "placeholder text" | Narrowed the rule to genuine unfinished copy | 0 errors |

## 9. Earlier v1 failures corrected in this release

The v1 package had already recorded several defects; this release fixed them and re-tested:

- Stop 0.1 required email addresses and treated an AI account as mandatory; replaced with a privacy-safe, no-AI-capable route.
- Stop 5.0's clipboard example claimed a copy without checking or handling failure; replaced with a real asynchronous copy and fallback.
- The quiz was eight questions with a 7/8 rule; replaced with ten questions and 8/10.
- Keys had generic distractor reasons; every key line was rewritten.
- Rubrics used templated descriptors; replaced with criterion-specific, level-specific descriptors.
- Videos were marked "not playback-tested"; all 38 were tested in the embed and the status text was updated.

## 10. Not tested

1. Playback from a Nigerian network or any specific region. Metadata lists Nigeria for all 38, but that is not a playback test.
2. Caption accuracy. English tracks are listed for all 38; no transcript or line-by-line review was completed because YouTube transcript endpoints returned empty or `FAILED_PRECONDITION`.
3. Direct watch-page playback for 25 videos: 8 were ad-blocked and 17 were not attempted. Embedded playback covers all 38.
4. A live beginner cohort, learning gain, completion rate or time-on-task.
5. Screen readers and disabled learners. No NVDA, JAWS, VoiceOver or TalkBack run.
6. Firefox, Safari, Edge, Samsung Internet, real Android or iOS devices.
7. Deployment to GitHub Pages or Netlify Drop. The files are static and deployment-ready; no upload was performed.
8. A backend, account system, LMS, SCORM or xAPI integration. None exists.
9. The Web Crypto fallback state was code-reviewed but not triggered in a browser.
10. Windows High Contrast / `forced-colors`, print layout and 200% browser zoom as separate manual checks (320 px reflow and text-size controls were tested).

## 11. Archive verification

The release archive is written with forward-slash paths, UTF-8 name flags, CRC32 per file and deflate compression. The writer reads back the central directory and asserts the entry count. The archive is then extracted into a clean directory; the extracted package is checked with `validate.js` and its HTML is served on a separate port for a route and quiz smoke test.

Tested build result: 315 entries, 0 backslash paths, 315 UTF-8 name flags, extracted to 315 files in 31 directories. The extracted copy passed `validate.js` with **0 errors and 0 warnings** when the archive was placed beside it. Its 40 HTML routes returned HTTP 200, Stop 0.1 scored 10/10, and the video component created the correct privacy-enhanced iframe.

The archive SHA-256 is published in the `.sha256` sidecar next to the ZIP because the archive cannot contain its own hash.

The final archive results are also recorded in `09_Verification/RELEASE_READINESS_REPORT.md`, Section 6.

## 12. Sign-off

**Verified by:** automated build and browser test harness, plus manual review of every report's claims against its evidence.
**Not signed off by:** an independent auditor, a disabled-user panel, a beginner cohort or a regional playback test in Nigeria.

The package is ready for release with the limitations above. Any statement that it is “fully tested” or “accessible to all” would exceed this log.
