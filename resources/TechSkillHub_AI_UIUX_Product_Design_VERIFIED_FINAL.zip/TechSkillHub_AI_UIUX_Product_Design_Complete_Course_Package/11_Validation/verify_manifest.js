const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const PKG = process.argv[2] ? path.resolve(process.argv[2]) : path.resolve(__dirname, '..');
const manifestPath = path.join(PKG, '10_Audit', 'FILE_MANIFEST_SHA256.txt');
const lines = fs.readFileSync(manifestPath, 'utf8').split(/\r?\n/).filter(l => /^[a-f0-9]{64}  /.test(l));
let ok = 0, bad = 0, missing = 0;
for (const line of lines) {
  const hash = line.slice(0, 64);
  const rel = line.slice(66);
  const abs = path.join(PKG, rel.split('/').join(path.sep));
  if (!fs.existsSync(abs)) { missing++; console.log('MISSING', rel); continue; }
  const got = crypto.createHash('sha256').update(fs.readFileSync(abs)).digest('hex');
  if (got === hash) ok++; else { bad++; console.log('HASH MISMATCH', rel); }
}
const all = [];
(function walk(d) { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isDirectory()) walk(p); else all.push(path.relative(PKG, p).replace(/\\/g, '/')); } })(PKG);
const extra = all.filter(f => f !== '10_Audit/FILE_MANIFEST_SHA256.txt' && !lines.some(l => l.slice(66) === f));
console.log(JSON.stringify({ entries: lines.length, ok, bad, missing, unlisted: extra.length, totalFiles: all.length }, null, 2));
if (bad || missing || extra.length) process.exitCode = 1;
