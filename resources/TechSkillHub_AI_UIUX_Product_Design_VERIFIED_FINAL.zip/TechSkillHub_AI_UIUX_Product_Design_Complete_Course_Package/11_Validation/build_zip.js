// Standards-compliant ZIP writer: forward-slash entry names, UTF-8, deflate.
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');

const PKG = path.resolve(__dirname, '..');
const OUT = path.join(PKG, '..', 'TechSkillHub_AI_UIUX_Product_Design_VERIFIED_FINAL.zip');

function walk(dir, base = dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, base, out);
    else if (e.isFile() && !/\.zip$/i.test(e.name)) out.push(path.relative(base, p).replace(/\\/g, '/'));
  }
  return out;
}
const names = walk(PKG).map(n => path.basename(PKG) + '/' + n).sort((a, b) => a.localeCompare(b));
if (names.length < 300) throw new Error('Unexpectedly few files: ' + names.length);

const CRC_TABLE = new Uint32Array(256);
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
  CRC_TABLE[n] = c >>> 0;
}
function crc32(buf) {
  let c = 0xFFFFFFFF;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xFF] ^ (c >>> 8);
  return (c ^ 0xFFFFFFFF) >>> 0;
}
function dosTime(d) {
  return ((d.getHours() & 31) << 11) | ((d.getMinutes() & 63) << 5) | (Math.floor(d.getSeconds() / 2) & 31);
}
function dosDate(d) {
  return (((d.getFullYear() - 1980) & 127) << 9) | (((d.getMonth() + 1) & 15) << 5) | (d.getDate() & 31);
}

const fixed = new Date(Date.UTC(2026, 9, 30, 12, 0, 0));
const time = dosTime(fixed);
const date = dosDate(fixed);
const chunks = [];
const central = [];
let offset = 0;

for (const name of names) {
  const rel = name.slice(name.indexOf('/') + 1);
  const abs = path.join(PKG, rel.split('/').join(path.sep));
  const data = fs.readFileSync(abs);
  const crc = crc32(data);
  const deflated = zlib.deflateRawSync(data, { level: 9 });
  const useDeflate = deflated.length < data.length;
  const body = useDeflate ? deflated : data;
  const method = useDeflate ? 8 : 0;
  const nameBuf = Buffer.from(name, 'utf8');

  const local = Buffer.alloc(30);
  local.writeUInt32LE(0x04034b50, 0);
  local.writeUInt16LE(20, 4);
  local.writeUInt16LE(0x0800, 6);
  local.writeUInt16LE(method, 8);
  local.writeUInt16LE(time, 10);
  local.writeUInt16LE(date, 12);
  local.writeUInt32LE(crc, 14);
  local.writeUInt32LE(body.length, 18);
  local.writeUInt32LE(data.length, 22);
  local.writeUInt16LE(nameBuf.length, 26);
  local.writeUInt16LE(0, 28);
  chunks.push(local, nameBuf, body);

  const cen = Buffer.alloc(46);
  cen.writeUInt32LE(0x02014b50, 0);
  cen.writeUInt16LE(20, 4);
  cen.writeUInt16LE(20, 6);
  cen.writeUInt16LE(0x0800, 8);
  cen.writeUInt16LE(method, 10);
  cen.writeUInt16LE(time, 12);
  cen.writeUInt16LE(date, 14);
  cen.writeUInt32LE(crc, 16);
  cen.writeUInt32LE(body.length, 20);
  cen.writeUInt32LE(data.length, 24);
  cen.writeUInt16LE(nameBuf.length, 28);
  cen.writeUInt16LE(0, 30);
  cen.writeUInt16LE(0, 32);
  cen.writeUInt16LE(0, 34);
  cen.writeUInt16LE(0, 36);
  cen.writeUInt32LE((0o100644 << 16) >>> 0, 38);
  cen.writeUInt32LE(offset, 42);
  central.push(cen, nameBuf);

  offset += local.length + nameBuf.length + body.length;
}

const centralBuf = Buffer.concat(central);
const end = Buffer.alloc(22);
end.writeUInt32LE(0x06054b50, 0);
end.writeUInt16LE(0, 4);
end.writeUInt16LE(0, 6);
end.writeUInt16LE(names.length, 8);
end.writeUInt16LE(names.length, 10);
end.writeUInt32LE(centralBuf.length, 12);
end.writeUInt32LE(offset, 16);
end.writeUInt16LE(0, 20);

fs.writeFileSync(OUT, Buffer.concat([...chunks, centralBuf, end]));
const stat = fs.statSync(OUT);
const sha = crypto.createHash('sha256').update(fs.readFileSync(OUT)).digest('hex');

// read-back verification
const buf = fs.readFileSync(OUT);
let entries = 0, backslash = 0, utf8 = 0;
for (let i = 0; i < buf.length - 4; i++) {
  if (buf.readUInt32LE(i) === 0x02014b50) {
    const flags = buf.readUInt16LE(i + 8);
    const nameLen = buf.readUInt16LE(i + 28);
    const name = buf.slice(i + 46, i + 46 + nameLen).toString('utf8');
    entries++;
    if (name.includes('\\')) backslash++;
    if (flags & 0x0800) utf8++;
  }
}
console.log(JSON.stringify({ out: OUT, entries, expected: names.length, backslash, utf8Flagged: utf8, bytes: stat.size, sha256: sha }, null, 2));
if (entries !== names.length) throw new Error('Central directory entry count mismatch');
if (backslash) throw new Error('Backslash paths found');
