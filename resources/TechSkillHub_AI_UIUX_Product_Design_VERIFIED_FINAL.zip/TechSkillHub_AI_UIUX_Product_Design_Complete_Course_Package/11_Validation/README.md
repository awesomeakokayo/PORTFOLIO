# Validation Toolkit

This folder contains the scripts used to validate the package. They are included so a maintainer can reproduce the checks instead of trusting this release's reports.

## Requirements

- Node.js 20 or newer.
- For `validate.js`, `verify_manifest.js` and `build_zip.js`: no third-party packages.
- For `test_platform.js`: Google Chrome, plus `puppeteer-core` and `axe-core` (see `package.json`).

## Quick start

From the package root:

```text
node 11_Validation/validate.js
```

Expected final lines:

```text
ERRORS 0
WARNINGS 0
```

If the release ZIP is not beside the package folder, the validator prints one warning that the archive is absent. That warning is about the archive location, not the package content.

Verify every file against the SHA-256 manifest:

```text
node 11_Validation/verify_manifest.js
```

Expected:

```json
{ "entries": 314, "ok": 314, "bad": 0, "missing": 0, "unlisted": 0, "totalFiles": 315 }
```

The exact counts depend on whether the archive and this toolkit are included; the important values are `bad: 0`, `missing: 0` and `unlisted: 0`.

Rebuild the release archive:

```text
node 11_Validation/build_zip.js
```

This writes `TechSkillHub_AI_UIUX_Product_Design_VERIFIED_FINAL.zip` beside the package folder, using forward-slash paths, UTF-8 name flags, CRC32 and a central-directory read-back check. It does not include `.zip` files inside the package.

## Browser test

The browser test needs the package served over HTTP. From `05_Platform_Ready/HTML`:

```text
python -m http.server 8765 --bind 127.0.0.1
```

In another terminal, from `11_Validation`:

```text
npm install
set BASE_URL=http://127.0.0.1:8765/
node test_platform.js
```

On macOS or Linux use `BASE_URL=... node test_platform.js`. If Chrome is not at the default Windows path, set `CHROME_PATH`.

The test writes its JSON evidence to the operating system's temporary directory as `tsh-platform-test-results.json`. It does not write into the package.

It checks:

- 40 HTML routes, local assets, console errors, headings, landmarks and language;
- all 38 quizzes: unanswered block, 10/10 pass, reset, 0/10 fail;
- 320 px layout and touch-target size;
- the video component's iframe URL, referrer policy and lazy-loading state;
- the low-bandwidth route with YouTube blocked;
- axe-core WCAG 2.2 AA on every page.

Expected summary:

```json
{
  "routes": 40, "routesPassed": 40,
  "quizzes": 38, "quizzesPassed": 38,
  "mobilePages": 40, "mobilePassed": 40,
  "videoComponentPassed": true,
  "lowBandwidthPassed": true,
  "axePages": 40, "axePassed": 40,
  "axeViolationTypes": [], "axeViolationNodes": 0
}
```

## What `validate.js` checks

- all JSON files parse;
- all CSV files have consistent columns;
- 38 lessons and 15 required sections each;
- 380 questions, 10 per stop;
- the 4/3/2/1 type mix;
- correct-answer balance A–D;
- answer keys: correct letter, why, lesson reference and three distractor explanations;
- 38 rubrics with four criteria and four levels;
- 38 assessment sheets, 38 platform Markdown files and 40 HTML pages;
- 66 sources, 66 resource reviews, 54 original reviews and 38 sufficiency rows;
- 38 video rows;
- internal links and local HTML assets;
- Stop 0.1 privacy and no-AI wording;
- Stop 5.0 clipboard error handling;
- optional ZIP path and entry-name portability.

## What `test_platform.js` does not test

- Firefox, Safari, real phones or screen readers;
- playback from Nigeria or any specific region;
- deployed URLs;
- learning outcomes.

Those gaps are described in `09_Verification/`.
