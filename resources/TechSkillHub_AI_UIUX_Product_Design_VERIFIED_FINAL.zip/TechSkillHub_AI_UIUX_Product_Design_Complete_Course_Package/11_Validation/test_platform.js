// Real-browser platform test, split into isolated stages so one crashed renderer
// cannot invalidate the rest. Writes platform_test_results.json after every record.
const fs = require('fs');
const path = require('path');
const puppeteer = require('puppeteer-core');
const axeSource = require('axe-core').source;

const CHROME = process.env.CHROME_PATH || 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const BASE = process.env.BASE_URL || 'http://127.0.0.1:8765/';
const OUT = path.join(require('os').tmpdir(), 'tsh-platform-test-results.json');
const HTML = path.join(__dirname, '..', '05_Platform_Ready', 'HTML');

const lessons = fs.readdirSync(path.join(HTML, 'lessons'))
  .filter(f => /^stop-[\d.]+\.html$/.test(f))
  .sort((a, b) => Number(a.match(/stop-([\d.]+)/)[1]) - Number(b.match(/stop-([\d.]+)/)[1]))
  .map(f => 'lessons/' + f);
const routes = ['index.html', 'sample_lesson_page.html', ...lessons];

const results = {
  generated: new Date().toISOString(),
  base: BASE,
  routes,
  routeResults: [],
  quizResults: [],
  mobileResults: [],
  axeResults: [],
  videoComponent: null,
  lowBandwidth: null,
  summary: {}
};
function save() { fs.writeFileSync(OUT, JSON.stringify(results, null, 2), 'utf8'); }
const sleep = ms => new Promise(r => setTimeout(r, ms));

if (process.env.STAGES && fs.existsSync(OUT)) {
  try {
    const prior = JSON.parse(fs.readFileSync(OUT, 'utf8'));
    for (const k of ['routeResults', 'quizResults', 'mobileResults', 'axeResults']) {
      if (Array.isArray(prior[k])) results[k] = prior[k];
    }
    if (prior.videoComponent) results.videoComponent = prior.videoComponent;
    if (prior.lowBandwidth) results.lowBandwidth = prior.lowBandwidth;
  } catch (_) {}
}

async function launch() {
  return puppeteer.launch({
    executablePath: CHROME,
    headless: true,
    protocolTimeout: 180000,
    args: ['--no-sandbox', '--disable-dev-shm-usage', '--disable-gpu', '--disable-extensions', '--no-first-run', '--lang=en-US']
  });
}

async function goto(page, route) {
  const errors = [];
  const bad = [];
  const onConsole = m => {
    if (m.type() !== 'error') return;
    const t = m.text();
    if (/favicon/i.test(t)) return;
    errors.push('console: ' + t);
  };
  const onPageError = e => errors.push('pageerror: ' + e.message);
  const onResponse = r => {
    if (r.url().startsWith(BASE) && r.status() >= 400 && !/favicon/i.test(r.url())) bad.push(r.status() + ' ' + r.url());
  };
  page.on('console', onConsole);
  page.on('pageerror', onPageError);
  page.on('response', onResponse);
  const resp = await page.goto(BASE + route, { waitUntil: 'domcontentloaded', timeout: 30000 });
  await sleep(200);
  page.off('console', onConsole);
  page.off('pageerror', onPageError);
  page.off('response', onResponse);
  return { status: resp ? resp.status() : null, errors, badAssets: bad };
}

async function routeInfo(page) {
  return page.evaluate(() => {
    const nav = document.querySelector('nav[aria-label="Course"]');
    return {
      title: document.title,
      lang: document.documentElement.lang,
      h1: [...document.querySelectorAll('h1')].map(h => h.textContent.trim()),
      skip: !!document.querySelector('a.skip'),
      main: !!document.querySelector('main#main'),
      navLinks: nav ? nav.querySelectorAll('a').length : 0,
      links: document.querySelectorAll('a[href]').length,
      script: !!document.querySelector('script[src$="app.js"]'),
      textLength: document.body.innerText.replace(/\s+/g, ' ').trim().length,
      quizFields: document.querySelectorAll('fieldset[data-q]').length,
      videoComponents: document.querySelectorAll('video-embed').length
    };
  });
}

function hashAnswers(page, fields, salt) {
  return page.evaluate(async (fields, salt) => {
    const hex = async t => {
      const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(t));
      return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
    };
    const out = {};
    for (const f of fields) {
      for (const L of ['A', 'B', 'C', 'D']) {
        if (f.hash.split('|').includes(await hex(f.q + ':' + L + ':' + salt))) { out[f.q] = L; break; }
      }
    }
    return out;
  }, fields, salt);
}

// ---------- stage 1: routes and assets ----------
async function stageRoutes(browser) {
  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 900 });
  for (const route of routes) {
    const rec = { route, lesson: route.startsWith('lessons/') };
    try {
      const load = await goto(page, route);
      const info = await routeInfo(page);
      Object.assign(rec, load, info);
      rec.ok = rec.status === 200 && rec.errors.length === 0 && rec.badAssets.length === 0 &&
        rec.h1.length === 1 && rec.skip && rec.main && rec.script && rec.lang === 'en' &&
        (!rec.lesson || (rec.quizFields === 10 && rec.videoComponents === 1));
      console.log('ROUTE', rec.ok ? 'PASS' : 'FAIL', route, rec.status,
        rec.errors.length + ' errors', rec.badAssets.length + ' bad assets');
    } catch (e) {
      rec.ok = false;
      rec.error = e.name + ': ' + e.message;
      console.log('ROUTE ERROR', route, e.message);
    }
    results.routeResults.push(rec);
    save();
  }
  await page.close();
}

// ---------- stage 2: quiz behaviour ----------
async function stageQuizzes(browser) {
  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 900 });
  for (const route of lessons) {
    const rec = { route, stop: (route.match(/stop-([\d.]+)/) || [])[1] };
    try {
      await goto(page, route);
      const setup = await page.evaluate(() => {
        const form = document.querySelector('form.quiz-form');
        return {
          salt: form.getAttribute('data-salt'),
          fields: [...document.querySelectorAll('fieldset[data-q]')].map(fs => ({
            q: fs.getAttribute('data-q'), hash: fs.getAttribute('data-hash')
          }))
        };
      });
      rec.fields = setup.fields.length;
      const correct = await hashAnswers(page, setup.fields, setup.salt);
      rec.correctFound = Object.keys(correct).length;

      await page.click('.quiz-submit');
      await sleep(150);
      rec.unanswered = await page.evaluate(() => ({
        alertHidden: document.getElementById('quiz-alert').hidden,
        alertText: document.getElementById('quiz-alert').textContent,
        resultHidden: document.getElementById('quiz-result').hidden,
        marked: document.querySelectorAll('fieldset.unanswered').length,
        focused: document.activeElement ? document.activeElement.name : ''
      }));

      for (const f of setup.fields) {
        await page.evaluate((q, L) => {
          const el = document.querySelector('fieldset[data-q="' + q + '"] input[value="' + L + '"]');
          if (el) el.click();
        }, f.q, correct[f.q]);
      }
      rec.checkedBeforePass = await page.evaluate(() => document.querySelectorAll('input:checked').length);
      await page.evaluate(() => document.querySelector('.quiz-submit').click());
      await page.waitForFunction(() => !document.getElementById('quiz-result').hidden, { timeout: 15000 });
      rec.allCorrect = await page.evaluate(() => ({
        text: document.getElementById('quiz-result').innerText,
        className: document.getElementById('quiz-result').className,
        correctMarks: document.querySelectorAll('fieldset.correct').length,
        incorrectMarks: document.querySelectorAll('fieldset.incorrect').length
      }));

      await page.evaluate(() => document.querySelector('.quiz-reset').click());
      await sleep(150);
      rec.reset = await page.evaluate(() => ({
        checked: document.querySelectorAll('input:checked').length,
        resultHidden: document.getElementById('quiz-result').hidden,
        marked: document.querySelectorAll('fieldset.correct, fieldset.incorrect, fieldset.unanswered').length,
        feedbackVisible: [...document.querySelectorAll('.q-feedback')].filter(p => !p.hidden).length
      }));

      for (const f of setup.fields) {
        const wrong = ['A', 'B', 'C', 'D'].find(L => L !== correct[f.q]);
        await page.evaluate((q, L) => {
          const el = document.querySelector('fieldset[data-q="' + q + '"] input[value="' + L + '"]');
          if (el) el.click();
        }, f.q, wrong);
      }
      await page.evaluate(() => document.querySelector('.quiz-submit').click());
      await page.waitForFunction(() => !document.getElementById('quiz-result').hidden, { timeout: 15000 });
      rec.allWrong = await page.evaluate(() => ({
        text: document.getElementById('quiz-result').innerText,
        className: document.getElementById('quiz-result').className,
        incorrectMarks: document.querySelectorAll('fieldset.incorrect').length,
        listed: document.querySelectorAll('#quiz-result li').length
      }));

      rec.ok = rec.fields === 10 && rec.correctFound === 10 &&
        rec.unanswered.alertHidden === false && rec.unanswered.resultHidden === true && rec.unanswered.marked === 10 &&
        /Score: 10\/10 \(100%\)\. Pass\./.test(rec.allCorrect.text) &&
        rec.allCorrect.correctMarks === 10 && rec.allCorrect.incorrectMarks === 0 &&
        rec.reset.checked === 0 && rec.reset.resultHidden === true && rec.reset.marked === 0 && rec.reset.feedbackVisible === 0 &&
        /Score: 0\/10 \(0%\)\. Not yet/.test(rec.allWrong.text) &&
        rec.allWrong.incorrectMarks === 10 && rec.allWrong.listed === 10;
      console.log('QUIZ', rec.ok ? 'PASS' : 'FAIL', route,
        JSON.stringify({ found: rec.correctFound, pass: rec.allCorrect.className, fail: rec.allWrong.className }));
    } catch (e) {
      rec.ok = false;
      rec.error = e.name + ': ' + e.message;
      console.log('QUIZ ERROR', route, e.message);
      try { await page.goto('about:blank'); } catch (_) {}
    }
    results.quizResults.push(rec);
    save();
  }
  await page.close();
}

// ---------- stage 3: mobile 320 px ----------
async function stageMobile(browser) {
  const page = await browser.newPage();
  await page.setViewport({ width: 320, height: 640 });
  for (const route of routes) {
    const rec = { route };
    try {
      await goto(page, route);
      rec.layout = await page.evaluate(() => {
        const vw = window.innerWidth;
        const hasScrollableAncestor = el => {
          let p = el.parentElement;
          while (p && p !== document.documentElement) {
            const s = getComputedStyle(p);
            if (/auto|scroll|hidden|clip/.test(s.overflowX)) return true;
            p = p.parentElement;
          }
          return false;
        };
        const overflow = [...document.querySelectorAll('body *')].filter(el => {
          const s = getComputedStyle(el);
          if (s.display === 'none' || s.visibility === 'hidden' || s.position === 'fixed') return false;
          if (el.classList.contains('skip')) return false;
          const r = el.getBoundingClientRect();
          return r.width > 0 && (r.right > vw + 1 || r.left < -1) && !hasScrollableAncestor(el);
        }).slice(0, 12).map(el => ({
          tag: el.tagName.toLowerCase(),
          cls: String(el.className || '').slice(0, 60),
          right: Math.round(el.getBoundingClientRect().right),
          width: Math.round(el.getBoundingClientRect().width)
        }));
        const targets = [...document.querySelectorAll('a[href], button, summary, label')].filter(el => {
          const r = el.getBoundingClientRect();
          return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== 'hidden';
        });
        const small = targets.filter(el => {
          const r = el.getBoundingClientRect();
          const inline = el.tagName === 'A' && getComputedStyle(el).display === 'inline';
          return !inline && (r.width < 24 || r.height < 24);
        });
        return {
          innerWidth: vw,
          scrollWidth: document.documentElement.scrollWidth,
          bodyScrollWidth: document.body.scrollWidth,
          overflow,
          targetCount: targets.length,
          smallTargets: small.slice(0, 12).map(el => ({
            tag: el.tagName.toLowerCase(),
            text: (el.textContent || '').trim().slice(0, 40),
            w: Math.round(el.getBoundingClientRect().width),
            h: Math.round(el.getBoundingClientRect().height)
          }))
        };
      });
      const toggle = await page.$('[data-text-size="large"]');
      rec.hasTextToggle = !!toggle;
      if (toggle) {
        await toggle.click();
        await sleep(80);
        rec.largeText = await page.evaluate(() => document.body.classList.contains('large-text'));
        rec.storedPreference = await page.evaluate(() => localStorage.getItem('tsh-text-size'));
        await page.click('[data-text-size="normal"]');
        await sleep(60);
        rec.normalText = await page.evaluate(() => !document.body.classList.contains('large-text'));
      }
      rec.ok = rec.layout.overflow.length === 0 && rec.layout.scrollWidth <= 321 &&
        (!rec.hasTextToggle || (rec.largeText === true && rec.normalText === true && rec.storedPreference === 'large'));
      console.log('MOBILE', rec.ok ? 'PASS' : 'FAIL', route,
        'overflow', rec.layout.overflow.length, 'small', rec.layout.smallTargets.length);
    } catch (e) {
      rec.ok = false;
      rec.error = e.name + ': ' + e.message;
      console.log('MOBILE ERROR', route, e.message);
      try { await page.goto('about:blank'); } catch (_) {}
    }
    results.mobileResults.push(rec);
    save();
  }
  await page.close();
}

// ---------- stage 4: video component and low-bandwidth ----------
async function stageVideo(browser) {
  {
    const page = await browser.newPage();
    await page.setViewport({ width: 1280, height: 900 });
    const rec = { route: 'lessons/stop-4.6.html' };
    try {
      await goto(page, rec.route);
      rec.before = await page.evaluate(() => ({
        iframes: document.querySelectorAll('iframe').length,
        button: !!document.querySelector('video-embed .play'),
        altLink: !!document.querySelector('video-embed .video-alt a')
      }));
      await page.click('video-embed .play');
      await sleep(500);
      rec.after = await page.evaluate(() => {
        const f = document.querySelector('video-embed iframe');
        return f ? {
          src: f.getAttribute('src'),
          title: f.getAttribute('title'),
          referrerPolicy: f.getAttribute('referrerpolicy'),
          loading: f.getAttribute('loading'),
          allow: f.getAttribute('allow')
        } : null;
      });
      rec.ok = rec.before.iframes === 0 && rec.before.button && rec.before.altLink &&
        !!rec.after && /^https:\/\/www\.youtube-nocookie\.com\/embed\/[A-Za-z0-9_-]+\?rel=0&hl=en$/.test(rec.after.src) &&
        rec.after.referrerPolicy === 'strict-origin-when-cross-origin' && rec.after.loading === null;
      console.log('VIDEO COMPONENT', rec.ok ? 'PASS' : 'FAIL', rec.after && rec.after.src);
    } catch (e) {
      rec.ok = false;
      rec.error = e.name + ': ' + e.message;
    }
    results.videoComponent = rec;
    save();
    await page.close();
  }

  {
    const page = await browser.newPage();
    await page.setViewport({ width: 320, height: 640 });
    const rec = { route: 'lessons/stop-0.1.html' };
    try {
      await page.setRequestInterception(true);
      page.on('request', req => {
        if (/youtube|ytimg|googlevideo|doubleclick|googleads/.test(req.url())) req.abort();
        else req.continue();
      });
      const resp = await page.goto(BASE + rec.route, { waitUntil: 'domcontentloaded', timeout: 30000 });
      await sleep(250);
      rec.status = resp.status();
      rec.content = await page.evaluate(() => ({
        textLength: document.body.innerText.replace(/\s+/g, ' ').trim().length,
        quizFields: document.querySelectorAll('fieldset[data-q]').length,
        videoPoster: !!document.querySelector('video-embed .play'),
        loadedIframes: document.querySelectorAll('iframe').length,
        h1: document.querySelector('h1') ? document.querySelector('h1').textContent.trim() : '',
        horizontalOverflow: document.documentElement.scrollWidth > window.innerWidth + 1
      }));
      const salt = await page.$eval('form.quiz-form', f => f.getAttribute('data-salt'));
      const fields = await page.$$eval('fieldset[data-q]', els => els.map(fs => ({ q: fs.getAttribute('data-q'), hash: fs.getAttribute('data-hash') })));
      const correct = await hashAnswers(page, fields, salt);
      for (const f of fields) {
        await page.evaluate((q, L) => document.querySelector('fieldset[data-q="' + q + '"] input[value="' + L + '"]').click(), f.q, correct[f.q]);
      }
      await page.click('.quiz-submit');
      await page.waitForFunction(() => !document.getElementById('quiz-result').hidden, { timeout: 15000 });
      rec.quizText = await page.$eval('#quiz-result', el => el.innerText);
      rec.ok = rec.status === 200 && rec.content.quizFields === 10 && rec.content.videoPoster &&
        rec.content.loadedIframes === 0 && rec.content.horizontalOverflow === false && /10\/10/.test(rec.quizText);
      console.log('LOW BANDWIDTH', rec.ok ? 'PASS' : 'FAIL', JSON.stringify(rec.content));
    } catch (e) {
      rec.ok = false;
      rec.error = e.name + ': ' + e.message;
    }
    results.lowBandwidth = rec;
    save();
    await page.close();
  }
}

// ---------- stage 5: axe WCAG 2.2 AA ----------
async function stageAxe(browser) {
  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 900 });
  for (const route of routes) {
    const rec = { route };
    try {
      await goto(page, route);
      await page.addScriptTag({ content: axeSource });
      const axe = await page.evaluate(async () => {
        const r = await window.axe.run(document, {
          runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22aa'] }
        });
        return {
          violations: r.violations.map(v => ({
            id: v.id, impact: v.impact, help: v.help, nodes: v.nodes.length,
            targets: v.nodes.slice(0, 5).map(n => n.target.join(' '))
          })),
          passes: r.passes.length
        };
      });
      rec.violations = axe.violations;
      rec.totalNodes = axe.violations.reduce((a, v) => a + v.nodes, 0);
      rec.ok = axe.violations.length === 0;
      console.log('AXE', rec.ok ? 'PASS' : 'FAIL', route, axe.violations.map(v => v.id + ':' + v.nodes).join(','));
    } catch (e) {
      rec.ok = false;
      rec.error = e.name + ': ' + e.message;
      console.log('AXE ERROR', route, e.message);
      try { await page.goto('about:blank'); } catch (_) {}
    }
    results.axeResults.push(rec);
    save();
  }
  await page.close();
}

(async () => {
  const stages = [
    ['routes', stageRoutes],
    ['quizzes', stageQuizzes],
    ['mobile', stageMobile],
    ['video', stageVideo],
    ['axe', stageAxe]
  ];
  const only = process.env.STAGES ? process.env.STAGES.split(',').map(s => s.trim()) : null;
  for (const [name, fn] of stages) {
    if (only && !only.includes(name)) continue;
    if (name === 'routes') results.routeResults = [];
    if (name === 'quizzes') results.quizResults = [];
    if (name === 'mobile') results.mobileResults = [];
    if (name === 'axe') results.axeResults = [];
    let browser;
    try {
      browser = await launch();
      console.log('--- stage', name, '---');
      await fn(browser);
    } catch (e) {
      console.log('STAGE FAILED', name, e.name + ': ' + e.message);
    } finally {
      if (browser) { try { await browser.close(); } catch (_) {} }
    }
    save();
  }
  const count = (arr, f) => arr.filter(f).length;
  results.generated = new Date().toISOString();
  results.summary = {
    routes: routes.length,
    routesPassed: count(results.routeResults, r => r.ok),
    quizzes: results.quizResults.length,
    quizzesPassed: count(results.quizResults, r => r.ok),
    mobilePages: results.mobileResults.length,
    mobilePassed: count(results.mobileResults, r => r.ok),
    videoComponentPassed: !!(results.videoComponent && results.videoComponent.ok),
    lowBandwidthPassed: !!(results.lowBandwidth && results.lowBandwidth.ok),
    axePages: results.axeResults.length,
    axePassed: count(results.axeResults, r => r.ok),
    axeViolationTypes: [...new Set(results.axeResults.flatMap(r => (r.violations || []).map(v => v.id)))],
    axeViolationNodes: results.axeResults.reduce((a, r) => a + (r.totalNodes || 0), 0)
  };
  save();
  console.log(JSON.stringify(results.summary, null, 2));
})().catch(e => {
  console.error(e);
  save();
  process.exit(1);
});
