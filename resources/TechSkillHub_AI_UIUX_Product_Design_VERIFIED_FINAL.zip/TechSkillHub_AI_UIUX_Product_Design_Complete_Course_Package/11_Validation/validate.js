const fs = require('fs');
const path = require('path');
const PKG = path.resolve(__dirname, '..');

function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out); else out.push(p);
  }
  return out;
}
const files = walk(PKG);
const rel = p => path.relative(PKG, p).replace(/\\/g, '/');
const errors = [];
const warnings = [];
const stats = {};
const read = p => fs.readFileSync(p, 'utf8');
function err(m) { errors.push(m); }
function warn(m) { warnings.push(m); }

function parseCsv(text) {
  const rows = []; let row = [], cur = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) {
      if (c === '"' && text[i + 1] === '"') { cur += '"'; i++; }
      else if (c === '"') q = false;
      else cur += c;
    } else {
      if (c === '"') q = true;
      else if (c === ',') { row.push(cur); cur = ''; }
      else if (c === '\n') { row.push(cur); cur = ''; rows.push(row); row = []; }
      else if (c !== '\r') cur += c;
    }
  }
  if (cur || row.length) { row.push(cur); rows.push(row); }
  return rows;
}
function csv(p) { return parseCsv(read(p)); }

// 1 JSON
const jsons = files.filter(f => f.endsWith('.json'));
for (const f of jsons) {
  try { JSON.parse(read(f)); } catch (e) { err('JSON parse: ' + rel(f) + ' :: ' + e.message); }
}
stats.json = jsons.length;

// 2 CSV width
const csvs = files.filter(f => f.endsWith('.csv'));
for (const f of csvs) {
  const rows = csv(f);
  const width = rows[0].length;
  rows.forEach((r, i) => { if (r.length !== width) err(`CSV width: ${rel(f)} row ${i + 1} has ${r.length}, expected ${width}`); });
}
stats.csv = csvs.length;

// 3 learner lessons
const learnerDir = path.join(PKG, '02_Learner_Content');
const lessonFiles = walk(learnerDir).filter(f => f.endsWith('.md'));
stats.lessons = lessonFiles.length;
if (lessonFiles.length !== 38) err('Learner lessons: expected 38, found ' + lessonFiles.length);
const stopIds = new Set();
let questionTotal = 0;
for (const f of lessonFiles) {
  const s = read(f);
  const m = s.match(/stop_id:\s*([\d.]+)/);
  if (!m) err('No stop_id in ' + rel(f)); else stopIds.add(m[1]);
  const q = (s.match(/\*\*Q\d+\.\*\*/g) || []).length;
  questionTotal += q;
  if (q !== 10) err(`Questions ${q} in ${rel(f)}`);
  if (/<!--\s*key:/i.test(s)) err('Hidden key leaked: ' + rel(f));
  if (/Correct answer:/i.test(s)) err('Answer text leaked: ' + rel(f));
  for (const sec of ['What you will be able to do', 'New words in plain English', 'Why this matters', 'Teaching, step by step', 'Worked example', 'We do it together', 'Your turn', 'Comprehension check', 'Practical task', 'Common mistakes', 'Proof artifact', 'Low-data', 'Watch and read more', 'What comes next']) {
    if (!s.includes(sec)) err(`Missing section "${sec}" in ${rel(f)}`);
  }
}
stats.learnerQuestions = questionTotal;
if (questionTotal !== 380) err('Learner questions: expected 380, found ' + questionTotal);
if (stopIds.size !== 38) err('Unique stop IDs: ' + stopIds.size);

// 4 answer keys
const keyDir = path.join(PKG, '04_Instructor_Only', 'Answer_Keys', 'Stop_Answer_Keys');
const keyFiles = fs.readdirSync(keyDir).filter(f => f.endsWith('.md'));
stats.answerKeys = keyFiles.length;
if (keyFiles.length !== 38) err('Answer keys: expected 38, found ' + keyFiles.length);
const answerPositions = { A: 0, B: 0, C: 0, D: 0 };
const types = { applied: 0, problem: 0, best: 0, judgment: 0 };
const stems = new Map();
const generic = [
  'This option is consistent with the lesson',
  'It addresses presentation rather than',
  "It conflicts with the lesson's explanation",
  'It invents a restriction',
  'It removes a step or safeguard',
  'It describes an action that does not establish',
  'It denies a distinction',
  'It overstates the benefit',
  'It asserts a false impossibility',
  'It invents an unrelated',
  'Adding more of the same',
  'It denies a requirement or distinction'
];
let correctChars = 0, wrongChars = 0, correctCount = 0, wrongCount = 0;
for (const f of keyFiles) {
  const s = read(path.join(keyDir, f));
  const blocks = s.split(/^### Q/m).slice(1);
  if (blocks.length !== 10) err(`Key blocks ${blocks.length}: ` + rel(f));
  for (const b of blocks) {
    const n = (b.match(/^(\d+)\./) || [])[1];
    const answer = (b.match(/\*\*Correct answer: ([A-D])\./) || [])[1];
    const why = (b.match(/\*\*Why this is correct:\*\* (.+)/) || [])[1];
    if (!answer) err(`Key missing answer Q${n}: ` + rel(f));
    else answerPositions[answer]++;
    if (!why) err(`Key missing rationale Q${n}: ` + rel(f));
    const type = (b.match(/\*\*Type:\*\* ([a-z]+)/) || [])[1];
    if (type && types[type] !== undefined) types[type]++;
    const stem = b.split(/\r?\n/)[0].replace(/^\d+\.\s*/, '').trim();
    if (stems.has(stem)) err(`Duplicate stem: ${rel(f)} Q${n} and ${stems.get(stem)}`);
    stems.set(stem, `${rel(f)} Q${n}`);
    const rows = [...b.matchAll(/^\| ([A-D]) \| (.+?) \| (Incorrect|\*\*Correct\*\*) \| (.+?) \|$/gm)];
    if (rows.length !== 4) err(`Key option rows ${rows.length} Q${n}: ` + rel(f));
    const seenText = new Set();
    for (const r of rows) {
      const text = r[2].replace(/\\\|/g, '|');
      if (seenText.has(text)) err(`Duplicate option text Q${n}: ` + rel(f));
      seenText.add(text);
      const isCorrect = r[3].includes('Correct');
      if (isCorrect) { correctChars += text.length; correctCount++; }
      else { wrongChars += text.length; wrongCount++; }
      if (!isCorrect && generic.some(g => r[4].includes(g))) err(`Generic distractor explanation Q${n} ${r[1]}: ` + rel(f));
      if (!isCorrect && r[4].trim().split(/\s+/).length < 8) warn(`Short distractor explanation Q${n} ${r[1]}: ` + rel(f));
    }
  }
}
stats.answerKeyPositions = answerPositions;
stats.questionTypes = types;
for (const L of ['A', 'B', 'C', 'D']) if (answerPositions[L] !== 95) err(`Answer balance ${L}: ${answerPositions[L]} (expected 95)`);
if (types.applied !== 152 || types.problem !== 114 || types.best !== 76 || types.judgment !== 38) {
  err(`Question type totals: ${JSON.stringify(types)}`);
}
const lengthRatio = (correctChars / correctCount) / (wrongChars / wrongCount);
stats.correctOptionLengthRatio = Number(lengthRatio.toFixed(2));
if (lengthRatio > 1.3 || lengthRatio < 0.77) warn(`Correct option length ratio ${lengthRatio.toFixed(2)} may be a clue`);

// 5 assessments
const assessDir = path.join(PKG, '03_Assessments', 'Learner', 'Stop_Assessments');
const assessFiles = fs.readdirSync(assessDir).filter(f => f.endsWith('.md'));
stats.assessments = assessFiles.length;
if (assessFiles.length !== 38) err('Assessments: expected 38, found ' + assessFiles.length);
for (const f of assessFiles) {
  const s = read(path.join(assessDir, f));
  const q = (s.match(/\*\*Q\d+\.\*\*/g) || []).length;
  if (q !== 10) err(`Assessment questions ${q}: ` + f);
  if (!/Pass target:\*\* 80%/.test(s)) err('Assessment missing 80% pass target: ' + f);
  if (/Correct answer:/.test(s)) err('Assessment leaks answers: ' + f);
  if (!/does not save to a TechSkillHub account/.test(s)) err('Assessment missing honest marking note: ' + f);
}

// 6 rubrics
const rubricDir = path.join(PKG, '04_Instructor_Only', 'Rubrics', 'Stop_Rubrics');
const rubricFiles = fs.readdirSync(rubricDir).filter(f => f.endsWith('.md') && f.startsWith('Stop_'));
stats.rubrics = rubricFiles.length;
if (rubricFiles.length !== 38) err('Rubrics: expected 38, found ' + rubricFiles.length);
const rubricGeneric = [
  'The work meets the requirement.',
  'The work is excellent.',
  'The work is good.',
  'The work is poor.',
  'Shows understanding',
  'Demonstrates understanding',
  'Some evidence is present',
  'Little or no evidence',
  'Clear and complete',
  'Needs improvement'
];
for (const f of rubricFiles) {
  const s = read(path.join(rubricDir, f));
  const crit = (s.match(/^### Criterion /gm) || []).length;
  if (crit !== 4) err(`Rubric criteria ${crit}: ` + f);
  const level4 = (s.match(/\| \*\*4 /g) || []).length;
  const level3 = (s.match(/\| \*\*3 /g) || []).length;
  const level2 = (s.match(/\| \*\*2 /g) || []).length;
  const level1 = (s.match(/\| \*\*1 /g) || []).length;
  if (!(level4 === 4 && level3 === 4 && level2 === 4 && level1 === 4)) err(`Rubric levels 4/3/2/1 = ${level4}/${level3}/${level2}/${level1}: ` + f);
  for (const g of rubricGeneric) if (s.includes(g)) err(`Generic rubric descriptor "${g}": ` + f);
  if (!/minimum gate/i.test(s) && !/minimum gates/i.test(s)) warn('Rubric does not mention minimum gates: ' + f);
}

// 7 platform markdown
const pm = walk(path.join(PKG, '05_Platform_Ready', 'Markdown')).filter(f => f.endsWith('.md'));
stats.platformMarkdown = pm.length;
if (pm.length !== 38) err('Platform markdown: expected 38, found ' + pm.length);

// 8 HTML
const htmlDir = path.join(PKG, '05_Platform_Ready', 'HTML');
const htmlFiles = walk(htmlDir).filter(f => f.endsWith('.html'));
stats.html = htmlFiles.length;
if (htmlFiles.length !== 40) err('HTML pages: expected 40, found ' + htmlFiles.length);
for (const f of htmlFiles) {
  const s = read(f);
  if (!/<html lang="en">/.test(s)) err('HTML missing lang: ' + rel(f));
  if (!/<meta name="viewport"/.test(s)) err('HTML missing viewport: ' + rel(f));
  if (!/<main id="main"/.test(s)) err('HTML missing main: ' + rel(f));
  if (!/class="skip"/.test(s)) err('HTML missing skip link: ' + rel(f));
  if (/<!--\s*key:/i.test(s)) err('HTML key leak: ' + rel(f));
  if (/Correct answer:/.test(s)) err('HTML answer leak: ' + rel(f));
  if (/not playback-tested/.test(s)) err('HTML stale playback status: ' + rel(f));
  if (f.includes('lessons') || f.includes('sample_lesson_page')) {
    const fsCount = (s.match(/<fieldset/g) || []).length;
    if (fsCount !== 10) err(`HTML quiz fieldsets ${fsCount}: ` + rel(f));
    if (!s.includes('<video-embed')) err('HTML missing video component: ' + rel(f));
    if ((s.match(/data-hash="/g) || []).length !== 10) err('HTML missing per-question hashes: ' + rel(f));
    if (!/English caption track is listed/.test(s)) err('HTML missing caption honesty note: ' + rel(f));
    if (!/playback from Nigeria was not tested/.test(s)) err('HTML missing region honesty note: ' + rel(f));
  }
}

// 9 resources
const reg = csv(path.join(PKG, '06_Research', 'SOURCE_REGISTER.csv'));
stats.sources = reg.length - 1;
if (stats.sources !== 66) err('Source register rows: ' + stats.sources);
const regUrls = new Set(reg.slice(1).map(r => r[4]));
if (regUrls.size !== 66) err('Source register unique URLs: ' + regUrls.size);
const rr = csv(path.join(PKG, '07_Resources', 'RESOURCE_REVIEW.csv'));
stats.resourceReview = rr.length - 1;
if (stats.resourceReview !== 66) err('Resource review rows: ' + stats.resourceReview);
if (rr[0].length !== 17) err('Resource review columns: ' + rr[0].length);
const rrUrls = new Set(rr.slice(1).map(r => r[4]));
if ([...regUrls].some(u => !rrUrls.has(u))) err('Resource review missing a register URL');
const or = csv(path.join(PKG, '07_Resources', 'ORIGINAL_RESOURCE_REVIEW.csv'));
stats.originalReview = or.length - 1;
if (stats.originalReview !== 54) err('Original resource review rows: ' + stats.originalReview);
if (or[0].length !== 10) err('Original review columns: ' + or[0].length);
const mx = csv(path.join(PKG, '07_Resources', 'RESOURCE_SUFFICIENCY_MATRIX.csv'));
stats.matrix = mx.length - 1;
if (stats.matrix !== 38) err('Sufficiency matrix rows: ' + stats.matrix);
if (mx[0].length !== 20) err('Sufficiency matrix columns: ' + mx[0].length);
const matrixIds = new Set(mx.slice(1).map(r => r[0]));
if (matrixIds.size !== 38) err('Sufficiency matrix unique stops: ' + matrixIds.size);
for (const r of mx.slice(1)) {
  if (!r[5] || !regUrls.has(r[5])) err('Matrix primary reading not in register for stop ' + r[0]);
  if (!/Sufficient/.test(r[19])) err('Matrix status not sufficient for stop ' + r[0]);
}

// 10 videos
const vm = csv(path.join(PKG, '08_YouTube', 'YOUTUBE_VIDEO_MANIFEST.csv'));
stats.videos = vm.length - 1;
if (stats.videos !== 38) err('Video manifest rows: ' + stats.videos);
if (vm[0].length !== 16) err('Video manifest columns: ' + vm[0].length);
const vids = new Set(vm.slice(1).map(r => r[1]));
if (vids.size !== 38) err('Unique video IDs: ' + vids.size);
for (const r of vm.slice(1)) {
  if (!/verified: currentTime/.test(r[14])) err('Video not embed-verified in manifest: ' + r[0]);
  if (!/English/.test(r[11])) err('Video caption status missing: ' + r[0]);
  if (!/not tested from Nigeria/.test(r[10])) err('Video region honesty missing: ' + r[0]);
  if (!['full', 'partial', 'peripheral'].includes(r[13])) err('Video fit value: ' + r[13]);
  if (/not playback-tested/i.test(r[15])) err('Video final status stale: ' + r[0]);
}
const courseJson = JSON.parse(read(path.join(PKG, '05_Platform_Ready', 'JSON', 'course.json')));
if (courseJson.stopCount !== 38) err('course.json stopCount: ' + courseJson.stopCount);
for (const l of courseJson.lessons) {
  const j = JSON.parse(read(path.join(PKG, '05_Platform_Ready', 'JSON', 'lessons', `stop_${l.id}.json`)));
  if (!j.video || !/verified in the embedded player/.test(j.video.embedStatus || '')) err('JSON video status not verified for stop ' + l.id);
  if (!j.video.captions || j.video.captions.accuracyReviewed !== false) err('JSON caption accuracy must be false for stop ' + l.id);
  if (!j.video.region || j.video.region.playbackTestedFromNigeria !== false) err('JSON Nigeria test flag must be false for stop ' + l.id);
  if (!Array.isArray(j.quiz) || j.quiz.length !== 10) err('JSON quiz count for stop ' + l.id);
}

// 11 internal markdown links
const mdFiles = files.filter(f => f.endsWith('.md'));
let linkCount = 0;
for (const f of mdFiles) {
  const s = read(f);
  const re = /\[[^\]]*\]\(([^)]+)\)/g;
  let m;
  while ((m = re.exec(s))) {
    const target = m[1].trim().split('#')[0];
    if (!target || /^(https?:|mailto:|tel:)/.test(target)) continue;
    linkCount++;
    const resolved = /^(00_|01_|02_|03_|04_|05_|06_|07_|08_|09_|10_)/.test(target)
      ? path.join(PKG, target)
      : path.resolve(path.dirname(f), target);
    if (!fs.existsSync(resolved)) err(`Broken internal link in ${rel(f)} -> ${target}`);
  }
}
stats.internalLinks = linkCount;

// 12 HTML local assets
for (const f of htmlFiles) {
  const s = read(f);
  const re = /(?:href|src)="([^"#]+)"/g;
  let m;
  while ((m = re.exec(s))) {
    const t = m[1];
    if (/^(https?:|mailto:|#|data:)/.test(t)) continue;
    const resolved = path.resolve(path.dirname(f), t);
    if (!fs.existsSync(resolved)) err(`Broken HTML asset/link in ${rel(f)} -> ${t}`);
  }
}

// 13 learner files must not point at instructor answer keys
for (const f of files.filter(f => rel(f).startsWith('02_') || rel(f).startsWith('03_Assessments/Learner') || rel(f).startsWith('05_Platform_Ready'))) {
  if (!/\.(md|html|json)$/.test(f)) continue;
  const s = read(f);
  if (/04_Instructor_Only\/Answer_Keys\/Stop_Answer_Keys/.test(s)) err('Learner file points to answer key: ' + rel(f));
}

// 14 Stop 0.1 privacy and no-AI route
const stop01 = read(lessonFiles.find(f => /Stop_0\.1_/.test(f)));
if (/write down which email|email address you used|create the two accounts/i.test(stop01)) err('Stop 0.1 still asks for private account details');
if (!/no-AI route/i.test(stop01)) err('Stop 0.1 missing a named no-AI route');
if (!/optional/i.test(stop01)) err('Stop 0.1 does not mark the AI account optional');

// 15 Stop 5.0 clipboard example
const stop50 = read(lessonFiles.find(f => /Stop_5\.0_/.test(f)));
if (!/navigator\.clipboard\.writeText/.test(stop50)) err('Stop 5.0 does not call clipboard.writeText');
if (!/catch \(error\)/.test(stop50)) err('Stop 5.0 has no clipboard error fallback');
if (!/role="status"/.test(stop50)) err('Stop 5.0 has no live status region');
if (/status\.textContent = 'Copied'/.test(stop50)) err('Stop 5.0 claims success before the copy resolves');

// 16 placeholder scan
const bad = /(\bTODO\b|\bTBD\b|\bFIXME\b|Lorem ipsum|\[insert|expand this lesson|coming soon|PLACEHOLDER\b|placeholder content)/;
for (const f of files.filter(f => /\.(md|html|json|csv|txt)$/.test(f))) {
  const s = read(f);
  if (bad.test(s)) warn('Possible placeholder in ' + rel(f) + ': ' + s.match(bad)[0]);
  if (s.includes('\uFFFD')) err('Replacement character in ' + rel(f));
}

// 17 ZIP portability (if the archive exists)
const zipPath = [path.join(PKG, '..', 'TechSkillHub_AI_UIUX_Product_Design_VERIFIED_FINAL.zip'), path.join(__dirname, 'TechSkillHub_AI_UIUX_Product_Design_VERIFIED_FINAL.zip')].find(p => fs.existsSync(p)) || path.join(PKG, '..', 'TechSkillHub_AI_UIUX_Product_Design_VERIFIED_FINAL.zip');
if (fs.existsSync(zipPath)) {
  const buf = fs.readFileSync(zipPath);
  let badName = 0, entries = 0;
  for (let i = 0; i < buf.length - 4; i++) {
    if (buf.readUInt32LE(i) === 0x02014b50) {
      const nameLen = buf.readUInt16LE(i + 28);
      const name = buf.slice(i + 46, i + 46 + nameLen).toString('utf8');
      entries++;
      if (name.includes('\\')) badName++;
    }
  }
  stats.zipEntries = entries;
  stats.zipBackslashEntries = badName;
  if (!entries) err('ZIP central directory not readable');
  if (badName) err('ZIP contains backslash paths: ' + badName);
} else {
  warnings.push('Final ZIP not built yet; run build_zip.js and re-run validate.js.');
}

console.log(JSON.stringify(stats, null, 2));
console.log('ERRORS', errors.length);
errors.slice(0, 120).forEach(e => console.log(' -', e));
console.log('WARNINGS', warnings.length);
warnings.slice(0, 60).forEach(e => console.log(' -', e));
fs.writeFileSync(path.join(require('os').tmpdir(), 'tsh-validation-results.json'), JSON.stringify({ generated: new Date().toISOString(), stats, errors, warnings }, null, 2));
if (errors.length) process.exitCode = 1;
