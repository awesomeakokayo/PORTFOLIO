# Phase 0 Gate — Foundations Check

**Phase:** 0 · Getting started
**Stops covered:** 0.1–0.5
**Suggested time:** 90–120 minutes
**Review:** human instructor review required
**Pass target:** every criterion met, and an average of at least 80% across this phase's stop comprehension checks

## Purpose

This gate checks that you can work safely and independently before the course asks you to research real people. It is not a test of design talent. It is a test of setup, habits and judgment.

You must show that you can:

- organise your files and protect other people's data;
- explain how the course works and how mastery is judged;
- observe an interface without jumping to solutions;
- use an AI assistant as a tutor without outsourcing your thinking;
- produce and publish a first screen.

## What to submit

1. **Workspace evidence:** a screenshot or file tree showing your course folder, a notes system and a backup location. Do not show personal documents.
2. **Learning contract:** one page stating your practice schedule, your proof-artifact folder, and what you will do when you fail a check.
3. **Observation set:** ten specific observations of one real interface, separated into observation and interpretation.
4. **AI tutoring log:** three prompts where you asked an AI to explain a concept, plus your own restatement and one thing the AI got wrong or oversimplified.
5. **First screen:** a published page or a Figma frame with a short note on three decisions and one thing you would change.
6. **Reflection:** 150–250 words on what you found hardest and how you will handle a fail.

## Tasks

### Task 1 — Set up and label

Create this folder structure and use it consistently:

```
design-course/
  00_admin/          learning contract, schedule, receipts
  01_research/       consent forms, anonymised notes
  02_design/         Figma exports, screenshots
  03_build/          code, assets
  04_evidence/       test notes, before/after, metrics
  05_portfolio/      final artifacts
```

Label every practice file with the word **fictional** if it contains invented people, businesses or numbers. Remove real names from research notes before saving.

### Task 2 — Observe without solving

Choose one interface you use daily: a banking app, a bus-booking site, a market listing, a government portal. Write ten observations.

Each row must have:

- **Where:** screen and element.
- **What happened:** observable behaviour.
- **Interpretation:** what you think it means.
- **Confidence:** high, medium or low.

Bad: "The app is confusing."
Good: "On the transfer screen, the fee appears only after I tap Continue; I only noticed it because I went back. Interpretation: the fee is easy to miss at the decision point. Confidence: medium."

Do not propose fixes in this task. Observation is the skill.

### Task 3 — Use AI as a tutor

Ask an AI assistant to explain one concept from Phase 0, for example "What is the difference between a user goal and a task?" Then:

1. Write the explanation in your own words, without looking.
2. Ask a follow-up that tests the explanation with an example.
3. Identify one thing the AI got wrong, oversimplified or assumed.
4. Write what you would check in a primary source.

Paste the prompts and a short excerpt of the output. Do not paste a whole essay.

### Task 4 — Publish a first screen

Complete Stop 0.5. Submit either:

- a live URL of a simple page, or
- a Figma frame with a clear caption and a note that it is not published.

State three decisions: one about hierarchy, one about colour or type, one about content. State one thing you would change after seeing it on a phone.

## Pass criteria

- [ ] Folder structure exists and is used; files are named clearly.
- [ ] Practice data is labelled fictional where appropriate.
- [ ] No real personal data appears in shared files.
- [ ] Ten observations separate what happened from what you think it means.
- [ ] At least three observations have a stated confidence and a reason.
- [ ] AI tutoring log shows your own restatement, not just a pasted answer.
- [ ] You identify at least one AI error or oversimplification.
- [ ] First screen is complete and viewable by someone else.
- [ ] Three decisions are explained with reasons, not preferences.
- [ ] Reflection names a specific difficulty and a specific response.

## Scoring

| Criterion | Weight | Met / Not yet met |
|---|---|---|
| Workspace and file hygiene | 15% | |
| Observation quality | 25% | |
| AI tutoring judgment | 20% | |
| First screen | 25% | |
| Reflection and honesty | 15% | |

A pass requires **all criteria met**. A high score cannot compensate for a privacy breach or fabricated evidence.

## Critical failures (automatic rework)

- Real names, phone numbers or addresses in a shared file.
- A fabricated observation presented as real research.
- A first screen copied from a tutorial without attribution.
- An AI answer pasted as your own explanation.

## If you do not pass

You will receive a written note naming the criterion and one targeted exercise. Typical resubmission:

- **Observation weak:** observe a different screen and submit five rows with confidence ratings.
- **AI log weak:** redo the exercise with a concept you cannot already explain, and include a source check.
- **First screen incomplete:** publish a one-page profile using the Stop 5.0 starter, then return.

You may resubmit once without penalty. A second resubmission requires a short conversation with the instructor.

## Instructor review notes

Review within five working days. Mark each criterion with one sentence of evidence. Check for personal data before returning files. Do not rewrite the learner's work; name the gap and the next action. Record the decision in the learner file. The detailed rubric is in `04_Instructor_Only/Rubrics/Gate_Rubrics.md`.
