# Phase 4 Gate — AI Workflow Comparison

**Phase:** 4 · The AI design workflow
**Stops covered:** 4.1–4.7
**Suggested time:** 4–6 hours
**Review:** human instructor review required
**Pass target:** every criterion met, and an average of at least 80% across this phase's stop comprehension checks

## Purpose

This gate checks whether you can use AI as a directed assistant rather than an authority. You will do the same design task twice — once without AI, once with AI — and show what improved, what broke and what you overrode.

You must show that you can:

- synthesise research without fabricating evidence;
- generate and critique options;
- produce UI and copy with AI, then verify both;
- detect accessibility, consistency and flow failures;
- explain your human decisions in a prompt and decision log.

## What to submit

1. **Task brief:** the same brief for both runs, including constraints and success criteria.
2. **Run A — no AI:** your unaided research notes, ideation, screen and rationale.
3. **Run B — AI-assisted:** prompts, outputs, the resulting screen and your edits.
4. **Prompt log:** at least 10 prompts with purpose, output summary and accept/change/reject.
5. **Verification review:** a findings table covering invention, accessibility, consistency, flow and content.
6. **Comparison:** a table of time, quality, errors caught, errors introduced and what you overrode.
7. **Reflection:** 250 words on when AI helped, when it harmed, and what you will change next time.

## Tasks

### Task 1 — Freeze the brief

Write one brief and use it for both runs. Include:

- the user and the problem;
- the screen or flow to produce;
- three constraints (for example, mobile-first, no custom icons, one primary action);
- the success criteria you will judge both runs against.

Do not change the brief between runs. If you must, record the change and why.

### Task 2 — Run A without AI

Produce a baseline:

- a short research or evidence summary from your own notes;
- three sketched directions;
- one chosen direction with a reason;
- a screen or wireframe;
- a list of uncertainties.

Timebox this run and record the time. The point is a fair comparison, not a perfect baseline.

### Task 3 — Run B with AI

Use AI for at least three of these: synthesis, ideation, UI generation, critique, microcopy.

For each use:

- write the prompt with evidence rules and constraints;
- save the raw output;
- verify every factual claim against your notes;
- mark what you accepted, changed or rejected.

Do not paste confidential data. Anonymise first. If you use synthetic practice data, label it.

### Task 4 — Verify like a reviewer

Use the five failure types from Stop 4.6:

1. **Invention:** fabricated facts, quotes, sources, metrics or social proof.
2. **Generic style:** a default look unrelated to context.
3. **Accessibility:** contrast, focus, labels, target size, keyboard.
4. **Inconsistency:** components, spacing, tone or terminology that drift.
5. **Broken flow:** a sequence that looks right but fails a real task.

For each finding: element, evidence, severity, fix and regression check.

### Task 5 — Compare honestly

| Dimension | Run A (no AI) | Run B (AI) | What this shows |
|---|---|---|---|
| Time to first draft | | | |
| Time to review and fix | | | |
| Accessibility issues | | | |
| Invented or unsupported claims | | | |
| Consistency | | | |
| Your understanding of the result | | | |

Do not claim AI was faster if you spent longer fixing it. Count the total time.

## Pass criteria

- [ ] One brief used for both runs, with constraints and success criteria.
- [ ] Run A is a genuine unaided baseline.
- [ ] Run B uses AI for at least three workflow stages.
- [ ] Prompt log has at least 10 prompts with decisions.
- [ ] Research claims are traceable to notes or sources.
- [ ] Verification covers all five failure types.
- [ ] At least two real AI errors are caught and corrected.
- [ ] Comparison includes total time, not just drafting time.
- [ ] Reflection names a specific situation where AI harmed the work.
- [ ] No confidential data or fabricated evidence is included.

## Scoring

| Criterion | Weight | Met / Not yet met |
|---|---|---|
| Brief and fair comparison | 15% | |
| Run A quality | 15% | |
| Run B direction and prompt log | 20% | |
| Verification and correction | 25% | |
| Comparison and reflection | 15% | |
| Integrity and privacy | 10% | |

All criteria must be met. Integrity and privacy failures override the score.

## Critical failures (automatic rework)

- Fabricated research, quotes, metrics, clients or sources.
- Uploading confidential or personal data to an unapproved tool.
- Presenting AI output as unaided work.
- A corrected screen that still contains an unsourced claim.
- Claiming an accessibility check that was not performed.

## If you do not pass

- **Unfair baseline:** redo Run A with the same timebox and no AI, and record the time honestly.
- **Weak verification:** take one screen and review it against all five failure types with evidence.
- **Fabrication:** remove the claim, trace it to a source or delete it, and write a note on how it entered.
- **Privacy issue:** stop, delete the data, and speak to the instructor before resubmitting.

## Instructor review notes

Ask the learner to explain one AI output they rejected and why. Check that the prompt log matches the files. Spot-check two factual claims against the cited source. If the learner cannot explain a generated decision, treat it as unverified. Detailed rubric: `04_Instructor_Only/Rubrics/Gate_Rubrics.md`.
