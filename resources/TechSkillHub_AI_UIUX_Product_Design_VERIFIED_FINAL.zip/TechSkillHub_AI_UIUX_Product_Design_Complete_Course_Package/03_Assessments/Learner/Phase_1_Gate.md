# Phase 1 Gate — Research and Problem Framing

**Phase:** 1 · Product thinking and research
**Stops covered:** 1.1–1.4
**Suggested time:** 3–5 hours across several sessions
**Review:** human instructor review required
**Pass target:** every criterion met, and an average of at least 80% across this phase's stop comprehension checks

## Purpose

This gate checks whether you can turn a vague idea into a researchable problem, collect evidence ethically, and frame a problem without smuggling in a solution.

You must show that you can:

- explain what product design is responsible for;
- plan and conduct basic qualitative research;
- synthesise evidence without inventing it;
- write a problem statement that is specific and testable;
- review competitors without copying them.

## What to submit

1. **Research plan:** research questions, method, participants, consent approach, limitations.
2. **Consent record:** template plus confirmation that consent was obtained. Do not submit participants' names.
3. **Raw notes:** anonymised notes from at least five conversations, or a clearly labelled synthetic practice set if real recruitment is not possible.
4. **Synthesis:** themes with quotes, a traceability table, counter-evidence and rejected themes.
5. **Problem statement:** one page using the who/what/barrier/why structure, with three "how might we" options and a recommendation.
6. **Competitive review:** three products compared on user task, strengths, weaknesses and one thing not to copy.
7. **Reflection:** 200 words on what surprised you and what you would research next.

## Tasks

### Task 1 — Write a research plan a stranger could run

Include:

- **Decision the research will inform:** for example, "whether to prioritise delivery tracking or reordering".
- **Research questions:** 2–3, not 10.
- **Who:** the specific people you need, and why.
- **Method:** interviews, observation, diary, or a mix.
- **Sample:** how many and the limitation.
- **Ethics:** consent, recording, anonymisation, storage, deletion.
- **What you will not claim:** for example, "this is not statistically representative".

### Task 2 — Collect five conversations

Use open questions:

- "Tell me about the last time you [did the task]."
- "What happened next?"
- "What was the hardest part?"
- "What did you do instead?"

Do not ask "Would you use this?" or "Do you like this design?" Those questions produce politeness, not evidence.

If you cannot recruit five people, you may use **synthetic practice data** that you write yourself, clearly labelled `SYNTHETIC — NOT REAL USERS`. You may not present synthetic data as interviews. The synthesis skill is the same; the claim is different.

### Task 3 — Synthesise with traceability

Build a table:

| Theme | Participant | Exact quote or close paraphrase | Context | Confidence |
|---|---|---|---|---|
| Fee uncertainty | P2 | "I did not know if the total included delivery until the end." | Checkout, first order | High |
| Trust in updates | P4 | "If it says two days ago, I assume it is broken." | Tracking screen | Medium |

Then write:

- three themes;
- one counter-example per theme;
- two rejected themes and why;
- one paragraph on what the evidence cannot tell you.

### Task 4 — Frame the problem, not the solution

Use:

> **[Who]** needs a way to **[outcome]** because **[barrier]**, and this matters because **[consequence]**.

Then write three "How might we" questions at different levels:

- a broad one;
- a focused one;
- a deliberately narrow one.

Recommend one and explain the trade-off. A problem statement that already contains a button is a solution in disguise.

### Task 5 — Review three competitors without copying

Compare on the user's task, not on visual style:

| Product | User task | What works | What fails | What not to copy |
|---|---|---|---|---|
| A | | | | |
| B | | | | |
| C | | | | |

Do not screenshot private or paywalled content. Do not claim a competitor's feature is a proven success without evidence.

## Pass criteria

- [ ] Research plan states a decision, 2–3 questions, sample and ethics.
- [ ] Consent is documented; no participant names appear.
- [ ] Five conversations or a clearly labelled synthetic set.
- [ ] Notes separate what was said from what you infer.
- [ ] Three themes each have a traceability row and a counter-example.
- [ ] Two rejected themes are explained.
- [ ] Problem statement includes who, outcome, barrier and consequence.
- [ ] Three "how might we" options are at different levels; one is recommended.
- [ ] Competitive review compares user tasks, not just visuals.
- [ ] Reflection names a limitation and a next research question.
- [ ] No fabricated quote, participant, statistic or client.

## Scoring

| Criterion | Weight | Met / Not yet met |
|---|---|---|
| Research plan and ethics | 20% | |
| Evidence quality | 25% | |
| Synthesis and traceability | 25% | |
| Problem framing | 20% | |
| Competitive review | 10% | |

All criteria must be met. The score is for feedback, not for compensation.

## Critical failures (automatic rework)

- Invented participants, quotes or findings.
- Recording or publishing without consent.
- Presenting synthetic data as real research.
- A problem statement that names the solution.
- Copying a competitor's protected content or claiming their work as yours.

## If you do not pass

- **Weak evidence:** run two more conversations with different people, or rewrite your synthetic set with contradictions and re-synthesise.
- **Weak synthesis:** redo the traceability table for every theme, including counter-evidence.
- **Solution-shaped problem:** rewrite using the sentence frame and remove every interface noun.
- **Ethics issue:** stop, delete the data, and speak to the instructor before resubmitting.

## Instructor review notes

Check consent documentation before reading notes. If synthetic data is used, confirm it is labelled consistently in every file. Look for quotes that are suspiciously polished or identical; ask for the raw note. Mark each criterion Met / Not yet met with evidence. The detailed rubric is in `04_Instructor_Only/Rubrics/Gate_Rubrics.md`.
