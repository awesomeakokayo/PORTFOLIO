# Phase 5 Gate — Deployed, Responsive Front-End Prototype

**Phase:** 5 · Design to build
**Stops covered:** 5.0–5.4
**Suggested time:** 6–10 hours
**Review:** human instructor review required
**Pass target:** every criterion met, and an average of at least 80% across this phase's stop comprehension checks

## Purpose

This gate checks whether your design survives contact with a browser. You must ship a working, responsive front-end prototype of a Phase 3 or 4 design to a live URL, with a public repository that another person could inspect and run.

You must show that you can:

- build and publish a page;
- translate a handoff into working UI;
- use AI coding tools with review rather than blind trust;
- apply tokens and reusable components;
- make it work on small screens and slow connections.

## What to submit

1. **Live URL** that works in a private browser window.
2. **Public repository URL** with a README that explains the project and how to run it.
3. **Handoff pack** for the screen, including states and edge cases.
4. **Build evidence:** prompt log and review table if AI was used.
5. **Responsive evidence:** screenshots at 320px, 768px and 1280px.
6. **Accessibility evidence:** keyboard test, contrast ratios, labels, focus states, 200% zoom.
7. **Performance evidence:** before/after weight, requests, LCP, CLS and INP.
8. **Known issues:** an honest list of what does not work and what you would fix next.

## Tasks

### Task 1 — Deploy something real

The prototype must:

- load from a public URL;
- implement at least one complete user task;
- have at least two non-default states (loading, empty, error or success);
- work without console errors;
- not require a login the reviewer does not have.

A screenshot of localhost is not a deployment. A link that only works on your machine is not a deployment.

### Task 2 — Make the repository inspectable

The README must state:

- what the project is and that it is a course prototype;
- the live URL;
- how to run it locally;
- the file structure;
- the design decisions and trade-offs;
- known limitations;
- credits and licences for assets and code;
- confirmation that no secrets or personal data are included.

Include a `.gitignore` if you use environment variables. Never commit API keys.

### Task 3 — Prove responsiveness

Test at 320px, 768px and 1280px. At 320px:

- no horizontal scrolling;
- the primary action is reachable;
- text does not overlap or clip;
- tap targets are at least 44×44 where practical, never below 24×24.

At 200% zoom, content must reflow without loss. Provide screenshots that show the same task at each width.

### Task 4 — Prove accessibility basics

- Every input has a visible label connected programmatically.
- Every action is a real button or link.
- Keyboard focus is visible and in a logical order.
- Contrast is at least 4.5:1 for body text and 3:1 for large text and UI boundaries.
- Images have appropriate `alt`.
- Errors are described in text, not colour alone.
- Motion respects `prefers-reduced-motion`.

State what you could not test, for example a screen reader you do not have.

### Task 5 — Meet a performance budget

Target:

- total page weight ≤ 500 KB (excluding video, which should not autoload);
- LCP ≤ 2.5 s on Slow 4G;
- CLS ≤ 0.1;
- INP ≤ 200 ms.

If you miss a target, report the measured number and explain why. An honest miss with a plan is better than an unsupported claim.

### Task 6 — Review the AI-assisted code

If you used an AI coding tool, submit:

- the prompt log;
- a review table with at least 10 checks;
- one defect you caught and fixed;
- one piece of code you removed because you could not explain it.

If you did not use AI, say so and submit your own review notes. The gate is about judgment, not tool use.

## Pass criteria

- [ ] Live URL works in a private window and on a phone.
- [ ] Public repository is accessible and has a complete README.
- [ ] One complete task works end to end.
- [ ] At least two non-default states work.
- [ ] No console errors on the main path.
- [ ] 320px, 768px and 1280px screenshots show no horizontal scroll at 320px.
- [ ] 200% zoom reflows without loss.
- [ ] Keyboard, focus, labels and contrast checks have evidence.
- [ ] Performance numbers are measured and reported, with misses explained.
- [ ] No secrets, personal data or unlicensed assets are in the repo.
- [ ] Known issues are listed honestly.

## Scoring

| Criterion | Weight | Met / Not yet met |
|---|---|---|
| Working deployment | 20% | |
| Code quality and repository | 15% | |
| Responsive behaviour | 20% | |
| Accessibility | 20% | |
| Performance | 15% | |
| Honest documentation | 10% | |

All criteria must be met. A deployment that excludes keyboard users does not pass, regardless of visual quality.

## Critical failures (automatic rework)

- A committed secret, API key or personal data.
- A live URL that does not load for the reviewer.
- A core task that cannot be completed by keyboard.
- A page that horizontally scrolls at 320px with no fix.
- Claiming performance or accessibility results that were not measured.
- Using unlicensed assets or copied code without attribution.

## If you do not pass

- **Deployment fails:** redeploy from the repository root; check the file name and branch; test in a private window.
- **Responsive fails:** fix the widest offending element first; replace fixed widths with `max-width`.
- **Accessibility fails:** fix the blocker, then re-run the keyboard and contrast checks.
- **Performance fails:** compress the largest image, remove one third-party script, and re-measure.
- **Repository hygiene fails:** remove the secret, rotate it, and rewrite history if necessary before resubmitting.

## Instructor review notes

Open the live URL on a phone-sized viewport and tab through the main task. Check the repository for secrets and licence notes. Re-measure one performance metric rather than trusting the screenshot. Ask the learner to explain one generated code block. Detailed rubric: `04_Instructor_Only/Rubrics/Gate_Rubrics.md`.
