# Phase 2 Gate — Visual and Interaction Foundations

**Phase:** 2 · Visual and interaction foundations
**Stops covered:** 2.1–2.5
**Suggested time:** 3–5 hours
**Review:** human instructor review required
**Pass target:** every criterion met, and an average of at least 80% across this phase's stop comprehension checks

## Purpose

This gate checks whether you can make a screen that is readable, consistent and usable, and whether you can explain the decisions rather than decorate.

You must show that you can:

- use layout, spacing and hierarchy deliberately;
- choose type and colour with contrast in mind;
- use components and patterns consistently;
- design interaction states, not just a static screen;
- meet WCAG 2.2 AA basics and explain the limits of your check.

## What to submit

1. **Three screens** for one fictional product: a home or list screen, a detail or form screen, and a confirmation or empty state.
2. **Style sheet:** type scale, colour tokens with contrast ratios, spacing scale, radius and shadow rules.
3. **Component sheet:** at least five components with states.
4. **Interaction notes:** what happens on hover, focus, press, loading, error, success and empty.
5. **Accessibility audit:** a table of checks with pass/fix status and evidence.
6. **Decision rationale:** 250 words on three visual decisions and one trade-off.

## Tasks

### Task 1 — Build a hierarchy you can defend

For each screen, mark:

- the first thing a user should see;
- the second;
- the action;
- the supporting detail.

Then check with the **squint test**: blur the screen or step back. If everything has equal weight, the hierarchy is missing. Fix size, weight, colour or spacing, not decoration.

### Task 2 — Set a type and colour system

- Body text at least 16px, line height around 1.5.
- A type scale with no more than five sizes.
- Body text contrast at least 4.5:1; large text and UI boundaries at least 3:1.
- A colour palette with semantic roles, not just swatches.
- Do not rely on colour alone to convey status; add text or an icon.

Record the contrast ratio for every text/background pair. Use a checker; do not estimate.

### Task 3 — Build components with states

At minimum:

- button (default, hover, focus, pressed, disabled, loading);
- input (empty, focused, filled, error, disabled, read-only);
- card or list item (default, selected, loading, empty, error);
- navigation (current, hover, focus);
- feedback (success, warning, error, info).

For each, state the trigger, visual change and behaviour. A component with only a default state is a picture.

### Task 4 — Design the interaction, not just the frame

Write the sequence for one core task, for example "add an item to a cart":

1. What the user sees before.
2. What they tap.
3. What happens immediately.
4. What happens while waiting.
5. What happens on success.
6. What happens on failure.
7. How they recover.

Include at least one error and one empty state. Do not hide failure behind a generic "Something went wrong" if you can say what happened and what to do.

### Task 5 — Audit accessibility honestly

Use this table:

| Check | Standard | Result | Evidence | Fix |
|---|---|---|---|---|
| Text contrast | 4.5:1 normal, 3:1 large | | Ratio | |
| Non-text contrast | 3:1 for UI boundaries | | Ratio | |
| Target size | 24×24 minimum; 44×44 preferred | | Measured | |
| Keyboard reach | All controls | | Tab test | |
| Visible focus | Clear indicator | | Screenshot | |
| Labels | Every input has one | | Inspector | |
| Error identification | Text, not colour alone | | Screenshot | |
| Reflow | 320px, 200% zoom | | Screenshot | |

State what you could not test, for example a screen reader you do not have. Do not claim full WCAG conformance from a partial check.

## Pass criteria

- [ ] Three screens are complete and consistent.
- [ ] Each screen has a clear first, second and third visual priority.
- [ ] Type scale has five sizes or fewer; body text is at least 16px.
- [ ] Every text/background pair has a recorded contrast ratio.
- [ ] Five components each have at least three states.
- [ ] One core task includes loading, success, error and recovery.
- [ ] At least one empty state is designed.
- [ ] Accessibility table has evidence for each row, not just "yes".
- [ ] Limitations of the audit are stated.
- [ ] Three decisions and one trade-off are explained.

## Scoring

| Criterion | Weight | Met / Not yet met |
|---|---|---|
| Layout and hierarchy | 20% | |
| Type and colour | 20% | |
| Components and consistency | 20% | |
| Interaction and states | 20% | |
| Accessibility | 20% | |

All criteria must be met. Accessibility cannot be waived by strength in visual craft.

## Critical failures (automatic rework)

- Body text below 4.5:1 where it is essential reading.
- A control that is unreachable or unusable by keyboard.
- Status conveyed by colour alone.
- A core flow with no error state.
- Claims of WCAG conformance that the evidence does not support.

## If you do not pass

- **Hierarchy weak:** rebuild one screen with only three weights and one accent colour.
- **Contrast failing:** replace the palette with a checked set; record every ratio.
- **States missing:** complete the state table for one component, then apply the pattern to the rest.
- **Accessibility failing:** fix the blocker first, then re-audit with evidence.

## Instructor review notes

Verify contrast ratios with your own checker on at least two pairs. Tab through the prototype yourself. If the learner claims a screen-reader test, ask for the announcement or a recording. Do not accept "looks accessible" as evidence. Detailed rubric: `04_Instructor_Only/Rubrics/Gate_Rubrics.md`.
