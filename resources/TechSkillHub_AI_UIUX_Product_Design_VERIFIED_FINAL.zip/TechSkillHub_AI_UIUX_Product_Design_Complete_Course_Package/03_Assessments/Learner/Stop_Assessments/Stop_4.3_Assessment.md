# Stop 4.3 Assessment — AI for UI Generation and Prototyping

**Phase:** 4 · The AI design workflow
**Prerequisite:** Stop 4.2
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** What is the main purpose of a constraint stack in a UI prompt?
- A. To make the prompt longer, because detailed prompts are assumed to produce better screens.
- B. To force the assistant to use one specific model with predictable visual output.
- C. To specify user, task, content, tokens, states and rules so output is usable.
- D. To remove the need to review the output, since constraints prevent every defect.

**Q2.** Why generate three drafts with different emphases?
- A. To avoid relying on one draft, since a single version is never valid.
- B. To increase the tool's cost per screen and justify a paid subscription later.
- C. To compare trade-offs instead of accepting the first plausible screen the tool produces.
- D. To leave the choice open until someone else reviews all three drafts.

**Q3.** A generated screen uses #9CA3AF secondary text at 12 px on white. What is the issue?
- A. The grey is too dark against white, making the text heavier than the heading.
- B. It fails contrast for normal text, measuring about 2.6:1 against the 4.5:1 minimum.
- C. It uses the wrong font family, which makes the secondary text look inconsistent.
- D. It is fine, because grey text is always accessible on a white background.

**Q4.** What should you do with an invented "Scan QR" feature in a draft?
- A. Remove it unless it is in scope, and log the removal for the decision record.
- B. Keep it, because a useful-looking feature adds value even when it was never planned.
- C. Add it to the backlog automatically so the team can consider it next sprint.
- D. Ask the AI to animate it, then judge whether the motion suits the screen.

**Q5.** Why rebuild at least one draft by hand?
- A. Because importing generated layers is forbidden by most design tool licences.
- B. Because rebuilding is faster than importing and reduces the time spent on review.
- C. Because rebuilding reveals what the AI approximated and applies your system properly.
- D. Because the rebuild teaches the model your tokens and improves its future output.

**Q6.** What does provenance record?
- A. Tool, date, prompt, output file, licence and the changes you made.
- B. Only the tool name, since the other details can be recovered from the file.
- C. The designer's mood, so reviewers understand the intent behind the screen.
- D. The file size and export format, so storage requirements stay predictable.

**Q7.** A generated headline says "Trusted by 10,000 users" with no data. What is wrong?
- A. It is too long for a headline and competes with the primary button.
- B. It is an invented claim that must be removed or properly substantiated.
- C. It uses the wrong font weight, so the number does not read as emphasis.
- D. It is fine, because the assistant sourced the figure from its training data.

**Q8.** How should you measure whether AI saved time?
- A. Time to the first usable draft only, since that is what the tool accelerates.
- B. The number of prompts sent, since more prompts indicate more exploration.
- C. Time to draft plus time to fix to standard, plus defects found.
- D. The tool's published marketing claims about average speed improvements for teams.

**Q9.** An AI-generated draft looks polished but has no empty, loading or error states. What should the learner do before presenting it?
- A. Present it as finished, because the default state is what most reviewers will see.
- B. Add more gradients and illustration so the missing states attract less attention.
- C. Add and review the missing states, then check the draft against real constraints.
- D. Delete the project and start from a blank file with the states designed first.

**Q10.** A generated screen uses 12 px grey text with a measured contrast of 2.6:1 on white. What is the specific failure?
- A. The text is too large for the screen and crowds the neighbouring content.
- B. The screen uses too many columns, so the reading order is unclear.
- C. Normal-sized text falls below the 4.5:1 WCAG AA contrast requirement.
- D. The text is not written in sentence case, which weakens the tone.

## Part B — Practical task

**Task.** Submit the eight-part generated-UI review pack.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] A constraint stack covering all seven layers.
- [ ] Three drafts with different emphases.
- [ ] Ten-point review completed for each.
- [ ] Invented features and token violations listed.
- [ ] One corrected screen with at least two states.
- [ ] Provenance and licence recorded.
- [ ] Time and defect measurement included.
- [ ] Verdict is specific and honest.
- [ ] No unlicensed asset or fabricated claim.

## Part C — If you do not pass

**Retry variant.** Generate a **desktop dashboard** instead of a mobile screen, with a table, filters and a status column. Review it for density, data-table accessibility and responsive behaviour. Submit three drafts, the review, one corrected screen and a 150-word note on which defect was hardest to see.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
