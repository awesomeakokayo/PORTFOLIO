# Stop 7.2 Assessment — Working With Developers and Product Managers

**Phase:** 7 · Capstone and career launch
**Prerequisite:** Stop 7.1 passed
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** What is the most useful way to present a design decision to a PM?
- A. As two or three options with user benefit, cost and risk, plus one recommendation and its rationale.
- B. As a firm demand supported by your professional judgement, so the team can move forward without further debate.
- C. As a finished screen with no written context, so the PM can react to the visual result immediately.
- D. As a complaint about the deadline, so the PM understands the pressure the design team is facing.

**Q2.** What makes a ticket buildable?
- A. A clear title alone, because the developer can ask for the rest of the context during stand-up.
- B. Context, scope, acceptance criteria, a design link, edge cases and open questions with named owners.
- C. A screenshot and a deadline, so the developer can see the target and plan the work backwards.
- D. A link to a competitor's page, so the developer can copy the behaviour that already works there.

**Q3.** In a critique, which comment is most useful?
- A. I don't like green, because it makes the whole product feel cheaper than the competitors' products.
- B. Make it pop, so the primary action stands out more clearly against everything else on the page.
- C. At 320px the primary button sits below the fold, so users may never see it on a small phone.
- D. My old team did it differently, and their version tested better with the users we surveyed.

**Q4.** What is scope creep?
- A. A design pattern where components grow in size as the screen width increases across breakpoints.
- B. Unplanned additions that expand the work without adjusting the agreed timeline, cost or quality.
- C. A type of estimate that assumes the team will work faster than the original forecast allowed.
- D. A critique method where reviewers keep adding suggestions until the design has changed substantially.

**Q5.** A disagreement is about speed versus completeness. What kind is it?
- A. A fact disagreement, because one side must be wrong about how long the work will actually take.
- B. A values disagreement, because the two sides are prioritising different things and neither is factually wrong.
- C. A taste disagreement, because the argument is really about which visual style looks more finished.
- D. A technical bug, because the disagreement will disappear once the underlying defect has been fixed.

**Q6.** What should an escalation brief include?
- A. A long history of the conflict, so the decision maker understands how the disagreement developed.
- B. Only the designer's preferred option, stated clearly enough that the decision maker can approve it.
- C. The decision needed, the options, a recommendation, a deadline and the default if nobody decides.
- D. A list of everyone who is wrong, so responsibility for the delay can be assigned properly.

**Q7.** Why keep a decision log?
- A. To fill the project documentation, so the repository looks maintained when a new manager reviews it.
- B. To prove you attended the meetings, which is useful when performance and contribution are reviewed each quarter.
- C. To replace the design file, so nobody needs to open the source frames once a decision is recorded.
- D. To preserve the rationale behind choices, prevent relitigating and help new team members understand earlier decisions.

**Q8.** What builds trust fastest with a developer?
- A. Beautiful mockups, because visual quality is what convinces engineers that a designer is worth listening to.
- B. Reliable delivery, early risk flags, updated designs and turning up to the build review each sprint.
- C. More meetings, because frequent contact shows the developer that the designer is engaged and reliable.
- D. Avoiding all constraints, because a designer who never compromises keeps the original product vision intact.

**Q9.** A developer says a design interaction is technically impossible in the current sprint. What is the most useful response?
- A. Insist that the original design ships exactly as drawn, because the interaction carries the whole experience.
- B. Remove the feature without telling the product manager, so the sprint stays on schedule and nobody notices.
- C. Escalate immediately without asking a question, because the developer is blocking work that was already agreed.
- D. Ask what constraint makes it impossible, then offer a smaller or alternative interaction with its trade-off.

**Q10.** A ticket says 'make the settings page nicer' and gives no acceptance criteria. What will most likely happen?
- A. The page will automatically become accessible, because the design system handles labels and focus order.
- B. The developer and designer will interpret 'nicer' differently, causing rework and a much slower review.
- C. The design system will update itself, because vague requests usually trigger a routine component refresh.
- D. The sprint will end early, because the developer can stop once the page looks better than before.

## Part B — Practical task

**Task.** Submit the collaboration pack and reflection.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] Ticket is self-contained with testable acceptance criteria.
- [ ] Decision log has at least four entries with rationale and owner.
- [ ] Critique note has one strength and three specific improvements tied to the goal.
- [ ] Escalation brief states the decision, options, recommendation, deadline and default.
- [ ] At least one trade-off is explained in user, cost and risk terms.
- [ ] The reflection names a constraint and its effect on the design.
- [ ] No confidential or personnel information is included.
- [ ] Language is professional and focused on the work.

## Part C — If you do not pass

**Retry variant.** Rewrite a real or imagined disagreement as a **one-page decision brief** with no mention of personalities. Then write a 100-word note on what changed when you removed emotion from the framing. This targets the most common collaboration failure.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
