# Stop 0.3 Assessment — Seeing Like a Designer

**Phase:** 0 · Getting started
**Prerequisite:** Stop 0.1, Stop 0.2
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** Which part is drawn by the operating system rather than the app?
- A. The status bar at the top, showing the time, battery level and signal strength.
- B. The primary button at the bottom of the screen that submits the form.
- C. The card in the content area that groups an image with its title.
- D. The helper text under the field that explains the required format.

**Q2.** What is the difference between a component and a pattern?
- A. A component is a reusable part; a pattern is a reusable solution made of parts.
- B. A pattern is always larger than a screen, while a component fits inside one.
- C. A component is used only on mobile, while a pattern works on any platform.
- D. There is no real difference between the two terms in everyday design work.

**Q3.** A form field shows "Enter your 11-digit phone number" inside the box, and the text disappears when the user types. What is missing?
- A. A primary button that submits the completed form to the server.
- B. A visible label above the field and helper text that stays on screen.
- C. A toast that confirms the number was accepted after submission.
- D. A breadcrumb that shows where the form sits in the wider flow.

**Q4.** Which is the strongest annotation of a screen's purpose?
- A. "This screen is for transfers between two accounts that the same person holds at one local bank branch."
- B. "This screen is beautiful because the colours and the spacing feel very calm, modern and easy to read."
- C. "This screen has a blue button in the footer area of the layout, which looks clear and modern."
- D. "This screen wants the user to check the amount and recipient, because the amount is largest and the button repeats it."

**Q5.** A screen shows "No orders yet" with a "Start shopping" button. What is this called?
- A. An error state, because the message reports that something failed.
- B. A loading state, because the screen is waiting for data to arrive.
- C. A modal, because it interrupts the user and demands a decision.
- D. An empty state, because there is no content yet and a route forward.

**Q6.** Why should you annotate with a numbered legend instead of writing labels over the interface?
- A. Labels over the interface obscure the thing being analysed and become unreadable.
- B. Legends are required by Figma before a file can be exported or shared.
- C. Numbers look more professional than words on a design portfolio page.
- D. A numbered legend reduces the file size of the exported image noticeably.

**Q7.** Which action is tertiary?
- A. A plain text link under the form that says "Forgot password?" quietly.
- B. A large filled "Pay now" button that spans the width of the footer.
- C. An outlined "Save draft" button placed beside the primary action in the footer.
- D. A floating action button in the corner of the screen for a new message.

**Q8.** Why is the empty state often revealing?
- A. It is usually the prettiest screen because designers spend most of their time on it.
- B. It never contains buttons, so it shows the product without any actions at all.
- C. It shows how the product behaves before the user has data, which every new user sees first.
- D. It is required by app stores before an app can be published to the public.

**Q9.** A learner is annotating a checkout screen and wants to point out the order total, the primary button and a missing error message. Which annotation method keeps the evidence readable?
- A. Write long labels directly over the interface elements so the notes sit close to them.
- B. Replace the screen with a written paragraph that describes what it looks like in detail.
- C. Place numbered markers on a copy of the screen and put the explanations in a legend beside it.
- D. Use a different colour for every note without adding any single key to explain them.

**Q10.** A learner labels the phone's time, battery icon and signal bars as app interface elements. What is the conceptual error?
- A. They are system UI, drawn by the operating system rather than by the app.
- B. They are components because they appear on every screen of the same app.
- C. They are patterns because the same three items repeat across every screen.
- D. They are decorative images that carry no meaning for the person using the phone.

## Part B — Practical task

**Task.** Submit the three-screen teardown described in section 8, as a PDF or a shared document.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] Three different real screens from three different apps (or three clearly different flows).
- [ ] At least 20 labelled parts in total, with terms used correctly.
- [ ] Every screen has the "wants the user to…" sentence with evidence.
- [ ] Every screen has one concrete improvement tied to a named part.
- [ ] Private data is removed or blurred.
- [ ] The missing-state note identifies at least one absent state and what it would need.
- [ ] The comparison names the clearest primary action and uses at least four glossary terms.

## Part C — If you do not pass

**Retry variant.** Do the teardown again with **three different screens from the same app**: its onboarding, its empty state, and its error state. Label at least 18 parts and write a paragraph on how the same product changes its visual language across those three moments. Submit the new teardown plus a corrected version of your original legend, with any misused terms fixed and explained.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
