# Stop 4.7 Assessment — Repeatable Personal Workflow

**Phase:** 4 · The AI design workflow
**Prerequisite:** Stop 4.6
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** Which stage should AI not own?
- A. Framing the problem and making the final decision to ship.
- B. Divergence, where the assistant generates flows and options quickly.
- C. Drafting variants of copy, flows and critique prompts for review.
- D. First-pass critique, where findings are drafted for a human to check.

**Q2.** What makes a prompt reusable?
- A. It is long, with several paragraphs of context before the task.
- B. It mentions a specific model, so the output stays consistent.
- C. It has placeholders, constraints, an output format and a verification instruction.
- D. It was written by an expert, so its structure is implicitly sound.

**Q3.** What is automation bias?
- A. Refusing to use automated tools at all because they feel untrustworthy.
- B. Automating a workflow so that fewer human steps are needed each time.
- C. Treating it as a bias in training data rather than in the user.
- D. Trusting automated output more than the available evidence actually warrants.

**Q4.** What is a verification gate?
- A. A suggestion to check the output later, once the sprint is finished.
- B. A binary checkpoint that output must pass before it proceeds.
- C. A prompt that asks the assistant to verify its own previous answer.
- D. A design review meeting where the team discusses the screen.

**Q5.** Which data should never be pasted into a consumer AI tool?
- A. Public documentation that anyone can download from the vendor site.
- B. Your own published portfolio, already visible to anyone online.
- C. A public competitor screenshot taken from their marketing page.
- D. A participant's name, phone number and home address.

**Q6.** Why keep prompts in plain text outside a tool?
- A. To survive tool churn and keep the workflow portable across vendors.
- B. To avoid relying on tools, which cannot store prompts for more than one session.
- C. To make each prompt longer and more detailed than a saved version.
- D. To share the prompts publicly as a portfolio of your AI practice.

**Q7.** How should productivity be measured?
- A. By the tool's claims about how much faster designers usually work.
- B. By the number of prompts sent during a typical working day.
- C. By total time, defects, rework and quality against the criteria.
- D. By the number of outputs produced in a single session.

**Q8.** Which is a valid "do not use AI" rule?
- A. "Never use AI for anything, because every output needs checking anyway."
- B. "Do not use AI to generate user quotes or interview findings."
- C. "Only use AI on Mondays, when the team has time to review outputs."
- D. "Do not use AI for colour, because palettes should come from the system."

**Q9.** A learner wants a reusable prompt for critiquing screens. Which addition makes the prompt most reusable?
- A. A longer list of adjectives describing what good design should feel like.
- B. A request to be as confident as possible so the critique sounds decisive.
- C. A rule to accept the first answer, saving time on repeated reviews.
- D. A fixed structure with role, criteria, evidence, output format and verification.

**Q10.** A team adopts AI output without review because the tool is usually right. Which risk is this?
- A. Automation bias, where people over-trust automated output and stop checking.
- B. Scope creep, where the project grows beyond the agreed problem statement.
- C. Design system drift, where components gradually diverge from the tokens.
- D. Low contrast, where text fails the minimum ratio against its background.

## Part B — Practical task

**Task.** Submit the eight-part workflow document.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] Five stages with human decisions identified.
- [ ] Five prompt templates with constraints and verification.
- [ ] Decision log with three real entries.
- [ ] Five binary verification gates.
- [ ] Five do-not rules with fallbacks.
- [ ] Data classification table.
- [ ] One honest measurement.
- [ ] A reflection naming a real risk and mitigation.
- [ ] No unmeasured productivity claim.

## Part C — If you do not pass

**Retry variant.** Apply your workflow to a **different, smaller task** (for example, drafting a single error message and its variants) and record where the workflow was too heavy. Revise it to a "lightweight" version for small tasks and a "full" version for gates. Submit both versions and a 120-word note on when each applies.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
