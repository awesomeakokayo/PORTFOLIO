# Stop 1.2 Assessment — User Research Basics

**Phase:** 1 · Product thinking and research
**Prerequisite:** Stop 1.1
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** Which question is most likely to produce a useful story?
- A. Would you use a savings app if it reminded you to put money aside every Friday evening?
- B. Don't you find saving difficult, given how prices have risen in the market this year?
- C. Do you like saving money, or do you prefer to spend it on things you need immediately?
- D. Tell me about the last time you tried to save money and what made it hard or easy.

**Q2.** What makes a question leading?
- A. It has more than five words, so the participant must hold too much in mind before answering.
- B. It asks about the past, so the participant reports a memory rather than a current opinion.
- C. It suggests the answer the researcher wants, so the participant agrees to be helpful and quick.
- D. It is asked in an interview rather than a survey, so the researcher is present when answering.

**Q3.** Which method best answers "how many users abandon at step 2?"
- A. A heuristic evaluation, because an expert reviewer can count the steps where users get stuck.
- B. Two interviews, because two people can explain why they personally abandoned the form.
- C. A focus group, because discussion reveals how common the abandonment problem really is.
- D. Analytics or a survey, because prevalence needs numbers from a larger sample of users.

**Q4.** What must be recorded before an interview begins?
- A. The participant's full name and address, so the notes can be matched to the right person later.
- B. The final design of the feature, so the participant can react to the screen during the conversation.
- C. The competitor analysis for the product, so the interview can focus on where rivals do better.
- D. Informed consent, including written permission to take notes and to record the audio if needed.

**Q5.** In two-column notes, which belongs in the left column?
- A. Users want a simpler app, because several participants mentioned that the flow felt long.
- B. This proves the flow is broken, because nobody completed the transfer without asking for help.
- C. The design should use a spinner, because waiting without feedback caused most of the doubt.
- D. I closed it and tried again because it said 'processing' for a long time.

**Q6.** Two interviews both mention calling the recipient before sending money. What is the most honest finding?
- A. All Nigerian users distrust banks, as shown by both participants calling before they send.
- B. Users want a photo of the recipient, since both participants checked the name before paying.
- C. The app is unusable, because both participants needed another channel to feel confident.
- D. 2 of 2 participants in this practice sample used a second channel to confirm the recipient.

**Q7.** What is the main risk of asking "Would you use this feature?"
- A. It takes too long to answer, so the interview runs over and later questions get rushed.
- B. People tend to say yes to imagined future use, which is weak evidence of real behaviour.
- C. It requires a survey tool, so the interview cannot be run in person with written notes.
- D. It is illegal without written consent, so the researcher must get approval before asking it.

**Q8.** Why keep the consent record separate from the notes?
- A. Because the consent record may contain identifying details that must not travel with anonymised notes.
- B. To save space, because the notes file should stay short enough to read during the analysis.
- C. Because Figma requires it, since shared design files are not allowed to hold participant information.
- D. Because consent expires in 24 hours, so the record is useless once the interview is over.

**Q9.** A learner wants to understand why people abandon a money-transfer form. Which interview question is most useful?
- A. Tell me about the last time you started a transfer and did not finish it. What happened?
- B. Would you finish the form if it had fewer steps and a clearer summary before you confirm?
- C. Do you agree the form is too long, and that the summary arrives far too late in the flow?
- D. Why do users always abandon forms, and what should the team change to stop that happening?

**Q10.** A learner interviews two friends who say they would use a new feature, then reports 'users want this feature'. What is the main research error?
- A. The learner should have used a survey instead of interviews, so the sample could be larger.
- B. Two interviews are never useful, so the learner should have run at least ten before reporting.
- C. The learner did not record the friends' names, so the findings cannot be traced back later.
- D. Hypothetical enthusiasm from two people is being presented as evidence of a broader need.

## Part B — Practical task

**Task.** Submit the six-part research pack from section 8.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] Two real practice interviews, or an honest statement that one did not happen.
- [ ] A discussion guide with at least seven open, non-leading questions.
- [ ] Two-column notes for each interview.
- [ ] Consent recorded for each participant, with no real names in the notes.
- [ ] 3–5 themes, each with a count, a direct quote and a separate interpretation.
- [ ] A Limits section that names who was not included and what cannot be concluded.
- [ ] No fabricated participant, quote, number or finding.

## Part C — If you do not pass

**Retry variant.** Run **one** new interview on a different topic with a participant who is **not** a close friend (a classmate, colleague or family member you do not usually discuss this with). Use a guide of five questions, all about a specific past event. Submit the two-column notes, the consent record, a three-theme findings table, and a 120-word note on how the stranger's answers differed from what you expected. If you cannot find a participant, do not invent one; instead submit a revised guide and a written plan for recruitment, and mark the task as not yet passed.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
