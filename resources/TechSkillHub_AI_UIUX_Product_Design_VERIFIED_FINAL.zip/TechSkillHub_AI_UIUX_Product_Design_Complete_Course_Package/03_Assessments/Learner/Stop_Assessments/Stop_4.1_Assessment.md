# Stop 4.1 Assessment — AI for Research Synthesis

**Phase:** 4 · The AI design workflow
**Prerequisite:** Phase 3 gate passed
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** What is the safest role for AI in research synthesis?
- A. Clustering the notes into candidate themes that a human then checks against every quote.
- B. Generating findings directly from the project brief, so the team saves the reading time.
- C. Conducting the interviews itself and reporting what participants said about the product.
- D. Writing participant quotes that read naturally, then filling gaps the notes left open.

**Q2.** An AI says "all participants distrusted the app". What should you do first?
- A. Accept it, because the model has read every note and summarised them consistently.
- B. Check each participant's notes separately to verify whether the quantifier is true.
- C. Delete the whole theme, since one exaggerated word makes the entire grouping unusable.
- D. Add a percentage beside the claim so the strength of the finding is clearer.

**Q3.** What does a traceability matrix contain?
- A. Theme, participant, exact quote, context, whether it supports or contradicts, and verification status.
- B. Theme names only, kept short so the synthesis document stays easy to scan.
- C. The AI model version and date, so a reviewer can reproduce the same summary later.
- D. The list of interview questions, so a reviewer can see what each participant was asked.

**Q4.** Why chunk long notes before synthesis?
- A. Because the assistant cannot process long text at all and returns an empty answer.
- B. Because a longer output makes the synthesis look more thorough to reviewers.
- C. Because shorter sections contain fewer names, so anonymising can be skipped.
- D. Because long inputs get truncated or lose attribution, and chunks give checkpoints.

**Q5.** An AI proposes "users want biometric login" but no participant mentioned it. What is this?
- A. A fabricated solution presented as a finding, which you reject and record as unsupported.
- B. A valid insight, because it follows logically from the trust problems participants described.
- C. A useful counter-example showing where participants disagreed with the proposed theme.
- D. A sample limitation, since only five participants were interviewed about the product.

**Q6.** What is the difference between a theme and an insight?
- A. A theme is simply the longer version of an insight, written up in more detail.
- B. A theme is a pattern in the evidence; an insight interprets what it means for design.
- C. An insight is always a direct quote, while a theme is the label attached to it.
- D. There is no real difference, since both describe the same pattern from interviews.

**Q7.** Why record rejected themes?
- A. To make the document longer, since a fuller appendix looks more thorough.
- B. To satisfy the design tool, which requires a rejection row before export.
- C. To show the assistant where it went wrong, so its next answer improves.
- D. To preserve the audit trail and stop the same unsupported claim returning.

**Q8.** Which is a privacy failure?
- A. Pasting a transcript with a participant's phone number into a free chat tool.
- B. Using P1 and P2 as identifiers when quoting participants in the synthesis table.
- C. Storing the anonymised notes in a password-protected folder on the team drive.
- D. Removing an employer name from a quote before sending it for synthesis.

**Q9.** An AI summary says '8 out of 10 participants distrusted the app', but the learner only has six interview notes. What should they do first?
- A. Add four invented interviews so the sample matches the number the summary reports.
- B. Publish the 8/10 figure because a larger-sounding sample makes the finding persuasive.
- C. Reject the statistic, then check every claim against the six notes that actually exist.
- D. Ask the AI to explain its confidence, then quote that explanation in the report.

**Q10.** A themes table contains labels such as 'trust' and 'speed' but no quotes or participant IDs. What is missing?
- A. A more attractive colour scheme, so reviewers can tell the themes apart at a glance.
- B. More themes on the page, so the synthesis looks comprehensive rather than thin.
- C. Traceability from each theme back to specific evidence and participant IDs in the notes.
- D. A second AI summary, so the two outputs can be compared for agreement.

## Part B — Practical task

**Task.** Submit the eight-part synthesis pack.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] Input is anonymised, or the substitution is explained.
- [ ] Prompts and raw output are included.
- [ ] Every theme has a traceability row with a verified quote.
- [ ] At least three AI errors or weak claims are caught and corrected.
- [ ] Quantifiers match the sample size.
- [ ] Insights are labelled as interpretation.
- [ ] Counter-evidence is reported.
- [ ] Human review explains what only the researcher could know.
- [ ] No fabricated quote, participant or percentage.

## Part C — If you do not pass

**Retry variant.** Repeat the synthesis using **invented practice notes** that you write yourself, containing two deliberate contradictions and one single-participant observation. Ask the AI to synthesise, then audit it against your known ground truth. Submit the notes, the AI output, your audit and a 150-word note on which error was hardest to catch. This variant tests detection without risking real participant data.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
