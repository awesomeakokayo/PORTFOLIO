# Stop 3.4 Assessment — Prototyping

**Phase:** 3 · Figma fluency and design systems
**Prerequisite:** Stop 3.3
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** What is a flow starting point?
- A. The first component in the file, which the presentation opens by default.
- B. The frame where the prototype begins when a flow is presented.
- C. The last screen in the flow, where the participant finishes the task.
- D. The file cover, which introduces the project before the flow starts.

**Q2.** When is an overlay better than a new screen?
- A. For every navigation, because overlays avoid duplicating any screen.
- B. For long forms, because a sheet keeps the form shorter on mobile.
- C. For the home screen, because it should appear above the previous screen.
- D. For modals, menus and pickers that sit above the current context.

**Q3.** What must every overlay have?
- A. At least one clear way for the participant to close it.
- B. An animation, so the participant notices that the overlay appeared.
- C. A back button, so the participant can return to the previous screen.
- D. A logo, so the overlay looks like part of the same product.

**Q4.** Why use "After delay" sparingly in a test prototype?
- A. Figma charges for each delay, so long delays increase the plan cost.
- B. Delay triggers break scrolling, so a scrolling screen cannot use them.
- C. A delayed connection cannot be reset, so each session starts mid-flow.
- D. It makes the test slower without testing the thing you care about.

**Q5.** What is a dead end?
- A. A screen with too many buttons, so the participant cannot choose one.
- B. A screen with no forward or back path out of it.
- C. A screen with no images, so nothing indicates where to tap next.
- D. A screen with a modal that covers most of the underlying content.

**Q6.** Why add a test path to an error state?
- A. To make the prototype longer, so it looks more complete to reviewers.
- B. So you can observe recovery, which is often the most important behaviour.
- C. Because errors are required by Figma before a prototype can be presented.
- D. To show off the animation that plays when the error message appears.

**Q7.** What does "fix position when scrolling" do?
- A. Keeps an element in place while the content behind it scrolls.
- B. Locks the frame size, so the frame cannot be resized afterwards.
- C. Stops the prototype, so the participant cannot continue the flow.
- D. Pins the file, so it stays at the top of recent files.

**Q8.** A participant taps a label that is not connected. What should you do?
- A. Tell them not to tap there, and ask them to use the button instead.
- B. Ignore it, because the participant will find the right control eventually.
- C. Fix the prototype or the design so the affordance matches the interaction.
- D. Remove the label, so nothing on the screen looks tappable but is not.

**Q9.** A prototype's back button always returns to the home screen instead of the previous step. What should the learner fix?
- A. Remove the back button from every screen so the flow cannot loop.
- B. Add a longer transition animation, so the change of screen feels clearer.
- C. Change the button colour to show it is secondary rather than primary.
- D. Connect each back control to the screen the user actually came from.

**Q10.** A clickable prototype has no path to its error state, so the error screen cannot be reached during a test. What is the testing consequence?
- A. The prototype will load more slowly, because the missing screen is loaded.
- B. The error state will automatically appear at random during the session.
- C. The error state cannot be evaluated, so the test cannot show whether users recover.
- D. Participants will assume the product has no errors at all after testing.

## Part B — Practical task

**Task.** Submit the prototype link, the test-readiness note and the observation notes.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] Six or more connected screens in flow order.
- [ ] A named flow and a starting point.
- [ ] A working overlay with two exits.
- [ ] A scrolling screen with a fixed element.
- [ ] Loading and error states, with a recovery path.
- [ ] No dead ends; a back path from every screen.
- [ ] Test-readiness note covers reset and branches.
- [ ] Observation notes record a real person's hesitations.

## Part C — If you do not pass

**Retry variant.** Build a **booking flow** prototype with a seat-selection screen, a payment sheet overlay, a "seat taken" conflict, and a confirmation. Add a horizontal scroll for date selection. Submit the prototype, a test-readiness note and three observations from a person attempting to book two seats.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
