# Stop 0.4 Assessment — Using AI as a Tutor

**Phase:** 0 · Getting started
**Prerequisite:** Stop 0.3
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** Why can an AI assistant give a confident but false answer?
- A. It generates likely text from patterns instead of looking up verified facts.
- B. It always copies its answers from unreliable websites that it finds online.
- C. It is designed to lie to users when it does not know the correct answer.
- D. It only works while offline, so it cannot check any current information.

**Q2.** Which is a primary source for a WCAG contrast requirement?
- A. A design blog post that summarises the WCAG contrast rules clearly.
- B. The W3C WCAG 2.2 specification, including the success criteria text.
- C. A comment under a YouTube tutorial that quotes the contrast number.
- D. An AI answer that mentions WCAG and gives a contrast ratio.

**Q3.** An AI says: "A primary button is always blue and always the largest element on screen." What is the best verdict?
- A. Partly right: the role is right, but "always blue" and "always largest" are false absolutes.
- B. Right, because primary buttons are usually blue and usually the largest element.
- C. Wrong, because primary buttons are never blue and are never the largest element.
- D. Right, because the AI was trained on a large amount of design data.

**Q4.** What is the best follow-up when you suspect an AI claim is unsupported?
- A. Ask which official source supports the claim, request the sentence and section, and accept a clear no.
- B. Tell the assistant it is wrong, demand an apology, and ask for a corrected answer right away.
- C. Start a new chat and ask the same question again using slightly different wording this time.
- D. Accept the answer if it sounds confident and matches what you already expected to hear.

**Q5.** Why should you avoid pasting a real client's interview transcript into a free AI chat?
- A. It makes the answer arrive much more slowly than a short prompt would.
- B. The service may store or review personal and confidential data afterwards.
- C. It changes the language and spelling that the AI uses in its reply.
- D. It is impossible to paste a long transcript into the chat box.

**Q6.** Which prompt is most likely to produce a useful beginner explanation?
- A. "Explain UI to me, covering everything that a complete beginner might ever need to know about the subject area."
- B. "Explain what a primary button is, in a way that a complete beginner can easily understand and then use."
- C. "Write everything about design, including its full history, its main tools, its underlying theory and everyday practice in real detail."
- D. "You are a patient tutor: explain a primary button in 120 words, with jargon defined, one banking example and a test question."

**Q7.** An AI answer is accurate but leaves out an important exception. Which verdict fits best?
- A. Right, with a noted omission — unless the omission makes the advice misleading.
- B. Wrong, because any omission means the answer cannot be trusted.
- C. Partly right only if the answer also cites a checkable official source.
- D. Unclear, because the missing exception cannot be seen from the answer alone.

**Q8.** What is the main purpose of keeping a tutor log?
- A. To prove to a reviewer that you used an AI assistant during the course.
- B. To make each chat session faster by storing your previous prompts and answers.
- C. To build evidence that you can verify and judge AI output, not just generate it.
- D. To replace your course notes with a record of every AI conversation.

**Q9.** An AI assistant says the WCAG 2.2 AA minimum contrast for normal text is 3:1. What is the strongest verification step?
- A. Check the success criterion in the official W3C WCAG 2.2 document and record the result.
- B. Ask the same assistant to confirm its answer and explain where the number came from.
- C. Search for a blog post that agrees with the number and quote it as evidence.
- D. Use the number because it sounds precise and comes from a design tool.

**Q10.** A learner pastes a real client's interview transcript into a free AI chat and asks for themes. What is the first problem to address?
- A. Confidential personal data has been sent to a third-party service without a lawful basis or consent.
- B. The transcript is too long for the model to hold inside its context window.
- C. The AI may reply using American spelling instead of the learner's local spelling.
- D. The learner did not ask for a short summary first before requesting the themes.

## Part B — Practical task

**Task.** Submit your three-term AI tutor log and the 150-word reflection.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] Three terms, none of which are the worked example ("toast").
- [ ] Each entry has an exact prompt, a summary, a verdict and a specific reason.
- [ ] Each entry names a real source with a working URL.
- [ ] At least one entry records a genuine error or omission in the AI answer.
- [ ] No personal, client or confidential data appears in any prompt.
- [ ] The reflection names one thing the AI did well and one thing you will always check.

## Part C — If you do not pass

**Retry variant.** Repeat the log with three **accessibility** terms (for example: contrast ratio, focus indicator, alt text) and check every claim against W3C WCAG 2.2 or the WAI quick reference. This variant is harder because the standard is precise, so vague AI answers are easier to catch. Submit the new log plus a corrected version of one earlier entry where your verdict was too generous.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
