# Stop 5.0 Assessment — Web Basics

**Phase:** 5 · Design to build
**Prerequisite:** Phase 4 gate passed
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** Which language is responsible for the structure and meaning of a page?
- A. CSS, because it sets colour, type and spacing for the headings and paragraphs on the page.
- B. JavaScript, because it runs first and builds the headings, paragraphs and buttons the visitor sees.
- C. HTML, because it marks each heading, paragraph, list and button with tags that carry meaning.
- D. SQL, because it stores the page's headings and paragraphs in a table the browser reads.

**Q2.** What does CSS primarily control?
- A. The server's location and the domain name that visitors type to reach the page.
- B. The appearance and layout: colour, type, spacing, and how boxes sit on the page.
- C. The database queries that fetch records before the page is assembled for the visitor.
- D. The encrypted connection and the address the browser resolves before downloading any files.

**Q3.** A page looks fine on a laptop but requires horizontal scrolling on a phone. Which is the most likely missing piece?
- A. A JavaScript framework that redraws the layout whenever the screen is resized or rotated.
- B. The viewport meta tag, plus layouts that use max-width instead of fixed pixel widths.
- C. More images and larger headings, so the page fills the narrow screen instead of looking empty.
- D. A larger base font size, so the text scales down automatically on smaller phone screens.

**Q4.** What is the difference between padding and margin?
- A. Nothing meaningful: both add space around a box, so the two words describe the same property.
- B. Margin is the space reserved for text only, while padding applies to images and buttons.
- C. Padding only works on images, while margin is the property used to space paragraphs and headings.
- D. Padding is the space inside the border, while margin is the space outside it, between boxes.

**Q5.** Why is "Click here" a weak button label?
- A. It is too short to fill the button, so it looks unbalanced beside longer text on the page.
- B. It never says what will happen, so screen-reader users hear an identical label on every link on the page.
- C. Buttons are limited to one word in HTML, so a label like 'Call to order' is invalid.
- D. The phrase is not valid HTML markup, so browsers ignore it and announce an empty button.

**Q6.** What does GitHub Pages do?
- A. It designs the page automatically from a short description, then keeps the layout updated as content changes.
- B. It replaces the stylesheet with a generated theme, so you no longer write colour or spacing rules.
- C. It hosts the static files in a public repository and serves them at a shareable public URL.
- D. It compresses images and strips unused CSS on every upload, so pages load faster automatically.

**Q7.** Why should you never commit an API key to a public repository?
- A. Because the key adds several kilobytes to the file, which slows every clone and download of the repository.
- B. Because anyone who opens the public repository can read the key and use it, spending your quota or exposing data.
- C. Because GitHub deletes accounts that contain secrets, and you lose every repository along with the page you published.
- D. Because keys only function inside private repositories, so a public one silently disables the integration you built.

**Q8.** A page's text is readable but the layout breaks at 200% zoom. What is the main problem?
- A. Content and containers are fixed in ways that cannot reflow, so they push past the viewport when text grows.
- B. The font is too small at the default size, so increasing zoom exposes how little text fits on screen.
- C. HTML is the wrong language for a zoomable page, so the browser cannot recalculate the layout correctly.
- D. The server is slow to respond, so the browser draws the layout before all the styles have arrived.

**Q9.** A learner's page overflows horizontally at 320 px, forcing users to scroll sideways. Which check should they make first?
- A. Check that the viewport meta tag is present and that no container has a fixed width wider than 320px.
- B. Add more images and cards to fill the empty space, which usually stops the page stretching sideways.
- C. Increase the body font size to 24px so the text wraps sooner and no longer pushes the layout wider.
- D. Remove the `lang` attribute from the html element, which lets the browser recalculate the page width.

**Q10.** A button says 'Copied' but the clipboard is empty, and the code changes the label before any copy operation finishes. What is the defect?
- A. The button uses the wrong font, so the browser cannot attach the clipboard permission prompt to that element.
- B. The interface claims success before the asynchronous copy has finished, and there is no error fallback.
- C. The page has too many headings, which interrupts the script that writes the order number to the clipboard.
- D. The copy should run on page load rather than on click, so the clipboard is already filled.

## Part B — Practical task

**Task.** Publish your edited one-page profile and submit the URL, a screenshot, and your "what I changed and why" note.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] The page loads from a public URL on a device other than the one you built it on.
- [ ] All visible text has been changed from the starter; nothing identifies a real person or business without permission.
- [ ] At least one heading, paragraph, list, image or icon, and button are present and meaningful.
- [ ] Body text contrast is at least 4.5:1 and is recorded.
- [ ] Images have appropriate `alt` text, or `alt=""` if decorative.
- [ ] The page works at 320px width without horizontal scrolling.
- [ ] The button has a visible focus state and a label that describes its action.
- [ ] The note explains at least one failed attempt and the fix.
- [ ] No passwords, keys, phone numbers or personal addresses are in the repository.

## Part C — If you do not pass

**Retry variant.** If you do not pass, take a different starter page (a simple event invitation) and make the same four kinds of change — text, colour, layout, and one behaviour — then publish it to a **new** repository. Submit the new URL plus a two-column table listing each change and the check you ran on it. This proves the skill transferred, not just that you can repeat one file.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
