# Stop 1.1 Assessment — What Product Design Actually Is

**Phase:** 1 · Product thinking and research
**Prerequisite:** Phase 0 gate passed
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** Which sentence is a problem statement rather than a solution?
- A. Users need a chatbot on the home screen so they can get answers without waiting for an email reply.
- B. Customers cannot tell whether their payment succeeded, so they either pay twice or abandon the order.
- C. Add a progress bar to checkout so customers can see how many steps remain before they pay.
- D. Build a dashboard for managers so they can compare branch performance before the monthly finance report.

**Q2.** What is the main difference between UX and UI?
- A. UI is only for mobile apps, while UX is only for websites that people use on a laptop.
- B. UX is done by researchers, while UI is done by developers who turn the files into code.
- C. There is no practical difference between the two terms, because both describe how a screen looks.
- D. UX is the whole experience of completing the job, while UI is the visible and interactive layer.

**Q3.** "Reduce support calls about failed transfers by 20%." What kind of goal is this?
- A. A user goal, because it describes what a customer wants to achieve when sending money.
- B. A UI pattern, because support calls usually drop when the confirmation screen is redesigned.
- C. A business goal with a measurable target, because it names an organisational outcome and a number.
- D. A research method, because it requires interviews with customers before the number can be set.

**Q4.** A team decides to hide advanced settings to simplify the first-run experience. What is the trade-off?
- A. Faster to build for the team, but more expensive to host once the simplified screens finally ship.
- B. Better accessibility for screen readers, but worse performance on older phones with slow connections.
- C. No real trade-off, because simplification only removes clutter and never costs any user anything.
- D. Simpler for beginners, but potentially frustrating for experts who rely on those settings daily.

**Q5.** Which decision is primarily **research**?
- A. Choosing the primary button colour so the call to action stands out against the booking form.
- B. Setting the commission rate so drivers earn enough to stay on the platform through the year.
- C. Interviewing five drivers about how they decide when to accept a trip on a busy evening.
- D. Writing the error message for a failed card payment so customers know what to try next.

**Q6.** Which is a **constraint**, not a goal?
- A. The team aims to increase retention by 15%, so more customers return and order again next quarter.
- B. The team wants to become the market leader in the city before any competitor establishes itself.
- C. The product must work on 2G connections and low-end Android phones sold in the local market.
- D. The team wants to improve trust so first-time users feel safe entering their card details.

**Q7.** Why is "the product chose not to offer guest checkout" a design decision?
- A. Because omissions never matter, since users only judge what they can see on the checkout screen.
- B. Because it is a UI colour choice that changes how the checkout button looks to returning users.
- C. Because what a product refuses to do shapes effort, privacy and conversion as much as what it adds.
- D. Because competitors already do it, so matching them proves the decision was made deliberately and safely.

**Q8.** A designer says "users will love this". What is missing?
- A. A colour palette that matches the brand and makes the new feature feel familiar to returning users.
- B. Evidence or an explicit hypothesis with a plan to test whether users actually respond that way.
- C. A Figma file that shows the feature in each state so the team can review the interaction.
- D. A business model that explains who pays for the feature and what it costs to run each month.

**Q9.** A team is deciding to add a saved-recipient list, measure transfer completion, and change the confirmation button colour. How should these be classified?
- A. Product/UX decision, business or product metric, and UI decision respectively, in that same order.
- B. All three are UI decisions because each one appears on a screen that users interact with.
- C. All three are research decisions, because each one involves learning something from real users.
- D. The list is a metric, completion is UI, and colour is research into what users prefer.

**Q10.** A brief says the team must 'increase revenue by 15%' and calls that the user problem. What is wrong with the framing?
- A. Revenue targets are always forbidden in a brief, because designers cannot influence how money is earned.
- B. The percentage is too precise, so the brief should round it to a range the team can remember.
- C. The brief lacks a colour palette, so the team cannot tell which direction the design should take.
- D. A business outcome is being substituted for the user problem the design can actually address.

## Part B — Practical task

**Task.** Submit the ten-decision table, the three trade-off sentences and the 150-word answer.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] Ten decisions from at least three real products.
- [ ] At least two of each type: research, UX, UI, business.
- [ ] At least three mixed decisions with dominant and secondary type.
- [ ] At least two omissions treated as decisions.
- [ ] Evidence or "assumption" recorded for every row, with no invented statistics.
- [ ] One trade-off sentence per product.
- [ ] The 150-word answer uses at least five glossary terms correctly.

## Part C — If you do not pass

**Retry variant.** Classify ten decisions from **one** product across its full journey (signup, first use, repeat use, failure, cancellation). Ensure at least one decision is about **pricing or policy**, not interface. Write a 120-word paragraph on which type of decision was hardest to classify and why. Submit the new table plus a corrected row from your first attempt.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
