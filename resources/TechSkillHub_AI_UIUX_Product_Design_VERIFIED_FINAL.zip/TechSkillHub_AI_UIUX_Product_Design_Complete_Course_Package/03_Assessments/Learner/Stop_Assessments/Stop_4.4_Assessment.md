# Stop 4.4 Assessment — AI for Critique

**Phase:** 4 · The AI design workflow
**Prerequisite:** Stop 4.3
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** What makes a critique finding actionable?
- A. It names the element, principle, harm, evidence and the specific fix.
- B. It is written by an AI critic, which makes it thorough and consistent.
- C. It uses design jargon, which signals expertise to the reviewing team.
- D. It is long and detailed, covering every part of the screen at once.

**Q2.** The AI says a button fails contrast. What should you do first?
- A. Measure the actual colour pair, because the claim may be a false positive.
- B. Delete the button and rebuild it with a darker background colour.
- C. Change the colour first, then confirm the new pair meets the requirement.
- D. Ask the AI to suggest a corrected colour and apply its recommendation.

**Q3.** What is a false negative in critique?
- A. A real problem the critique missed because its method could not detect it.
- B. A problem that does not exist, reported confidently by the reviewing tool.
- C. A problem rated with a low severity because it affects very few users.
- D. A finding about colour contrast rather than about interaction behaviour.

**Q4.** Why run separate passes for heuristics, accessibility and content?
- A. Because a shorter prompt makes the assistant respond faster to each request.
- B. Because the assistant cannot run multiple checks in one prompt and stops early.
- C. Because WCAG requires separate passes, so accessibility is never mixed with heuristics.
- D. Because each pass produces more specific findings and makes verification easier.

**Q5.** What does a red-team pass add?
- A. A colour palette that makes the screen feel urgent to first-time users.
- B. Adversarial perspectives from specific roles that expose exploitation and failure modes.
- C. A faster prototype, because the tool generates the corrected screens itself.
- D. A guarantee that no usability problems remain before the design ships.

**Q6.** Severity should be based on…
- A. How easy the fix is, so quick improvements can be cleared from the list.
- B. The AI's ranking, because it has compared many similar screens before.
- C. The designer's own preference, since they know which issues matter most.
- D. Harm and frequency, not fix effort, because critical issues come first.

**Q7.** The AI suggests masking the full account number on a confirmation screen. Why might you reject it?
- A. Because masking is always wrong on any screen that shows a payment amount.
- B. Because the task requires verifying the full number, so masking defeats the purpose.
- C. Because masking is too easy to implement and adds no real design value.
- D. Because the AI cannot actually read numbers, so its suggestion is unreliable.

**Q8.** What should a rejected-findings log contain?
- A. Only the word rejected, so the table stays short and easy to scan.
- B. The finding and the specific evidence that justified rejecting it.
- C. The AI's apology and a note that it will try harder next time.
- D. A new design that resolves the finding without discussing it.

**Q9.** An AI critique returns 20 findings, including 'the design feels cluttered'. Which revision makes the critique usable?
- A. Keep all twenty, because a long list demonstrates thoroughness to stakeholders.
- B. Rewrite each as a specific observation with evidence, severity and next action.
- C. Delete every negative finding so the critique feels constructive to the team.
- D. Ask the AI to make the wording friendlier without changing the findings.

**Q10.** A review based only on screenshots misses a keyboard trap in the prototype. What kind of critique failure is this?
- A. A false positive, because the reviewer invented an issue that is not there.
- B. A visual hierarchy error, because the trap disrupts the reading order.
- C. A false negative, because the method could not observe the real issue.
- D. A content tone problem, because the keyboard behaviour confuses the copy.

## Part B — Practical task

**Task.** Submit the eight-part critique pack.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] A brief with role, task, standards and output format.
- [ ] Four passes completed.
- [ ] Verification table with labels and evidence.
- [ ] At least two false positives rejected with evidence.
- [ ] At least one false negative found independently.
- [ ] Severity ratings tied to harm and frequency.
- [ ] Action list with owner, fix and verification.
- [ ] Revised screen with at least three fixes.
- [ ] No accepted finding without evidence.

## Part C — If you do not pass

**Retry variant.** Critique a **competitor's public screen** instead of your own. Run the same four passes, verify findings, and write a 150-word note on which findings were context-dependent and could not be judged from a screenshot alone. Submit the pack and the note.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
