# Stop 2.5 Assessment — Accessibility and Inclusive Design

**Phase:** 2 · Visual and interaction foundations
**Prerequisite:** Stop 2.4
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** What does POUR stand for?
- A. Practical, Open, Usable, Responsive, the four headings used in the audit template.
- B. Private, Optimal, Universal, Reliable, the four qualities of an accessible page.
- C. Perceivable, Original, Useful, Responsive, the four stages of an audit.
- D. Perceivable, Operable, Understandable, Robust, the four principles behind every success criterion.

**Q2.** What is the WCAG 2.2 AA minimum contrast for normal text?
- A. 3:1, the threshold that applies to large text and essential icons.
- B. 4.5:1, the AA minimum SC 1.4.3 sets for normal-sized text.
- C. 7:1, the AAA target, which is stricter than the AA minimum asked for.
- D. 2:1, a decorative-only ratio that no text of any size may use.

**Q3.** What is the WCAG 2.2 AA minimum target size?
- A. 16 × 16 CSS px, the size at which icon-only buttons stop being usable.
- B. 44 × 44 CSS px, Apple's recommended size for comfortable finger targets.
- C. 24 × 24 CSS px, the minimum SC 2.5.8 sets for AA conformance.
- D. 48 × 48 CSS px, Material's recommended size for primary mobile controls.

**Q4.** Why is a 16 px icon with a 16 px hit area a problem?
- A. The icon is too large for the toolbar and crowds the controls beside it.
- B. Icons should never be used, because text labels are always clearer.
- C. It fails contrast, because the icon colour is too close to the background.
- D. The tappable area is too small for reliable touch, even if it looks fine.

**Q5.** A form shows errors only with a red border. Which criterion is at risk?
- A. 2.4.7 Focus Visible, because the field shows no outline when tabbed to.
- B. 1.4.1 Use of Color, because the error is conveyed by hue alone.
- C. 1.4.10 Reflow, because the field overflows at 320 px screen width.
- D. 3.1.1 Language of Page, because the error text is not language-tagged.

**Q6.** What does "not testable in this format" mean in an audit?
- A. The check is optional, so the auditor may skip it without recording anything.
- B. The criterion does not apply to this screen, so it can be removed.
- C. The designer forgot to run the check before submitting the audit.
- D. The current artifact cannot verify it, so it must be tested in the build.

**Q7.** Why is semantic HTML an accessibility issue?
- A. It makes pages smaller, because semantic tags compress better when served.
- B. It changes the default colours, which can lower the page's contrast ratio.
- C. It is required for search engine ranking, and accessibility is a side effect.
- D. Assistive technology relies on element roles and structure to announce the interface.

**Q8.** Which is an example of inclusive design beyond compliance?
- A. Passing a contrast checker on every text and background pair used.
- B. Adding alt text to every meaningful image and empty alt to decorative ones.
- C. Using a 24 px target for every control, which is the AA minimum.
- D. Allowing phone formats and informal addresses that match local naming reality.

**Q9.** A learner writes alt text for a chart showing monthly sales. Which alt text is most useful?
- A. A short description of the chart's purpose and the main trend.
- B. The single word chart, repeated once for each axis label.
- C. A full transcription of every monthly data point inside the attribute.
- D. An empty alt attribute, because the chart is decorative rather than informative.

**Q10.** A learner removes the default focus outline because it looks ugly, and keyboard users can no longer see where they are. Which requirement has failed?
- A. Colour contrast for body text, which must reach 4.5:1 on white.
- B. Image alt text, which must describe every meaningful picture.
- C. Page language declaration, which tells screen readers how to pronounce.
- D. Visible keyboard focus, so the current interactive element can be located.

## Part B — Practical task

**Task.** Submit the twelve-check audit, corrected screen, prioritised fixes, developer notes and reflection.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] At least twelve checks across POUR.
- [ ] Evidence for every result, with ratios or measurements where relevant.
- [ ] Failures honestly marked, including "not testable".
- [ ] A corrected screen with at least five fixes applied.
- [ ] Developer notes that name element, value, behaviour and reason.
- [ ] A prioritisation with a stated rationale.
- [ ] The reflection distinguishes compliance from inclusion with a concrete example.

## Part C — If you do not pass

**Retry variant.** Audit a **public government or banking page** instead of your own screen. Do at least twelve checks, including keyboard navigation and 200% zoom in a browser. Record three failures and write developer notes for each. Then compare: which failures are design decisions, and which are engineering? Submit the audit and a 120-word comparison.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
