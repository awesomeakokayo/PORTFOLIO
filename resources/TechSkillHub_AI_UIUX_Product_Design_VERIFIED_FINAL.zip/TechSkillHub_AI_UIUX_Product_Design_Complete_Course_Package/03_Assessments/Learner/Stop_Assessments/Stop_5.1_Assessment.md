# Stop 5.1 Assessment — Handoff That Developers Love

**Phase:** 5 · Design to build
**Prerequisite:** Stop 5.0 passed, or equivalent ability to publish a page
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** What is the main purpose of a handoff pack?
- A. To make the design file look tidy, with neat layers and frames that are easy to browse later.
- B. To replace usability testing by settling every question before the design reaches a real user.
- C. To prove the designer worked long hours by showing a detailed record of every revision made.
- D. To give builders the specs, states and rules they need to build the screen correctly without guessing.

**Q2.** Which is a testable acceptance criterion?
- A. "At 320px wide, the primary button stays visible without horizontal scrolling."
- B. "The page feels premium and modern, with generous spacing and a calm, confident tone."
- C. "Use nice spacing and a clean type scale throughout the checkout flow."
- D. "Make the primary button pop so the main action is obvious at a glance."

**Q3.** Why must disabled buttons still be readable?
- A. Because they are decorative placeholders that show the layout, so their contrast does not matter much.
- B. Because disabled buttons are always clickable, so users need to read the label before pressing them.
- C. Because users need to understand what is unavailable and why, and low contrast hides that information.
- D. Because screen readers skip disabled controls entirely, so the label must carry the meaning visually.

**Q4.** What belongs in a state matrix?
- A. Only the default state, drawn once, because the other states are left to the developer's judgment.
- B. Every relevant state, with its trigger, visual change and behaviour, including loading, error and empty.
- C. A list of the colour names used on the screen, so the palette stays consistent across builds.
- D. The project timeline, so the team knows which screens are finished and which are still in review.

**Q5.** A developer asks "what happens if the API fails?" What kind of gap is this?
- A. A visual gap about the size, spacing and colour of the elements on the screen.
- B. A naming gap about how the layers, components and files in the design are labelled.
- C. A pricing gap about what the feature costs to run and who pays for the extra requests.
- D. A behaviour and content gap: what the screen does and says after a failed request.

**Q6.** Why is `Frame 427` a bad layer name?
- A. It carries no meaning, so nobody can tell what it holds, find it later or reuse it.
- B. It is too long for Figma's layer field, so the name gets truncated before the useful part.
- C. Figma forbids names that contain numbers, so the layer stays unnamed and cannot be exported.
- D. It slows the file down, because the editor re-reads every numeric label on each save.

**Q7.** What should an open-questions table include?
- A. Only questions that are already answered, so the table reads as a settled record of decisions.
- B. A list of every layer in the file, so reviewers can trace each one back to a component.
- C. The designer's opinions about the product, recorded so the team knows what to prioritise next.
- D. The question, its owner, the date it is needed by, and a default if it stays unanswered.

**Q8.** Which asset handover is most useful?
- A. A screenshot of the icon, taken at the size it appears on the finished screen.
- B. A JPG of the whole screen, so the developer can crop the icons out of it later.
- C. A link to a competitor's site, where the same icon can be inspected and copied.
- D. A named SVG with a 24×24 viewBox and `currentColor`, so it scales and inherits text colour.

**Q9.** A developer asks what should happen when the payment API returns a timeout. What should the handoff provide?
- A. A higher-resolution screenshot of the happy path, so the developer can match the finished layout exactly.
- B. The relevant states, the exact message, the recovery action, and the rule preventing a duplicate payment.
- C. A note saying 'handle errors gracefully', leaving the wording and the retry logic to the developer.
- D. A link to the brand guidelines, so the error message uses the approved tone and colour palette.

**Q10.** A handoff contains final screens but no loading, empty or error states. What will the developer most likely have to do?
- A. Ship the happy path only and ignore failures, because nothing in the pack says they matter.
- B. Ask the designer for a colour palette, since the screens do not show which colours to use.
- C. Reduce the page weight automatically, because incomplete screens usually mean the build is unfinished.
- D. Invent behaviour and copy for those states, which creates rework and drifts from the design intent.

## Part B — Practical task

**Task.** Submit the handoff pack for one screen, plus a short record of a review with a peer or developer.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] One screen is fully specified, with values and units.
- [ ] At least 6 states are defined with triggers and behaviour.
- [ ] Content rules cover at least 4 text slots, including overflow.
- [ ] Assets are listed with names, formats, sizes and licence status.
- [ ] A naming convention is defined and applied.
- [ ] Edge cases cover content, data, network, permission and device.
- [ ] 5–10 acceptance criteria are testable.
- [ ] Open questions have owners and defaults.
- [ ] The review record shows at least three questions asked and how the pack was improved.
- [ ] No real personal or confidential data is included.

## Part C — If you do not pass

**Retry variant.** Take a different screen — a login form or a search results page — and produce a **one-page** handoff using only a table and five annotations. The constraint forces you to prioritise the decisions that actually block a build. Submit the one-pager plus a list of what you deliberately left out and why.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
