# Stop 1.3 Assessment — Problem Framing

**Phase:** 1 · Product thinking and research
**Prerequisite:** Stop 1.2
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** Which is a job story?
- A. As a user, I want a dashboard, so that I can see my money and check every payment that leaves.
- B. Build a confirmation modal that repeats the amount and the recipient name before the sender finally taps send.
- C. Users need trust, because sending money to a new account feels risky without a visible confirmation before paying.
- D. When I pay a new seller, I want to check who I am paying, so I can avoid losing money.

**Q2.** What is wrong with "Users need a notification feature" as a problem statement?
- A. It names a solution, not the problem, so no alternative response can be judged against it.
- B. It is too short, so it cannot explain who is affected by the missing notification and why.
- C. It has no metric, so nobody can tell whether the notification reduced the confusion it targets.
- D. It is not in English, so the brief cannot be reviewed by the stakeholders who approve scope.

**Q3.** A metric has a target but no baseline. What should the brief do?
- A. State that the baseline is unknown and describe how it will be measured before launch.
- B. Invent a plausible baseline, because a target only becomes meaningful once it has a number.
- C. Remove the metric, because a measure without a baseline cannot be tracked or reported.
- D. Use a competitor's number as your baseline, because their data reflects the same market.

**Q4.** What is a guardrail metric?
- A. A measure you must not make worse while improving the main metric, such as fraud reports.
- B. The main measure of success, the one number the team watches to judge whether the change worked.
- C. A metric that only applies to accessibility, such as whether labels remain visible at 200% text size.
- D. A target set by the finance team, because money and risk are their responsibility rather than design's.

**Q5.** Which is a well-written non-goal?
- A. We will not do social features, because they are not needed for the confirmation job and add moderation cost.
- B. We will not do social features, because the team has not decided whether they belong in this release.
- C. Maybe social later, once the confirmation work ships and the team has spare capacity to revisit it.
- D. No bad ideas, because the brief should stay open to whatever the team discovers during the research.

**Q6.** Why should a problem brief avoid solution nouns?
- A. They make the page longer, because each named component needs a sentence explaining how it works.
- B. They are grammatically incorrect, because a noun cannot follow the verb that introduces the problem.
- C. They close off better alternatives and make the problem impossible to judge independently of a fix.
- D. They confuse developers only, because stakeholders read the brief for budget rather than for detail.

**Q7.** Which is the strongest evidence label for "users want a recipient photo"?
- A. Evidence, because a participant suggested it during the interview and asked why it was missing.
- B. Fact, because it is a common pattern in banking apps and other products people already trust.
- C. Hypothesis, because no participant was shown or asked about a photo in a way that tests the claim.
- D. Metric, because it can be counted whenever a user taps the recipient photo in the app.

**Q8.** What does a good brief do when the research is thin?
- A. Fills gaps with confident language, because a brief that hedges will not convince anyone to fund it.
- B. Removes the problem statement, because a problem without evidence cannot be framed precisely enough to test.
- C. States the limits, labels assumptions and names the next research question to close the gap.
- D. Copies a competitor's brief, because their research already covers the same market conditions and users.

**Q9.** A brief has a target of 'reduce failed transfers by 20%' but no baseline. What is the most honest next step?
- A. Invent a baseline of 30% so the target looks achievable and the team can start planning work.
- B. State that the baseline is unknown, define how it will be measured, and call the target provisional.
- C. Remove the metric and rely on opinion, because a number nobody can verify invites false confidence.
- D. Change the target to 100% to motivate the team, since ambitious goals usually raise performance.

**Q10.** A problem brief lists 'users need a notification feature' as the problem. What is the specific framing defect?
- A. It is too short to be a problem statement, because a frame needs several sentences to explain context.
- B. It does not mention the colour of the notification, so the team cannot build the screen consistently.
- C. It names a solution before establishing the user situation and the barrier that design should address.
- D. It uses the word users, which is too broad for a brief that must name who is affected.

## Part B — Practical task

**Task.** Submit the one-page brief and the 120-word "What I am not solving" note.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] All ten sections present, in order, on one page.
- [ ] At least one job story and one problem statement with no solution nouns.
- [ ] Every factual claim traceable to evidence or labelled assumption/hypothesis.
- [ ] One primary metric with definition, baseline (or measurement plan) and target.
- [ ] One guardrail and one counter-metric.
- [ ] At least two non-goals with reasons.
- [ ] At least one accessibility risk and one privacy/ethical risk with mitigations.
- [ ] Three open questions.
- [ ] No invented statistics, quotes or baselines.

## Part C — If you do not pass

**Retry variant.** Rewrite the brief for a **different** problem in the same product: not the confirmation step, but the **failed-transfer recovery** experience. Keep it to one page. Add a "decision I changed after writing v1" paragraph explaining what the new frame revealed. Submit the new brief plus a marked-up version of your first brief showing three cuts.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
