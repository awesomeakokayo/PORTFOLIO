# Stop 3.2 Assessment — Auto Layout and Constraints

**Phase:** 3 · Figma fluency and design systems
**Prerequisite:** Stop 3.1
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** What does "Hug contents" do?
- A. The child expands to fill all the space available inside its parent frame.
- B. The frame resizes itself to fit the children it contains, growing or shrinking.
- C. The text inside the frame becomes bold whenever the frame is resized.
- D. The frame locks in place so it cannot be moved or resized by accident.

**Q2.** A button stretches across the whole screen unexpectedly. What is the likely cause?
- A. It is set to Fill width inside a parent that is also Fill.
- B. It has a stroke applied, which adds width around the button's edges.
- C. The label text is too short, so the button expands to fill the gap.
- D. It is a component instance, and instances always stretch to the parent.

**Q3.** Which is the best sizing for body text in a card?
- A. Fixed width and fixed height, so the text block stays the same size.
- B. Hug width and fixed height, so the block grows sideways with the copy.
- C. Fill width and auto height, so the block fills the card and grows downward.
- D. Fixed width and Hug height, but only when the body text is short.

**Q4.** When are constraints more appropriate than auto layout?
- A. For every text block, because constraints keep copy inside its column.
- B. For lists, because constraints keep each row aligned as items change.
- C. For backgrounds, overlays and elements pinned to the frame's edges.
- D. Never, because auto layout has replaced constraints in current Figma.

**Q5.** Why nest auto layout frames?
- A. To increase the file size deliberately, so Figma reserves more space for layers.
- B. Because Figma requires nesting before auto layout can be applied to a frame.
- C. To avoid using components, since nested frames already behave like instances.
- D. To give different groups their own spacing rhythms, alignment rules and padding.

**Q6.** A fixed-height card clips a long title. What is the fix?
- A. Shrink the font until the title fits inside the existing fixed height.
- B. Set the card height to Hug and let the title wrap onto two lines.
- C. Remove the title from the card and rely on the description instead.
- D. Add a vertical scrollbar inside the card so the title can be scrolled.

**Q7.** What does min/max width protect against?
- A. Colour contrast failures, by widening the area behind low-contrast labels.
- B. Very long or very short content producing extreme, unusable layouts.
- C. Missing fonts, by reserving space for fallback typefaces in every label.
- D. Slow prototypes, by limiting how many elements load at each breakpoint.

**Q8.** What is the real test of an auto layout component?
- A. How it behaves when the content and the container size change.
- B. How clean and balanced it looks with the sample content in place.
- C. How many layers it contains when the component is fully expanded.
- D. Whether it is built as a component rather than a loose group.

**Q9.** A toolbar must keep 16 px padding and an 8 px gap while its buttons change. Which Figma structure best supports this?
- A. A group whose buttons are each positioned by eye at the correct spacing.
- B. A single exported image of the toolbar, placed once and reused on each screen.
- C. An auto layout frame with 16 px padding and an 8 px gap between buttons.
- D. A frame with absolutely positioned buttons and a height that never changes.

**Q10.** A card's title is clipped when translated into a longer language. The card has a fixed height. What is the most likely fix?
- A. Reduce the font size until the translated title fits the fixed height.
- B. Let the card height hug its content and allow the title to wrap.
- C. Shorten the translation without consulting the owner of the content.
- D. Add a horizontal scrollbar to the card so the title can be read.

## Part B — Practical task

**Task.** Submit the three components, the screen at three widths, the behaviour table and the note.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] Three components with auto layout and documented sizing rules.
- [ ] Card grows with long titles and description.
- [ ] List row keeps the trailing action visible at 320 px.
- [ ] Form field includes label, helper and error states.
- [ ] Screen tested at 320, 393 and 430 px.
- [ ] Behaviour table covers all three components.
- [ ] No fixed heights on text containers.
- [ ] The note names one rule that was hard to get right and how it was resolved.

## Part C — If you do not pass

**Retry variant.** Build a **responsive pricing card** that changes from a vertical stack at 320 px to a horizontal layout at 768 px. Use auto layout wrap or two variants, and explain the trade-off. Test with a long plan name and a missing price. Submit both widths and a 120-word note on which approach you chose and why.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
