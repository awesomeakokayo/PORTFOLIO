# Stop 0.5 Assessment — Your First Screen

**Phase:** 0 · Getting started
**Prerequisite:** Stop 0.1 (Figma account), Stop 0.3 (interface vocabulary)
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** What is the main difference between a frame and a group in Figma?
- A. A frame has a fixed size and can clip and export; a group only keeps layers together.
- B. A group can contain text layers, while a frame can only contain shapes and images.
- C. A frame is always transparent, while a group takes the colour of its contents.
- D. A group appears in the layers panel, while a frame is hidden from that panel.

**Q2.** Why set X, Y, W and H with numbers instead of dragging?
- A. Dragging is not allowed in Figma once a frame has been created.
- B. Numbers make the file smaller because Figma stores fewer position values.
- C. Dragging changes the font of the layer that you are moving.
- D. Numbers are repeatable and precise, which makes later changes and handoff reliable.

**Q3.** You export a frame and get a blank white image. What is the most likely cause?
- A. PNG cannot export frames, so the format saves an empty white canvas instead.
- B. The font used in the frame is missing, so no text can be rendered.
- C. The file is too large, so Figma stops rendering before the export finishes.
- D. The frame has no fill and you exported the wrong layer or an empty area.

**Q4.** Which is a good reason to repeat the amount inside the primary button label?
- A. It makes the button wider, which makes it easier to tap with a thumb.
- B. It is required by app stores before a payment feature can be published.
- C. It forces a final read of the most error-prone detail before an irreversible action.
- D. It fills the empty space on the right side of the button rectangle.

**Q5.** Why name layers during the build rather than at the end?
- A. Names are needed to find, reuse and hand off objects later, and renaming at the end is error-prone.
- B. Figma deletes any layer that still has no name when you close and reopen the file.
- C. Named layers export faster because the renderer can skip over all of the unnamed items in the file.
- D. Naming changes the stacking order of the layers, which makes the whole file easier to read.

**Q6.** What makes a change "deliberate" rather than decorative?
- A. It uses a different colour from the one used in the first version.
- B. It states the expected effect on the user and how you would check it.
- C. It is reviewed and approved by an experienced designer before you continue.
- D. It makes the screen taller so that more content fits inside the frame.

**Q7.** Why keep both v1 and v2 frames?
- A. To keep a record of the older design in case the new one is rejected.
- B. To make the change and its effect visible and easy to review later.
- C. To satisfy Figma's requirement for a duplicate before any frame is exported.
- D. To practise exporting the same frame twice at two different image scales.

**Q8.** A beginner aligns a value to the label next to it, and the value ends up in the middle of the row. What should they align it to instead?
- A. The title at the top of the content area, which shares the same left edge.
- B. The primary button in the footer, which is centred across the screen.
- C. The status bar at the top, which the operating system draws for you.
- D. The frame's right margin, so values line up along a consistent edge.

**Q9.** A learner wants to build a 393 by 852 mobile screen in Figma. Which starting choice best supports later responsive work?
- A. Create a frame at 393 by 852 and place elements inside it using a layout structure.
- B. Draw loose rectangles directly on the canvas with no frame around them at all.
- C. Use a group as the screen and set a fixed width for the whole group.
- D. Start at 1440 pixels wide and shrink the export down to phone size later.

**Q10.** A learner's mobile mock-up looks correct at 393 px but every element overlaps when the frame is narrowed to 320 px. What is the most likely cause?
- A. The text uses a system font that is not installed on the phone.
- B. The file has too many pages, which slows down the layout engine.
- C. The export scale is set to 2x, so the exported image is twice as wide.
- D. Elements are positioned with fixed coordinates instead of a layout that can reflow.

## Part B — Practical task

**Task.** Submit the Figma file link (view access) and a PDF containing the two PNG exports, your build notes and your 120–180 word rationale.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] A named frame at a stated phone size.
- [ ] At least 12 named layers with consistent naming.
- [ ] Three levels of text hierarchy.
- [ ] One primary action aligned with alignment tools.
- [ ] Two versions with exactly one deliberate change.
- [ ] The rationale states the expected user effect and how it would be checked.
- [ ] Exports are not blank, not cut off, and readable at phone size.
- [ ] No real bank branding, logos or personal data.

## Part C — If you do not pass

**Retry variant.** Recreate a **login screen** instead, with: a title, two fields with labels, a primary button, a tertiary "Forgot password?" link, and one helper text. Build it at 360 × 800. Then make one change that improves **error recovery** (for example, adding a password visibility toggle or moving the error message next to the field), and justify it. Submit both versions and a 150-word rationale.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
