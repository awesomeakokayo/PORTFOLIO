# Stop 5.4 Assessment — Responsive, Mobile-First and Low-Bandwidth Design

**Phase:** 5 · Design to build
**Prerequisite:** Stop 5.2 passed; a working page to adapt
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** What does mobile-first mean?
- A. Designing only for phones, since that is where most visitors to a site will arrive.
- B. Shipping a mobile app instead of a website, because apps handle small screens better.
- C. Starting with the smallest layout and adding complexity only as the screen allows.
- D. Hiding the least important content on desktop, so the phone version stays the reference.

**Q2.** When should you add a breakpoint?
- A. When the content needs more room or becomes hard to read at the current width.
- B. At every popular device width, so the layout matches the phones and tablets people own.
- C. Every 100 pixels, so the layout changes smoothly as the window is resized.
- D. Only at 1024 pixels, because that is where desktop browsers usually start.

**Q3.** Why provide `width` and `height` on images?
- A. To make them load faster, because the browser can request a smaller file for the slot.
- B. To improve the alt text, since the description is generated from the image's proportions.
- C. To enable lazy loading, which only works when dimensions are declared in the markup.
- D. To reserve the right space before the file arrives, so the page does not shift while loading.

**Q4.** Which image should generally NOT be lazy-loaded?
- A. The hero image that is the largest contentful paint element on first load.
- B. A gallery image far below the fold, which nobody sees until they scroll.
- C. A footer logo that sits at the very bottom of every page on the site.
- D. A decorative image at the bottom of the page, hidden from assistive technology.

**Q5.** What is a performance budget?
- A. The money spent on hosting and bandwidth each month, tracked against the project's running costs.
- B. An agreed limit on page weight, requests or timing metrics that the team measures against.
- C. The number of designers assigned to a team, which determines how much polish a page receives.
- D. A CSS framework that ships with performance defaults, so teams do not configure them.

**Q6.** A page shows a blank screen for six seconds on a slow network. What is the design failure?
- A. The brand colour is wrong for the audience, so the page feels unfamiliar when it appears.
- B. The font is too large, so fewer words fit and the text takes longer to wrap.
- C. The page has too many headings, so the browser waits for all of them to render.
- D. There is no honest loading state and no prioritised content, so the screen stays blank.

**Q7.** Why is `clamp()` useful for headings?
- A. It makes text bold automatically, so headings stand out without a separate font-weight rule.
- B. It replaces media queries entirely, so a page needs no breakpoints for any layout change.
- C. It creates a fluid size range with minimum and maximum bounds, so headings stay legible.
- D. It compresses images automatically, so large photos no longer slow the heading down.

**Q8.** Which is the most honest offline behaviour?
- A. Pretending the save worked, so the interface stays optimistic and the user is not distracted.
- B. Showing that the user is offline and that saving will resume when the connection returns.
- C. Hiding the page until the network returns, so the user never sees a stale or partial state.
- D. Reloading the page continuously until it succeeds, so the user sees the freshest data.

**Q9.** A page's large hero image is lazy-loaded below the fold, but it is actually the first visible element. What is the likely effect?
- A. The largest contentful paint is delayed, because the browser waits before requesting the image.
- B. The image will be sharper, because the browser can pick a higher-resolution file.
- C. The page will use less data and look identical immediately, since the image is deferred.
- D. The HTML will become invalid, because loading is not allowed on the first visible element.

**Q10.** A page shows a blank white screen for six seconds on a slow connection before any text appears. What is the design failure?
- A. The text is too large, so the browser needs longer to lay out each paragraph.
- B. The page uses too many headings, which delays the first paint of the content.
- C. No early readable content or loading state, so the user cannot tell whether it is working.
- D. The logo is the wrong colour, so the page looks broken before the text arrives.

## Part B — Practical task

**Task.** Submit the responsive, low-bandwidth page with before/after measurements and a trade-off note.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] No horizontal scrolling at 320px; primary action is reachable.
- [ ] Layout remains usable at 200% zoom.
- [ ] At least one image uses `srcset`/`sizes` or is correctly compressed for display size.
- [ ] All images have dimensions and appropriate `alt`.
- [ ] Total page weight is at or below 500 KB, or the overage is explained with a plan.
- [ ] LCP on Slow 4G is 2.5 s or less, or the miss is measured and explained.
- [ ] CLS is 0.1 or less.
- [ ] Loading, offline and error behaviour are described and at least one is implemented.
- [ ] Before/after table includes weight, requests, LCP, CLS and INP.
- [ ] The note states what was removed, what was kept and what could not be tested.

## Part C — If you do not pass

**Retry variant.** Take a different page — a simple article page with one image — and hit the same budget of 300 KB and LCP 2 s. Because there is less to remove, you must focus on image strategy, font loading and critical CSS. Submit the measurements and a 100-word explanation of the hardest trade-off.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
