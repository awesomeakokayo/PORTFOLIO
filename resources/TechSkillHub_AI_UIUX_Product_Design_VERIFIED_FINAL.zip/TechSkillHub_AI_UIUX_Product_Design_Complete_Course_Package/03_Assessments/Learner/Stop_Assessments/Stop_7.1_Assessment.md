# Stop 7.1 Assessment — Case Study Writing

**Phase:** 7 · Capstone and career launch
**Prerequisite:** Phase 6 gate passed
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** What should a case study lead with?
- A. A one-line summary stating the problem, the action taken and the result, placed before any images.
- B. A gallery of polished final screens, arranged to show the visual range of the finished product.
- C. A short list of the design tools used, with a note on how long you have used each.
- D. A short personal biography describing your education, design influences and how you became interested in the field.

**Q2.** Which is a precise problem statement?
- A. New users abandon at payment because the delivery fee appears late, so the total feels untrustworthy.
- B. The interface looks outdated next to competitors, so the visual style should be refreshed before launch.
- C. Users want a better experience overall, and the product should feel more modern and more welcoming.
- D. The app needs more colour and personality, because the current palette feels flat on most screens.

**Q3.** Why show a rejected alternative?
- A. To demonstrate the judgement behind the decision by explaining what you considered and why you set it aside.
- B. To fill space in the case study so the document reaches the required length without extra research.
- C. To criticise the teammates who preferred the other option, showing that your own judgement was the correct one.
- D. To show that you can use more design tools than the other candidates applying for the same role.

**Q4.** What is the difference between an output and an outcome?
- A. An output is what you made, such as a prototype; an outcome is what changed for users or the business.
- B. An output is longer and more detailed, while an outcome is a brief note that summarises the same work.
- C. An outcome is a screenshot of the finished screen, while an output is the written report that explains it.
- D. There is no meaningful difference, because both terms describe the same deliverables listed in the final handoff.

**Q5.** How should a small-sample result be reported?
- A. Users loved the new flow, and several said they would happily recommend it to friends and colleagues.
- B. Conversion increased by 40%, proving that the redesign worked and should now be rolled out to everyone.
- C. The sample was small but encouraging, so the detailed numbers can safely be left out of the summary.
- D. Three of five participants improved, and the result comes from a small sample with no controlled test.

**Q6.** A client project is under NDA. What is acceptable?
- A. Publish the full project, because the work is yours and the client's confidentiality agreement covers only their staff.
- B. Publish a reconstructed example with a clear label, or describe the method without any confidential client detail.
- C. Invent a different client name and change the logo, so the work can be shown without identifying anyone.
- D. Publish the internal metrics only, since figures reveal far less about the client than screenshots or names would.

**Q7.** What makes a lesson useful?
- A. It is inspirational and reminds the reader why design work matters in a difficult and fast-moving industry.
- B. It mentions a famous company, which shows that the method has already been validated at a large scale.
- C. It is short enough to fit in one word, so readers remember it easily after finishing the case study.
- D. It is specific about what you would do differently and about what you would test next time.

**Q8.** Why include a short version?
- A. Recruiters never read long text, so the short version is the only part of the case study anyone will see.
- B. It replaces the long version entirely, which becomes unnecessary once the key points have been compressed into a card.
- C. Portfolio cards and introductions need a scannable summary that leads interested readers to the full case study.
- D. It is required by Figma when a project is published, and the portfolio cannot go live without one.

**Q9.** A learner's case study opens with 'I designed a beautiful banking app' and then shows final screens. What is the most important missing element?
- A. More decorative mockup frames, so the finished screens look consistent with a polished case study.
- B. A longer list of software tools, including the exact versions used for each screen and each prototype.
- C. The user problem, evidence, decisions and outcomes that together explain why the design exists at all.
- D. A brighter colour palette, so the banking app feels more modern than the current screens do.

**Q10.** A case study reports 'users loved the new design' after five informal conversations, with no quotes or counts. What is the problem?
- A. The case study is too short, and a longer narrative would make the same point more convincingly.
- B. Five conversations are never allowed in a portfolio, so the evidence should have come from a survey.
- C. A small, undocumented sample is being turned into an unsupported claim that users loved the design.
- D. The design should have used more colours, since visual appeal is what makes users respond well.

## Part B — Practical task

**Task.** Submit the full case study and the 150-word short version.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] One-line summary includes problem, action and result.
- [ ] Context states the product, user and your specific role.
- [ ] Problem statement includes who, what, barrier and why it matters.
- [ ] At least two decision points include rationale.
- [ ] At least one rejected alternative and one trade-off are explained.
- [ ] 4–6 images carry evidence and have captions.
- [ ] Results include counts, denominators and limitations.
- [ ] Lessons are specific and include a next step.
- [ ] Participants and clients are anonymised or permission is documented.
- [ ] Course work is labelled as course work; no invented metrics.

## Part C — If you do not pass

**Retry variant.** Rewrite the same project as a **one-page decision memo** for a product manager: problem, three options, recommendation, evidence, risk, decision needed. No images. This forces you to separate reasoning from visual presentation.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
