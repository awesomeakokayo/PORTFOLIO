# Stop 4.5 Assessment — AI for Content and Microcopy

**Phase:** 4 · The AI design workflow
**Prerequisite:** Stop 4.4
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** Which button label is strongest for an irreversible transfer?
- A. "Submit" is compact, familiar from forms, and consistent with the rest of the flow.
- B. "Send ₦25,000" names the action and repeats the amount before an irreversible step.
- C. "OK" is short and familiar from dialogs, so it keeps the footer uncluttered.
- D. "Continue" suggests progress to the next step rather than completion of a transfer.

**Q2.** When writing recovery microcopy after a failed payment, which four pieces should the message carry?
- A. Apology, blame, error code and close, so the user knows the team is sorry.
- B. What happened, why, what to do now and what is safe.
- C. Title, body, image and link, so the message matches the page layout.
- D. Error, retry, cancel and help, so every possible next action is offered.

**Q3.** Why is "Oops!" a weak error message?
- A. It trivialises the problem and gives no information or route forward.
- B. It is too formal for a consumer payment app used on mobile.
- C. It is too long for an error area that has limited space.
- D. It is inaccessible to screen readers that read punctuation aloud.

**Q4.** What should an empty state do?
- A. Show plausible fake data so the screen looks populated and complete.
- B. Use a large illustration only, since text would clutter the empty area.
- C. Explain what would be here and offer the first useful action.
- D. Hide the screen until the user has created their first record.

**Q5.** What is the best way to test microcopy?
- A. Ask a few people whether they like the wording and tone.
- B. Count the words and compare the total with the style guide limit.
- C. Run it through a grammar checker and fix every flagged sentence.
- D. Ask a reader to restate what happened and what they would do.

**Q6.** "Trusted by 10,000 users" with no data is…
- A. An unverified claim that must be substantiated or removed.
- B. Good social proof, because a large number reassures new visitors.
- C. A tone choice, since confident copy suits a competitive market.
- D. A localisation issue, because numbers are grouped differently by region.

**Q7.** Why does tone change while voice stays constant?
- A. Because users get bored by the same tone and need variety to stay engaged.
- B. Because voice is only for marketing pages, while product screens use tone.
- C. Because the AI cannot hold a consistent voice across several screens.
- D. Because the emotional context changes: success, error and danger need different warmth.

**Q8.** What is localisation beyond translation?
- A. Changing the font so the text suits the scripts used in each market.
- B. Adding flags to the language switcher so users recognise their region quickly.
- C. Translating word for word while keeping the same sentence structure everywhere.
- D. Adapting currency, formats, idioms, terminology and cultural context for local readers.

**Q9.** A learner is writing the primary button for an irreversible transfer of ₦12,500. Which label is strongest?
- A. "Submit" is the conventional label and tells users the form is complete.
- B. "Send ₦12,500 now" names the action and the exact amount leaving the account.
- C. "Continue" keeps the flow moving without repeating the amount the user has already seen.
- D. "OK" is quick to scan and fits the compact width of the footer button.

**Q10.** A landing page says 'Trusted by 10,000 users' but the team has no source for the number. What is the main problem?
- A. It is fabricated social proof and must be removed or verifiable.
- B. The number is too small to impress visitors and should be larger.
- C. The sentence is too short to explain what the product actually does.
- D. It should be in all capitals so the claim stands out on the page.

## Part B — Practical task

**Task.** Submit the six-part microcopy pack.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] Voice and tone page with rules and four contexts.
- [ ] Five before/after elements.
- [ ] Five AI variants with edits and rejection reasons.
- [ ] Claim check table with unverified claims removed or substantiated.
- [ ] A reader test with a verbatim restatement.
- [ ] No blaming, false urgency or fake social proof.
- [ ] Reflection is specific about AI's limits.

## Part C — If you do not pass

**Retry variant.** Rewrite the copy for a **failed payment at an agent** where the user has already handed over cash and the agent's app shows a pending state. Include a message for the agent and one for the customer. Test both with a reader and submit the copy, the claim check and a 150-word note on which message was harder to make honest.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
