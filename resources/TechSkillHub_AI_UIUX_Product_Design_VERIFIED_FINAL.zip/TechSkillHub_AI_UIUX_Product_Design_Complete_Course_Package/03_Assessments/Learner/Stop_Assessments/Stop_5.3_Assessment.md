# Stop 5.3 Assessment — Design Systems in Code

**Phase:** 5 · Design to build
**Prerequisite:** Stop 5.2 passed; a small Figma component set from Phase 3
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** When a token set moves from Figma into CSS, what is the difference between a primitive and a semantic token?
- A. Primitive tokens are only used in code, while semantic tokens exist only inside the Figma file.
- B. Semantic tokens always describe colours, while primitive tokens also cover spacing and radius values in the file.
- C. There is no real difference; the two names describe the same value at different points in the file.
- D. A primitive is a raw value like green-700; a semantic token names a job and points to it.

**Q2.** Why use `rem` for font sizes?
- A. Because it is shorter to type than pixels, keeping the stylesheet compact and easier to scan.
- B. Because it makes text bold by default, so headings need fewer separate font-weight declarations.
- C. Because HTML requires relative units for text, and pages using pixels fail validation.
- D. Because it respects browser zoom and user font settings, unlike a fixed pixel size.

**Q3.** A Figma variant has no code equivalent. What is the correct response?
- A. Ignore it for now, since the coded components already cover the main actions the product needs.
- B. Either implement the variant in code or remove it from the Figma file entirely.
- C. Add a screenshot of the variant to the code folder so developers can reference it.
- D. Rename the variant so it matches a code class, and leave the implementation unchanged.

**Q4.** What is drift?
- A. An animation that plays when a token changes, showing the old and new values.
- B. A type of token that stores a value the team wants to review before release.
- C. A Git branch where designers and developers merge their changes before a release.
- D. A mismatch between the value in the design source and the value in the built product.

**Q5.** Which is a good reason NOT to add a component to the system?
- A. It appears on every screen, so keeping one canonical version would reduce repeated work.
- B. It is used once, on a single page, and is unlikely to appear again.
- C. It carries accessibility requirements, such as labels, focus behaviour and announced errors.
- D. It has several variants, such as primary, secondary, disabled and loading states.

**Q6.** What should component documentation include?
- A. Purpose, usage rules, the exact HTML, states, accessibility behaviour, do/don't examples and known limitations.
- B. A single screenshot of the component, so readers can see what it looks like in use.
- C. The designer's name and contact details, so readers know who to ask about changes.
- D. A list of every colour in the company palette, with hex values and contrast ratios.

**Q7.** Why connect help text to an input with `aria-describedby`?
- A. So assistive technology announces the help text together with the field when it receives focus.
- B. So the input can be made wider, giving long help text more room beside the field.
- C. So the form can validate the answer before it is submitted to the server.
- D. So the input changes colour when the help text is present, matching the design spec.

**Q8.** A button's focus outline is removed because it "looks ugly". What is the problem?
- A. Nothing is wrong, because focus outlines are optional decoration that designers may remove.
- B. Keyboard users lose the only indication of which element is focused, so they cannot navigate reliably.
- C. The page becomes slower, because browsers recalculate the outline on every key press.
- D. The grid breaks, because the outline was contributing to the column widths of the layout.

**Q9.** A design token changes in Figma but the coded component still uses the old hex value. What should the team add?
- A. A larger component library, so the team has more ready-made parts to choose from.
- B. A rule that developers memorise every hex code, so they notice when a value changes.
- C. A drift check that compares the token source with the coded values and flags mismatches.
- D. A new logo, so users associate the refreshed visual identity with the updated colours.

**Q10.** A coded design system uses pixels for all font sizes, and users who increase their browser text size see no change. What is the problem?
- A. The page has too many semantic tokens, which override the browser's text-size preference.
- B. The CSS file is too small to hold the media queries that respond to larger text.
- C. The buttons use the wrong border radius, which stops the layout from scaling proportionally.
- D. Absolute pixel sizes ignore the user's text-size preference, so relative units such as rem are needed.

## Part B — Practical task

**Task.** Submit the coded design system, usage page and drift table.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] At least 8 primitive and 6 semantic tokens are defined and used.
- [ ] Type and spacing scales are documented, with units explained.
- [ ] Two components each support at least three states.
- [ ] One composed example uses both components together.
- [ ] A usage page shows HTML, variants, accessibility behaviour and do/don't rules.
- [ ] A drift table has at least 6 rows and one real mismatch corrected.
- [ ] Focus is visible, labels are connected, and contrast meets 4.5:1 for text and 3:1 for UI boundaries.
- [ ] A governance note states who changes tokens and what is checked before merging.
- [ ] No real client or personal data is present.

## Part C — If you do not pass

**Retry variant.** Take a different pair of components (for example a badge and an alert) and build only the tokens and states, with no layout. The constrained version tests whether you can define an API and a state model without hiding behind visual design. Submit the token file, the state table and a 100-word note on what you left out.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
