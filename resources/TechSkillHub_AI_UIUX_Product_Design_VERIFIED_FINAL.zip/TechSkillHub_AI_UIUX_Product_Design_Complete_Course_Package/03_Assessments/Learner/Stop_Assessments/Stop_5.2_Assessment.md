# Stop 5.2 Assessment — Turning a Design Into Working UI With AI Coding Tools

**Phase:** 5 · Design to build
**Prerequisite:** Stops 5.0 and 5.1 passed
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** What is the most important part of using an AI coding tool well?
- A. Writing the longest possible prompt, so the model has every detail it could ever need.
- B. Accepting the first result quickly, because speed is the main advantage these tools offer.
- C. Using the most expensive model, since higher price usually means fewer invented details.
- D. Specifying intent clearly and reviewing the output against explicit criteria before accepting it.

**Q2.** Why is a clickable `<div>` a problem?
- A. It renders more slowly than a native button, so the interaction feels delayed on older phones.
- B. It cannot be styled with CSS, so it never matches the visual design of the rest of the page.
- C. It breaks the CSS grid it sits in, which collapses the surrounding layout on narrow screens.
- D. It is not focusable or operable by keyboard, and it gives assistive tech no button role or name.

**Q3.** The generated CSS uses `#333` when your token is `#171717`. What should you do?
- A. Leave it as it is, since #333 and #171717 are visually close enough for most visitors.
- B. Delete all the generated CSS and start again, because one stray value proves the output is unreliable.
- C. Replace it with the token, so the theme stays consistent and later token changes still apply.
- D. Add a second token for #333, so both greys are documented and available for future screens.

**Q4.** Which is a reason to reject and rebuild rather than patch?
- A. One wrong colour, because repainting a single element by hand is slower than rebuilding.
- B. A missing semicolon, because broken syntax means the whole stylesheet cannot be trusted.
- C. A fundamentally wrong structure, such as a table-based layout with inline styles throughout.
- D. A typo in a comment, because comments are read by the model on every later prompt.

**Q5.** Why test at 320px and 200% zoom?
- A. To make the page load more slowly, which reveals how it behaves on a weak connection.
- B. To check that content reflows readably for small screens and for users with low vision.
- C. Because AI tools cannot write media queries, so the layout must be verified by hand.
- D. To increase the contrast ratio of body text, which improves as the layout gets narrower.

**Q6.** What belongs in a prompt log?
- A. Only the final code, so the log stays short and shows exactly what was shipped.
- B. The prompts, output summaries, and what you accepted, changed or rejected, with reasons.
- C. The model's marketing description, so readers know which product version produced the code.
- D. Your password and account details, so the tool can resume the session on another machine.

**Q7.** A generated page loads a 900 KB icon font for three icons. What is the best fix?
- A. Keep the font, because polished icons matter more than a few hundred kilobytes on a portfolio page.
- B. Add more icons to the page, so the 900 KB font is amortised across more visible content.
- C. Load a second icon font as a fallback, in case the first one fails to arrive.
- D. Replace the font with three inline SVGs or a small sprite, which draws only what you need.

**Q8.** You cannot explain what a generated JavaScript function does. What should you do?
- A. Ship it anyway, since the page works and users never see the code behind it.
- B. Ask the tool to explain it, then either understand it well enough or remove it.
- C. Rename the function so its purpose is clearer, and leave the body unchanged.
- D. Add a comment saying 'AI wrote this', so future readers know the code is unverified.

**Q9.** An AI coding tool generates a clickable card using a `<div>` with a click handler. What is the best correction?
- A. Add a cursor-pointer style so the card looks clickable, and leave the markup as it is.
- B. Add a tabindex to the div so it can receive focus, and change nothing else.
- C. Use a native button or link, keeping the styling, keyboard behaviour and visible focus style.
- D. Replace the card with an image of the action, which cannot be misused by a keyboard.

**Q10.** A generated page looks correct but cannot be operated with a keyboard, and focus disappears after the first field. What review was missed?
- A. A colour palette review, checking that every token used on the page matches the brand.
- B. A keyboard and focus review of the rendered page, not just a visual comparison with the design.
- C. A content word-count check, confirming that every label and paragraph fits inside its slot.
- D. A logo placement review, comparing its position on each breakpoint against the brand guide.

## Part B — Practical task

**Task.** Build one screen with AI assistance and submit the page, prompt log, review table and reflection.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] The page renders and matches the handoff's core layout and tokens.
- [ ] Semantic HTML is used for actions, headings, landmarks and form labels.
- [ ] All interactive elements are keyboard reachable with a visible focus state.
- [ ] Body text contrast is at least 4.5:1; large text and UI boundaries at least 3:1.
- [ ] The page reflows at 320px without horizontal scrolling and remains usable at 200% zoom.
- [ ] At least two non-default states work (for example loading and error).
- [ ] No unexplained hard-coded values that contradict the tokens.
- [ ] The prompt log covers at least 6 prompts with accept/change/reject decisions.
- [ ] The review table covers at least 10 checks.
- [ ] The reflection names one real risk the tool introduced and how you handled it.

## Part C — If you do not pass

**Retry variant.** Rebuild the same screen **without AI**, using only your handoff pack, and then compare the two versions in a table: time taken, accessibility issues, responsiveness issues, code you understand. The comparison is the deliverable. It proves you can judge the tool rather than depend on it.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
