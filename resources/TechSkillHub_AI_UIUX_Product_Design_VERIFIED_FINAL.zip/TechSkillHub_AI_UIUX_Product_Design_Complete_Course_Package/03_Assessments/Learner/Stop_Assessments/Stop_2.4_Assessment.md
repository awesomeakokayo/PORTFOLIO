# Stop 2.4 Assessment — Interaction and States

**Phase:** 2 · Visual and interaction foundations
**Prerequisite:** Stop 2.3
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** Why is "Try again" dangerous after an unknown transfer outcome?
- A. It is too long for the primary button and wraps onto two lines.
- B. It is inaccessible, because screen readers announce the two words poorly.
- C. It requires a confirmation dialog, which slows the recovery path down.
- D. The first attempt may have succeeded, so retrying can duplicate the transfer.

**Q2.** When is a spinner with no label acceptable?
- A. For waits of several minutes, when the user has nothing else to do.
- B. For very short waits, or when the activity is already obvious.
- C. Never, because an unlabelled spinner is always an accessibility failure.
- D. Only on desktop, where screens have room for a supporting caption.

**Q3.** What are the four parts of a good error message?
- A. Error code, timestamp, affected user name and the full stack trace.
- B. Apology, blame for the mistake, a retry prompt and a close button.
- C. A title, a supporting image, a primary button and a small footer.
- D. What happened, why it happened, what to do now, what is safe.

**Q4.** A dashboard loads six sections and one fails. What is the best state?
- A. Blank the whole page and show one generic error where the dashboard was.
- B. Show invented sample figures in the failed section so the layout looks complete.
- C. Redirect the user to the home page and ask them to try the dashboard later.
- D. Show the five loaded sections and mark the failed one with a retry.

**Q5.** Which action needs confirmation rather than undo?
- A. Liking a post, because the like appears instantly in other people's feeds.
- B. Adding an item to a cart, because the total updates on the next screen.
- C. Changing a filter, because the results list reloads with a new ordering.
- D. Permanently deleting an account, because all of the data is unrecoverable.

**Q6.** What is wrong with "Invalid input" as an error?
- A. It is too polite, so users do not realise that something has actually failed.
- B. It is too long to fit beside the field on a narrow mobile screen.
- C. It does not say what is wrong, why, or how to fix it.
- D. It relies on colour alone, and the message carries no icon.

**Q7.** Why disable the submit button during processing?
- A. To make the button look busy so the interface feels responsive.
- B. To improve the contrast between the button label and its background.
- C. Because WCAG 2.2 requires submit buttons to be disabled while loading.
- D. To prevent duplicate submissions and show that the action is underway.

**Q8.** What should an empty state avoid?
- A. An explanation of why the section is empty and what belongs here.
- B. Fake content that pretends the user already has activity to look at.
- C. A first action that lets the user create the first item.
- D. A short headline that names the state in a few words.

**Q9.** A transfer request times out and the app does not know whether the money left the account. What should the interface show?
- A. A Try again button as the primary action, with the amount still filled in.
- B. A success message, because the request left the device and reached the bank.
- C. An outcome-unknown state that checks status and tells the user not to retry yet.
- D. A blank screen until the user pulls to refresh and reload the balance.

**Q10.** A dashboard spinner has run for two minutes with no message, timeout or retry. What is missing?
- A. A bounded waiting state with an explanation, a timeout and a recovery action.
- B. A brighter spinner colour so the loading state stands out on the page.
- C. More animation around the spinner so the progress feels continuous to the user.
- D. A larger logo above the spinner so the brand remains visible while loading.

## Part B — Practical task

**Task.** Submit the state map, variants, error messages, destructive-action decisions, worst-moment analysis and usability observation.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] At least eight states, including loading, empty, error, success and offline.
- [ ] A visual variant for each state.
- [ ] Every error has the four parts and a recovery route.
- [ ] Every destructive action has a stated confirm/undo/status-check decision.
- [ ] No state is a dead end without a route forward.
- [ ] The worst-moment analysis identifies a real harm and a mitigation.
- [ ] The usability observation records a person's actual response.

## Part C — If you do not pass

**Retry variant.** Design the states for a **booking flow** (book a seat on a bus) instead of a transfer. Include a "seat taken while you were paying" conflict state, a "payment succeeded but booking failed" state, and an offline state. Submit the map, the variants and a 120-word note on which conflict was hardest to resolve fairly.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
