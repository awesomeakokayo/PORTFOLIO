# Stop 7.3 Assessment — Portfolio and Presence

**Phase:** 7 · Capstone and career launch
**Prerequisite:** Stop 7.1 passed; at least two case studies drafted
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** What should the first screen of a portfolio answer?
- A. Your life story, told from childhood, so visitors understand the experiences that shaped your design taste.
- B. Every tool you have used, listed by category, so visitors can confirm you know the relevant software.
- C. What you do, who you do it for, and what proof the visitor can see immediately.
- D. Your favourite colour and typeface, so the page expresses a distinctive personal style right away.

**Q2.** Which case study title is strongest?
- A. Making delivery costs visible before checkout, and rebuilding trust in the final total.
- B. Checkout redesign, covering the payment form, the fee display and the confirmation screen.
- C. Project 3 final final, the version submitted after the last round of client feedback.
- D. UI exploration, a visual study of colours, cards and buttons for the checkout flow.

**Q3.** How many case studies should a beginner portfolio show?
- A. Three strong ones, or fewer if only fewer are strong, with the site labelled honestly.
- B. As many as possible, because a large archive shows range and proves you have shipped often.
- C. Exactly ten, because a round number signals a complete and well-organised body of work.
- D. Only one, because a single deep project is always stronger than several shallower ones.

**Q4.** Why compress portfolio images?
- A. To reduce load time and data cost on mobile, where most visitors first open the portfolio.
- B. To make the images slightly blurry, so visitors focus on the writing instead of the screenshots.
- C. To hide confidential details inside the screenshots without having to edit each image by hand.
- D. To improve search ranking only, since page speed does not affect how visitors judge the work.

**Q5.** A client project is under NDA. What should you do?
- A. Publish it anyway, because the portfolio is personal and the agreement binds the company rather than you.
- B. Change the client's name and publish, since the work is unrecognisable once the logo is removed.
- C. Publish the metrics only, because numbers are abstract and reveal nothing about the client's product.
- D. Get permission, anonymise the details, or publish a clearly labelled reconstruction of the project.

**Q6.** What makes a portfolio accessible?
- A. A dark theme, because high-contrast dark backgrounds are easier for everyone to read on a phone.
- B. A loading animation, because motion signals progress and keeps visitors patient on slower connections.
- C. A PDF download, because a fixed document preserves the layout for every visitor on every device.
- D. Proper headings, alt text, sufficient contrast, visible keyboard focus and captions for any embedded video.

**Q7.** Why align one professional profile with the portfolio?
- A. To post more often, because regular publishing is what keeps a profile visible in crowded feeds.
- B. To collect more followers, because a larger audience makes employers much more likely to reply.
- C. To create a consistent, recognisable impression and reduce confusion for anyone who checks both places.
- D. Because the platforms require it, and profiles that do not match a linked site may be restricted.

**Q8.** What is the best test of your home page?
- A. You like it, because your own judgement is the only reliable measure of clarity and visual quality.
- B. A stranger can say what you do within 30 seconds of opening the page on a phone.
- C. It has many animations, because motion keeps visitors on the page long enough to read the text.
- D. It uses the latest framework, because modern tooling signals to employers that your skills are current.

**Q9.** A portfolio home page opens with a large abstract illustration and the words 'I am passionate about design'. What should replace it first?
- A. A longer biography starting from childhood, so visitors understand the full path that led to design.
- B. More abstract illustrations, so the page feels visually consistent and memorable at first glance to visitors.
- C. A clear statement of who the designer helps, with what problem, and a link to proof.
- D. A list of every tool the designer has opened, ranked by how confidently each one is used.

**Q10.** A portfolio's case study images are 5 MB each and the home page takes 12 seconds to load on mobile data. What is the main problem?
- A. Uncompressed images make the portfolio slow on mobile and contradict the user-centred claims it makes.
- B. The case studies are too short, so visitors leave before they reach the results or the lesson.
- C. The portfolio has too many colours, which makes the layout feel busy on a small screen.
- D. The designer has too many case studies, and each one adds weight to the home page.

## Part B — Practical task

**Task.** Publish the portfolio and submit the URL plus screenshots and an improvement note.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] Live URL works in a private window.
- [ ] Positioning statement names who, outcome and approach.
- [ ] Three case studies (or fewer, with a reason) have problem-led titles and results.
- [ ] About section is under 250 words and includes a contact route.
- [ ] Site works at 320px with no horizontal scrolling.
- [ ] Images are compressed and have `alt` text.
- [ ] Headings, links, focus states and contrast pass basic accessibility checks.
- [ ] A professional profile matches the site's positioning.
- [ ] All work is published with permission and participants are anonymised.
- [ ] No invented clients, results or job titles.

## Part C — If you do not pass

**Retry variant.** Build a **one-page text-only** portfolio with three case study summaries and contact details. No images, no animations. If the positioning and results are clear without visuals, the argument works; then add visuals selectively.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
