# Stop 2.1 Assessment — Layout, Grid, Spacing and Hierarchy

**Phase:** 2 · Visual and interaction foundations
**Prerequisite:** Phase 1 gate passed
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** Why use a spacing scale instead of choosing each gap by eye?
- A. It creates consistency and removes arbitrary decisions that accumulate into visual noise.
- B. It keeps the design file smaller, because repeated gap values can be stored once.
- C. It is required by WCAG, which sets minimum spacing for all text blocks.
- D. It makes body text render larger, so fewer elements are needed per screen.

**Q2.** In a 4-column mobile grid with 24 px margins and 16 px gutters, what is the content width on a 393 px screen?
- A. 393 px, the width of the frame before either 24 px margin is deducted.
- B. 345 px, after subtracting both 24 px margins from the 393 px frame.
- C. 369 px, after subtracting a single 24 px margin from the 393 px frame.
- D. 321 px, after subtracting both margins and then one 24 px gutter again.

**Q3.** Which technique best groups a label with its value?
- A. Make the gap inside the pair smaller than the gap between neighbouring pairs.
- B. Draw a bordered box around each pair so the grouping is explicit.
- C. Give every label its own colour so related values are easy to spot.
- D. Centre each label and value in the row so the pair looks balanced.

**Q4.** A screen has a 36 px title, a 34 px subtitle, a 32 px amount and a 30 px button label. What is the main problem?
- A. The screen has too much contrast between its four main text elements.
- B. The text is too small to read, so each element needs a larger size.
- C. The four sizes are so close that hierarchy reads as noise instead of order.
- D. The elements sit on no shared grid, so nothing lines up vertically.

**Q5.** What is the fastest first response to a crowded screen?
- A. Reduce every text size by about 2 px so the screen holds more content.
- B. Remove or defer content that does not support the task at hand.
- C. Add divider lines between sections so the content is clearly separated.
- D. Add a second accent colour so the sections become easier to tell apart.

**Q6.** What does the squint test reveal?
- A. Whether the colour pairs on the screen reach the required contrast ratio.
- B. Whether the design file will export cleanly to a shareable image format.
- C. Whether the visible text has been proofread for spelling and grammar.
- D. Whether the intended hierarchy still survives once fine detail is blurred away.

**Q7.** Why is optical alignment sometimes needed?
- A. Because grids are optional once the designer trusts their own eye.
- B. Because users generally prefer deliberate asymmetry to perfectly even spacing.
- C. Because mathematically equal spacing can look uneven around round or irregular shapes.
- D. Because Figma cannot align circles and rounded icons to a grid.

**Q8.** A confirmation screen puts the primary button first in the reading order. Why is that a problem?
- A. Buttons should never be visible before the user has read every other element.
- B. It invites commitment before the facts are checked, which is risky for irreversible actions.
- C. It makes the screen taller than the viewport and forces the user to scroll.
- D. It breaks the spacing scale by placing a large element above smaller ones.

**Q9.** A learner is placing a balance label and value on a row. Which alignment choice best supports scanning?
- A. Centre every label and value independently so each row looks symmetrical.
- B. Place each value directly beneath its label with no gap between them.
- C. Align all labels to the left edge and all values to one right edge.
- D. Use a different alignment on each row so the list feels less repetitive.

**Q10.** A card's title, body text and button all have the same 16 px gap between them. What is the most likely hierarchy problem?
- A. The card uses too many colours, so the eye cannot tell which part matters.
- B. Equal spacing fails to group related content and separate the action from the description.
- C. The button is too large for the card and crowds the body text above it.
- D. The body text is written in sentence case, which flattens the card's hierarchy.

## Part B — Practical task

**Task.** Submit the before/after layout, annotations, change list, 150-word explanation and five-second test notes.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] Before and after versions of the same screen.
- [ ] A visible grid with consistent margins and gutters.
- [ ] At least eight spacing annotations using values from the scale.
- [ ] No more than three type sizes and one accent colour.
- [ ] A stated intended reading order that matches the design.
- [ ] Five-second test notes with verbatim answers from one person.
- [ ] The explanation links each technique to the reading order, not to taste.

## Part C — If you do not pass

**Retry variant.** Lay out a **settings screen** with eight rows, each with a label and a toggle, plus a section header and a destructive "Delete account" action. Use a 4-column grid and the same spacing scale. Then produce a second version for a **low-vision user** at 200% text size, and explain what breaks and how you fixed it. Submit both versions and a 120-word note on which layout decision was hardest.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
