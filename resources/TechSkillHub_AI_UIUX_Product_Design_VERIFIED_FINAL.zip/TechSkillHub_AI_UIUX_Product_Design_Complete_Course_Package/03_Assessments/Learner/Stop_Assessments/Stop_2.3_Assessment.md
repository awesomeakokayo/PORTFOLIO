# Stop 2.3 Assessment — Components and Patterns

**Phase:** 2 · Visual and interaction foundations
**Prerequisite:** Stop 2.2
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** Which control should turn a setting on immediately, with no Save step?
- A. A checkbox, because it records a choice that is applied when the form is saved.
- B. A radio button, because it shows a small set of options side by side.
- C. A dropdown, because it hides the list until the user opens it.
- D. A toggle, because it changes the setting at once with no confirmation step.

**Q2.** When is a dropdown a poor choice?
- A. When the list holds forty options and the user must find one bank.
- B. When the option labels are long enough to wrap onto two lines.
- C. When the user is on a mobile screen with limited vertical space.
- D. When only two or three options exist and all could be shown.

**Q3.** What is the difference between a button and a link?
- A. A link is always blue and underlined, while a button uses a filled background.
- B. A button can only be used once, whereas a link can be followed repeatedly.
- C. A button triggers an action, while a link navigates or reveals more content.
- D. There is no real difference; both simply respond when the user clicks them.

**Q4.** Which content is best as a list rather than a card?
- A. A product with an image, a price and an Add to cart action.
- B. A promotional banner announcing a seasonal discount across the store.
- C. A photo gallery of customer images from the past month.
- D. Ten beneficiaries, each with a name and a bank and nothing else.

**Q5.** What must a text field label do?
- A. Disappear once the user starts typing so the field looks less cluttered.
- B. Sit inside the field as grey placeholder text until the input begins.
- C. Stay optional, so only the fields a user cares about carry a label.
- D. Remain visible above the field so its purpose is never lost.

**Q6.** Which is a good empty-state message?
- A. 'No saved beneficiaries yet. Save someone you pay often to skip this next time,' plus an action.
- B. 'No data is available for this section right now,' with no explanation and no action.
- C. 'Nothing here yet,' shown with a small illustration but no route forward for the user.
- D. A sad face illustration on its own, with no text message and no button at all.

**Q7.** Why is a visible focus state essential?
- A. It makes the interface look modern and up to date with current design trends.
- B. It raises the control's contrast ratio automatically whenever the ring appears.
- C. Keyboard users need to see which control will receive their next input.
- D. It matters only on forms, where several fields sit close together.

**Q8.** A toggle is used for "Subscribe to marketing emails" inside a form with a Save button. What is wrong?
- A. The toggle implies immediate effect, yet the setting only applies after Save.
- B. Nothing is wrong, because toggles are always acceptable for binary settings.
- C. It should be a link, because subscribing is really a navigation choice.
- D. It should be a table, because the preference is one row of data.

**Q9.** A learner must let users choose one of three delivery speeds before confirming an order. Which control is the best fit?
- A. A dropdown that hides two of the three speeds until the user opens it.
- B. A toggle switch for each speed, so users can enable any they like.
- C. A free-text field where the user types the speed they want.
- D. A radio group showing all three speeds and what each one costs.

**Q10.** A learner uses a toggle for 'Email me offers' inside a form that only takes effect when the user presses Save. What is the interaction problem?
- A. The toggle is too small to see, so users miss it beside the longer fields.
- B. The label is written as a sentence rather than a short verb phrase.
- C. The form has no Submit button, so the setting can never be applied.
- D. The toggle implies an immediate change, but the setting only applies on Save.

## Part B — Practical task

**Task.** Submit the component sheet, the applied screen, the choice defence and the missing-states list.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] Seven components, each with the required states.
- [ ] Buttons have primary, secondary and tertiary variants.
- [ ] Text field includes visible label, helper, error and focus states.
- [ ] Usage notes include do, don't and an accessibility note.
- [ ] One screen uses at least four components consistently.
- [ ] The choice defence compares two controls and names the nearest alternative.
- [ ] Missing states are listed honestly.

## Part C — If you do not pass

**Retry variant.** Build a **five-component sheet for a desktop dashboard**: side navigation, table, filter bar, status badge and modal. Add a "density" variant for the table (comfortable and compact). Document when each density is appropriate. Submit the sheet plus a 120-word note on how desktop choices differ from mobile and why.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
