# Stop 0.1 Assessment — Your Workspace

**Phase:** 0 · Getting started
**Prerequisite:** None. This is the first stop.
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** What is the main reason for choosing a single "source of truth" folder?
- A. It makes the folder structure look tidy and consistent in the screenshots you submit for review.
- B. It removes the need for descriptive file names because the folder itself records what each item is.
- C. It guarantees that every file is backed up automatically even if the computer is lost or replaced.
- D. It prevents two copies of the same work from competing as the official version of the file.

**Q2.** Which file name follows the course naming rule?
- A. `final design new.fig`, saved on the desktop after the latest changes.
- B. `2026-11-02_sendmoney_home-screen_v1.fig`, saved directly inside the project's design folder.
- C. `SendMoney-final-v2.fig`, saved in the shared team folder for review.
- D. `home screen.fig`, saved in Downloads immediately after the export finished.

**Q3.** You close the browser tab of a cloud design tool and reopen the site. The work is missing. Which cause is least likely?
- A. You are signed into a different account from the one that created the file.
- B. The file name put a date first, ahead of the project name and the version number.
- C. The file sits in a team or project space that is not currently open in the view.
- D. The autosave never completed because the connection dropped while you were still editing the file.

**Q4.** What is the difference between "Download" and "Export"?
- A. Export only works for text files, while download handles images and every other kind of media.
- B. They are the same action with different buttons, so either one produces an identical copy.
- C. Download copies a file to your device; export creates a file in a different format.
- D. Download only works for images, while export converts text into a printable document.

**Q5.** Why should you avoid writing real passwords in a plain text file?
- A. Text files cannot be opened again later, so the passwords would be lost permanently.
- B. Anyone who gets access to the device or the cloud account can read them.
- C. Passwords stored in text files stop autosave from working in the browser.
- D. The file becomes too large to open on an older computer or phone.

**Q6.** Which behaviour best reduces data use while studying?
- A. Leaving autoplay switched on so you never have to press play yourself.
- B. Watching every video at the highest quality so nothing looks blurred.
- C. Setting video quality manually and downloading the notes once on Wi-Fi.
- D. Keeping twenty tabs open so you can return to them later in the week.

**Q7.** A folder tree separates lessons, exercises, projects, research and exports. Which is the strongest reason?
- A. It keeps the total number of files on the computer much smaller over time.
- B. Reviewers require exactly six top-level folders before they will pass a project.
- C. Different kinds of work need different handling, and evidence must stay findable later.
- D. Cloud storage only allows six folders, so the tree has to match that limit.

**Q8.** You are on a shared computer and cannot rely on local files surviving. What is the most sensible workspace decision?
- A. Keep everything in the Downloads folder because it opens fastest on that machine.
- B. Email the files to yourself and delete the originals so nothing is left behind.
- C. Use a cloud folder as the source of truth and sign out when you finish.
- D. Save only screenshots of your work so the other user cannot open the files.

**Q9.** A learner keeps the official course folder in the cloud but edits a downloaded copy on the Desktop for a week. What should they do to restore one source of truth?
- A. Keep both copies and add the word final to the Desktop file name before submitting.
- B. Delete the cloud folder and work only on the Desktop copy from now on, permanently.
- C. Email the Desktop copy to yourself and leave both folders unchanged for another week.
- D. Upload the edited copy, replace the cloud version, and delete the Desktop copy once checked.

**Q10.** A learner saved a Figma file yesterday but cannot see it in Recents today. They are signed into the same account. Which check is most likely to explain the disappearance?
- A. Assume Figma deleted the file because the name contained a date at the start.
- B. Create a new account and start the same file again from the beginning of the process.
- C. Check whether the file sits in a team or project space that is not currently open.
- D. Clear the browser cache completely before searching for the file in Recents again.

## Part B — Practical task

**Task.** Set up your course workspace, create the design account (and, if you choose, an AI account), and prove that you can recover a saved file. Submit:

1. A screenshot of your full folder tree with the folders expanded.
2. Your completed workspace checklist (the one-page text file).
3. The `Kudi` project folder from section 8, zipped, containing the four subfolders and the README.
4. One exported PNG from your Figma practice file.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] A single source of truth is named in the checklist.
- [ ] The folder tree contains the six top-level folders and Phase 0–7 subfolders, or a documented equivalent that serves the same purposes.
- [ ] At least four files use the naming rule with date, project, item and version.
- [ ] The checklist records the selected tools and confirms each chosen account is ready; if the no-AI route is used, it is recorded as a valid choice. No email addresses, passwords or tokens appear.
- [ ] The screenshot shows the folders expanded, not just a closed parent folder.
- [ ] The recovered file is named and the recovery method is described in one sentence.
- [ ] The exported PNG opens and is not blank.
- [ ] No personal or client data appears in the AI chat screenshot (if the AI route is used) or the checklist. If the no-AI route is used, the equivalent written explanation and any source notes contain no personal data.

**What "meets" looks like:** a reviewer can open your folder and find the design, the research and the export in under a minute, using only the names.

## Part C — If you do not pass

See the lesson for the retry variant.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
