# Stop 6.2 Assessment — Product Metrics

**Phase:** 6 · Testing, metrics and iteration
**Prerequisite:** Stop 6.1 passed
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** What makes a metric useful?
- A. A precise definition, a stated formula and a time window tied to a decision someone will make.
- B. A large total that grows every month, so it looks impressive on the dashboard during reviews.
- C. A place on the main dashboard, so the whole team sees it every morning without extra work.
- D. A number that is easy to increase, so any change the team ships will show visible progress.

**Q2.** Which is the best activation event for a savings app?
- A. Creating a goal and making a first deposit of a set amount within the first week.
- B. Opening the app for the first time after installing it and reaching the home screen.
- C. Seeing the logo on the splash screen while the app loads for the first few seconds.
- D. Installing the app from the store and granting the permissions it asks for at start-up.

**Q3.** A funnel shows a 58% drop between product view and cart. What does it tell you?
- A. Why people left at that step, because the size of the drop shows what they were thinking.
- B. That the design is bad, because a loss that large cannot happen in a well-made interface.
- C. Where people left the sequence at that step, but not the reason, which needs observation or interviews.
- D. That the sample is significant, because a 58% difference is too large to be chance.

**Q4.** In a product metric tree, what is a guardrail metric?
- A. A metric you try to increase at any cost, because it is the main sign that the change worked.
- B. A metric that is always larger than the others, so it stands out when the dashboard is scanned.
- C. A metric you protect from harm while you try to improve the primary metric for the change.
- D. A vanity metric that looks impressive in a review but does not guide any product decision.

**Q5.** Why are cohorts more informative than a single average?
- A. They are easier to calculate, since the spreadsheet can total every user in one simple sum.
- B. They remove the need for definitions, because the groups already share a start period.
- C. They show change over time for comparable groups, which a flat overall average can hide.
- D. They increase the sample size, so every group has more users than the overall figure did.

**Q6.** "6 of 20 users completed the task" is better than "30% of users" because:
- A. It is shorter, so the finding fits more easily into a summary slide or a status email.
- B. Percentages are always wrong in usability work and should never appear in a written research report.
- C. It shows the count and the sample size, so readers can see how uncertain the result is.
- D. It sounds more technical, which makes the report more credible to the engineers and senior managers.

**Q7.** A completion rate rises while refunds double. What should you conclude?
- A. The change is a clear success, because completion is the primary metric the team chose.
- B. The guardrail signals possible harm, so investigate the refunds before celebrating the result or shipping anything.
- C. Refunds are unrelated to this change, so the doubling is probably seasonal and can be ignored.
- D. The sample is too small to read anything, so no conclusion is possible until next quarter.

**Q8.** Which is a vanity metric?
- A. Total cumulative page views with no decision attached to the number in any review.
- B. Week-4 retention for a defined cohort of users who signed up in the same month.
- C. Task success rate measured with a defined protocol and a stated denominator per task.
- D. Drop-off at a named step of the checkout funnel, compared with the previous release.

**Q9.** A savings app wants an activation metric. Which event best represents first real value?
- A. The user opens the app for the first time and reaches the welcome screen after installing it.
- B. The user completes a first deposit and sees the confirmed balance in the account view.
- C. The user taps the sign-up button on the landing page and starts filling in the form.
- D. The user views the marketing page before deciding whether to create an account at all.

**Q10.** A funnel shows a 58% drop between product view and cart, but the team does not know why. What can the funnel itself tell them?
- A. That the loss occurs between the steps, not the reason people left at that point.
- B. The exact emotional cause of the drop, because the size shows how people felt.
- C. That the product is definitely too expensive, since price is the usual reason for a drop.
- D. That the checkout code is broken, because a 58% loss points to a technical fault.

## Part B — Practical task

**Task.** Submit the metric pack and interpretation page.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] User job stated in one sentence.
- [ ] Activation event defined with a window.
- [ ] Four metrics have explicit formulas.
- [ ] Funnel has at least five steps with counts and conversion rates.
- [ ] Cohort table has at least three cohorts.
- [ ] One primary metric and two guardrails are chosen for a proposed change.
- [ ] Interpretation separates measurement, observation, interpretation and limits.
- [ ] At least three limitations are stated.
- [ ] All data is labelled fictional or clearly sourced and aggregated.
- [ ] No real user-level data is included.

## Part C — If you do not pass

**Retry variant.** Take a different product — a public library booking system — and define only three metrics: activation, task success and one guardrail. Write a one-page memo explaining why those three and not others. The constraint tests whether you can choose metrics rather than list them.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
