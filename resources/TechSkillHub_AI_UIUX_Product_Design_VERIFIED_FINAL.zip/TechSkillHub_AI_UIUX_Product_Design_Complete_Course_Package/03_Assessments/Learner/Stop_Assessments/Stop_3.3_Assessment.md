# Stop 3.3 Assessment — Components, Variants and Variables

**Phase:** 3 · Figma fluency and design systems
**Prerequisite:** Stop 3.2
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** What is the difference between a main component and an instance?
- A. An instance cannot be edited at all, because its structure is owned by the main.
- B. A main component is always larger, since it holds every variant inside it.
- C. An instance inherits the main's structure, while the main defines what that structure is.
- D. There is no real difference, because both are copies of the same object.

**Q2.** Why use a component property instead of an override?
- A. Properties make the file smaller, because they remove the need for extra layers.
- B. Overrides are not allowed in Figma, so a property is the only option available.
- C. Properties are visible and repeatable, while overrides are hidden one-off changes.
- D. Properties change the font automatically, keeping every instance on the brand.

**Q3.** What does a semantic variable alias do?
- A. It deletes the primitive it pointed to, so the palette holds only role names.
- B. It points a role name at a primitive, separating meaning from raw values.
- C. It creates a new component that carries the role name in its title.
- D. It exports the aliased values as CSS custom properties for developers.

**Q4.** Why should variants differ in values, not structure?
- A. Because Figma cannot handle variants that contain different layers at all.
- B. To reduce the number of colours used across the component set.
- C. To make the file larger, so the library looks more complete to reviewers.
- D. So properties and swaps work consistently across every variant in the set.

**Q5.** What is a variable mode used for?
- A. Changing the file owner, so another designer can edit the collection.
- B. Adding new pages to the file, one for each theme you support.
- C. Compressing the images inside components so the file loads faster.
- D. Switching a set of values, such as light and dark themes.

**Q6.** Why check contrast again in dark mode?
- A. Dark mode is not an inversion, so pairs that pass on white may fail.
- B. Dark mode always fails contrast, so every dark theme needs a full redesign.
- C. Figma resets colours whenever a mode is applied, discarding the stored values.
- D. Contrast only applies to light mode, so dark values need no checking.

**Q7.** Which name follows the course convention?
- A. color.action.primary, lower-case with consistent dot separators and a role.
- B. BlueButtonColorFinal, which is descriptive but adds no role or separators.
- C. #1D4ED8, the exact hex value copied straight from the brand palette.
- D. primary-button-color-new, hyphenated and ending with a version word.

**Q8.** A disabled variant removes the icon layer. Why is this a problem?
- A. It makes the button too small, because the icon no longer adds width.
- B. It changes the button's colour, because the fill is tied to the icon.
- C. It is not a problem, since disabled buttons rarely show an icon anyway.
- D. It changes structure across variants, so the boolean property cannot work consistently.

**Q9.** A learner needs the same button to work in light and dark themes. Which structure is most maintainable?
- A. Use semantic colour variables and switch their values with a variable mode.
- B. Create a separate unconnected button for each theme and maintain both.
- C. Override the fill on every instance by hand whenever a theme is needed.
- D. Use one hard-coded hex value that works acceptably in both themes.

**Q10.** A designer detaches a button instance to change its icon, then the team updates the main component. What is the consequence?
- A. The main component is deleted, leaving the file without a source object.
- B. All other instances change automatically, including the detached copy in the file.
- C. The detached copy no longer receives the update and drifts from the system.
- D. The file becomes read-only, because detaching an instance changes its permission.

## Part B — Practical task

**Task.** Submit the component set, variables, modes, naming index and documentation.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] At least 12 variants, or a documented reduction with a reason.
- [ ] Text, boolean and instance-swap properties used.
- [ ] 15+ primitives and 10+ semantic aliases.
- [ ] Semantic variables applied to components, not raw hex values.
- [ ] Light and dark modes with three recorded contrast checks.
- [ ] Component structure consistent across variants.
- [ ] Naming index and component doc complete.
- [ ] The trade-off note is specific.

## Part C — If you do not pass

**Retry variant.** Build a **text field component set** with states default, focus, error, disabled and read-only, plus a boolean for helper text and a text property for the label. Add variables for border, surface and text. Submit the set, a light/dark comparison and a 120-word note on which state was hardest to model and why.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
