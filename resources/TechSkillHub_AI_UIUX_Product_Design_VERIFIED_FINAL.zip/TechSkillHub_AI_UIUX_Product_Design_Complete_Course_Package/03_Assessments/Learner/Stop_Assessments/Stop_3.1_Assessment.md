# Stop 3.1 Assessment — Figma Essentials

**Phase:** 3 · Figma fluency and design systems
**Prerequisite:** Phase 2 gate passed
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** What is the main difference between a frame and a group?
- A. A group can hold text layers and images, while a frame can hold only one shape.
- B. A frame is always transparent, so anything placed behind it stays visible through the canvas.
- C. A frame has size, clipping and export, while a group is only a container for its layers.
- D. A group cannot be renamed in the layers panel, so it always keeps its default name.

**Q2.** Why use pages for workstreams rather than one page per screen?
- A. Figma limits a file to five pages, so each screen must share a page with other screens.
- B. Pages per screen multiply navigation and make it harder to compare screens side by side.
- C. Screens cannot be placed on pages at all, so each screen needs its own separate file.
- D. Pages are reserved for components only, so screens belong on the canvas and not on pages.

**Q3.** What does a local text style do?
- A. It automatically writes sample copy into every text layer that uses the style.
- B. It exports each text layer as a separate image file when the frame is exported.
- C. It translates the file's text into another language whenever the style is applied.
- D. It saves reusable typography values that can be applied and updated in one place.

**Q4.** When should you create a component?
- A. Only when a designer on the team explicitly asks you to create one.
- B. When an object repeats and will need consistent updates across several screens.
- C. Only for buttons, because other objects change too often to be worth componentising.
- D. After handoff, once the final screens have been approved by the client.

**Q5.** What does naming a version in history help with?
- A. It makes the file smaller by compressing earlier versions of every page.
- B. It marks a meaningful milestone that can be restored or referenced later.
- C. It shares the file publicly with anyone who has the version name.
- D. It transfers ownership of the file to the person who named the version.

**Q6.** Which shortcut opens command search?
- A. Ctrl/Cmd+S, which saves the current file and shows the save confirmation.
- B. Shift+2, which zooms the canvas to the layer you have selected.
- C. Alt+F4, which closes the application window on a Windows machine.
- D. Ctrl/Cmd+/, which opens a search field for finding commands by name.

**Q7.** Why compress images before placing them?
- A. Figma rejects any image over 1 MB, so compression is required before placing.
- B. Figma stores the original, so large images bloat the file and slow collaboration.
- C. Compression raises image contrast, which keeps small text legible on busy photos.
- D. Compression converts every placed image into a lighter vector format automatically.

**Q8.** What is the best sharing setting for a reviewer who only needs to comment?
- A. Can edit, so the reviewer can fix small issues without waiting for you.
- B. Owner, so the reviewer has full control of the file during the review.
- C. Can view or can comment, which lets the reviewer read and respond without editing.
- D. A public edit link, so anyone who receives it can open and change the file.

**Q9.** A learner is organising a Figma file with explorations, final screens and a component library. Which page structure is most useful to a collaborator?
- A. One page holding every frame in creation order, with no sections or page names.
- B. One page for each colour used in the file, so the palette is easy to compare.
- C. Separate pages for exploration, final screens and the component library, with clear names.
- D. A separate file for every screen, with no index or shared navigation between them.

**Q10.** A learner shares a file with 40 frames named Frame 1 to Frame 40 and no page structure. What will most likely happen in review?
- A. Reviewers will struggle to find the current screen and may comment on the wrong version.
- B. Figma will automatically rename the frames by reading the text inside each one.
- C. The file will export faster, because unnamed layers take less time to process.
- D. The frames will convert themselves into components once the file is shared.

## Part B — Practical task

**Task.** Submit the file link (view access) and the one-page file guide PDF.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] Five pages with a clear purpose.
- [ ] A cover frame with project, name, date and description.
- [ ] Three named sections.
- [ ] Six numbered frames in flow order.
- [ ] Five text and five colour styles applied.
- [ ] Two components with instances.
- [ ] A named version in history.
- [ ] No unnamed frames or groups on the main design page.
- [ ] A file guide and shortcut sheet.

## Part C — If you do not pass

**Retry variant.** Take a messy file (your own or a practice file you deliberately mess up), clean it, and record a five-minute screen recording or a ten-step written log of every rename, style and component decision. Submit the cleaned file link and the log. The log must explain one decision you reversed.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
