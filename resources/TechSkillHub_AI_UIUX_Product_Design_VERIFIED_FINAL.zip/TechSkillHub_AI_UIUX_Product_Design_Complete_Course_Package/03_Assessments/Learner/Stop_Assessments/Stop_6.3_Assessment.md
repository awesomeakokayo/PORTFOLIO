# Stop 6.3 Assessment — Iteration

**Phase:** 6 · Testing, metrics and iteration
**Prerequisite:** Stops 6.1 and 6.2 passed
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** What is the first thing to do with a list of findings?
- A. Fix the easiest one immediately, so the team can show progress while the harder items wait.
- B. Normalise them first into problem statements with evidence and frequency, so they can be compared fairly.
- C. Add them to a slide deck, so stakeholders can see the full list at the next review meeting.
- D. Ask the client which ones they prefer, so the final choice matches their expectations and priorities.

**Q2.** Which finding is a must-fix?
- A. A keyboard trap in the date picker that stops keyboard users from booking any appointment.
- B. A dated illustration on the confirmation page that no longer matches the current brand.
- C. A slightly long paragraph in the FAQ that takes a few extra seconds to read through.
- D. A colour on the secondary button that is not listed in the current brand guide.

**Q3.** In an ICE score, what does confidence mean?
- A. How much you personally like the idea, and whether it fits the direction you prefer.
- B. How easy the change is to build with the team and time you have available now.
- C. How many users the change could reach once it ships to the whole audience.
- D. How sure you are that the change will have the expected effect, based on evidence.

**Q4.** When is an A/B test least appropriate?
- A. With high traffic and a clear primary metric that is already instrumented on every page.
- B. With a stable product and a change that is easy to reverse if the result looks bad.
- C. With tiny traffic and a must-fix accessibility problem that already blocks keyboard users from booking.
- D. With guardrails already in place, covering cancellations and support contacts over the same four-week period.

**Q5.** What must a hypothesis include?
- A. Only the change itself, described clearly enough for a developer to build it this week.
- B. A design screenshot of the new version, attached so reviewers can see what changed.
- C. A link to a competitor that made a similar change, as evidence that it works.
- D. A testable expected effect, with a reason why the change should produce that effect.

**Q6.** Why change one thing at a time?
- A. It makes the work slower, which is a fair price for a tidier release and a calmer team.
- B. Because users dislike variety and respond better to a product that stays visually stable over time.
- C. So you can attribute the result to a specific change rather than a bundle of them.
- D. Because analytics tools cannot record more than one change in the same release window at a time.

**Q7.** A change increases completion but doubles cancellations. What should you do?
- A. Ship it, because completion is the primary metric and the team agreed to optimise it.
- B. Investigate the guardrail and likely revert or revise, because doubled cancellations signal real harm to users.
- C. Ignore the cancellations, since they are a separate team's metric and outside this scope.
- D. Run more ads to offset the cancellations with new orders from a fresh audience.

**Q8.** Why keep a record of failed changes?
- A. To punish the team members responsible, so the same people do not repeat the mistake.
- B. To avoid repeating past mistakes and to show an honest, evidence-based process that includes reversals.
- C. To fill the portfolio with more entries, so the case study looks longer and more complete.
- D. Because clients require a written log before they will approve any further design work.

**Q9.** A team changes the button label, the page layout and the price at the same time, then sees conversion rise. What is the main problem?
- A. The test used too many users, so the result is harder to explain to the wider team.
- B. The conversion metric is always invalid when more than one element on a page changes.
- C. The team forgot to add animation, which would have made the new layout feel finished.
- D. The changes are bundled, so the team cannot attribute the result to any one of them.

**Q10.** A team has 30 findings from a test and starts fixing the easiest ones first. What is the main prioritisation error?
- A. They are fixing too few issues, so the backlog will still be large after this sprint.
- B. They did not run an A/B test first, so they cannot know which fix will move the metric.
- C. They should fix all 30 at once, so the release is complete before anyone tests it again.
- D. They are prioritising ease over severity and user impact, so the important blockers may still wait.

## Part B — Practical task

**Task.** Submit the v2 plan, implemented changes, re-test table and change log.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] Findings are normalised with evidence and frequency.
- [ ] Must-fix items are identified separately from scored items.
- [ ] At least five items are scored with defined scales.
- [ ] Three change entries include problem, change, reason, expected effect, risk and check.
- [ ] An A/B hypothesis is complete, or its absence is justified.
- [ ] v2 changes are implemented or prototyped in enough detail to test.
- [ ] Before/after re-test results are reported with the same tasks.
- [ ] Change log has at least three entries, including a revert or revision.
- [ ] No unsupported claim of causation from a small sample.
- [ ] No live experiment on real users without approval.

## Part C — If you do not pass

**Retry variant.** Take three findings and write **only** the must-fix decision and one change entry, with no scoring. Then write a 100-word argument for why scoring the other two would be premature. This tests judgment about when process helps and when it becomes theatre.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
