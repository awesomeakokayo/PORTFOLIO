# Stop 0.2 Assessment — How This Course Works

**Phase:** 0 · Getting started
**Prerequisite:** Stop 0.1
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** A learner scores 8/10 on the comprehension check but their task misses two essential rubric criteria. What happens?
- A. They pass, because the quiz score is above the required 80% threshold.
- B. They rework the task, because the stop is not passed until it is met.
- C. They pass with a warning that is recorded on their permanent course record.
- D. They skip to the phase gate and submit the missing criteria there instead.

**Q2.** What is the purpose of a retry variant?
- A. To repeat the identical task until every answer is memorised correctly.
- B. To lower the pass mark slightly so the learner can move on sooner.
- C. To test the same ability with a fresh task after receiving targeted feedback.
- D. To replace the phase gate with a shorter check that needs no reviewer.

**Q3.** Which is a critical issue that cannot be averaged away by high marks elsewhere?
- A. Fabricated interview quotes that are presented in a case study as real.
- B. A spelling mistake in the label of one secondary button.
- C. A brand colour that is slightly off the palette used elsewhere.
- D. A missing favicon on a prototype that is otherwise complete.

**Q4.** Which note field is designed to catch an illusion of understanding?
- A. The stop title, written at the top of the page before you begin reading.
- B. The date, recorded when you first open the lesson and when you finish.
- C. The idea I almost got wrong, written from memory after the lesson ends.
- D. The resource list, added at the end from the links in the lesson.

**Q5.** What makes a help request useful?
- A. Describing what you were doing, expected, observed and had already tried.
- B. Saying that it does not work and attaching a screenshot of the screen.
- C. Sending the whole project file with no message and letting them explore it.
- D. Asking directly for the final answer so you can compare it with your own.

**Q6.** Why does the course avoid a week-by-week deadline?
- A. Because progress is judged by mastery, and learners start with different time and constraints.
- B. Because learners cannot read calendars reliably and often miss the dates they set.
- C. Because the course has no phases, gates or fixed order of lessons at all.
- D. Because videos are optional and most learners choose to skip them entirely.

**Q7.** A learner uses AI to draft a case study and submits it without checking. Which rule did they break first?
- A. Use only paper notes, never a chat tool, when drafting a case study.
- B. Declare it, verify it, explain it, and above all verify every claim before submitting.
- C. Never use AI for writing, even when it is only a first draft.
- D. Submit only on Sundays, after the weekly review session has finished completely.

**Q8.** What does a course certificate honestly prove?
- A. That the learner will get a job offer soon after finishing the course.
- B. That the learner is better than designers who have no certificate.
- C. That the learner's portfolio is complete and ready for interviews.
- D. That the learner completed assessed work against the published criteria.

**Q9.** A learner scores 8/10 on a stop check but their practical submission is missing the required screenshot evidence. What should happen next?
- A. The learner passes because 8/10 meets the 80% threshold for the stop.
- B. The learner skips the stop and returns to the same work at the capstone.
- C. The instructor lowers the practical criteria for this learner and records the change.
- D. The learner supplies the missing evidence and the task is re-marked against the same criteria.

**Q10.** A learner fails a retry by submitting the same file with a new date. Which problem does this reveal?
- A. The learner has not watched enough of the optional videos for the stop.
- B. The instructor marked the first attempt more strictly than the rubric allows.
- C. The learner is repeating a memorised answer instead of transferring the skill to new work.
- D. The course needs a longer deadline so learners can revise before resubmitting.

## Part B — Practical task

**Task.** Submit your one-page study plan, your tracking table with Stops 0.1 and 0.2 entered, and a full four-field note for Stop 0.2.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] The plan names real days/times and at least one real constraint.
- [ ] A minimum commitment is stated in one sentence.
- [ ] The note contains all four fields and the "almost got wrong" field is specific, not "nothing".
- [ ] The pass rule is stated correctly: 80% plus all essential criteria.
- [ ] The help request template contains the four parts.
- [ ] The AI rule says when AI will and will not be used.
- [ ] The tracking table includes a retry count column.

## Part C — If you do not pass

**Retry variant.** Rewrite your study plan for a week that goes badly: two missed sessions, one power cut, and half your usual data. It must still contain a minimum commitment and a recovery rule ("if I miss Tuesday, I do X"). Add a note explaining which part of the original plan was unrealistic and why. Submit the revised plan plus a new four-field note for Stop 0.1 written from memory.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
