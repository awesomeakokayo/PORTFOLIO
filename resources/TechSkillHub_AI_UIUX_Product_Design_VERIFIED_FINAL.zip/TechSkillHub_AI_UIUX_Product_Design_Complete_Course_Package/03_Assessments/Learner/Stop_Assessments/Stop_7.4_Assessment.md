# Stop 7.4 Assessment — Getting Paid

**Phase:** 7 · Capstone and career launch
**Prerequisite:** Stop 7.3 passed
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** Why calculate a minimum rate from costs rather than copying competitors?
- A. Competitors are always wrong, because they price by guesswork and rarely track their own expenses.
- B. Your costs and required income are specific to you, so copying may leave the work unsustainable.
- C. It is required by law, and freelancers who cannot show a cost-based rate may face penalties.
- D. It makes you the cheapest, so you win more work and can raise prices once demand grows.

**Q2.** What is a deposit?
- A. An upfront payment that secures the work and covers the initial effort before any delivery is made.
- B. A discount offered at the start, so the client commits early and the total price falls.
- C. A tax collected on the project fee and passed to the government at the end of the year.
- D. A revision round included in the agreed scope, so changes are settled before the work begins.

**Q3.** Which belongs in a proposal's exclusions?
- A. The client's name and project title, so the document is clearly identified as belonging to them.
- B. Your portfolio link and two client references, so the client can check your previous work before approving.
- C. Work that is not included, such as copywriting, development and recruiting users for the tests.
- D. The weather and travel time, so the client understands the daily conditions the work depends on.

**Q4.** What is a reasonable response to unpaid spec work with commercial value?
- A. Do it for free to prove yourself, because a strong sample often turns into a paid contract later.
- B. Send the final files immediately, so the employer can assess the quality and make a decision quickly.
- C. Ask about time, use and fee, then offer a short walkthrough or a paid trial instead.
- D. Ignore every employer who asks, because any request for sample work is simply exploitative by nature.

**Q5.** What is a walk-away number?
- A. The first number you say in the call, which sets the anchor for the whole negotiation.
- B. The client's stated budget, which tells you the most they are willing to spend on the project.
- C. Your hourly rate, multiplied by the hours you expect the project to take from start to finish.
- D. The lowest offer you are willing to accept, written down before the negotiation begins in earnest.

**Q6.** Why tailor a remote application?
- A. To send more applications in less time, so you reach more companies before the roles close.
- B. To show specific relevance to the role and increase the chance of a reply from the team.
- C. To hide your portfolio, because a targeted cover note matters far more than the work itself does.
- D. Because templates are now banned by most employers, and a generic application is rejected automatically.

**Q7.** A client offers 40% below your floor for the full scope. What is the best response?
- A. Accept and hope, because the relationship may lead to better-paid work once the client trusts you.
- B. Ignore the client entirely, because an offer that low shows they will never respect your rate.
- C. Offer a reduced scope within that budget, or deliver the full scope at your stated rate.
- D. Double the price, so the client learns that the original quote was already a fair deal.

**Q8.** Why separate business and personal money?
- A. To look professional, because separate accounts signal to clients that you run a serious design practice.
- B. To track costs, tax and buffer accurately, so you can make sustainable decisions about the work.
- C. Because clients require it, and invoices sent from a personal account may not be accepted.
- D. To avoid invoices, because keeping one account makes it hard to prove what was actually earned.

**Q9.** A client asks for a full brand and app design as an unpaid 'test' before any contract. What is the most professional response?
- A. Do the full project for free to win the client, because the contract will follow if the work is good.
- B. Refuse to speak to the client again, because the request shows they do not value design work.
- C. Offer a small paid discovery task or a time-boxed sample, and keep the full work behind a contract.
- D. Send a generic price list with no scope, so the client can choose what fits their budget.

**Q10.** A freelancer starts work with no deposit and no milestones, then the client stops responding after the first draft. What was missing?
- A. A larger portfolio, because more visible work would have made the client value the project more.
- B. A brighter proposal template, because a clearer layout would have kept the client more engaged.
- C. More free revisions, because generous changes would have persuaded the client to stay more involved.
- D. A payment schedule tied to milestones and a deposit that commits both sides before work starts.

## Part B — Practical task

**Task.** Submit the pricing calculator, proposal, application pack and negotiation plan.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] Rate calculation includes costs, tax reserve, savings, billable hours and assumptions.
- [ ] Proposal has scope, exclusions, deliverables, timeline, revisions and payment schedule.
- [ ] At least one deposit or milestone structure is defined.
- [ ] Application pack is tailored to a named role and company.
- [ ] Design-challenge policy states what you accept, decline and ask.
- [ ] Negotiation plan includes target, walk-away, priorities and three tradeables.
- [ ] Payment and tax responsibilities are acknowledged as country-specific.
- [ ] No real bank details, ID numbers or signed contracts are included.
- [ ] No promise of employment or income is made.

## Part C — If you do not pass

**Retry variant.** Recalculate your rate assuming **only 15 billable hours per week** and a three-month buffer. Then write a 100-word note on how the number changes and what you would do differently. The constraint exposes hidden costs and unrealistic assumptions.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
