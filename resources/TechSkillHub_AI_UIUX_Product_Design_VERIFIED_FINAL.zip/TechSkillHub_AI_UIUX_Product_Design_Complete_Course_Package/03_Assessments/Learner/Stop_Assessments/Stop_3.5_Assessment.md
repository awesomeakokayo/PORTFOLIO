# Stop 3.5 Assessment — Building a Small Design System

**Phase:** 3 · Figma fluency and design systems
**Prerequisite:** Stop 3.4
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** What is the difference between a primitive and a semantic token?
- A. A primitive is a raw value, while a semantic token names a role and aliases it.
- B. A primitive is used for colour only, while semantics cover spacing and type.
- C. A semantic token is always darker, so it reads correctly on every surface.
- D. There is no difference, because both resolve to the same value in code.

**Q2.** What should component documentation include beyond appearance?
- A. Only a screenshot of the component in its default state, with a caption.
- B. Purpose, use, don't, accessibility, content and developer notes for each component.
- C. The designer's name and the date the component was last edited.
- D. The file size and the number of layers the component contains.

**Q3.** What is design system drift?
- A. A file becoming corrupted, so components no longer open correctly.
- B. A colour fading over time, so the palette gradually loses contrast.
- C. The gap between the system and the product as local changes accumulate.
- D. A component moving on the canvas, so the layout no longer aligns.

**Q4.** Why have a governance page for a one-person system?
- A. Because Figma requires a governance page before a library can be published.
- B. Because future-you will not remember today's decisions, and the system may be handed over.
- C. To increase the page count, so the file looks more thorough to reviewers.
- D. To satisfy clients only, since internal teams rarely read governance pages.

**Q5.** A screen needs a one-off component. What are the two legitimate options?
- A. Detach a component from the library and adapt it until it fits the screen.
- B. Use a raw hex value for that one element and record nothing about it.
- C. Add it to the system if it recurs, or document it as an exception.
- D. Copy a similar component from another product, then rename it locally to fit.

**Q6.** What does an adoption table reveal?
- A. How many pages the file contains, and which ones are out of date.
- B. How much of the product uses the system, and where overrides live.
- C. The total number of distinct colours used anywhere in the file.
- D. The number of contributors who have edited the library this month.

**Q7.** Why are principles only useful if they change a decision?
- A. Because Figma limits how much text a principles page can hold.
- B. Because clients dislike principles and prefer to see finished screens.
- C. Otherwise they are decoration and cannot guide real trade-offs in the work.
- D. Because principles must be numeric, so each one can be measured.

**Q8.** What does deprecation mean in a design system?
- A. Deleting a file without notice, so nobody keeps using the old version.
- B. Retiring a component or token while giving teams time to migrate.
- C. Renaming a colour, so the old name no longer appears in the index.
- D. Adding a variant, so the component covers one more state or size.

**Q9.** A team changes its primary colour in 12 separate components and misses two. What should the system have provided?
- A. A semantic colour token or variable that all components reference.
- B. A longer brand guidelines PDF, with the new colour specified precisely.
- C. More one-off components for each screen, so each can be edited separately.
- D. A rule that designers must remember all 12 places and check them.

**Q10.** A design system page lists component names and pictures but no usage rules. What is the main documentation gap?
- A. More decorative illustrations, so the page feels finished and on brand.
- B. Guidance on when to use each component, its states, content rules and accessibility.
- C. A larger logo, so readers recognise which team owns the system.
- D. A list of every file the team has made since the system started.

## Part B — Practical task

**Task.** Submit the system file link and the documentation PDF.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] Five principles, each with a consequence.
- [ ] 20+ primitives and 15+ semantic tokens.
- [ ] Ten components with variants and documented properties.
- [ ] Documentation covers purpose, anatomy, use, don't, accessibility, content and developer notes.
- [ ] One screen composed only from system components.
- [ ] Adoption table with overrides and detached instances counted.
- [ ] Governance page with version, owner, change log, review, deprecation and contribution.
- [ ] Reflection identifies a real documentation difficulty.

## Part C — If you do not pass

**Retry variant.** Build a **second theme** (high-contrast or dark) for your system using variable modes, and document which components required structural changes. Submit the themed system, a migration note for developers and a 150-word reflection on what the theme revealed about hidden assumptions.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
