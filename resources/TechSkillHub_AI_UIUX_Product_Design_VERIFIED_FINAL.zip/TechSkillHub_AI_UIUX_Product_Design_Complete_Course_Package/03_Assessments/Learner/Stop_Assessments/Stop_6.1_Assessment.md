# Stop 6.1 Assessment — Usability Testing

**Phase:** 6 · Testing, metrics and iteration
**Prerequisite:** Phase 5 gate passed; a deployed prototype
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** What is the main purpose of a first usability test round?
- A. To prove that the design is already good, so the team can stop testing and move on to the next feature.
- B. To observe where real people actually struggle and replace the team's opinions with evidence early, while changes are still cheap.
- C. To collect complimentary quotes from participants that the team can reuse in marketing material and on sales pages later.
- D. To replace product analytics entirely, because watching five people shows how often every event happens for every user.

**Q2.** Which task is written correctly?
- A. Click the blue Delivery tab at the top of the basket page, then read the fee in the order summary.
- B. Find out how much delivery will cost before you pay, because you are ordering food to your house.
- C. Did you find the blue delivery button easy to use, or would you prefer a clearer label on it?
- D. Use the search bar on the menu page to look for a jollof rice option that serves two people.

**Q3.** A participant asks, "Is this right?" What is the best response?
- A. Yes, that is right, well done for finding it so quickly without any help from me today.
- B. Click the next button at the bottom of the form, then check whether the summary looks correct.
- C. What do you think, and what would you expect to happen next on this screen right now?
- D. Most people get that wrong on their first attempt, so do not worry about it at this stage.

**Q4.** Why separate observation from interpretation?
- A. To make each set of session notes longer and more detailed, so the final report looks thorough and professional.
- B. Because interpretations are not allowed in usability work and only recorded behaviour may appear in the findings.
- C. To hide the moderator's personal bias from readers, so the notes appear neutral even where judgement crept in.
- D. So that later claims and recommendations can be checked against what was actually seen in the session.

**Q5.** What does "3 of 5" communicate that "most users" does not?
- A. The exact count and the sample behind it, which is more honest than a vague majority claim.
- B. Nothing extra, since both phrases describe the same group of participants in a five-person round.
- C. Statistical significance, because a count out of five proves the difference is not due to chance.
- D. Severity, because the number of participants affected shows how badly the issue blocks the task.

**Q6.** One participant loses a saved order. Four do not. How should this be rated?
- A. Low, because only one of the five participants hit it, and rare problems can wait for a later release.
- B. Critical, because losing a saved order is severe impact even though only one participant saw it.
- C. Not rated at all, because a single participant cannot show a pattern that is worth acting on.
- D. Medium, because it affected one person only and the other four completed the same task fine.

**Q7.** What must be agreed before recording a session?
- A. Nothing in advance, because joining the call is generally taken as permission to record the screen.
- B. Only the participant's name, so the file can be labelled correctly when it is stored after the call.
- C. A small payment for their time, which stands in for written permission to keep and use the clip.
- D. Explicit consent covering the purpose, who will see the recording, and when it will be deleted.

**Q8.** Which is a limitation that belongs in the report?
- A. The brand colour used on the primary button, which was chosen before the sessions and never changed.
- B. The designer's name and role, so readers know who was responsible for the prototype that was tested.
- C. Five participants and a prototype that could not take real payments during the checkout tasks at all.
- D. The number of headings on the checkout page, which the team had reduced before the sessions.

**Q9.** A usability test task says: 'Click Settings, then Privacy, then turn off sharing.' What is wrong with the task?
- A. It is too short for the participant to understand what is being asked of them in the session.
- B. It does not mention the participant's name, so the moderator cannot personalise the instruction before reading it aloud.
- C. It uses the word Privacy, which gives away the name of the screen the participant must find.
- D. It prescribes the exact interface path instead of stating a goal and the context around it.

**Q10.** A report says 'most users struggled' after testing five people but gives no counts. What is the reporting problem?
- A. The report is too long, so readers lose the main finding among details that do not matter.
- B. The claim hides the small sample and gives no count, so the reader cannot judge its weight.
- C. Five participants is always too many for a first round, so the sessions should have been cut short.
- D. The report should say all instead of most, to make the finding sound stronger and more urgent.

## Part B — Practical task

**Task.** Submit the complete test pack and summary.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] A one-sentence research question and a one-page plan.
- [ ] Consent obtained and documented before each session.
- [ ] 3–5 realistic tasks that do not name interface controls.
- [ ] Five sessions (or three, clearly labelled as a pilot).
- [ ] Notes separate observation from interpretation.
- [ ] Findings table includes participants, evidence, severity and recommendation.
- [ ] Summary reports what worked, what failed and limitations.
- [ ] No participant's name, face or identifying detail appears without permission.
- [ ] Storage and deletion plan stated.

## Part C — If you do not pass

**Retry variant.** Run a **three-participant pilot** on a different flow with a stricter constraint: you may not speak at all during tasks except to read the task and ask one probe. Submit the notes and a reflection on what the silence revealed. The constraint targets the most common moderation failure.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
