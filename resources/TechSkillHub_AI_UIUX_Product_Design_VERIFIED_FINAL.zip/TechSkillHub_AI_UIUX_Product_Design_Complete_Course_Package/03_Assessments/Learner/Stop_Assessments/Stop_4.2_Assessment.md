# Stop 4.2 Assessment — AI for Ideation and Flows

**Phase:** 4 · The AI design workflow
**Prerequisite:** Stop 4.1
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** Why ask for three structurally different flows rather than "three options"?
- A. To make the prompt longer, because detailed prompts are treated as higher quality.
- B. To give the assistant enough examples that it can produce one usable flow.
- C. To postpone critique, since comparing options feels more productive than judging one.
- D. To force real divergence rather than three cosmetic variations of the same structure.

**Q2.** What is a hallucinated feature?
- A. A capability the AI invents that the product does not have or support.
- B. A feature that is technically hard to build within the current project timeline.
- C. A feature that users dislike, according to the research themes already gathered.
- D. A feature already listed in the product backlog but not yet designed.

**Q3.** What does the Have/Build/Assume/Invent marking do?
- A. Scores each step for visual quality, so the most polished flow can be selected.
- B. Separates what already exists from what is feasible, assumed or invented.
- C. Counts the screens in each flow, so the shortest path can be identified.
- D. Measures accessibility risk per step, using contrast and target sizes as criteria.

**Q4.** Why generate IA separately from the flow?
- A. Because IA only applies to websites, while mobile products rely on flows instead.
- B. Because flows cannot contain screens, so their structure has to be described elsewhere.
- C. Because IA covers structure and naming while a flow covers sequence, and mixing hides structural faults.
- D. Because the assistant can only handle one artefact per prompt and cannot do both.

**Q5.** What is a pre-mortem?
- A. Imagining the flow has failed in production and listing the most likely reasons.
- B. Testing the flow with five users and recording where they hesitate or stop.
- C. Critiquing the visual hierarchy, spacing and consistency of each screen.
- D. Mapping the project timeline, including design, build and release milestones.

**Q6.** A flow has six steps and low cognitive load per step. Is it automatically better than a three-step flow?
- A. Yes, because more steps keep each screen simpler and users rarely mind the extra taps.
- B. No, because total effort, abandonment and context switching matter more than per-step load.
- C. Yes, because users prefer wizards and will abandon a flow that asks for everything at once.
- D. No, because step count is irrelevant and only the visual design of each screen matters.

**Q7.** What belongs in a decision log?
- A. Only the final flow, presented cleanly so the choice needs no further explanation.
- B. What was selected, what was kept, changed or rejected, and the reason for each.
- C. The AI model's name and version, so the output can be reproduced later.
- D. A list of the colours and components used in the selected flow.

**Q8.** Why draw the selected flow yourself?
- A. Because drawing forces you to notice gaps and dependencies that copying hides.
- B. Because AI diagrams are usually wrong, so redrawing is the only way to correct them.
- C. Because the export process requires a hand-drawn frame before the file can be shared.
- D. Because a hand-drawn flow looks more professional in a portfolio case study.

**Q9.** An AI produces three flows that are almost identical. Which follow-up prompt is most likely to produce genuinely different options?
- A. Ask for three more flows with no additional constraints and compare them again.
- B. Ask the assistant to make the three screens prettier, then choose the clearest one.
- C. Ask for one flow minimising steps, one maximising control, one working offline, with trade-offs stated.
- D. Ask for one flow, then copy it three times and label the copies as alternatives.

**Q10.** A generated flow includes a 'Scan QR to pay' step, but the product has no camera permissions or QR feature. What is the defect?
- A. The flow has too few steps for the task and skips the confirmation stage.
- B. The flow uses a modal where a full page would be clearer on small screens.
- C. The flow lacks a colour palette, so the payment action is not visually distinct.
- D. The flow invents a capability the product lacks, namely camera access and a QR feature.

## Part B — Practical task

**Task.** Submit the nine-part flow pack.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] Three flows with genuinely different structures.
- [ ] An IA with five or fewer top-level destinations.
- [ ] A critique matrix with six criteria and justifications.
- [ ] Every step marked Have/Build/Assume/Invent.
- [ ] At least three unsupported features identified and handled.
- [ ] A pre-mortem with five reasons.
- [ ] A hand-drawn or FigJam flow including failure paths.
- [ ] A decision log explaining kept, changed and rejected.
- [ ] No unmarked invented capability.

## Part C — If you do not pass

**Retry variant.** Generate flows for a **different task**: cancelling a subscription or disputing a charge. Focus on the failure and recovery paths, and include a regulatory or policy constraint. Submit three flows, a critique matrix, a decision log and a 150-word note on which assumption was most dangerous.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
