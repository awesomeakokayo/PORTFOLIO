# Stop 1.4 Assessment — Competitive and Market Review

**Phase:** 1 · Product thinking and research
**Prerequisite:** Stop 1.3
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** What makes a product "comparable" in a competitive review?
- A. A real user might choose it for the same job, including substitutes like a cash agent.
- B. It is famous, because widely used products set the standard that smaller products must match.
- C. It has a similar logo, so users recognise it as part of the same category of products.
- D. It is in the same app store category, where the store groups products that compete directly.

**Q2.** Why must every product be tested on the same task?
- A. Otherwise the observations are not comparable, and the matrix cannot support a conclusion about any product.
- B. To make the table symmetrical, so each product has the same number of cells filled in.
- C. Because users only do one task, so testing more than one would not reflect their behaviour.
- D. To save time, because fewer distinct tasks mean fewer screenshots and notes to organise.

**Q3.** Which is a gap rather than a difference?
- A. Product A uses blue buttons while Product B uses green, and users notice the change immediately.
- B. All three products hide the fee until after confirmation, and users abandon when it appears.
- C. Product A has a dark mode while Product B does not, so night-time use feels harsher.
- D. Product C uses a different font from the others, which some reviewers found harder to read.

**Q4.** What is the purpose of the evidence log's date?
- A. To prove you worked on a certain day, so the review can be credited as your own effort.
- B. To sort screenshots alphabetically, so the folder stays tidy when the review grows larger over time.
- C. To mark the observation as a historical record, because interfaces change after you capture them.
- D. To satisfy app store rules, which require a capture date before a screenshot can be published.

**Q5.** What does "parity" mean in a direction statement?
- A. Matching the expectations users need to trust the product, before you differentiate anywhere else.
- B. Copying every competitor feature, so the product cannot be criticised for missing anything obvious.
- C. Having the same price as the market leader, so users compare the products on design alone.
- D. Using the same colours as competitors, so the product feels familiar the moment it opens.

**Q6.** A competitor has a feature. What is the best reason to include it?
- A. They have it, so users expect it, and its absence would make the product look incomplete beside rivals.
- B. It is easy to build, so the team can ship it quickly without delaying the rest of the release.
- C. It addresses an evidenced user problem within your scope and constraints, at a cost you can bear.
- D. It looks modern, so the interface feels current and reviewers are more likely to praise it.

**Q7.** Which is an indirect competitor for "book a tutor"?
- A. Another tutoring app that lets students search tutors, compare prices and book a lesson directly.
- B. A WhatsApp group where tutors and students arrange lessons by messaging each other directly.
- C. A school that assigns teachers to students and schedules lessons through its own academic timetable.
- D. A textbook that students study alone when no tutor is available to explain the difficult topics.

**Q8.** You cannot complete a transfer without spending money. What should you record?
- A. A guessed result, based on how the flow usually ends in apps with a similar confirmation screen.
- B. A note that the product failed, because stopping before the success screen means the flow could not work.
- C. Not tested up to the confirmation screen, with the limit and the reason stated clearly.
- D. A competitor's screenshot as if it were yours, since the screens look almost identical anyway.

**Q9.** A learner is comparing three money-transfer apps. Which comparison gives the most defensible evidence?
- A. Review each app's marketing page and score the visual style against the other two brands.
- B. Ask friends which brand they like best, then rank the three apps by stated preference.
- C. Compare only the features listed in each app store description, because those lists are standardised.
- D. Run the same transfer task with the same starting conditions in each app, recording steps and failures.

**Q10.** A competitive review tests a different task in each product, then concludes one product has the best checkout. What invalidates the conclusion?
- A. The tasks and starting conditions differ, so the comparison is not controlled across the three products.
- B. Three products is too many to review, so the scores cannot be checked by a second reviewer.
- C. The review did not include screenshots, so nobody can confirm what each checkout screen looked like.
- D. The reviewer used a laptop instead of a phone, so the checkout looked different from the mobile version.

## Part B — Practical task

**Task.** Submit the eight-part competitive review.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] Three products including at least one direct and one indirect/substitute.
- [ ] One precisely defined task and starting state.
- [ ] An 8–12 row pattern matrix with "not tested" where applicable.
- [ ] Five heuristic scores per product, each with evidence.
- [ ] A dated evidence log with screenshot references.
- [ ] Three filtered opportunity statements.
- [ ] A direction statement separating parity, differentiation and rejection.
- [ ] A Limits note naming what could not be tested.
- [ ] No copied logos, illustrations or proprietary content; no real payments.

## Part C — If you do not pass

**Retry variant.** Review **three products for a different job**: booking a bus or ride from a phone. Include one product that works mainly by WhatsApp or phone call. Produce the same eight parts, but add a "market context" paragraph (100 words) on device, data, payment and trust conditions that change what "good" means. Submit the new review plus a corrected version of one heuristic score from your first attempt, with the missing evidence supplied.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
