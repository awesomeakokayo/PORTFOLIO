# Stop 2.2 Assessment — Typography and Colour

**Phase:** 2 · Visual and interaction foundations
**Prerequisite:** Stop 2.1
**Suggested time:** 25–35 minutes
**Pass target:** 80% on the comprehension check (8 of 10) **and** all practical pass criteria.

## Part A — Comprehension check

Answer all ten questions without looking back. Each question has one best answer. Do not use the answer key until you have attempted the whole set.

**Q1.** What does a type scale ratio of 1.25 mean?
- A. Every size in the scale is 1.25 px larger than the one before it.
- B. The line height for all text styles is fixed at a 1.25 multiplier.
- C. Each step in the scale is 1.25 times the size of the step below.
- D. The typeface provides 1.25 available weights, from light through to bold.

**Q2.** What is the WCAG 2.2 AA minimum contrast for normal body text?
- A. 2:1, a threshold that applies only to decorative borders and dividers.
- B. 3:1, the threshold shared by large text and essential icons.
- C. 4.5:1, the minimum SC 1.4.3 sets for normal-sized body text.
- D. 7:1, the stricter AAA target for normal text above the AA baseline.

**Q3.** What is the minimum for large text under AA?
- A. 2:1, the floor for decorative separators that carry no information.
- B. 4.5:1, the normal-text threshold applied here because large text is harder.
- C. 3:1, the lower threshold AA allows once text reaches large-text size.
- D. 7:1, the AAA target for small text that designers often over-apply.

**Q4.** Why is a placeholder not a label?
- A. It disappears once typing starts, so the field's instruction is lost.
- B. It is always set too small to read comfortably on a phone screen.
- C. It cannot be announced by screen readers, which skip placeholder text.
- D. It is not permitted in forms under the WCAG 2.2 AA standard.

**Q5.** A designer uses red text alone to indicate an error. Which principle is violated?
- A. The contrast minimum, because red text rarely reaches a 4.5:1 ratio.
- B. Use of colour alone (WCAG 1.4.1), because hue carries the meaning.
- C. Text resize, because the error message does not grow at 200% zoom.
- D. Focus visible, because the field shows no outline when tabbed to.

**Q6.** Why use semantic colour roles instead of raw hex values in screens?
- A. Roles survive theme changes and keep meaning consistent across every screen.
- B. Hex values take longer to load, so screens that use them render more slowly.
- C. Roles raise contrast automatically, so a failing pair passes once it is tokenised.
- D. Figma cannot store raw hex values reliably across shared team libraries.

**Q7.** Body text at 16 px with a line height of 16 px will most likely be…
- A. Perfectly readable, because the lines are spaced exactly one text size apart.
- B. Too tight, so ascenders and descenders collide and reading slows down.
- C. Too loose, because each line occupies a full 16 px of vertical space.
- D. Inaccessible, because the grey text colour fails the 4.5:1 threshold.

**Q8.** You check `#9CA3AF` grey text on white and get 2.6:1. It is used for 13 px helper text. What should you do?
- A. Keep it as it is, because helper text is exempt from contrast requirements.
- B. Darken it to at least 4.5:1, or enlarge it to the large-text threshold for 3:1.
- C. Make the helper text bold and keep the colour, since weight raises contrast.
- D. Add an icon beside the helper text so the low contrast no longer matters.

**Q9.** A learner needs a muted grey for 13 px helper text on a white card. Which action is correct?
- A. Pick a grey reaching 4.5:1 on white and confirm it with a checker.
- B. Pick any grey lighter than body text, since helper text is optional.
- C. Use 3:1, because all secondary text counts as large text.
- D. Trust your own screen; if the grey looks readable, it passes.

**Q10.** A form marks an invalid field only with a red border. Which user group is most directly excluded?
- A. People who cannot distinguish the red border from the surrounding border colour.
- B. People who use a mouse instead of a keyboard to complete the form.
- C. People on a fast internet connection who skip past the error message.
- D. People who prefer dark mode and see a different surface colour.

## Part B — Practical task

**Task.** Submit the seven-part type and colour specification.



### Pass criteria

**Pass criteria — all must be met:**

- [ ] A type scale with a stated ratio and at least six steps.
- [ ] Line heights appropriate to size (body 1.4–1.6).
- [ ] A specimen using real sentences.
- [ ] Nine neutrals, one brand ramp and four semantic colours.
- [ ] A role table with at least ten tokens.
- [ ] Eight measured contrast pairs, with ratios and pass/fail labels.
- [ ] No normal text below 4.5:1 presented as body text.
- [ ] Greyscale version included and no meaning lost.
- [ ] A rationale that explains the accessibility decision.

## Part C — If you do not pass

**Retry variant.** Build a **dark-mode** version of the same specification. Every text/background pair must be re-measured; dark mode is not an inversion. Add a table of five pairs that passed in light mode but fail in dark mode, and explain how you fixed each. Submit the dark specification, the comparison table and a 120-word note on what surprised you.

## Submission checklist

- [ ] All ten answers recorded.
- [ ] Practical task completed with the required evidence.
- [ ] Proof artifact saved to your portfolio folder.
- [ ] No real personal or confidential data included.

> **Honest marking note:** this Markdown file is a static assessment sheet. It does not grade itself and it does not save to a TechSkillHub account. Your instructor, or the self-check built into the HTML lesson, marks Part A. Part B requires human or rubric-based review of the evidence you submit. The HTML self-check calculates a score in your browser but does not transmit or store it.
