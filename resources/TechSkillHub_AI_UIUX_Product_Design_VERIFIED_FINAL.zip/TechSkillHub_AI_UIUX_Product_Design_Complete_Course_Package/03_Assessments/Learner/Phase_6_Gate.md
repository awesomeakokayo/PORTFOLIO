# Phase 6 Gate — Usability Test and Shipped v2

**Phase:** 6 · Testing, metrics and iteration
**Stops covered:** 6.1–6.3
**Suggested time:** 6–10 hours
**Review:** human instructor review required
**Pass target:** every criterion met, and an average of at least 80% across this phase's stop comprehension checks

## Purpose

This gate checks whether you can learn from real people and change the product because of what you learned. You must run a usability test on your deployed prototype with at least five people and ship a v2 with a before/after.

You must show that you can:

- plan and moderate a test ethically;
- separate observation from interpretation;
- turn findings into prioritised changes;
- decide when an experiment is appropriate;
- ship a v2 and re-test it honestly.

## What to submit

1. **Test plan:** research question, tasks, participants, method, ethics, limitations.
2. **Consent record:** template and confirmation. No participant names in the submission.
3. **Five session notes,** anonymised, with observation and interpretation separated.
4. **Findings table:** issue, participants affected, evidence, severity, recommendation.
5. **Metric pack:** definitions, funnel or task metrics, primary metric and guardrails.
6. **v2 plan:** must-fix list, scored backlog, change entries and one A/B hypothesis or a justified decision not to test.
7. **Shipped v2:** the updated live URL or repository commit.
8. **Before/after re-test:** same tasks, comparable participants, results and limitations.
9. **Change log:** at least three entries, including one revision or revert.

## Tasks

### Task 1 — Run the test properly

Minimum:

- five participants who are not close collaborators on the design;
- a consent conversation before recording;
- 3–5 realistic tasks that do not name interface controls;
- a moderator who does not lead;
- notes that separate what happened from what you think it means.

If you can only recruit three, label the round **pilot** and state the limitation. Do not claim five.

### Task 2 — Analyse without overclaiming

For each finding:

- count participants, not clicks;
- quote or describe the evidence;
- rate severity (critical, high, medium, low);
- state the recommendation.

Example: "3 of 5 participants missed the delivery fee. Severity: high. Evidence: all three scrolled past the summary and completed payment without noticing. Recommendation: show an estimate before checkout."

Do not write "users want" from five people. Write "3 of 5 participants".

### Task 3 — Connect to metrics

Define:

- task success rate;
- drop-off at the step you changed;
- one primary metric for the change;
- two guardrails.

Use fictional or aggregated data only. State the window, population and denominator. A funnel shows where, not why; pair it with the qualitative evidence.

### Task 4 — Ship a v2

Fix must-fix issues first:

- blockers, data loss, privacy or safety risks;
- accessibility failures;
- false or misleading claims.

Then make the scored changes in priority order. Change one thing at a time where possible. Update the change log with reason and expected effect.

### Task 5 — Re-test and compare

Use the same tasks and a comparable group. Report:

- task success before and after;
- time on task;
- errors;
- issues resolved and issues remaining;
- new issues introduced;
- limitations.

A before/after table is the minimum. If you changed the tasks, say so; the comparison is no longer direct.

## Pass criteria

- [ ] Five participants, or three clearly labelled as a pilot.
- [ ] Consent documented before each session.
- [ ] Tasks are realistic and do not name controls.
- [ ] Notes separate observation from interpretation.
- [ ] Findings table includes evidence, count, severity and recommendation.
- [ ] Metric definitions include formula, window and denominator.
- [ ] Must-fix issues are separated from scored items.
- [ ] v2 is deployed and linked.
- [ ] Before/after re-test uses the same tasks and reports limitations.
- [ ] Change log has at least three entries, including a revision or revert.
- [ ] No participant's identity is exposed.
- [ ] No invented result or unsupported causal claim.

## Scoring

| Criterion | Weight | Met / Not yet met |
|---|---|---|
| Test design and ethics | 20% | |
| Moderation and notes | 20% | |
| Analysis and prioritisation | 20% | |
| v2 implementation | 20% | |
| Re-test and honest reporting | 20% | |

All criteria must be met. Ethics and fabrication failures override the score.

## Critical failures (automatic rework)

- Recording or publishing a participant without consent.
- Invented participants, quotes, findings or metrics.
- Exposing a participant's identity.
- Claiming five participants when fewer were tested.
- A "v2" with no substantive change.
- A causal claim from a small uncontrolled sample presented as proof.

## If you do not pass

- **Recruitment short:** run a three-person pilot and label it; do not inflate the number.
- **Leading moderation:** re-run two sessions with a silent protocol and compare the notes.
- **Weak analysis:** rebuild the findings table with one evidence line per finding.
- **No real v2:** implement one must-fix change and re-test that specific task.
- **Ethics issue:** stop, delete the data, and speak to the instructor before resubmitting.

## Instructor review notes

Check consent records before reading notes. Look for leading questions in the transcript and for findings without evidence. Ask which change was hardest to justify. Re-open the live v2 and confirm the change exists. Detailed rubric: `04_Instructor_Only/Rubrics/Gate_Rubrics.md`.
