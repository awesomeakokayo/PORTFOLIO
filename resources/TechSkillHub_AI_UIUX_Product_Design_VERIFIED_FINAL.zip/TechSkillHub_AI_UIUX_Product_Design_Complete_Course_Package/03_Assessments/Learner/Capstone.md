# Capstone — One Complete Product, Tested and Presented

**Phase:** 7 · Capstone and career launch
**Prerequisite:** Phase 6 gate passed
**Suggested time:** 20–40 hours across several sessions
**Review:** live human reviewer panel required
**Pass target:** 80% overall, no criterion below 60%, and no critical failure

> **Policy note:** the 80% overall / 60% per-criterion threshold is a **proposed TechSkillHub policy** for this package. It is not an external standard or a claim about industry practice. The provider should confirm or adjust it before delivery.

## Purpose

The capstone is the proof that you can take a product from a real problem to a tested, deployed v2 and explain your decisions under questioning. It is not a bigger case study. It is a demonstration of end-to-end judgment.

You must show that you can:

- frame a problem and justify why it matters;
- research ethically and synthesise evidence;
- design and build a working product;
- test it with real people and iterate;
- present the work honestly and answer hard questions;
- separate what you know from what you assume.

## What to submit

1. **Capstone brief:** product, user, problem, scope, constraints and success measures.
2. **Research evidence:** plan, consent, anonymised notes, synthesis and problem statement.
3. **Design file:** key flows, states, components and accessibility notes.
4. **Live product:** deployed URL and public repository (or a documented equivalent if hosting is impossible).
5. **Test evidence:** five-participant usability test, findings, prioritisation and v2.
6. **Before/after evidence:** task success, key metric, screenshots and limitations.
7. **Case study:** 900–1,200 words, plus a 150-word short version.
8. **Presentation:** 15 minutes live, plus 15 minutes of questions.
9. **Decision log and AI use statement:** what you decided, what AI did, what you verified.
10. **Known issues and next steps:** an honest list.

## The product brief

Choose a **fictional** product or a **fictionalised** version of a real problem. Do not use a real company's confidential material. Do not fabricate users, quotes or results.

A strong brief names:

- a specific user and context;
- a task the user is trying to complete;
- the barrier and its consequence;
- the scope you will deliver;
- what you will not deliver;
- how you will know it worked.

Weak: "A design system for a fintech app."
Strong: "A mobile checkout for a fictional produce market that lets a first-time buyer see the delivery fee before payment, so they can decide without surprise. Scope: cart, delivery details, fee estimate, confirmation. Not in scope: payments integration, account creation."

## Presentation structure (15 minutes)

1. **The problem (2 min):** who, what, why it matters. One piece of evidence.
2. **What you learned (3 min):** research and synthesis, including a counter-example.
3. **What you decided (3 min):** two decisions, one rejected alternative, one trade-off.
4. **What you built (3 min):** a live walkthrough of the core task, including a failure state.
5. **What happened (2 min):** test results, before/after, limits.
6. **What you would do next (2 min):** the next experiment, not a wish list.

Do not read slides. Do not show every screen. Do not claim causation from five users.

## Panel questions

The panel will ask at least six questions, including:

- "What did you get wrong, and how did you find out?"
- "Why this decision rather than the obvious alternative?"
- "What does your evidence actually support?"
- "How did you handle the participant who behaved unexpectedly?"
- "What would you cut if you had half the time?"
- "Where did AI help, and where did it mislead you?"
- "How do you know the product is accessible?"
- "What would make you abandon this direction?"

Answers must be specific. "I would do more research" is not an answer. "I would test the fee estimate with five low-income users before building the confirmation screen, because the current sample was all classmates" is.

## Pass criteria

- [ ] Problem is specific and evidenced, not a solution in disguise.
- [ ] Research is ethical, documented and honestly limited.
- [ ] Design includes states, edge cases and accessibility evidence.
- [ ] Product is live and one core task works end to end.
- [ ] Five-participant test is documented, or a labelled pilot with a clear limitation.
- [ ] v2 responds to evidence and is deployed.
- [ ] Before/after comparison uses the same tasks and states limits.
- [ ] Case study is honest, specific and free of fabricated claims.
- [ ] Presentation fits 15 minutes and covers problem, decisions, build, results and next steps.
- [ ] Panel questions are answered with evidence, not deflection.
- [ ] AI use is disclosed and verified.
- [ ] No privacy, accessibility or integrity critical failure.

## Scoring

| Criterion | Weight | 4 | 3 | 2 | 1 |
|---|---|---|---|---|---|
| Problem framing and evidence | 20% | Specific, evidenced, consequential | Clear with minor gaps | Vague or partly solution-shaped | No real problem |
| Research and synthesis | 15% | Ethical, traceable, includes counter-evidence | Mostly traceable | Thin or overgeneralised | Fabricated or absent |
| Design and build | 20% | Works, responsive, accessible, states covered | Works with minor gaps | Partial or fragile | Does not work |
| Testing and iteration | 20% | Five users, honest analysis, real v2 | Small sample, some analysis | Token testing | No testing or invented |
| Communication and case study | 15% | Clear, honest, well-evidenced | Clear with gaps | Descriptive or inflated | Misleading |
| Panel Q&A and judgment | 10% | Specific, reflective, evidence-led | Adequate | Deflects or guesses | Cannot explain work |

A 4 is strong, 3 is pass, 2 is not yet, 1 is a critical gap. The overall score is weighted. A score below 60% on any criterion requires rework even if the total is above 80%.

## Critical failures (automatic rework, regardless of score)

- Fabricated research, participants, quotes, metrics, clients or outcomes.
- Recording or publishing a participant without consent.
- A privacy breach or exposed personal data.
- An accessibility failure that blocks a core task.
- A live product that does not work for the reviewer.
- Presenting AI-generated work as unaided, or being unable to explain shipped code.
- A misleading claim about results or impact.

## Academic and professional integrity

- Label fictional products and data clearly.
- Cite sources for external claims.
- Disclose AI use in the AI use statement: tools, stages, what you accepted, what you changed.
- Do not submit another learner's work or a template case study.
- Do not use a real client's confidential material without permission.
- Keep consent records and delete raw recordings on the stated date.

## If you do not pass

The panel will give you a written decision with:

- the criteria not met;
- the evidence;
- one required change;
- a resubmission scope and date.

Typical resubmission is targeted: re-run the test with a better sample, fix the accessibility blocker, or rewrite the results section without causal overreach. You do not repeat the whole capstone unless the problem framing itself is unsound.

## Panel conduct

- Three reviewers where possible: one design practitioner, one adjacent discipline (engineering, research or product), one provider representative.
- Declare conflicts of interest.
- Use the rubric independently before discussing.
- Ask questions, do not deliver a lecture.
- Record the decision and the evidence.
- Give the learner the right to respond to factual errors in the review.

The reviewer guide and full rubric are in `04_Instructor_Only/`.
