# Assessment Overview

This folder contains every **learner-facing** assessment. Answer keys, marking guidance and detailed rubrics are in `04_Instructor_Only/` and must not be shared with learners.

## How assessment works

| Element | Where | Pass rule |
|---|---|---|
| Stop comprehension check | 10 questions at the end of each lesson; learner copy in `Stop_Assessments/` | 8 of 10 (80%) |
| Stop practical task | Lesson section 10 and the assessment sheet | All listed pass criteria met |
| Phase gate | `Phase_0_Gate.md` … `Phase_6_Gate.md` | All criteria met and phase quiz average ≥ 80% |
| Capstone | `Capstone.md` | 80% overall, no criterion below 60%, no critical failure |

The course default mastery target is **80%**. Each stop has ten questions, so the pass mark is **8/10**. A learner who scores 7/10 has 70% and must retry.

The ten questions are balanced by purpose: four applied scenarios, three problem-identification items, two best-solution items and one judgment item. Correct answers are spread evenly across A–D across the course (95 each), so guessing one letter is not a strategy.

## How the browser check behaves

- The learner page never contains the correct option in plain text; it stores a SHA-256 hash per question.
- Submitting with unanswered questions is blocked and the first unanswered question receives focus.
- After submission the page shows the score, pass/fail at 8/10, per-question feedback and a list of sections to revisit.
- **The result is not saved to a TechSkillHub account and is not sent anywhere.** There is no backend in this package. Learners who need a record must copy the result into their learning log.
- If the browser cannot compute SHA-256 (for example, an old browser without Web Crypto), the page states that scoring is unavailable rather than guessing.

The instructor key remains the authoritative record.

## Critical-error override

A learner can meet the numeric threshold and still fail a stop or gate. The following force rework regardless of score:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: personal data in a shared file, recording without consent, publishing without permission;
- an accessibility failure that blocks a core task;
- an unsafe or deceptive design instruction (hidden fees, dark patterns, bypassing consent);
- claiming a test, measurement or conformance check that was not performed.

The override is recorded with evidence in the learner file.

## Resubmission

- One resubmission is allowed without penalty.
- A second resubmission requires a short conversation with the instructor.
- Resubmission is targeted: the learner redoes the criterion, not the whole phase.
- The highest score after resubmission is recorded, with the original attempt retained for audit.

## Human review

Every gate and the capstone require human review. AI may assist with first-pass consistency checks, but it cannot approve a gate, certify accessibility, or replace the capstone panel.

## Files

- `Stop_Assessments/` — 38 per-stop assessment sheets (10 questions, task, criteria, retry).
- `Phase_0_Gate.md` … `Phase_6_Gate.md` — seven phase gates.
- `Capstone.md` — final project and panel requirements.

## Marking records

Instructors should keep, for each learner:

- the submitted evidence;
- the criterion-by-criterion decision with one sentence of evidence;
- the score;
- any critical-error override and its basis;
- the resubmission decision and date.

Do not store raw recordings longer than the consent allows.
