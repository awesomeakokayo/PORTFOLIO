# Phase 3 Gate — Figma Fluency and Design Systems

**Phase:** 3 · Figma fluency and design systems
**Stops covered:** 3.1–3.5
**Suggested time:** 4–6 hours
**Review:** human instructor review required
**Pass target:** every criterion met, and an average of at least 80% across this phase's stop comprehension checks

## Purpose

This gate checks whether you can work inside Figma at a professional baseline: structured files, auto layout, components with variants and variables, a clickable prototype and a small system that another person could use.

You must show that you can:

- build a file with clear pages, frames and names;
- use auto layout and constraints rather than manual positioning;
- create components, variants and variables that behave predictably;
- build a prototype that tests a real task;
- document and govern a small design system.

## What to submit

1. **Figma file link** with view access (or an exported `.fig` plus screenshots if sharing is not possible).
2. **File map:** one page listing pages, frames and naming conventions.
3. **Three screens** built with auto layout and constraints.
4. **Component set:** at least three components, each with at least three variants.
5. **Variables:** colour and spacing variables used in the components, with a token table.
6. **Prototype:** a clickable flow for one task, with at least one error or empty branch.
7. **System documentation:** one page covering usage, do/don't and accessibility notes.
8. **Reflection:** 200 words on one thing that broke and how you fixed it.

## Tasks

### Task 1 — Structure the file before designing

Use pages:

- `00 Cover` — project name, version, owner, date, status.
- `01 Foundations` — colour, type, spacing, radius, elevation.
- `02 Components` — component sets and variants.
- `03 Screens` — product screens.
- `04 Prototype` — flows and connections.
- `05 Archive` — old work, clearly labelled.

Name layers with the pattern `area/component/variant/state`. No `Frame 427`, no `final-final-v2`.

### Task 2 — Build with auto layout

Every screen should survive a text change and a width change.

- Use auto layout for stacks, padding and gaps.
- Use `Fill container` for elements that should stretch.
- Use `Hug contents` for elements that should stay compact.
- Set min and max widths where content can break.
- Test with the longest realistic string, not filler Latin text.

A frame that only works with the exact placeholder copy is not finished.

### Task 3 — Build components, variants and variables

For each component:

- name the properties a user of the component would understand (`Size`, `State`, `Tone`);
- use variants for meaningful alternatives, not every colour;
- use variables for values that should change with theme or brand;
- document which combinations are valid and which are not.

Do not create a variant for a state that code cannot implement. Do not nest so deeply that nobody can find the override.

### Task 4 — Prototype a real task

The prototype must let a reviewer:

- start from a realistic entry point;
- complete one task in three to six steps;
- see a loading state;
- hit an error or empty state and recover;
- return to the start.

Use clear hotspots and a sensible back behaviour. Do not connect every frame to every other frame. A prototype is an argument about a flow, not a maze.

### Task 5 — Document the system

One page covering:

- purpose and scope;
- token table with names and values;
- component usage rules;
- do/don't examples;
- accessibility notes: focus, labels, contrast, target size;
- known limitations;
- change process: who can edit, how changes are reviewed.

Documentation that only shows screenshots is incomplete. Someone must be able to use the system without asking you.

## Pass criteria

- [ ] File has clear pages, names and a version/status.
- [ ] Three screens use auto layout and constraints.
- [ ] Screens survive a longest-text test and a narrow-width test.
- [ ] Three components each have at least three variants.
- [ ] Variables are used for colour and spacing; a token table exists.
- [ ] Prototype completes one task in 3–6 steps.
- [ ] Prototype includes loading and an error or empty branch.
- [ ] System documentation covers usage, do/don't and accessibility.
- [ ] No detached copies presented as components.
- [ ] Reflection describes a real failure and fix.

## Scoring

| Criterion | Weight | Met / Not yet met |
|---|---|---|
| File structure and naming | 15% | |
| Auto layout and resilience | 20% | |
| Components, variants and variables | 25% | |
| Prototype flow | 20% | |
| System documentation | 20% | |

All criteria must be met. A beautiful file that cannot be used by another designer does not pass.

## Critical failures (automatic rework)

- A component set that is only detached copies.
- A prototype with no error or empty path for a core task.
- Text that overflows or disappears at 320px with no stated reason.
- A system with no usage rules.
- Sharing a file that contains real client or personal data.

## If you do not pass

- **Structure weak:** rebuild the file map and rename layers before adding anything new.
- **Auto layout weak:** rebuild one screen from scratch using only auto layout, then apply the pattern.
- **Variants messy:** reduce to the three properties that matter and document valid combinations.
- **Prototype weak:** write the flow as a numbered list first, then connect only those steps.
- **Documentation weak:** ask a peer to use the system without your help and record every question.

## Instructor review notes

Open the file and try to resize a frame and change a text string. If it breaks, auto layout is not finished. Check that variants map to real states, not cosmetic duplicates. Ask the learner to explain one override. Detailed rubric: `04_Instructor_Only/Rubrics/Gate_Rubrics.md`.
