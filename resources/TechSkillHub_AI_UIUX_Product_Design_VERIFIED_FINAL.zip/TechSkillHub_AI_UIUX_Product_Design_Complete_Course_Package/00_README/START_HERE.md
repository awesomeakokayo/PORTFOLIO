# Start Here

**Course:** AI-Assisted UI/UX and Product Design
**Provider:** TechSkillHub
**Format:** self-paced, project-based, human-reviewed
**Stops:** 38 across eight phases
**Assessment:** 10 questions per stop (380 total), pass mark 8/10 (80%), plus a practical task
**Mastery target:** 80%, with a critical-error override
**Package version:** 1.1 (verified final)
**Content last verified:** 2026-10-30

## What this package is

A complete, beginner-friendly course that takes you from setting up a workspace to presenting a tested, deployed product to a reviewer panel. It teaches UI/UX and product design with AI as a directed assistant, not an authority.

It is not a collection of slides. Every stop contains teaching, a worked example, guided practice, an independent task, a comprehension check, pass criteria, a proof artifact and a low-data path. The full lesson text is in this package; you do not need to buy a tool or watch a video to complete a stop.

## Read this before your first lesson

1. **You are responsible for what you ship.** AI can draft, suggest and generate. You must verify facts, accessibility, privacy and code.
2. **The course is self-paced.** Suggested times are guidance. There are no weeks, deadlines or penalties for taking longer.
3. **Mastery is 80%.** Each stop has ten questions; you need 8/10. A practical task must also meet every pass criterion.
4. **Critical errors override the score.** Fabrication, privacy breaches, accessibility blockers and unsafe design force rework even if the quiz score is high.
5. **The course does not promise a job or income.** It provides practice, feedback and portfolio evidence.

## Your first hour

1. Read this file and [`COURSE_MAP.md`](../01_Course_Map/COURSE_MAP.md).
2. Create the folder structure in Stop 0.1.
3. Open [`Stop 0.1 — Your Workspace`](../02_Learner_Content/Phase_0_Getting_Started/Stop_0.1_Your_Workspace.md).
4. Complete the stop, then answer the ten questions in [`Stop 0.1 Assessment`](../03_Assessments/Learner/Stop_Assessments/Stop_0.1_Assessment.md).
5. Save your proof artifact in your portfolio folder.
6. Move to Stop 0.2. Do not skip Phase 0; it sets the habits the rest of the course depends on.

If you want to see the platform format first, open [`sample_lesson_page.html`](../05_Platform_Ready/HTML/sample_lesson_page.html) in a browser.

## Package structure

```
00_README/
  START_HERE.md                  this file
01_Course_Map/
  COURSE_MAP.md                  phases, stops, sequence, time
  STOP_INDEX.csv                 machine-readable stop list
  DEPENDENCY_GRAPH.md            what must come before what
  ACHIEVEMENT_MAP.md             capabilities and evidence
02_Learner_Content/
  Phase_0_Getting_Started/       Stop 0.1–0.5
  Phase_1_Product_Thinking_And_Research/
  Phase_2_Visual_And_Interaction_Foundations/
  Phase_3_Figma_And_Design_Systems/
  Phase_4_AI_Design_Workflow/
  Phase_5_Design_To_Build/
  Phase_6_Testing_Metrics_Iteration/
  Phase_7_Capstone_And_Career/
03_Assessments/
  Learner/                       stop sheets, seven phase gates, capstone
04_Instructor_Only/              never distribute to learners
  Answer_Keys/                   38 stop keys (380 questions) with rationales
  Rubrics/                       gate rubrics, capstone rubric, handbook, panel guide
05_Platform_Ready/
  Markdown/                      38 platform-ready lesson files
  JSON/                          course.json and 38 lesson JSON files
  HTML/                          40-page responsive site with quizzes and video component
06_Research/
  RESEARCH_REPORT.md             method, findings, limits
  SOURCE_REGISTER.csv            66 reviewed reading sources with status evidence
07_Resources/
  RESOURCE_DOCUMENTATION.md      how resources were selected and checked
  RESOURCE_REVIEW.csv            66 current sources, 17 review fields
  ORIGINAL_RESOURCE_REVIEW.csv   the original 54 sources, 49 kept / 5 replaced
  RESOURCE_SUFFICIENCY_MATRIX.csv  38 stops x resource coverage
08_YouTube/
  YOUTUBE_VIDEO_MANIFEST.csv     38 rows, one per stop, with playback evidence
09_Verification/
  VERIFICATION_LOG.md            what was run, what passed, what remains unverified
  VIDEO_VERIFICATION_REPORT.md
  RESOURCE_SUFFICIENCY_REPORT.md
  BEGINNER_LEARNING_QUALITY_REPORT.md
  PLATFORM_FUNCTIONAL_TEST_REPORT.md
  ACCESSIBILITY_AUDIT.md
  RELEASE_READINESS_REPORT.md
10_Audit/
  FINAL_COMPLETENESS_AUDIT.md    requirement-by-requirement audit
  CHANGELOG.md                   what changed between v1 and this release
  FILE_MANIFEST_SHA256.txt       hashes for every packaged file
11_Validation/
  README.md                      how to reproduce the checks
  validate.js                    structure, links, keys, rubrics, resources, videos, HTML
  verify_manifest.js             SHA-256 check of every packaged file
  test_platform.js               browser routes, quizzes, mobile, video, low bandwidth, axe
  build_zip.js                   rebuild the archive with forward-slash paths
  package.json                   optional browser-test dependencies
```

## Where the answers are

Learner files contain questions and tasks but **no answers, rationales or marking guidance**. Those are in [`04_Instructor_Only/`](../04_Instructor_Only/Rubrics/Instructor_Handbook.md). If you are learning on your own, do not open that folder until you have attempted the task. If you are delivering the course, keep it out of the learner-facing LMS and shared drives.

The browser quizzes check answers against SHA-256 hashes, so the correct option is not stored in plain text in the learner page. The published keys remain in the instructor folder and are the authoritative record.

## How paths and links work

Markdown links in this package are ordinary relative links, so they work when the folder is opened on disk or served as static files. Paths written in backticks that begin with `00_`, `01_` … `10_` are **package-root-relative**: they name a location from the top of the package, not from the file you are reading. Example: `03_Assessments/Learner/Capstone.md` means the Capstone file inside the `03_Assessments` folder at the package root. The validator resolves both link forms and reports any missing target.

## How the course uses AI

- AI is used for synthesis, ideation, UI generation, critique, microcopy and code.
- Every AI output must be verified against evidence, standards or a running product.
- You must keep a prompt and decision log for substantial AI work.
- You must disclose AI use at gates and in the capstone.
- You must not upload personal or confidential data to a tool you have not checked.
- You must be able to explain any code or design decision you ship.

The course does not require AI. A learner who does the work without AI can pass every gate; the comparison in Gate 4 asks for judgment, not dependence. Stop 0.1 includes a full no-AI route through the task, evidence and pass criteria.

## Tools and cost

- **Figma:** free tier is enough for the design phases.
- **Browser and editor:** any modern browser and a plain-text editor.
- **Hosting:** GitHub Pages or Netlify Drop, free.
- **AI:** free tiers are enough; paid tiers are optional.
- **Images:** use your own, public-domain or clearly licensed assets; credit them.
- **No paid stock library, device or certification is required.**

Every stop has a low-data path, including offline alternatives and text-only resources. The HTML lessons load no video until the learner presses the button, and the quiz works with YouTube blocked.

## Accessibility of this package

- The HTML site has a skip link, visible focus states, text-size controls, semantic headings, keyboard-focusable code and table regions, and a low-bandwidth video fallback.
- The Markdown files are plain text and work with screen readers.
- Tables are used for structured comparison; on small screens they scroll or wrap within a labelled container.
- Videos are optional. The lesson text covers the outcome without requiring playback.
- Automated WCAG 2.2 AA checks (axe-core) report zero violations on all 40 pages; this is not a substitute for testing with disabled learners and their own assistive technology.

Known limitation: every recommended video advertises an English caption track, but caption accuracy was not reviewed because YouTube transcript retrieval was blocked from the test environment. The lessons provide equivalent text, and the HTML notes where to find YouTube captions.

## Privacy and data

- Research notes must be anonymised before storage or sharing.
- Consent is required before recording.
- Do not put real names, phone numbers, addresses, account numbers or client contracts in course files.
- Use fictional data for practice and label it clearly.
- Delete raw recordings at the consent date.
- Stop 0.1 never asks you to record an email address, and the AI account is optional.

## Regional context

Examples use Nigerian and wider African settings where relevant. They are fictional. The course does not assume one country, currency, device, connectivity level or family structure. Adapt the examples and say what you changed.

All 38 videos list Nigeria in their available-country metadata, but playback from a Nigerian network was **not** tested. Treat regional availability as unconfirmed and use the lesson text or an alternative source if a video is blocked.

## What is verified, and what is not

Verified on 2026-10-30:

- all 38 lessons exist and contain the required sections;
- all 38 stop quizzes have ten questions, a published key and balanced A–D answer positions (95 each);
- 380 questions match the required 152 applied / 114 problem / 76 best / 38 judgment composition;
- all 380 key lines explain why the answer is right and why each distractor is wrong;
- all 38 rubrics have four criteria with four distinct levels;
- JSON files parse and CSV files have consistent columns;
- internal links and local HTML assets resolve within the package;
- all 40 HTML routes load with zero console errors in a real browser;
- all 38 quizzes block unanswered submission, score 10/10 and 0/10 correctly, and reset cleanly;
- all 40 pages pass a 320 px reflow check and axe WCAG 2.2 AA with zero violations;
- all 38 videos play inside the real lesson embed (iframe loaded, `readyState 4`, time advanced);
- all 38 videos report playability `OK` and list Nigeria in available countries;
- 66 reading sources were reviewed; 65 returned HTTP 200 and one (W3C) returned 403 to Node but loaded in a browser.

Not verified:

- playback from a Nigerian network or any specific region;
- direct watch-page content playback for 25 stops (pre-roll ads exceeded the test window); embedded playback is verified instead;
- caption accuracy or full video content review;
- timestamps inside videos;
- real beginner pilot testing or learner outcomes;
- screen-reader behaviour on every assistive technology and device;
- deployment through Netlify Drop (the interface was reviewed, but no live upload was performed);
- a TechSkillHub account backend: quiz results are **not** saved or sent anywhere.

The full record is in [`09_Verification/VERIFICATION_LOG.md`](../09_Verification/VERIFICATION_LOG.md). The requirement-by-requirement audit is in [`10_Audit/FINAL_COMPLETENESS_AUDIT.md`](../10_Audit/FINAL_COMPLETENESS_AUDIT.md), and the hash list is [`10_Audit/FILE_MANIFEST_SHA256.txt`](../10_Audit/FILE_MANIFEST_SHA256.txt). Do not describe the package as "fully tested" beyond what those files support.

## If you get stuck

1. Re-read the step named in the question rationale.
2. Use the retry variant in the lesson; it is designed for a fresh attempt, not a repeat.
3. Ask an instructor for targeted feedback, not the answer.
4. If a link or video fails, use the text resources and report it so the package can be updated.

## If you are delivering the course

Read [`04_Instructor_Only/Rubrics/Instructor_Handbook.md`](../04_Instructor_Only/Rubrics/Instructor_Handbook.md) first. It covers gate review, feedback, AI policy, privacy, safeguarding, accessibility, regional context and record keeping. Then read [`Reviewer_Panel_Guide.md`](../04_Instructor_Only/Rubrics/Reviewer_Panel_Guide.md) before the first capstone.

Do not add deadlines to learner-facing files. Do not promise employment. Do not share answer keys.
