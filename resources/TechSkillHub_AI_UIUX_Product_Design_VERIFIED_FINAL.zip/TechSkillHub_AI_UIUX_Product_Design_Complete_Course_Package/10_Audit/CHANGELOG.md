# Changelog

## 1.1 — Verified Final (2026-10-30 testing; packaged 2026-11-01)

This release corrects the v1.0 package after a full content, assessment, resource, video and platform review. The eight phases, 38 stop IDs, sequence and prerequisites are unchanged.

### Assessment

- Replaced the eight-question check with **10 questions per stop, 380 total**.
- Question composition is now exactly **152 applied / 114 problem / 76 best / 38 judgment**, matching the required 4/3/2/1 pattern per stop.
- Correct-answer positions are balanced **A = 95, B = 95, C = 95, D = 95**.
- Pass mark is **8/10 (80%)**, replacing the old 7/8 rule.
- Added two new questions per stop and merged them into the canonical source.
- Rewrote every distractor explanation with an option-specific reason; removed generic "this is wrong" text.
- Fixed two wrong keys found during review: **4.4 Q2 C → A** and **4.6 Q7 D → A**.
- Rebalanced every option set so the correct answer is not a length clue. Average correct option length is 14.0 words; average distractor length is 14.0 words; validator ratio 1.03.
- Removed three duplicate stems: 6.2 Q4, 4.5 Q2 and 5.3 Q1.
- The browser quiz now stores only salted SHA-256 hashes, blocks unanswered submission, marks each question, lists sections to revisit, and resets cleanly.
- The quiz result explicitly says it is **not saved to a TechSkillHub account and not sent anywhere**.

### Rubrics

- Replaced template-style rubric rows with **four criterion-specific criteria per stop**, each with four distinct level descriptors.
- Added an explicit criterion-to-kind map and kind-specific level modules (foundation, visual, build, career).
- Remaining pass criteria are now **mandatory minimum gates**, not additional rubric rows.
- Capstone remains 80% overall / 60% per criterion, labelled a proposed TechSkillHub policy.

### Content corrections

- **Stop 0.1 privacy:** removed the instruction to record an email address; removed the claim that two accounts are mandatory; made the AI account optional; added a complete no-AI route through tools, Steps 5 and 8, Section 13 and the pass criteria; updated the privacy criterion to cover the no-AI route.
- **Stop 5.0 clipboard:** replaced the example that claimed success without checking with a real `navigator.clipboard.writeText()` call, a secure-context guard, an awaited result, a caught failure and a manual-copy fallback. Added `role="status"` and explanatory text. Modernised `var` to `const`.
- Corrected **39 stops → 38 stops** and **8 questions → 10 questions** in Stop 0.2.
- Corrected a wrong explanation that said the course has seven phases.
- Removed stale "not playback-tested" text from 12 video notes.
- Replaced Google PAIR with Microsoft HAX Guidelines for Human-AI Interaction where PAIR's app shell was not content-readable.

### Resources

- Reviewed the original **54 non-video sources** one by one: **49 kept, 5 removed or replaced**.
- Expanded the current source set to **66 unique sources**.
- Added stronger sources at 0.2, 0.4, 1.1, 1.3, 1.4, 2.4, 3.4, 4.1, 4.2, 6.2, 6.3, 7.1, 7.2 and 7.4.
- Created `RESOURCE_REVIEW.csv` (66 rows, 17 fields), `ORIGINAL_RESOURCE_REVIEW.csv` (54 rows) and `RESOURCE_SUFFICIENCY_MATRIX.csv` (38 rows, 20 fields).
- Recorded honest access evidence: 62 sources returned HTTP 200; 4 W3C pages returned 403 to scripted clients and were reviewed in a browser.
- Recorded beginner fit, cost, login requirement, currency, lesson fit, review note, verdict and gap/replacement for every source.

### Videos

- Tested all 38 videos in the real lesson embed: every iframe loaded, every media element reached `readyState 4`, playback advanced.
- Found and fixed YouTube **Error 153** by setting `referrerPolicy = "strict-origin-when-cross-origin"` before `src` and removing `loading="lazy"` from the click-created iframe.
- Confirmed 38/38 watch pages return HTTP 200 with playability `OK`.
- Confirmed 38/38 list Nigeria among 249 available countries.
- Confirmed 38/38 list an English caption track.
- Confirmed direct watch-page content playback for 13/38; 8 were blocked by pre-roll ads and 17 were not attempted. Embedded playback is verified for all 38.
- Created a 16-column `YOUTUBE_VIDEO_MANIFEST.csv` and a 38-row verification report with honest final statuses.
- Did **not** invent replacement IDs or timestamps. No video was replaced in this round.

### Platform and accessibility

- Added a `data:` favicon to all 40 pages.
- Made all fenced code blocks keyboard-focusable with `aria-label="Code sample"`.
- Made table wrappers labelled, focusable scroll regions; removed the forced table `min-width`.
- Allowed wrapping for links, inline code, table cells and pre blocks; added vertical padding to nav links.
- Added `tabindex="-1"` to `main` so the skip link moves focus, not just scroll position.
- Verified 40/40 routes, 38/38 quizzes, 40/40 mobile pages, the video component, the low-bandwidth route and 40/40 axe WCAG 2.2 AA pages with zero violations.
- Verified the concrete code samples in a browser: clipboard success, clipboard rejection fallback, missing-API fallback, offline indicator, seven CSS blocks and responsive image markup (14/14).

### Documentation

- Rewrote `START_HERE.md`, `COURSE_MAP.md`, `Assessment_Overview.md`, the answer-key README, the instructor handbook, the research report, the resource documentation and this audit trail for the new counts and honest verification status.
- Added `VIDEO_VERIFICATION_REPORT.md`, `RESOURCE_SUFFICIENCY_REPORT.md`, `BEGINNER_LEARNING_QUALITY_REPORT.md`, `PLATFORM_FUNCTIONAL_TEST_REPORT.md`, `ACCESSIBILITY_AUDIT.md`, `RELEASE_READINESS_REPORT.md`, `CHANGELOG.md` and a rewritten `VERIFICATION_LOG.md`.
- Added `validate.js`, `build_zip.js`, the browser test harnesses and the code-sample harness to the build workspace. The package now ships `11_Validation/` with `validate.js`, `verify_manifest.js`, `test_platform.js`, `build_zip.js`, a README and an optional `package.json`, so a maintainer can reproduce the checks.

### Release packaging

- Built the archive with a custom ZIP writer using forward-slash paths, UTF-8 name flags, CRC32 and a central-directory read-back check.
- Extracted the archive into a clean directory and re-ran structural validation before release.

### Not changed

- The eight phases, 38 stop IDs, titles, order and prerequisites.
- The 80% mastery policy (now applied as 8/10).
- The capstone 80% / 60% policy.
- The requirement that every stop has a low-data and a no-AI route.
- The ban on employment, salary or income promises.
