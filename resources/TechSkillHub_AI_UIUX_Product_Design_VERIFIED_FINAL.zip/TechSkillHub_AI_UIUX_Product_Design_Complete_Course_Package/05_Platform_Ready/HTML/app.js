/* TechSkillHub course platform: no dependencies. */
(function () {
  'use strict';

  // ---- offline notice ----
  function setOnline() {
    var el = document.getElementById('offline');
    if (!el) return;
    el.hidden = navigator.onLine;
  }
  window.addEventListener('online', setOnline);
  window.addEventListener('offline', setOnline);
  setOnline();

  // ---- text size ----
  var KEY = 'tsh-text-size';
  function applyText(size) {
    document.body.classList.toggle('large-text', size === 'large');
    try { localStorage.setItem(KEY, size); } catch (e) {}
  }
  try { applyText(localStorage.getItem(KEY) || 'normal'); } catch (e) {}
  document.querySelectorAll('[data-text-size]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      applyText(btn.getAttribute('data-text-size'));
    });
  });

  // ---- video embed component ----
  // Attributes: video-id, title, creator, duration, url, summary
  class VideoEmbed extends HTMLElement {
    connectedCallback() {
      var id = this.getAttribute('video-id');
      var title = this.getAttribute('title') || 'Recommended video';
      var creator = this.getAttribute('creator') || '';
      var duration = this.getAttribute('duration') || '';
      var url = this.getAttribute('url') || ('https://www.youtube.com/watch?v=' + id);
      var summary = this.getAttribute('summary') || '';
      var shell = document.createElement('div');
      shell.className = 'video-shell';
      shell.innerHTML =
        '<div class="video-poster">' +
        '<p><strong>' + escapeHtml(title) + '</strong></p>' +
        '<p>' + escapeHtml(creator) + (duration ? ' · ' + escapeHtml(duration) : '') + '</p>' +
        '<button type="button" class="play">Load video (uses data)</button>' +
        '<p>Low-bandwidth option: the page works without loading the video. Use the link below to open it in a new tab, or read the course text in this lesson.</p>' +
        '</div>';
      this.appendChild(shell);
      var self = this;
      shell.querySelector('.play').addEventListener('click', function () {
        var iframe = document.createElement('iframe');
        iframe.title = title;
        iframe.allow = 'accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share';
        iframe.allowFullscreen = true;
        // YouTube returns "Error 153" for many embeds when the referrer is
        // stripped. Set the policy before src so the first request carries it.
        iframe.referrerPolicy = 'strict-origin-when-cross-origin';
        iframe.src = 'https://www.youtube-nocookie.com/embed/' + encodeURIComponent(id) + '?rel=0&hl=en';
        shell.innerHTML = '';
        shell.appendChild(iframe);
        self.dispatchEvent(new CustomEvent('video-loaded', { bubbles: true }));
      });
      var alt = document.createElement('div');
      alt.className = 'video-alt';
      alt.innerHTML = 'Direct link (no embed): <a href="' + escapeAttr(url) + '" rel="noopener">' +
        escapeHtml(title) + '</a>. Video summary, not a transcript: ' + escapeHtml(summary);
      this.appendChild(alt);
    }
  }
  if (!customElements.get('video-embed')) customElements.define('video-embed', VideoEmbed);

  function escapeHtml(s) {
    return String(s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }
  function escapeAttr(s) { return escapeHtml(s).replace(/'/g, '&#39;'); }

  // ---- quiz: browser-only self-check against hashed answers ----
  var form = document.querySelector('form.quiz-form');
  if (form) {
    var salt = form.getAttribute('data-salt') || '';
    var alertBox = document.getElementById('quiz-alert');
    var resultBox = document.getElementById('quiz-result');

    function clearQuizState() {
      form.querySelectorAll('fieldset[data-q]').forEach(function (fs) {
        fs.classList.remove('correct', 'incorrect', 'unanswered');
        var fb = fs.querySelector('.q-feedback');
        if (fb) { fb.hidden = true; fb.textContent = ''; }
      });
      if (alertBox) { alertBox.hidden = true; alertBox.textContent = ''; }
      if (resultBox) { resultBox.hidden = true; resultBox.textContent = ''; resultBox.className = 'quiz-result'; }
    }

    function sha256Hex(text) {
      var bytes = new TextEncoder().encode(text);
      return window.crypto.subtle.digest('SHA-256', bytes).then(function (buffer) {
        return Array.prototype.map.call(new Uint8Array(buffer), function (b) {
          return b.toString(16).padStart(2, '0');
        }).join('');
      });
    }

    form.addEventListener('reset', function () {
      window.setTimeout(clearQuizState, 0);
    });

    form.addEventListener('submit', function (event) {
      event.preventDefault();
      clearQuizState();

      var fieldsets = Array.prototype.slice.call(form.querySelectorAll('fieldset[data-q]'));
      var unanswered = fieldsets.filter(function (fs) {
        return !fs.querySelector('input:checked');
      });

      if (unanswered.length) {
        unanswered.forEach(function (fs) { fs.classList.add('unanswered'); });
        if (alertBox) {
          alertBox.hidden = false;
          alertBox.textContent = 'Answer every question before checking. Unanswered: Q' +
            unanswered.map(function (fs) { return fs.getAttribute('data-q'); }).join(', Q') + '.';
        }
        var first = unanswered[0].querySelector('input');
        if (first) first.focus();
        return;
      }

      if (!(window.crypto && window.crypto.subtle && window.TextEncoder)) {
        if (resultBox) {
          resultBox.hidden = false;
          resultBox.className = 'quiz-result unavailable';
          resultBox.textContent = 'Scoring is unavailable in this browser context because Web Crypto is blocked. ' +
            'Your answers were not scored and nothing was saved. Open this page over HTTPS or localhost, or ask your instructor to mark the answers with the answer key.';
          resultBox.focus();
        }
        return;
      }

      Promise.all(fieldsets.map(function (fs) {
        var picked = fs.querySelector('input:checked');
        var q = fs.getAttribute('data-q');
        return sha256Hex(q + ':' + picked.value + ':' + salt).then(function (hash) {
          var hashes = (fs.getAttribute('data-hash') || '').split('|');
          return { fs: fs, q: q, ref: fs.getAttribute('data-ref') || 'the lesson', correct: hashes.indexOf(hash) !== -1 };
        });
      })).then(function (marks) {
        var score = 0;
        var wrong = [];
        marks.forEach(function (mark) {
          var fb = mark.fs.querySelector('.q-feedback');
          mark.fs.classList.add(mark.correct ? 'correct' : 'incorrect');
          if (mark.correct) {
            score += 1;
            if (fb) {
              fb.hidden = false;
              fb.textContent = 'Correct.';
            }
          } else {
            wrong.push(mark);
            if (fb) {
              fb.hidden = false;
              fb.textContent = 'Not correct. Re-read ' + mark.ref + ' and compare your reasoning with the lesson. The answer key is instructor-only.';
            }
          }
        });

        var percent = Math.round((score / marks.length) * 100);
        var passed = score >= 8;
        if (!resultBox) return;
        resultBox.hidden = false;
        resultBox.className = 'quiz-result ' + (passed ? 'pass' : 'fail');
        resultBox.textContent = '';

        var headline = document.createElement('p');
        headline.className = 'quiz-score';
        headline.textContent = 'Score: ' + score + '/' + marks.length + ' (' + percent + '%). ' +
          (passed ? 'Pass.' : 'Not yet at the 8/10 pass mark.');
        resultBox.appendChild(headline);

        var note = document.createElement('p');
        note.textContent = passed
          ? 'The comprehension check is complete. Now submit the practical task and its evidence; the quiz score cannot replace the practical criteria.'
          : 'Re-read the sections listed below, then complete the retry variant in Section 11. Do not simply guess again.';
        resultBox.appendChild(note);

        if (wrong.length) {
          var list = document.createElement('ul');
          wrong.forEach(function (mark) {
            var item = document.createElement('li');
            item.textContent = 'Q' + mark.q + ' — revisit ' + mark.ref + '.';
            list.appendChild(item);
          });
          resultBox.appendChild(list);
        }

        var saved = document.createElement('p');
        saved.className = 'hint';
        saved.textContent = 'This result is not saved to a TechSkillHub account and is not sent anywhere. Copy it into your learning log if you need a record.';
        resultBox.appendChild(saved);
        resultBox.focus();
      }).catch(function () {
        if (resultBox) {
          resultBox.hidden = false;
          resultBox.className = 'quiz-result unavailable';
          resultBox.textContent = 'Scoring could not run in this browser. Your answers were not scored and nothing was saved. Ask your instructor to mark them with the answer key.';
          resultBox.focus();
        }
      });
    });
  }

  // ---- reading progress (subtle, no layout shift) ----
  var bar = document.querySelector('.progress-bar');
  if (bar) {
    function update() {
      var h = document.documentElement;
      var max = h.scrollHeight - h.clientHeight;
      var pct = max > 0 ? (h.scrollTop / max) * 100 : 0;
      bar.style.width = pct.toFixed(1) + '%';
    }
    window.addEventListener('scroll', update, { passive: true });
    update();
  }
})();
