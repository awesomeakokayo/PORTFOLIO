# Lesson JSON schema (version 1.2)

One file per stop: `lessons/stop_<id>.json`. `course.json` indexes them. All files parse with a standard JSON parser.

## Top level

| Field | Type | Meaning |
|---|---|---|
| `schemaVersion` | string | Schema version for this payload. |
| `id` | string | Stop ID, for example `2.3`. |
| `title` | string | Stop title. |
| `phase` | number | Phase number, 0–7. |
| `phaseTitle` | string | Human-readable phase title. |
| `prerequisites` | string | What must be completed first. |
| `outcome` | string | Observable learning outcome. |
| `time` | string | Suggested session length. Guidance only; no deadline. |
| `tools`, `cost`, `data` | string | Tool, cost and data-use warnings for the stop. |
| `artifact` | string | Proof artifact the learner saves. |
| `visibility` | string | Always `learner` for this payload. |
| `instructorOnly` | boolean | Always `false`. Answers and rationales are not present. |
| `wordCount` | number | Word count of the learner lesson body. |
| `content` | object | Structured lesson content (below). |
| `video` | object | Video metadata, verification evidence and embed URL. Playback evidence is recorded per stop; it is not a guarantee for every region or device. |
| `quiz` | array | Ten questions, four options each, a question type and a lesson reference. **No correct answer, rationale or distractor analysis.** |
| `resources` | object | Video note and selected readings, plus the readings as Markdown. |
| `markdown` | string | Full learner-facing Markdown, with all hidden keys stripped. |

## `content` object

| Field | Type | Meaning |
|---|---|---|
| `definitions` | string (Markdown) | Plain-English terms. |
| `whyItMatters` | string (Markdown) | Relevance and everyday example. |
| `beforeYouStart` | string (Markdown) | Prerequisites and setup checks. |
| `teachingChunks` | array of `{title, body}` | Ordered teaching steps parsed from the lesson. |
| `workedExample` | string (Markdown) | I-do example including reasoning. |
| `guidedPractice` | string (Markdown) | We-do practice with hints. |
| `independentPractice` | string (Markdown) | You-do task that is not a copy of the example. |
| `comprehensionCheck` | object | `instructions` and `questionCount`. |
| `practicalTask` | object | `task` and `passCriteria` array. |
| `commonMistakes` | string (Markdown) | Mistakes table. |
| `remediation` | object | `commonMistakes` and `retryVariant`. |
| `proofArtifact` | string (Markdown) | What goes in the portfolio. |
| `lowDataPath` | string (Markdown) | Text-first, offline and low-cost route. |

## Instructor separation

Answer letters, rationales and marking guidance are **not** fields in this schema. They live only in `04_Instructor_Only/`. A platform adapter must not merge that folder into a learner payload.

## Video evidence fields

`video.watchPageStatus`, `video.playability`, `video.directWatchPlayback`, `video.embedStatus`, `video.embedEvidence`, `video.captions`, `video.region`, `video.contentFit` and `video.fitNote` record what was tested on 2026-10-30. Caption accuracy was not reviewed, and playback from Nigeria was not tested even though the metadata lists Nigeria. Do not present these fields as a promise that the video will play for every learner.

## Validation

`validate.js` parses every JSON file, checks that all 38 lesson files exist and that every stop has a quiz with ten questions and four options. It also checks answer-position balance, scans learner payloads for hidden answer markers and answer-key paths, and verifies that each stop has ten learner questions and ten instructor answers.
