# Stop 0.4 — Using AI as a Tutor

> **Phase 0 · Getting started** · Prerequisite: Stop 0.3 · Suggested session: 45–60 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Write a tutor prompt that produces an explanation at your level, with an example.
2. Check an AI answer against a trusted source instead of accepting it.
3. Mark an answer **right**, **partly right** or **wrong**, and say exactly what is off.
4. Explain, in plain words, why an AI can sound confident and still be wrong.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **AI assistant** | A chat tool that generates text in response to your instructions, for example ChatGPT or Gemini. |
| **Large language model (LLM)** | The kind of model behind these tools. It predicts likely next words from patterns in training data. |
| **Prompt** | The instruction you give the AI. Better prompts produce more useful answers. |
| **Hallucination** | A confident answer that is false or invented, such as a source that does not exist. |
| **Source** | The original place a claim comes from: official documentation, a standard, a study, a named expert. |
| **Primary source** | The first-hand document, such as W3C's WCAG text or Figma's own help page. |
| **Secondary source** | A summary of a primary source, such as a blog post explaining WCAG. Useful, but one step removed. |
| **Verification** | Checking a claim against evidence before using it. |
| **Bias** | A systematic slant in output, often reflecting patterns in training data or the way a question was asked. |
| **Context window** | How much text the AI can consider at once. Very long documents may be truncated or summarised. |
| **Prompt injection** | Text inside a document or web page that tries to redirect the AI's behaviour. Relevant when you paste untrusted content. |
| **Data privacy** | Keeping personal and confidential information out of tools that may store or review it. |

## 3. Why this matters

AI is a patient tutor with infinite time and no memory of being wrong. That combination is powerful and dangerous. It will explain a concept ten different ways until one lands. It will also invent a WCAG success criterion number, misname a Figma feature, or confidently describe a tool that no longer exists.

The skill you are building is not "use AI". It is **use AI and stay the judge**. This is the first appearance of the course's central habit: generate, verify, decide.

> **Everyday example.** A helpful stranger gives you directions in a city they have never visited. They sound certain. If you follow without checking a map, you may walk confidently in the wrong direction. The map is the primary source. The stranger is the model.

## 4. Before you start

- Have your Stop 0.3 glossary open.
- Sign in to one AI assistant. If you have none, read the low-data path in section 13 and use a search engine plus official docs instead; the verification skill is the same.
- Do **not** paste personal data, client data, passwords or unpublished work into the chat. Use invented examples.

## 5. Teaching, step by step

### Step 1 — Understand what the tool is doing

An LLM does not look up a fact and hand it to you. It produces the most plausible continuation of your text, based on patterns it learned. Most of the time that produces useful, fluent answers. Sometimes it produces fluent nonsense. It has no built-in "I am unsure" signal that you can trust, and it may apologise and change a correct answer just because you pushed back.

Practical consequence: **confidence is not evidence.** Judge the claim, not the tone.

### Step 2 — Write a tutor prompt with five parts

Use this structure:

1. **Role and level:** "You are a patient design tutor for a complete beginner."
2. **Task:** "Explain what a 'primary button' is."
3. **Constraints:** "Use plain English, no jargon without defining it, at most 120 words."
4. **Example:** "Give one example from a mobile banking app."
5. **Check:** "End with one question that tests whether I understood."

Full example:

> You are a patient design tutor for a complete beginner. Explain what a "primary button" is in interface design. Use plain English, define any jargon, and keep it under 120 words. Give one example from a mobile banking app. End with one question that tests whether I understood.

This prompt works because it removes the AI's freedom to write an encyclopaedia entry. It also gives you a built-in comprehension check.

### Step 3 — Ask for the answer in a form you can verify

You want claims you can check, not vibes. Add one of these:

- "List any standards or official documents your answer relies on, with their names."
- "Separate what is a widely accepted principle from what is your opinion."
- "State one thing you are uncertain about."

If the AI cites a document, **open it**. If it cannot be found, treat the claim as unverified. This is exactly what you will do at scale in Stop 4.6.

### Step 4 — Check against a source you trust

For this course, the trusted check depends on the topic:

| Topic | Check against |
|---|---|
| Interface terms | This course's glossary, Material Design, Apple HIG, GOV.UK Design System |
| Accessibility | W3C WCAG 2.2 and the WAI quick reference |
| Figma procedure | Figma Help Centre |
| Research method | NN/g articles or GOV.UK Service Manual |
| Web basics | MDN |
| AI risk and privacy | NIST AI RMF, OECD AI Principles, provider documentation |

Open the source and search for the specific claim. Do not accept "the documentation says so" without seeing the sentence.

### Step 5 — Classify the answer honestly

Use three verdicts:

- **Right:** the core claim is correct, and the example does not mislead. Minor wording differences are fine.
- **Partly right:** the core is correct but something important is missing, oversimplified, or stated too absolutely. Example: "A primary button is always blue" — the role is right, the colour rule is false.
- **Wrong:** the core claim is false, or the answer invents a rule, standard or source.

Then write **what exactly** is off. "Partly right because it says the primary button is always the biggest element; a primary action can be a text link in some contexts, and size is one signal among several."

### Step 6 — Push back carefully

If you think the AI is wrong, do not say "you are wrong". Ask it to justify:

> "Which official source supports the claim that a primary button must be blue? Quote the sentence and give the section. If no source supports it, say so."

A model that folds immediately under pressure is showing you that its first answer was not grounded. A model that cites a real, checkable source is more useful — but you still open the source.

### Step 7 — Keep a tutor log

For every checked answer, record:

```
Date:
Question/topic:
Prompt used:
Answer in 2 sentences:
Verdict: right / partly right / wrong
What was off:
Source used to check (title + URL):
What I will ask next:
```

The log is the artifact. It proves you can use the tool without surrendering judgment.

## 6. Worked example (I do)

**Topic:** "What is a toast message?"

**Prompt used:**

> You are a patient design tutor for a complete beginner. Explain what a "toast" message is in interface design, in under 100 words, with one example from a food delivery app. Define any jargon. End with one question to test me.

**AI answer (paraphrased):** "A toast is a small notification that appears at the bottom of the screen for a few seconds and then disappears. It confirms something without interrupting the user, like 'Order placed'. It usually cannot be interacted with."

**My check:** I compare with this course's glossary (term 23) and with Material Design's snackbar guidance.

**Verdict:** **Right**, with one nuance. The core is correct. The nuance: toasts are for brief, non-critical confirmation; if the message requires action, a snackbar with an action or a dialog is better. The AI did not say that, but it did not claim the opposite, so it is not "partly right" — it is incomplete but accurate.

**What I would ask next:** "When should a designer choose a dialog instead of a toast? Give two concrete cases and name the trade-off."

**Why this is the right level of rigour:** I did not demand encyclopaedic completeness from a 100-word answer. I checked whether anything said was false or misleading, and I noted what was missing. That is the judgment the course is teaching.

**Second example, where the AI is wrong:** asked to name the minimum contrast ratio for normal text in WCAG 2.2 AA, an AI might say "3:1". The correct value is **4.5:1** for normal text and **3:1** for large text. Verdict: wrong. Source: W3C WCAG 2.2, Success Criterion 1.4.3. The fix is not to memorise the number from the AI; it is to open the standard.

## 7. We do it together

1. Choose three terms from the Stop 0.3 glossary: one you understand, one you half-understand, one you cannot explain.
2. For each, write a five-part tutor prompt. Keep them in your log.
3. Run the first prompt. Read the answer once, without checking.
4. Now open the lesson glossary and the relevant official source. Check every claim.
5. Write the verdict and "what was off".
6. Ask the follow-up question from the prompt and check that answer too.
7. For the term you cannot explain, ask the AI to quiz you with three questions, then answer without looking. This is the difference between reading an explanation and learning it.
8. Record how long the whole cycle took. Most beginners take 8–12 minutes per term at first; it gets faster.

## 8. Your turn (You do)

**Independent task.** Produce a **three-term AI tutor log** using three terms **not used in the worked example**. At least one term must be one you did not understand before this stop.

For each term include:

1. The exact prompt you used.
2. A two-sentence summary of the answer.
3. Your verdict: right, partly right or wrong.
4. The specific thing that was off, or "nothing material" if it was right.
5. The source you used to check, with title and URL.
6. One follow-up question you asked, and whether the follow-up improved the answer.

End with a 150-word reflection: *What did the AI do well, what did it get wrong, and what will you always check from now on?*

**Rules:** no personal data in the chat; no invented sources accepted; if the AI cites something, open it. If you cannot access an AI tool, use a search engine and a Q&A site as the "tutor" and apply the same verdict process — state this in the reflection.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** Why can an AI assistant give a confident but false answer?
- A. It generates likely text from patterns instead of looking up verified facts.
- B. It always copies its answers from unreliable websites that it finds online.
- C. It is designed to lie to users when it does not know the correct answer.
- D. It only works while offline, so it cannot check any current information.

**Q2.** Which is a primary source for a WCAG contrast requirement?
- A. A design blog post that summarises the WCAG contrast rules clearly.
- B. The W3C WCAG 2.2 specification, including the success criteria text.
- C. A comment under a YouTube tutorial that quotes the contrast number.
- D. An AI answer that mentions WCAG and gives a contrast ratio.

**Q3.** An AI says: "A primary button is always blue and always the largest element on screen." What is the best verdict?
- A. Partly right: the role is right, but "always blue" and "always largest" are false absolutes.
- B. Right, because primary buttons are usually blue and usually the largest element.
- C. Wrong, because primary buttons are never blue and are never the largest element.
- D. Right, because the AI was trained on a large amount of design data.

**Q4.** What is the best follow-up when you suspect an AI claim is unsupported?
- A. Ask which official source supports the claim, request the sentence and section, and accept a clear no.
- B. Tell the assistant it is wrong, demand an apology, and ask for a corrected answer right away.
- C. Start a new chat and ask the same question again using slightly different wording this time.
- D. Accept the answer if it sounds confident and matches what you already expected to hear.

**Q5.** Why should you avoid pasting a real client's interview transcript into a free AI chat?
- A. It makes the answer arrive much more slowly than a short prompt would.
- B. The service may store or review personal and confidential data afterwards.
- C. It changes the language and spelling that the AI uses in its reply.
- D. It is impossible to paste a long transcript into the chat box.

**Q6.** Which prompt is most likely to produce a useful beginner explanation?
- A. "Explain UI to me, covering everything that a complete beginner might ever need to know about the subject area."
- B. "Explain what a primary button is, in a way that a complete beginner can easily understand and then use."
- C. "Write everything about design, including its full history, its main tools, its underlying theory and everyday practice in real detail."
- D. "You are a patient tutor: explain a primary button in 120 words, with jargon defined, one banking example and a test question."

**Q7.** An AI answer is accurate but leaves out an important exception. Which verdict fits best?
- A. Right, with a noted omission — unless the omission makes the advice misleading.
- B. Wrong, because any omission means the answer cannot be trusted.
- C. Partly right only if the answer also cites a checkable official source.
- D. Unclear, because the missing exception cannot be seen from the answer alone.

**Q8.** What is the main purpose of keeping a tutor log?
- A. To prove to a reviewer that you used an AI assistant during the course.
- B. To make each chat session faster by storing your previous prompts and answers.
- C. To build evidence that you can verify and judge AI output, not just generate it.
- D. To replace your course notes with a record of every AI conversation.

**Q9.** An AI assistant says the WCAG 2.2 AA minimum contrast for normal text is 3:1. What is the strongest verification step?
- A. Check the success criterion in the official W3C WCAG 2.2 document and record the result.
- B. Ask the same assistant to confirm its answer and explain where the number came from.
- C. Search for a blog post that agrees with the number and quote it as evidence.
- D. Use the number because it sounds precise and comes from a design tool.

**Q10.** A learner pastes a real client's interview transcript into a free AI chat and asks for themes. What is the first problem to address?
- A. Confidential personal data has been sent to a third-party service without a lawful basis or consent.
- B. The transcript is too long for the model to hold inside its context window.
- C. The AI may reply using American spelling instead of the learner's local spelling.
- D. The learner did not ask for a short summary first before requesting the themes.

## 10. Practical task and pass criteria

**Task.** Submit your three-term AI tutor log and the 150-word reflection.

**Pass criteria — all must be met:**

- [ ] Three terms, none of which are the worked example ("toast").
- [ ] Each entry has an exact prompt, a summary, a verdict and a specific reason.
- [ ] Each entry names a real source with a working URL.
- [ ] At least one entry records a genuine error or omission in the AI answer.
- [ ] No personal, client or confidential data appears in any prompt.
- [ ] The reflection names one thing the AI did well and one thing you will always check.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Accepting the first answer | It sounds authoritative | Always open one source and check the central claim. |
| Asking "is this right?" | Invites agreement | Ask for the source and the reasoning, then check it yourself. |
| Treating a citation as proof | Citations look rigorous | Open the link; invented citations are common. |
| Pasting real transcripts | Convenience | Anonymise or use invented data. |
| Writing a vague prompt | Feels faster | Use the five parts; specificity saves iterations. |
| Recording only "right/wrong" | Binary thinking | Record what was off; that is the learning. |
| Letting the AI do the thinking | It is fluent | Ask it to quiz you; answer without looking. |

**Retry variant.** Repeat the log with three **accessibility** terms (for example: contrast ratio, focus indicator, alt text) and check every claim against W3C WCAG 2.2 or the WAI quick reference. This variant is harder because the standard is precise, so vague AI answers are easier to catch. Submit the new log plus a corrected version of one earlier entry where your verdict was too generous.

## 12. Proof artifact for your portfolio

**Artifact:** `AI-Tutor-Log-v1` — the three-term log and reflection, stored in `03_Projects/00_Foundations/ai-workflow`.

It becomes the first entry in your AI workflow log, which you will formalise in Stop 4.7 and show in your capstone.

## 13. Low-data and low-cost path

- The chat is text-only; it uses far less data than video.
- If you have no AI account, use a search engine and a reputable Q&A site, and apply the same verdict process. State the substitution in your reflection.
- If data is very low, do one term per session and combine the log afterwards. The assessment requires three terms, not one sitting.
- Skip the video; the lesson is complete without it.

## 14. Watch and read more

**Recommended video (optional, 21:16):** *ChatGPT Study Mode - Explained By A Learning Expert* — Justin Sung. `https://www.youtube.com/watch?v=m3jNwwuvqx8`. Verified available on 2026-10-30. It covers study-mode features that may change; the durable lesson is about using AI to test understanding rather than to produce answers. Feature availability varies by plan and country.

**Read (verified 2026-10-30):**

- IBM, *What Are AI Hallucinations?* — `https://www.ibm.com/think/topics/ai-hallucinations`. Beginner explanation of why a confident AI answer can still be false. Read the definition and causes; skip the product links. Updated 31 July 2026.
- NIST, *AI Risk Management Framework* — `https://www.nist.gov/itl/ai-risk-management-framework`. Advanced and optional. Skim only the "valid and reliable" characteristic; you do not need the whole framework for this stop.
- Microsoft, *Guidelines for Human-AI Interaction* — `https://www.microsoft.com/en-us/haxtoolkit/ai-guidelines/`. Advanced and optional. A readable list of 18 evidence-based practices for AI interfaces; useful later for designing AI features, not for judging a tutor answer today.

## 15. What comes next

Stop 0.5 is your first real design action: recreate one simple screen in Figma, then change one thing on your own. It is deliberately a copy-and-change task, so you get an early win before the harder thinking starts.