# Stop 6.3 — Iteration

> **Phase 6 · Testing, metrics and iteration** · Prerequisite: Stops 6.1 and 6.2 · Suggested session: 80–100 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Turn findings into a prioritised backlog using impact, confidence and effort.
2. Separate must-fix problems from nice-to-have improvements.
3. Write a v2 change with a reason, an expected effect and a way to check it.
4. Explain when an A/B test is appropriate and when it is not.
5. Protect against regressions with a re-test plan and a change log.
6. Say no to changes that are not supported by evidence.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Iteration** | A deliberate cycle of change, test and learn. |
| **Backlog** | An ordered list of possible changes. |
| **Prioritisation** | Deciding what to do first, based on evidence and constraints. |
| **Impact** | How much a change improves the user's ability to complete their goal. |
| **Confidence** | How sure you are that the change will have the expected effect. |
| **Effort** | The time, skill and risk needed to make the change. |
| **ICE / RICE** | Simple scoring models: Impact, Confidence, Ease (ICE) or Reach, Impact, Confidence, Effort (RICE). |
| **Must-fix** | A problem that blocks the task, causes data loss or excludes people; it is not optional. |
| **A/B test** | A controlled comparison where users are randomly assigned to version A or B. |
| **Hypothesis** | A testable statement: "If we change X, Y will improve because Z." |
| **Control** | The unchanged version in an experiment. |
| **Variant** | The changed version in an experiment. |
| **Regression** | A previously working behaviour that breaks after a change. |
| **Change log** | A record of what changed, why, and what happened. |
| **Rollback** | Reverting a change when it causes harm. |
| **Guardrail** | A metric protected from harm during an experiment. |

## 3. Why this matters

Testing produces a list of problems. Metrics produce a picture of where people leave. Neither tells you what to do next. Iteration is the judgment step: choose the few changes that matter, make them well, and check whether they worked.

Without prioritisation, teams fix the easiest thing or the loudest complaint. Without a hypothesis, they cannot tell whether a change helped. Without a change log, they repeat mistakes and cannot explain the product's history.

> **Everyday example.** A restaurant gets complaints about slow service, cold food, loud music and a broken chair. It cannot fix everything tonight. It fixes the broken chair immediately because it is a safety issue, turns down the music because it is cheap and may affect everyone, and investigates the kitchen timing with data. That is prioritisation, not a to-do list.

## 4. Before you start

- Bring the findings table from Stop 6.1 and the metric pack from Stop 6.2.
- Create a spreadsheet with columns: `ID | Finding | Evidence | Impact | Confidence | Effort | Priority | Decision | Owner | Check`.
- Set constraints: how many hours do you realistically have? What can you build without help?
- Decide the release boundary: what must be true before this v2 is shown to users?
- Do not run a live A/B test on real users for this course. Write the design of the test instead.

## 5. Teaching, step by step

### Step 1 — Normalise the findings

Rewrite every finding as a problem statement with evidence:

- Weak: "The checkout is confusing."
- Strong: "3 of 5 participants missed the delivery fee because it appeared only after the payment step; 2 abandoned the task."

Weak: "Users want a dark mode."
- Strong: "2 of 5 participants used the app at night and mentioned screen brightness; no participant abandoned a task because of it."

The second version in each pair is testable and honest about frequency. Normalising prevents a single comment from becoming a redesign.

### Step 2 — Classify must-fix, should-fix and could-fix

**Must-fix** (release blockers):

- prevents task completion for a core flow;
- causes data loss or duplicate charges;
- excludes people from using the product (keyboard trap, missing label, contrast failure);
- creates a privacy or safety risk;
- makes a legal or policy claim that is false.

**Should-fix** (next iteration):

- causes delay or confusion but a workaround exists;
- affects many people but not catastrophically;
- weakens trust or comprehension.

**Could-fix** (backlog):

- cosmetic;
- affects few people;
- speculative, with no evidence yet.

Must-fix items do not need a score. They need a date.

### Step 3 — Score the rest with impact, confidence and effort

Use a simple 1–5 scale and write the definitions:

- **Impact:** 5 = blocks the core task for many; 1 = cosmetic.
- **Confidence:** 5 = observed in testing plus metric evidence; 1 = opinion.
- **Effort:** 5 = large, risky, needs many people; 1 = small, safe, one person.

Priority score = `(Impact × Confidence) ÷ Effort`. Higher is sooner. Do not over-engineer the maths; the conversation about the numbers is the point.

| ID | Finding | Impact | Confidence | Effort | Score |
|---|---|---|---|---|---|
| U1 | Delivery fee missed | 5 | 5 | 2 | 12.5 |
| U2 | Continue enabled too early | 4 | 4 | 2 | 8.0 |
| U3 | Address field unclear | 3 | 3 | 1 | 9.0 |
| U4 | Illustration feels dated | 1 | 2 | 3 | 0.7 |

U1 goes first. U3 scores above U2 despite lower impact because it is cheap and well understood. U4 waits.

### Step 4 — Write a change with a reason

A change entry has six parts:

1. **Problem:** what is wrong, with evidence.
2. **Change:** what you will do.
3. **Reason:** why this change addresses the problem.
4. **Expected effect:** what should improve, and by how much (as a hypothesis, not a promise).
5. **Risk:** what could get worse.
6. **Check:** how you will know.

Example:

> **Problem:** 3 of 5 participants missed the delivery fee; funnel shows a 38% drop at checkout.
> **Change:** show an estimated delivery fee on the product page and repeat it in the order summary.
> **Reason:** the fee is a known cost that currently appears late, creating surprise.
> **Expected effect:** fewer checkout abandonments; more informed users.
> **Risk:** estimates may differ from the final fee, reducing trust. Mitigate with "estimated" wording and a clear final total.
> **Check:** re-test with five users; compare checkout completion and support contacts.

### Step 5 — Decide whether an A/B test is appropriate

An A/B test is appropriate when:

- you have enough traffic to detect a meaningful difference;
- the change is easy to isolate;
- the primary metric is defined and instrumented;
- you can run long enough to cover weekly variation;
- there is no serious ethical or safety risk;
- guardrails are in place.

It is not appropriate when:

- traffic is tiny;
- the change is a must-fix accessibility or safety issue (just fix it);
- the outcome is long-term and hard to measure in the test window;
- you cannot randomise fairly;
- the change affects the whole product experience and cannot be isolated.

For most beginners, qualitative re-testing is more useful than an A/B test. Say so.

### Step 6 — Write the hypothesis and the test design

A complete hypothesis:

> "If we show the estimated delivery fee on the product page, then checkout completion will increase from 62% to at least 66% within four weeks, because users will no longer be surprised by the cost at payment. We will guard against a rise in cancellations and support contacts."

Include:

- **Primary metric:** checkout completion.
- **Guardrails:** cancellation rate, support contacts per 1,000 orders.
- **Unit:** user or session.
- **Split:** 50/50, random assignment.
- **Duration:** four weeks, covering paydays and weekends.
- **Minimum sample:** state what you would need, or say it is a limitation.
- **Decision rule:** ship, iterate or stop, defined before the test.

### Step 7 — Build the v2 itself

Make the changes in the prototype or code, in priority order. After each change:

- check the acceptance criteria from the handoff;
- re-run keyboard and 320px checks;
- check the state matrix for regressions;
- update the change log.

Do not bundle five changes and then test once. If the result is bad, you will not know which change caused it.

### Step 8 — Re-test and compare

Use the same tasks and a comparable group. Report:

- task success before and after;
- time on task;
- errors;
- the specific issues that disappeared or persisted;
- new issues introduced.

A before/after table is the minimum evidence. If you changed the tasks, say so; you cannot compare unlike sessions.

### Step 9 — Record what you learned, including what failed

A change log entry:

| Date | Change | Reason | Evidence before | Result | Keep / revert |
|---|---|---|---|---|---|
| 12 Nov | Fee estimate on product page | U1, funnel drop | 3/5 missed fee | 1/5 missed; completion +4 pts | Keep |
| 19 Nov | Disable Continue until valid | U2 | 2/5 clicked early | errors down; 1 new confusion about why disabled | Keep with helper text |

Failed changes are valuable. "We tried X; it did not improve task success and increased support contacts; we reverted it" is a sign of maturity, not failure.

## 6. Worked example (I do)

A learner, Halima, has five findings from a fictional clinic-booking prototype and metrics showing a 44% drop between choosing a doctor and choosing a time.

She classifies:

- **Must-fix:** the date picker cannot be operated by keyboard. No score, fix now.
- **Should-fix:** users do not understand "next available" versus a specific date.
- **Could-fix:** the clinic photos are low quality.

She scores the should-fix items. "Next available" confusion scores highest (impact 5, confidence 4, effort 2 = 10). She changes the label to "Earliest available: Tue 14 Nov, 10:30" and adds a secondary "Choose another date" link.

Expected effect: fewer back-and-forth taps and a higher time-selection completion. Risk: the longer label could crowd the card at 320px. Check: 320px screenshot, five-user re-test, funnel completion.

She writes an A/B design but decides not to run it because traffic is low and the change is clearly an improvement in comprehension. She says so in the plan: "A/B not appropriate at current volume; we will re-test qualitatively and monitor the funnel."

**Why this is good:** she fixes the accessibility blocker without debate, uses evidence for the rest, and refuses an experiment that cannot produce a trustworthy answer.

## 7. We do it together

Using your findings:

1. Rewrite two weak findings as problem statements with evidence.
2. Mark one must-fix and explain why it cannot wait for a score.
3. Score three items with impact, confidence and effort.
4. Write one change entry with all six parts.
5. Decide whether an A/B test is appropriate for that change. Write one sentence explaining why or why not.

**Hint:** if everything is high impact, your scale is not discriminating. Force yourself to rank.

## 8. Your turn (You do)

Produce a v2 plan:

- a normalised findings table with evidence;
- must-fix / should-fix / could-fix classification;
- a scored backlog with at least five items;
- three change entries with problem, change, reason, expected effect, risk and check;
- one A/B hypothesis with primary metric, guardrails, unit, split, duration and decision rule — or a justified decision not to test;
- the implemented v2 changes (or a detailed prototype);
- a before/after re-test table;
- a change log with at least three entries, including one revert or revision.

Use fictional data. Do not run live experiments on real users without approval.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** What is the first thing to do with a list of findings?
- A. Fix the easiest one immediately, so the team can show progress while the harder items wait.
- B. Normalise them first into problem statements with evidence and frequency, so they can be compared fairly.
- C. Add them to a slide deck, so stakeholders can see the full list at the next review meeting.
- D. Ask the client which ones they prefer, so the final choice matches their expectations and priorities.

**Q2.** Which finding is a must-fix?
- A. A keyboard trap in the date picker that stops keyboard users from booking any appointment.
- B. A dated illustration on the confirmation page that no longer matches the current brand.
- C. A slightly long paragraph in the FAQ that takes a few extra seconds to read through.
- D. A colour on the secondary button that is not listed in the current brand guide.

**Q3.** In an ICE score, what does confidence mean?
- A. How much you personally like the idea, and whether it fits the direction you prefer.
- B. How easy the change is to build with the team and time you have available now.
- C. How many users the change could reach once it ships to the whole audience.
- D. How sure you are that the change will have the expected effect, based on evidence.

**Q4.** When is an A/B test least appropriate?
- A. With high traffic and a clear primary metric that is already instrumented on every page.
- B. With a stable product and a change that is easy to reverse if the result looks bad.
- C. With tiny traffic and a must-fix accessibility problem that already blocks keyboard users from booking.
- D. With guardrails already in place, covering cancellations and support contacts over the same four-week period.

**Q5.** What must a hypothesis include?
- A. Only the change itself, described clearly enough for a developer to build it this week.
- B. A design screenshot of the new version, attached so reviewers can see what changed.
- C. A link to a competitor that made a similar change, as evidence that it works.
- D. A testable expected effect, with a reason why the change should produce that effect.

**Q6.** Why change one thing at a time?
- A. It makes the work slower, which is a fair price for a tidier release and a calmer team.
- B. Because users dislike variety and respond better to a product that stays visually stable over time.
- C. So you can attribute the result to a specific change rather than a bundle of them.
- D. Because analytics tools cannot record more than one change in the same release window at a time.

**Q7.** A change increases completion but doubles cancellations. What should you do?
- A. Ship it, because completion is the primary metric and the team agreed to optimise it.
- B. Investigate the guardrail and likely revert or revise, because doubled cancellations signal real harm to users.
- C. Ignore the cancellations, since they are a separate team's metric and outside this scope.
- D. Run more ads to offset the cancellations with new orders from a fresh audience.

**Q8.** Why keep a record of failed changes?
- A. To punish the team members responsible, so the same people do not repeat the mistake.
- B. To avoid repeating past mistakes and to show an honest, evidence-based process that includes reversals.
- C. To fill the portfolio with more entries, so the case study looks longer and more complete.
- D. Because clients require a written log before they will approve any further design work.

**Q9.** A team changes the button label, the page layout and the price at the same time, then sees conversion rise. What is the main problem?
- A. The test used too many users, so the result is harder to explain to the wider team.
- B. The conversion metric is always invalid when more than one element on a page changes.
- C. The team forgot to add animation, which would have made the new layout feel finished.
- D. The changes are bundled, so the team cannot attribute the result to any one of them.

**Q10.** A team has 30 findings from a test and starts fixing the easiest ones first. What is the main prioritisation error?
- A. They are fixing too few issues, so the backlog will still be large after this sprint.
- B. They did not run an A/B test first, so they cannot know which fix will move the metric.
- C. They should fix all 30 at once, so the release is complete before anyone tests it again.
- D. They are prioritising ease over severity and user impact, so the important blockers may still wait.

## 10. Practical task and pass criteria

**Task.** Submit the v2 plan, implemented changes, re-test table and change log.

**Pass criteria — all must be met:**

- [ ] Findings are normalised with evidence and frequency.
- [ ] Must-fix items are identified separately from scored items.
- [ ] At least five items are scored with defined scales.
- [ ] Three change entries include problem, change, reason, expected effect, risk and check.
- [ ] An A/B hypothesis is complete, or its absence is justified.
- [ ] v2 changes are implemented or prototyped in enough detail to test.
- [ ] Before/after re-test results are reported with the same tasks.
- [ ] Change log has at least three entries, including a revert or revision.
- [ ] No unsupported claim of causation from a small sample.
- [ ] No live experiment on real users without approval.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Fixing the easiest thing | It feels productive | Score impact and confidence first. |
| Treating every comment as a requirement | Feedback is compelling | Require evidence and frequency. |
| Bundling changes | Faster to ship | Change one thing, check, then next. |
| A/B testing everything | It sounds rigorous | Use qualitative tests when volume is low. |
| No decision rule | Enthusiasm | Define ship/iterate/stop before the test. |
| Ignoring guardrails | Focus on the win | Protect against harm explicitly. |
| No change log | Administrative fatigue | Log as you go, in one line per change. |
| Claiming causation from five users | Portfolio pressure | Say "consistent with" and state limits. |

**Retry variant.** Take three findings and write **only** the must-fix decision and one change entry, with no scoring. Then write a 100-word argument for why scoring the other two would be premature. This tests judgment about when process helps and when it becomes theatre.

## 12. Proof artifact for your portfolio

Keep the v2 plan, before/after table and change log. In a portfolio, the strongest story is: problem, evidence, change, result, and what you would do next. That is a case study in miniature.

## 13. Low-data and low-cost path

- Use a spreadsheet for scoring and the change log.
- Re-test with three to five peers instead of a paid panel.
- Skip an A/B test; write the design and explain why it is not feasible.
- Prototype changes in Figma if coding is too slow, and state that the test used a prototype.
- Keep the backlog to five items so the exercise stays completable.

## 14. Watch and read more

**Recommended video:** *UX Design Prioritization Methods* by NNgroup (2022, 6 min 19 s) — `https://www.youtube.com/watch?v=gklsUyD6RPE`. Covers common prioritisation approaches and their trade-offs. Metadata checked 2026-10-30; embedded playback was verified in Chrome on 2026-10-30.

**Read:**

- Nielsen Norman Group, *Prioritization* — `https://www.nngroup.com/topic/prioritization/`. Methods and pitfalls.
- GOV.UK Service Manual, *Iterating and improving* — `https://www.gov.uk/service-manual/agile-delivery`. Working in iterations with evidence.
- Google, *HEART framework* — `https://research.google/pubs/measuring-the-user-experience-on-a-large-scale-user-centered-metrics-for-web-applications/`. Choosing metrics for a change.
- Nielsen Norman Group, *A/B Testing 101* — `https://www.nngroup.com/articles/ab-testing/`. When a controlled comparison is appropriate and what it cannot tell you at low volume.

## 15. What comes next

**Gate 6** asks you to run a real usability test with at least five people on your deployed prototype and ship a v2 based on what you learned, with a before/after. Read `03_Assessments/Learner/Phase_6_Gate.md`. Phase 7 turns the work into a case study, a portfolio and a professional practice.