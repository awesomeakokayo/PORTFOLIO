# Stop 4.5 — AI for Content and Microcopy

> **Phase 4 · The AI design workflow** · Prerequisite: Stop 4.4 · Suggested session: 70–90 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Write interface copy that names the action, the object and the consequence.
2. Set a simple tone standard and apply it consistently.
3. Use AI to draft variants, then edit for honesty, clarity and local fit.
4. Replace vague errors, empty states and button labels.
5. Test comprehension with a real reader and revise.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Microcopy** | The short text in an interface: labels, buttons, errors, hints, empty states. |
| **UX writing** | Writing interface content to help people complete tasks. |
| **Content design** | Designing what content is needed, not just how it is worded. |
| **Tone** | The attitude conveyed by the words, which can change by context. |
| **Voice** | The consistent personality of the product across contexts. |
| **Plain language** | Clear wording that the intended reader understands on first read. |
| **Reading level** | A rough measure of text complexity. |
| **Jargon** | Specialised terms the reader may not know. |
| **Error message** | Text explaining what went wrong and how to recover. |
| **Empty state copy** | Text explaining why a screen is empty and what to do next. |
| **Call to action (CTA)** | The label of the main action. |
| **Localisation** | Adapting content for a language or region, beyond translation. |
| **False urgency** | Pressure language that exaggerates time or scarcity. |
| **Social proof** | Claims about other users, which must be true and verifiable. |
| **Comprehension test** | Asking a reader to explain what the text means in their own words. |

## 3. Why this matters

Interface copy is the part of the design users read most and designers revise least. "Submit" instead of "Send ₦25,000" costs the user a moment of doubt. "Something went wrong" instead of "The transfer did not go through; no money left your account" costs trust.

AI is good at producing fluent alternatives and bad at knowing what is true, what is local, and what the product can actually do. It will happily write "Instant transfers, zero fees" because that is what marketing copy looks like. You are responsible for whether it is true.

> **Everyday example.** A sign that says "Queue here" is clearer than "Please await assistance". Both are polite; only one tells you what to do. Microcopy is the sign.

## 4. Before you start

- Choose one flow with at least five text elements: a title, a button, a form label, an error and an empty state.
- Know the facts: fees, timing, limits, what happens on failure. If you do not know, do not write a claim.
- Have one reader available for a five-minute comprehension test.

## 5. Teaching, step by step

### Step 1 — Set voice and tone in one page

Voice stays constant; tone changes with the moment.

Example:

- **Voice:** plain, calm, respectful, specific. We do not shout, blame or exaggerate.
- **Tone in success:** warm but brief. "Transfer sent."
- **Tone in error:** calm and factual, with a route forward. "The transfer did not go through. No money left your account."
- **Tone in danger:** direct and serious. "This cannot be undone."
- **Tone in empty states:** helpful, not cute. "No saved beneficiaries yet."

Write three rules:

1. Use the user's words, not internal jargon.
2. Say what happened, what it means, what to do next.
3. Never claim something the product cannot guarantee.

### Step 2 — Name the action and the consequence

Button labels should be verb + object:

| Weak | Better |
|---|---|
| Submit | Send ₦25,000 |
| OK | Save changes |
| Continue | Review transfer |
| Cancel | Keep editing |
| Delete | Delete 3 files |

Why repeat the amount? Because it confirms the consequence and reduces error. Why "Keep editing" instead of "Cancel"? Because "Cancel" is ambiguous: cancel the dialog or cancel the transfer?

### Step 3 — Write errors with four parts

1. What happened.
2. Why, if known.
3. What to do now.
4. What is safe.

Example:

> "We couldn't confirm the account name because the bank did not respond. Your details are saved. Try again in a moment, or continue without the name check."

Avoid:

- "Invalid input" (says nothing);
- "Oops!" (trivialises);
- "Error 500" (internal);
- "You entered the wrong number" (blames, and may be false).

### Step 4 — Write empty states that help

An empty state should:

- say what would be here;
- explain why it is empty, if relevant;
- offer the first action;
- avoid fake data and excessive illustration.

Example: "No saved beneficiaries yet. Save someone you pay often to skip entering their details next time." + "Save beneficiary".

### Step 5 — Prompt AI for variants, not verdicts

Prompt:

> "Write five versions of this button label for a mobile transfer confirmation. The action sends ₦25,000 to Adaeze O. and cannot be reversed. Use plain English, sentence case, maximum 28 characters. Do not use 'Submit', 'OK' or 'Confirm' alone. For each, state the trade-off in one line."

Then edit. AI is useful for volume and for showing you options you would not have considered. It is not the judge of truth or tone.

### Step 6 — Check every claim

For each sentence, ask:

- Is it true?
- Can the product deliver it?
- Is it verifiable?
- Would it still be true for a user on a slow connection, a different bank, or a failed transfer?
- Does it create false urgency or social proof?

Delete or substantiate anything you cannot verify. "Trusted by thousands" is a claim; "No hidden fees" is a claim; "Instant" is a claim. If you do not have the data, do not say it.

### Step 7 — Test comprehension, not preference

Do not ask "Do you like this copy?" Ask:

> "Read this sentence and tell me in your own words what happened and what you would do next."

Record the answer. If the reader cannot restate it, the copy failed, regardless of how it sounds. Test with someone outside your course cohort if possible.

### Step 8 — Localise without stereotyping

For Nigerian and African contexts:

- use local currency symbols and number grouping consistently;
- consider English, Pidgin, Yoruba, Hausa, Igbo and mixed language use, and ask rather than assume;
- avoid idioms that do not translate;
- use familiar terms for payment channels, agents and data bundles;
- keep names and address formats flexible;
- do not use slang to signal "local" if it reduces clarity.

Localisation is not decoration. It is whether the sentence makes sense to the person reading it.

## 6. Worked example (I do)

**Screen:** transfer confirmation.

**Before:**

- Title: "Transaction"
- Button: "Confirm"
- Warning: "Note: transactions are final."
- Error: "Error: invalid account."
- Empty state: "No data."

**After:**

- Title: "Confirm transfer"
- Button: "Send ₦25,000"
- Warning: "This cannot be reversed. Check the name before you send."
- Error: "We couldn't confirm this account name. The bank did not respond. Your details are saved — try again, or continue without the name check."
- Empty state: "No saved beneficiaries yet. Save someone you pay often to skip entering their details next time."

**Reasoning:**

- "Transaction" is a category, not a task. "Confirm transfer" tells the user where they are.
- "Confirm" does not name the consequence. The amount does.
- "Transactions are final" is abstract. "This cannot be reversed" is concrete.
- "Invalid account" does not say what is wrong or what to do.
- "No data" is a database message, not a human one.

**AI variants I rejected:**

- "Send money now →" — adds urgency and an arrow that implies navigation.
- "Confirm & send ₦25,000" — the ampersand adds visual noise; "Send ₦25,000" is enough.
- "Yes, send ₦25,000" — conversational but longer; the confirmation screen already establishes context.

**Reader test:** I asked a family member to read the error and say what happened. They said: "The bank didn't answer, so it didn't check the name, but my details are still there." That is the intended meaning. The copy passed.

## 7. We do it together

1. Write your voice and tone page with three rules.
2. List five text elements in your flow.
3. Rewrite each using verb + object and the four-part error structure.
4. Prompt AI for five variants of one element, with constraints.
5. Edit the variants for truth and local fit.
6. Run a claim check on every sentence.
7. Test two sentences with a reader using the comprehension question.
8. Revise based on the reader's answer.
9. Record what the AI suggested and what you changed.

## 8. Your turn (You do)

**Independent task.** Produce a **microcopy pack** for one flow.

Submit:

1. A voice and tone page with three rules and examples for success, error, danger and empty states.
2. Before/after copy for five elements: title, primary button, form label or helper, error, empty state.
3. Five AI-generated variants for one element, with your edits and the reason for each rejection.
4. A claim check table: sentence, claim, true/unverified, action.
5. A comprehension test with one reader, including their verbatim restatement.
6. A 150-word reflection on what AI did well and where it was untrustworthy.

**Rules:** no unverified claims, no fake social proof, no false urgency, no blaming language. Do not use AI output without editing.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** Which button label is strongest for an irreversible transfer?
- A. "Submit" is compact, familiar from forms, and consistent with the rest of the flow.
- B. "Send ₦25,000" names the action and repeats the amount before an irreversible step.
- C. "OK" is short and familiar from dialogs, so it keeps the footer uncluttered.
- D. "Continue" suggests progress to the next step rather than completion of a transfer.

**Q2.** When writing recovery microcopy after a failed payment, which four pieces should the message carry?
- A. Apology, blame, error code and close, so the user knows the team is sorry.
- B. What happened, why, what to do now and what is safe.
- C. Title, body, image and link, so the message matches the page layout.
- D. Error, retry, cancel and help, so every possible next action is offered.

**Q3.** Why is "Oops!" a weak error message?
- A. It trivialises the problem and gives no information or route forward.
- B. It is too formal for a consumer payment app used on mobile.
- C. It is too long for an error area that has limited space.
- D. It is inaccessible to screen readers that read punctuation aloud.

**Q4.** What should an empty state do?
- A. Show plausible fake data so the screen looks populated and complete.
- B. Use a large illustration only, since text would clutter the empty area.
- C. Explain what would be here and offer the first useful action.
- D. Hide the screen until the user has created their first record.

**Q5.** What is the best way to test microcopy?
- A. Ask a few people whether they like the wording and tone.
- B. Count the words and compare the total with the style guide limit.
- C. Run it through a grammar checker and fix every flagged sentence.
- D. Ask a reader to restate what happened and what they would do.

**Q6.** "Trusted by 10,000 users" with no data is…
- A. An unverified claim that must be substantiated or removed.
- B. Good social proof, because a large number reassures new visitors.
- C. A tone choice, since confident copy suits a competitive market.
- D. A localisation issue, because numbers are grouped differently by region.

**Q7.** Why does tone change while voice stays constant?
- A. Because users get bored by the same tone and need variety to stay engaged.
- B. Because voice is only for marketing pages, while product screens use tone.
- C. Because the AI cannot hold a consistent voice across several screens.
- D. Because the emotional context changes: success, error and danger need different warmth.

**Q8.** What is localisation beyond translation?
- A. Changing the font so the text suits the scripts used in each market.
- B. Adding flags to the language switcher so users recognise their region quickly.
- C. Translating word for word while keeping the same sentence structure everywhere.
- D. Adapting currency, formats, idioms, terminology and cultural context for local readers.

**Q9.** A learner is writing the primary button for an irreversible transfer of ₦12,500. Which label is strongest?
- A. "Submit" is the conventional label and tells users the form is complete.
- B. "Send ₦12,500 now" names the action and the exact amount leaving the account.
- C. "Continue" keeps the flow moving without repeating the amount the user has already seen.
- D. "OK" is quick to scan and fits the compact width of the footer button.

**Q10.** A landing page says 'Trusted by 10,000 users' but the team has no source for the number. What is the main problem?
- A. It is fabricated social proof and must be removed or verifiable.
- B. The number is too small to impress visitors and should be larger.
- C. The sentence is too short to explain what the product actually does.
- D. It should be in all capitals so the claim stands out on the page.

## 10. Practical task and pass criteria

**Task.** Submit the six-part microcopy pack.

**Pass criteria — all must be met:**

- [ ] Voice and tone page with rules and four contexts.
- [ ] Five before/after elements.
- [ ] Five AI variants with edits and rejection reasons.
- [ ] Claim check table with unverified claims removed or substantiated.
- [ ] A reader test with a verbatim restatement.
- [ ] No blaming, false urgency or fake social proof.
- [ ] Reflection is specific about AI's limits.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| "Submit" / "OK" labels | They are conventional | Use verb + object + consequence. |
| "Invalid input" | It is quick | Name the rule and the fix. |
| Cute error copy | It feels friendly | Be calm and factual in failure. |
| Fake social proof | It sounds persuasive | Substantiate or remove. |
| Asking "do you like it?" | Preference is easy | Test comprehension. |
| AI copy left unedited | It reads smoothly | Check every claim and local fit. |
| Slang for local flavour | It seems authentic | Prioritise clarity; ask local readers. |

**Retry variant.** Rewrite the copy for a **failed payment at an agent** where the user has already handed over cash and the agent's app shows a pending state. Include a message for the agent and one for the customer. Test both with a reader and submit the copy, the claim check and a 150-word note on which message was harder to make honest.

## 12. Proof artifact for your portfolio

**Artifact:** `Microcopy-Pack-v1` — stored in `03_Projects/<project>/design/content`.

Strong microcopy is rare in junior portfolios and immediately noticeable. Keep the reader-test notes.

## 13. Low-data and low-cost path

- Text only; no tools beyond a notes app and an AI chat.
- Test with a family member or classmate in person.
- The video is optional and eight minutes; the structure and claim checks above are the lesson.
- If AI is unavailable, write five variants yourself and document the process.

## 14. Watch and read more

**Recommended video (optional, 8:19):** *Microcopy. Complete UX Writing Guide* — Maria Fetiskina. `https://www.youtube.com/watch?v=ylx67a1v7_M`. Verified available on 2026-10-30. It covers general UX writing; the claim-check and localisation rules here are the course's own.

**Read (verified 2026-10-30):**

- GOV.UK Design System, *Content design: writing for GOV.UK* — `https://design-system.service.gov.uk/`. A strong public example of plain-language standards and error-message patterns.
- W3C, *WCAG 2.2* — `https://www.w3.org/TR/WCAG22/`. See SC 3.3.1 and 3.3.3 for error identification and suggestion.

## 15. What comes next

Stop 4.6 is the judgment stop: the five ways AI design fails, how to catch them, and how to write a review that another person can trust.