# Stop 3.4 — Prototyping

> **Phase 3 · Figma fluency and design systems** · Prerequisite: Stop 3.3 · Suggested session: 80–100 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Turn frames into a connected flow with a clear starting point.
2. Choose the right trigger and action for a interaction.
3. Use overlays for modals and menus without duplicating screens.
4. Add scrolling, fixed elements and back navigation.
5. Prepare a prototype for a usability test, including a reset and a fallback path.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Prototype** | A clickable simulation of a design, used to test flow and interaction. |
| **Flow** | A named sequence of connected frames with a starting point. |
| **Trigger** | What starts an interaction: tap, click, drag, key press, delay. |
| **Action** | What happens: navigate, open overlay, close, back, scroll to, swap. |
| **Connection** | The link between a hotspot and a destination. |
| **Hotspot** | The area that responds to the trigger. |
| **Overlay** | A frame that appears on top of the current screen, such as a modal or menu. |
| **Smart animate** | Figma's automatic transition between frames with matching layers. |
| **Dissolve** | A cross-fade transition. |
| **Move in / move out** | Directional transitions for pushes and modals. |
| **Scroll behaviour** | Whether a frame scrolls vertically, horizontally or both. |
| **Fixed position** | An element that stays in place while content scrolls. |
| **Starting point** | The frame where the prototype begins. |
| **Device preview** | Viewing the prototype on a phone via the Figma app or a browser. |
| **Test-ready** | The prototype can be used by a participant without the designer's help. |
| **Dead end** | A screen with no way forward or back. |
| **Reset** | Returning the prototype to its starting state between participants. |

## 3. Why this matters

A static screen can look finished and still be unusable. The prototype is where you discover that the back button goes to the wrong place, the modal cannot be closed, the keyboard covers the primary action, or the flow has a dead end.

Prototypes are also the cheapest form of testing. A participant can tap through a flow before anyone writes code, and the confusion you observe is real. The goal is not a beautiful animation; it is a **believable, complete path** that lets someone attempt the task.

> **Everyday example.** A cardboard mock-up of a chair lets you check the height and the angle before cutting wood. It is not a chair, but it answers the question "would this be comfortable?" A prototype answers "could someone complete this task?"

## 4. Before you start

- Have at least six frames from your flow: entry, input, confirmation, processing, success, error.
- Name the frames in flow order.
- Decide the device frame size (393 × 852 is fine).
- Create a page `05_Prototype` and place copies of the frames there. Keep the design page clean.

## 5. Teaching, step by step

### Step 1 — Set the starting point and the flow name

Select the first frame, open Prototype panel, and set "Flow starting point". Name the flow after the user task: `Send money — new recipient`.

Why name it? Because a file can contain several flows, and a tester needs to know which one they are testing. A named flow also appears in the presentation menu.

### Step 2 — Connect the happy path first

Add connections in order:

1. Entry → input (tap "Continue").
2. Input → confirmation (tap "Review").
3. Confirmation → processing (tap "Send").
4. Processing → success (after delay or tap).
5. Success → home (tap "Done").

Use "On tap" for user-initiated actions. Use "After delay" only for a realistic processing state, and keep the delay short (1–2 seconds) in a test, because waiting is not the thing you are testing.

### Step 3 — Choose transitions that explain the relationship

| Change | Transition | Why |
|---|---|---|
| Push to a new screen | Move in, from right | Matches the mental model of going deeper. |
| Back | Move out, to right | Reverses the push. |
| Modal | Open overlay, move in from bottom | Shows it sits above the current screen. |
| Success replacement | Dissolve or smart animate | Shows a state change, not a new place. |
| Tab switch | Instant or dissolve | Tabs are lateral, not hierarchical. |

Do not use a different transition for every connection. Consistency teaches the user what movement means.

### Step 4 — Use overlays for modals, menus and pickers

An overlay keeps the underlying screen visible and avoids duplicating it. Configure:

- **Position:** centre for dialogs, bottom for sheets, top-right for menus.
- **Background:** dim the underlying screen for modal decisions.
- **Close behaviour:** tap outside, close button, or both.
- **Focus:** in the built product, focus must move into the dialog and return on close; note this for developers.

An overlay with no close behaviour is a trap. Always add at least one exit.

### Step 5 — Add scrolling and fixed elements

For a content screen longer than the frame:

1. Set the frame's scrolling to vertical.
2. Make the content taller than the frame.
3. Pin the header and bottom bar with "Fix position when scrolling".

Test on a phone-sized preview. A header that scrolls away can be fine; a primary action that scrolls away may be wrong for a task that needs it at the end.

### Step 6 — Cover the non-happy states

A test-ready prototype needs:

- a loading state that appears after the action;
- an error state reachable from the loading or input;
- a way to recover from the error;
- an empty state if the flow starts with no data;
- a back path from every screen.

If a participant cannot reach the error, you cannot test how they recover. Add a hidden route for testing: a small "test controls" frame, or a separate flow starting point for the error path. Tell the facilitator, not the participant.

### Step 7 — Make it operable without you

Hand the phone to someone and say only: "Try to send ₦5,000 to a new person." Watch what happens. Common failures:

- The hotspot is too small or in the wrong place.
- The participant taps a label that looks interactive but is not connected.
- The keyboard covers the button.
- The back gesture exits the prototype.
- The success screen has no next step.
- The prototype restarts unexpectedly.

Fix the prototype, not the participant.

### Step 8 — Prepare for a test session

Before each session:

1. Open the prototype in presentation mode.
2. Set it to the starting point.
3. Check the device size and zoom.
4. Turn on "Show hotspots" only if you want to reveal them; usually keep it off.
5. Have a reset plan: close and reopen the link, or use "Restart" in the presentation menu.
6. Test the link on the device the participant will use.

A prototype that requires you to tap through to the start before every session wastes the session.

## 6. Worked example (I do)

**Flow:** send money to a new recipient.

**Frames:** `00_Entry`, `01_Recipient`, `02_Amount`, `03_Confirm`, `04_Processing`, `05_Success`, `06_Error_Name`, `07_Error_Unknown`.

**Connections:**

- `00_Entry` → `01_Recipient` (tap "Send money").
- `01_Recipient` → `02_Amount` (tap "Continue", only if valid).
- `02_Amount` → `03_Confirm` (tap "Review").
- `03_Confirm` → `04_Processing` (tap "Send ₦25,000").
- `04_Processing` → `05_Success` (after 1.5 s).
- `04_Processing` → `07_Error_Unknown` (after 6 s, for the test path).
- `03_Confirm` → `06_Error_Name` (tap "Check name" in the test path).
- `06_Error_Name` → `01_Recipient` (tap "Edit recipient").
- `07_Error_Unknown` → `05_Success` (tap "Check status", simulating a resolved check).
- `05_Success` → `00_Entry` (tap "Done").

**Overlay:** "Cancel transfer?" dialog on `03_Confirm`, with "Keep editing" closing the overlay and "Cancel transfer" returning to `00_Entry`.

**Reasoning, not just the wiring:**

- The processing delay is 1.5 s because a test should not make the participant wait; the real product may take longer.
- The unknown state is reachable through a test path, because recovery from uncertainty is the most important behaviour to test.
- The overlay has two exits, because a modal with one exit is a trap if the user changes their mind.
- The back path from every screen returns to the previous step with data preserved in the real build; the prototype approximates this by returning to the screen, and the note tells developers to preserve input.

**What I rejected:** a fancy smart-animate success animation. It would add polish but delay the confirmation and complicate the test. The state change is better communicated by a clear success screen.

## 7. We do it together

1. Copy six frames to `05_Prototype` and name them in flow order.
2. Set the starting point on the first frame and name the flow.
3. Connect the happy path with "On tap".
4. Add one "After delay" connection for processing.
5. Add a modal overlay with two exits.
6. Add a vertical scroll to one content screen and fix the header.
7. Add a back connection from every screen.
8. Add an error branch and a recovery path.
9. Present the prototype and complete the task yourself without using the layers panel.
10. Hand it to one person with a single task sentence and note every hesitation.

## 8. Your turn (You do)

**Independent task.** Build a **test-ready prototype** of one complete flow.

Submit:

1. A Figma link to the prototype, set to the starting point.
2. At least six connected screens, named in flow order.
3. A named flow with a clear user task.
4. At least one overlay with two exits.
5. A scrolling screen with a fixed element.
6. A loading state and an error state with a recovery path.
7. A back path from every screen.
8. A "test readiness" note: how to reset, how to reach each branch, and what is simulated rather than real.
9. Notes from one person attempting the task, with verbatim hesitations and where they tapped.

**Do not** leave any dead ends. Do not require the facilitator to explain the interface. Do not use a different transition for every connection.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** What is a flow starting point?
- A. The first component in the file, which the presentation opens by default.
- B. The frame where the prototype begins when a flow is presented.
- C. The last screen in the flow, where the participant finishes the task.
- D. The file cover, which introduces the project before the flow starts.

**Q2.** When is an overlay better than a new screen?
- A. For every navigation, because overlays avoid duplicating any screen.
- B. For long forms, because a sheet keeps the form shorter on mobile.
- C. For the home screen, because it should appear above the previous screen.
- D. For modals, menus and pickers that sit above the current context.

**Q3.** What must every overlay have?
- A. At least one clear way for the participant to close it.
- B. An animation, so the participant notices that the overlay appeared.
- C. A back button, so the participant can return to the previous screen.
- D. A logo, so the overlay looks like part of the same product.

**Q4.** Why use "After delay" sparingly in a test prototype?
- A. Figma charges for each delay, so long delays increase the plan cost.
- B. Delay triggers break scrolling, so a scrolling screen cannot use them.
- C. A delayed connection cannot be reset, so each session starts mid-flow.
- D. It makes the test slower without testing the thing you care about.

**Q5.** What is a dead end?
- A. A screen with too many buttons, so the participant cannot choose one.
- B. A screen with no forward or back path out of it.
- C. A screen with no images, so nothing indicates where to tap next.
- D. A screen with a modal that covers most of the underlying content.

**Q6.** Why add a test path to an error state?
- A. To make the prototype longer, so it looks more complete to reviewers.
- B. So you can observe recovery, which is often the most important behaviour.
- C. Because errors are required by Figma before a prototype can be presented.
- D. To show off the animation that plays when the error message appears.

**Q7.** What does "fix position when scrolling" do?
- A. Keeps an element in place while the content behind it scrolls.
- B. Locks the frame size, so the frame cannot be resized afterwards.
- C. Stops the prototype, so the participant cannot continue the flow.
- D. Pins the file, so it stays at the top of recent files.

**Q8.** A participant taps a label that is not connected. What should you do?
- A. Tell them not to tap there, and ask them to use the button instead.
- B. Ignore it, because the participant will find the right control eventually.
- C. Fix the prototype or the design so the affordance matches the interaction.
- D. Remove the label, so nothing on the screen looks tappable but is not.

**Q9.** A prototype's back button always returns to the home screen instead of the previous step. What should the learner fix?
- A. Remove the back button from every screen so the flow cannot loop.
- B. Add a longer transition animation, so the change of screen feels clearer.
- C. Change the button colour to show it is secondary rather than primary.
- D. Connect each back control to the screen the user actually came from.

**Q10.** A clickable prototype has no path to its error state, so the error screen cannot be reached during a test. What is the testing consequence?
- A. The prototype will load more slowly, because the missing screen is loaded.
- B. The error state will automatically appear at random during the session.
- C. The error state cannot be evaluated, so the test cannot show whether users recover.
- D. Participants will assume the product has no errors at all after testing.

## 10. Practical task and pass criteria

**Task.** Submit the prototype link, the test-readiness note and the observation notes.

**Pass criteria — all must be met:**

- [ ] Six or more connected screens in flow order.
- [ ] A named flow and a starting point.
- [ ] A working overlay with two exits.
- [ ] A scrolling screen with a fixed element.
- [ ] Loading and error states, with a recovery path.
- [ ] No dead ends; a back path from every screen.
- [ ] Test-readiness note covers reset and branches.
- [ ] Observation notes record a real person's hesitations.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Hotspots on the label only | The label is the visible element | Make the whole button the hotspot. |
| No back path | The happy path feels enough | Connect back on every screen. |
| Modal with one exit | It seems decisive | Add "cancel" and tap-outside. |
| Different transition everywhere | Each feels nice | Standardise push, modal, state change. |
| Error state unreachable | It was designed later | Add a test branch and document it. |
| Prototype starts mid-flow | Last position was saved | Reset to the starting point before each session. |
| Testing with the designer explaining | It feels helpful | Give one task sentence, then stay quiet. |

**Retry variant.** Build a **booking flow** prototype with a seat-selection screen, a payment sheet overlay, a "seat taken" conflict, and a confirmation. Add a horizontal scroll for date selection. Submit the prototype, a test-readiness note and three observations from a person attempting to book two seats.

## 12. Proof artifact for your portfolio

**Artifact:** `Clickable-Prototype-v1` — link and test notes, stored in `03_Projects/<project>/prototype`.

A working prototype is a core portfolio asset. Keep the test notes; they prove the flow was used, not just drawn.

## 13. Low-data and low-cost path

- Prototype with text and shapes; no video or heavy images.
- Test on the same device you design on if a phone is unavailable; note the limitation.
- The video is optional and six minutes; the wiring rules above are the lesson.
- Share a view link rather than exporting a video, which is much smaller.

## 14. Watch and read more

**Recommended video (optional, 6:06):** *Figma Prototype Tutorial for Beginners* — Aliena Cai. `https://www.youtube.com/watch?v=1ucLq6JTxac`. Verified available on 2026-10-30. It covers the basics of connections and presentation; overlays and test-readiness here follow Figma's documentation and usability practice.

**Read (verified 2026-10-30):**

- Figma Help, *Guide to prototyping in Figma* — `https://help.figma.com/hc/en-us/articles/360040314193-Guide-to-prototyping-in-Figma`.
- Nielsen Norman Group, *Case Study: Iterative Design and Prototype Testing* — `https://www.nngroup.com/articles/case-study-iterative-design-prototyping/`. Shows why a prototype is built to answer a question, not to look finished.

## 15. What comes next

Stop 3.5 turns components, variants and variables into a **small design system**: tokens, ten components, documentation and rules for reuse. This is the artifact that proves you can work at professional speed.