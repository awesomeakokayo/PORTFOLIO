# Stop 2.5 — Accessibility and Inclusive Design

> **Phase 2 · Visual and interaction foundations** · Prerequisite: Stop 2.4 · Suggested session: 80–100 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Explain the four WCAG principles (POUR) in plain language.
2. Audit a screen for contrast, touch target size, text resize, keyboard access, focus visibility, labels, alt text and colour-only meaning.
3. Fix the most common failures without breaking the design.
4. Distinguish "meets the minimum standard" from "works for people in context".
5. Write an accessibility note that a developer can act on.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Accessibility** | Designing so people with disabilities can use the product. |
| **Inclusive design** | Designing for the widest range of people and situations, including temporary and situational limitations. |
| **Disability** | A mismatch between a person's abilities and the environment, not a defect in the person. |
| **WCAG** | Web Content Accessibility Guidelines, published by W3C. |
| **POUR** | The four principles: Perceivable, Operable, Understandable, Robust. |
| **Conformance level** | A/AA/AAA. AA is the common target for professional and legal compliance. |
| **Contrast ratio** | Luminance difference between two colours, from 1:1 to 21:1. |
| **Touch target** | The tappable area of a control, which may be larger than its visible shape. |
| **Focus indicator** | The visible outline showing which element will receive keyboard input. |
| **Keyboard trap** | A state where keyboard focus cannot leave a component. |
| **Screen reader** | Software that reads the interface aloud and exposes structure to blind and low-vision users. |
| **Alt text** | A text description of an image for users who cannot see it. |
| **Semantic HTML** | Using elements for their meaning (`button`, `nav`, `label`) rather than generic containers. |
| **ARIA** | Accessible Rich Internet Applications: attributes that add meaning when HTML alone is insufficient. |
| **Reduced motion** | A user preference to minimise animation. |
| **Text resize** | The ability to enlarge text up to 200% without loss of content or function. |
| **Colour vision deficiency** | Difficulty distinguishing certain colours; affects a significant minority. |
| **Cognitive load** | The mental effort required to use an interface. |
| **Assistive technology** | Any tool that helps a person use a device, such as a screen reader or switch control. |

## 3. Why this matters

Accessibility is not a niche feature. People have low vision, tremors, dyslexia, migraines, broken wrists, noisy environments, cheap phones and slow connections. A design that only works for a healthy young adult with a fast phone and perfect eyesight excludes most of the world at some point.

It is also a legal and professional requirement in many contexts, and a quality signal. Accessible products tend to be clearer for everyone: visible labels help all users, captions help in noisy rooms, keyboard access helps power users, and good contrast helps outdoors.

> **Everyday example.** A ramp at a building entrance is for wheelchair users, but it also helps people with luggage, parents with prams, delivery workers and anyone with a temporary injury. Accessibility features are often universal features.

## 4. Before you start

- Choose one screen you have designed, ideally a form or a flow with a button.
- Open WebAIM Contrast Checker.
- If possible, install NVDA (Windows, free) or use VoiceOver (Mac/iOS) or TalkBack (Android). If not, use the accessibility tree in browser dev tools.
- Have a keyboard ready; you will navigate without a mouse.

## 5. Teaching, step by step

### Step 1 — Learn POUR in one sentence each

- **Perceivable:** can the user perceive the content? Text alternatives, contrast, captions, not relying on colour alone.
- **Operable:** can the user operate the interface? Keyboard, touch targets, no traps, enough time.
- **Understandable:** can the user understand it? Clear language, predictable behaviour, helpful errors.
- **Robust:** does it work with different browsers and assistive technologies? Valid structure, correct names and roles.

Every WCAG success criterion belongs to one of these. When you are unsure what to check, ask which principle is at risk.

### Step 2 — Audit contrast

Check every text/background pair:

- normal text ≥ 4.5:1;
- large text ≥ 3:1;
- essential icons and input borders ≥ 3:1;
- focus indicators visible against both the component and the background.

Record the pair, the ratio and pass/fail. Do not check only the headline. Check secondary text, input placeholder copy, disabled text (which is exempt but should still be recognisable), button labels, and text over images.

For text over images, test the worst part of the image, not the average. If it fails, add a solid overlay or move the text.

### Step 3 — Audit touch targets

WCAG 2.2 AA requires a minimum target size of **24 × 24 CSS pixels** (SC 2.5.8), with exceptions for inline links and spacing. Professional mobile practice is larger: **44 × 44** (Apple) or **48 × 48** (Material). Use 44–48 px for primary controls.

Check:

- the visible control and its actual tappable area;
- spacing between adjacent targets;
- small icon buttons, close buttons and steppers;
- targets near screen edges and in the thumb zone.

A 16 px icon with a 16 px hit area is a failure even if it looks fine. Increase the padding, not just the icon.

### Step 4 — Navigate with the keyboard

Put the mouse aside. Press `Tab` repeatedly.

Check:

1. Every interactive element is reachable.
2. The focus indicator is clearly visible.
3. Focus order follows the visual order.
4. No keyboard trap (you can always Tab out).
5. `Enter` or `Space` activates buttons.
6. Modals trap focus **inside** while open and return focus to the trigger when closed.
7. Skip links exist for long navigation.

If you cannot reach a control, a keyboard user cannot use your product. This is a critical issue, not a polish item.

### Step 5 — Check labels, names and structure

- Every input has a persistent visible label.
- The label is programmatically associated with the input (`<label for>` or `aria-labelledby`).
- Buttons have accessible names, not just icons.
- Images have alt text if meaningful, or empty alt if decorative.
- Headings are in a logical order (h1, h2, h3), not chosen for size.
- Errors are announced and linked to the field.
- Language is declared (`lang="en"` or the appropriate language).

In Figma, you can annotate these requirements for developers, but the real check happens in the built page. The design must specify them.

### Step 6 — Test text resize and reflow

Enlarge text to 200% and check:

- no text is clipped;
- no content overlaps;
- buttons grow with their labels;
- horizontal scrolling is not required for vertical content at 320 px width (SC 1.4.10 Reflow);
- the layout remains usable at 400% zoom on desktop.

A design that only works at one text size is fragile. Use flexible containers and avoid fixed heights on text blocks.

### Step 7 — Remove colour-only meaning

Convert the screen to greyscale. Ask:

- Can I still tell error from success?
- Can I tell selected from unselected?
- Can I tell a link from body text?
- Can I tell a required field from an optional one?

If not, add an icon, a label, a pattern, or a text change. Colour can remain as an enhancer; it cannot be the only signal.

### Step 8 — Consider cognitive and situational inclusion

Compliance is the floor. Also ask:

- Is the language plain? Would a first-time user understand "beneficiary"?
- Is the flow short enough for someone with low bandwidth or a cognitive load?
- Are there time limits? Can they be extended?
- Does it work offline or on a slow connection?
- Is the content culturally appropriate without stereotyping?
- Are names, addresses and phone formats flexible enough for local reality?
- Does the design assume a shared device or a personal one?

Inclusion is context-specific. A form that requires a postcode may exclude people who use landmarks; a form that requires a surname and first name may exclude naming conventions that do not split that way. Ask before you assume.

### Step 9 — Write fixes a developer can implement

Weak: "Improve accessibility."

Strong:

> - Increase the account-number input height to 48 px and the label contrast to at least 4.5:1 (`#4B5563` on `#FFFFFF` is 7.6:1).
> - Add a 2 px focus ring using `--color-focus` with a 2 px offset; ensure it is visible on both white and grey surfaces.
> - Associate the error message with the field using `aria-describedby`, and move focus to the field on submit failure.
> - Do not rely on red alone: include the error icon and the word "Error" in the message.

This is actionable. It names the element, the value, the behaviour and the reason.

## 6. Worked example (I do)

**Screen:** the transfer form from Stop 2.4.

**Audit, ten checks:**

| # | Check | Result | Evidence | Fix |
|---|---|---|---|---|
| 1 | Body text contrast | Pass | `#111827` on `#FFFFFF` = 17.7:1 | — |
| 2 | Helper text contrast | Fail | `#9CA3AF` on `#FFFFFF` = 2.6:1 at 13 px | Darken to `#4B5563` (7.6:1) |
| 3 | Input border contrast | Fail | `#E5E7EB` on `#FFFFFF` = 1.3:1 | Use `#6B7280` (4.8:1) |
| 4 | Touch target | Fail | Close icon is 20 × 20 px | Increase hit area to 48 × 48 px |
| 5 | Visible label | Pass | "Account number" above field | — |
| 6 | Placeholder as instruction | Fail | Format hint only in placeholder | Move to helper text |
| 7 | Keyboard reachability | Not tested in Figma | Prototype only | Add to developer acceptance criteria |
| 8 | Focus indicator | Fail | No focus state designed | Add 2 px ring, 2 px offset |
| 9 | Colour-only error | Fail | Red border only | Add icon, "Error" text and message |
| 10 | Text resize | Fail | Button has fixed 48 px height and 14 px label | Use min-height and padding; test at 200% |

**Prioritisation:** contrast, labels and colour-only errors first, because they block comprehension. Touch targets and focus next, because they block operation. Text resize after, because it affects layout rather than access.

**The honest limit:** checks 7 and 10 cannot be fully verified in a static Figma file. They must be tested in the built page. The design can specify the requirement, but the audit is not complete until the build is tested. Write that in the report; do not claim a pass you did not verify.

## 7. We do it together

1. Open your screen and the contrast checker.
2. List every text/background pair. Measure and record.
3. List every interactive element. Measure its tappable area.
4. Tab through the prototype or the built page. Record where focus goes.
5. Convert to greyscale and list any meaning that disappears.
6. Check every field for a persistent label and a linked error.
7. Test at 200% text size and note what breaks.
8. Write the audit table with evidence and fixes.
9. Prioritise the fixes: blocks comprehension, blocks operation, causes discomfort, polish.
10. Write the developer notes for the top three fixes.

## 8. Your turn (You do)

**Independent task.** Produce an **accessibility audit** of one screen with at least **twelve** checks.

Submit:

1. The audit table: check, WCAG reference where applicable, result (pass/fail/not testable), evidence, fix.
2. Screenshots or descriptions of the failures.
3. A prioritised remediation list with the reason for the order.
4. A corrected version of the screen with at least five fixes applied.
5. Developer notes for three fixes, written as implementation instructions.
6. A 150-word reflection on the difference between **compliance** and **inclusion**, using one example from your own screen.

**Rules:** do not claim a check passed if you could not test it. Mark it "not testable in this format" and say what would be required. Do not use an automated checker as your only evidence; automated tools miss many issues.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** What does POUR stand for?
- A. Practical, Open, Usable, Responsive, the four headings used in the audit template.
- B. Private, Optimal, Universal, Reliable, the four qualities of an accessible page.
- C. Perceivable, Original, Useful, Responsive, the four stages of an audit.
- D. Perceivable, Operable, Understandable, Robust, the four principles behind every success criterion.

**Q2.** What is the WCAG 2.2 AA minimum contrast for normal text?
- A. 3:1, the threshold that applies to large text and essential icons.
- B. 4.5:1, the AA minimum SC 1.4.3 sets for normal-sized text.
- C. 7:1, the AAA target, which is stricter than the AA minimum asked for.
- D. 2:1, a decorative-only ratio that no text of any size may use.

**Q3.** What is the WCAG 2.2 AA minimum target size?
- A. 16 × 16 CSS px, the size at which icon-only buttons stop being usable.
- B. 44 × 44 CSS px, Apple's recommended size for comfortable finger targets.
- C. 24 × 24 CSS px, the minimum SC 2.5.8 sets for AA conformance.
- D. 48 × 48 CSS px, Material's recommended size for primary mobile controls.

**Q4.** Why is a 16 px icon with a 16 px hit area a problem?
- A. The icon is too large for the toolbar and crowds the controls beside it.
- B. Icons should never be used, because text labels are always clearer.
- C. It fails contrast, because the icon colour is too close to the background.
- D. The tappable area is too small for reliable touch, even if it looks fine.

**Q5.** A form shows errors only with a red border. Which criterion is at risk?
- A. 2.4.7 Focus Visible, because the field shows no outline when tabbed to.
- B. 1.4.1 Use of Color, because the error is conveyed by hue alone.
- C. 1.4.10 Reflow, because the field overflows at 320 px screen width.
- D. 3.1.1 Language of Page, because the error text is not language-tagged.

**Q6.** What does "not testable in this format" mean in an audit?
- A. The check is optional, so the auditor may skip it without recording anything.
- B. The criterion does not apply to this screen, so it can be removed.
- C. The designer forgot to run the check before submitting the audit.
- D. The current artifact cannot verify it, so it must be tested in the build.

**Q7.** Why is semantic HTML an accessibility issue?
- A. It makes pages smaller, because semantic tags compress better when served.
- B. It changes the default colours, which can lower the page's contrast ratio.
- C. It is required for search engine ranking, and accessibility is a side effect.
- D. Assistive technology relies on element roles and structure to announce the interface.

**Q8.** Which is an example of inclusive design beyond compliance?
- A. Passing a contrast checker on every text and background pair used.
- B. Adding alt text to every meaningful image and empty alt to decorative ones.
- C. Using a 24 px target for every control, which is the AA minimum.
- D. Allowing phone formats and informal addresses that match local naming reality.

**Q9.** A learner writes alt text for a chart showing monthly sales. Which alt text is most useful?
- A. A short description of the chart's purpose and the main trend.
- B. The single word chart, repeated once for each axis label.
- C. A full transcription of every monthly data point inside the attribute.
- D. An empty alt attribute, because the chart is decorative rather than informative.

**Q10.** A learner removes the default focus outline because it looks ugly, and keyboard users can no longer see where they are. Which requirement has failed?
- A. Colour contrast for body text, which must reach 4.5:1 on white.
- B. Image alt text, which must describe every meaningful picture.
- C. Page language declaration, which tells screen readers how to pronounce.
- D. Visible keyboard focus, so the current interactive element can be located.

## 10. Practical task and pass criteria

**Task.** Submit the twelve-check audit, corrected screen, prioritised fixes, developer notes and reflection.

**Pass criteria — all must be met:**

- [ ] At least twelve checks across POUR.
- [ ] Evidence for every result, with ratios or measurements where relevant.
- [ ] Failures honestly marked, including "not testable".
- [ ] A corrected screen with at least five fixes applied.
- [ ] Developer notes that name element, value, behaviour and reason.
- [ ] A prioritisation with a stated rationale.
- [ ] The reflection distinguishes compliance from inclusion with a concrete example.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Checking only the headline contrast | It is the obvious pair | Check all text, borders, icons and focus rings. |
| Automated checker only | It is fast | Add keyboard, resize and greyscale tests. |
| Icon-only buttons | They look clean | Add an accessible name and a visible label where possible. |
| Placeholder as label | Saves space | Add a persistent label. |
| Fixed heights on text containers | Easier layout | Use min-height and padding; test 200%. |
| Claiming a pass without testing | Optimism | Mark "not testable" and specify the test. |
| Treating accessibility as a final checklist | It feels like compliance | Build constraints into components and states from the start. |

**Retry variant.** Audit a **public government or banking page** instead of your own screen. Do at least twelve checks, including keyboard navigation and 200% zoom in a browser. Record three failures and write developer notes for each. Then compare: which failures are design decisions, and which are engineering? Submit the audit and a 120-word comparison.

## 12. Proof artifact for your portfolio

**Artifact:** `Accessibility-Audit-v1` — stored in `03_Projects/<project>/design/accessibility`.

Accessibility evidence is increasingly expected in hiring. Keep the corrected screen and the developer notes; they show you can move from finding to fixing.

## 13. Low-data and low-cost path

- Use WebAIM in a browser; no paid tools.
- NVDA is free on Windows; VoiceOver and TalkBack are built in.
- If you cannot install a screen reader, use the browser accessibility tree and state the limitation.
- The video is optional and short; the audit table is the lesson.
- Work offline once the screen is open; contrast checking needs only the page.

## 14. Watch and read more

**Recommended video (optional, 1:50):** *WCAG for beginners - What are the Web Content Accessibility Guidelines? - Web Accessibility* — Silktide. `https://www.youtube.com/watch?v=5H1JGdqLrWo`. Verified available on 2026-10-30. It is a very short introduction; use the W3C sources below for the actual criteria.

**Read (verified 2026-10-30):**

- W3C, *WCAG 2.2* — `https://www.w3.org/TR/WCAG22/`. The normative standard.
- W3C WAI, *How to Meet WCAG 2.2 Quick Reference* — `https://www.w3.org/WAI/WCAG22/quickref/`. Filter by level AA for a practical checklist.
- W3C WAI, *Introduction to Web Accessibility* — `https://www.w3.org/WAI/fundamentals/accessibility-intro/`. Good plain-language framing.
- MDN, *Accessibility* — `https://developer.mozilla.org/en-US/docs/Web/Accessibility`. Practical implementation guidance for later.

## 15. What comes next

**Gate 2** asks you to redesign a deliberately poor real screen **by hand, with no AI**, including all states, with a short rationale for every major decision. Read `03_Assessments/Learner/Phase_2_Gate.md`. Phase 3 then makes you fast and structured in Figma.