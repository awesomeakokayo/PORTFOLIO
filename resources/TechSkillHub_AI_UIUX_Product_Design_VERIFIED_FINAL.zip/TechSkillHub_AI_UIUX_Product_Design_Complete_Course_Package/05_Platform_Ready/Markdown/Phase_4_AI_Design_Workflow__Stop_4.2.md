# Stop 4.2 — AI for Ideation and Flows

> **Phase 4 · The AI design workflow** · Prerequisite: Stop 4.1 · Suggested session: 70–90 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Prompt for three genuinely different flows, not three variations of the same one.
2. Ask for information architecture, edge cases and failure paths.
3. Critique generated flows against tasks, constraints and evidence.
4. Select and adapt a flow without treating the AI's structure as authority.
5. Record the decision in a log that a reviewer can follow.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Ideation** | Generating possible solutions before choosing one. |
| **Divergent thinking** | Producing many different options. |
| **Convergent thinking** | Narrowing options against criteria. |
| **User flow** | The sequence of steps a user takes to complete a task. |
| **Task flow** | The essential steps for one task, without interface detail. |
| **Information architecture (IA)** | How content and destinations are organised, named and related. |
| **Navigation model** | The structure that lets users move between destinations. |
| **Edge case** | An uncommon but real situation the flow must handle. |
| **Failure path** | What happens when a step fails. |
| **Happy path** | The flow when everything works. |
| **Constraint** | A limit the flow must respect. |
| **Critique** | A structured judgement against criteria, not a taste reaction. |
| **Decision log** | A record of what was chosen, why, and what was rejected. |
| **Hallucinated feature** | A capability the AI invents that the product does not have. |
| **Scope creep** | The gradual expansion of work beyond the agreed problem. |

## 3. Why this matters

AI is very good at producing a plausible flow. That is the danger. A flow can look complete — entry, form, confirmation, success — while missing the bank name lookup failure, the duplicate-tap risk, the offline case, or the user who has no saved beneficiary and no data.

The value is in **divergence**: asking for three different structures, then comparing them. If you ask for "the flow", you get the most conventional one. If you ask for "three flows with different trade-offs", you get material to think with.

> **Everyday example.** Asking a taxi driver for "the route" gives you the usual route. Asking for three routes — fastest, cheapest, most reliable at rush hour — gives you a decision. The second question is the design question.

## 4. Before you start

- Have your problem brief and research themes open.
- Know your constraints: device, connectivity, payment method, regulatory checks, team size.
- Create a FigJam board or a large sheet of paper with three columns.

## 5. Teaching, step by step

### Step 1 — Ask for divergence with explicit differences

Prompt:

> "Generate three user flows for [task] for [user] under [constraints]. Each flow must use a different structural approach: (1) a single-screen flow, (2) a step-by-step wizard, (3) a conversational or chat-like flow. For each, list the steps, the information required at each step, the failure points, and the trade-offs. Do not assume features we do not have: [list]."

Why specify the three approaches? Because "give me three options" usually produces three cosmetic variations. Naming the structural difference forces real divergence.

### Step 2 — Ask for the information architecture separately

IA is not a flow. Ask:

> "Propose an information architecture for [product] with no more than five top-level destinations. For each destination, list the screens and the user questions it answers. Explain why each destination deserves top-level placement. Identify what you would put in 'More' or a secondary menu."

Then check: can a user reach the primary task in one or two taps? Are the labels in the user's language? Is anything top-level that is actually a setting?

### Step 3 — Demand edge cases and failure paths

Prompt:

> "For the selected flow, list every edge case and failure path you can identify across: network, payment, identity, data, permissions, timeouts, duplicate actions, partial success, accessibility, and low-end devices. For each, state what the user sees and how they recover. Mark any case where you are unsure whether the product supports it."

This is where AI earns its keep. It will surface cases you forgot. It will also invent capabilities; mark those and check.

### Step 4 — Critique against criteria, not vibes

Build a critique matrix:

| Criterion | Flow A | Flow B | Flow C |
|---|---|---|---|
| Steps to complete | 4 | 6 | 5 |
| Cognitive load | Low | Medium | High |
| Failure recovery | Weak | Strong | Medium |
| Offline support | None | Partial | Strong |
| Accessibility risk | Medium | Low | High |
| Build complexity | Low | High | Medium |
| Fits evidence | Partly | Strongly | Partly |

Score with a short justification, not just a number. Then ask: which flow best fits the **evidence** and the **constraints**, not which is most impressive?

### Step 5 — Attack the winner

Before selecting, run a "pre-mortem":

> "Assume this flow failed in production. List the five most likely reasons, in order of likelihood, with the evidence that would confirm each."

This surfaces risks that the flow's elegance hides. Common results: users do not understand the confirmation, the name lookup fails for a major bank, the retry duplicates a transfer, the flow assumes a smartphone the user does not have.

### Step 6 — Check for hallucinated features

For every step, mark:

- **Have:** the product or prototype already supports it.
- **Build:** feasible within the project.
- **Assume:** depends on a capability you have not verified.
- **Invent:** the AI made it up.

Any "invent" step must be removed or replaced. Any "assume" step needs a test or a fallback. This single discipline prevents most AI-generated flow nonsense.

### Step 7 — Select and adapt

Selection is not copying. Write:

> "I selected Flow B because it keeps the recipient check visible at the point of risk and supports offline recovery. I removed the AI's 'scan a QR code' step because we have no QR capability. I merged Flow C's status-check pattern into Flow B's failure state. I rejected Flow A's single screen because it hides the fee until after the action."

This is the decision log. It names the evidence, the constraints, the kept parts, the removed parts and the reason.

### Step 8 — Draw the flow yourself

Draw the selected flow in FigJam or on paper, using:

- rectangles for screens;
- diamonds for decisions;
- arrows for transitions;
- a distinct marker for failure paths;
- a note on each step for the data required.

Drawing it yourself forces you to notice gaps. Pasting the AI's ASCII diagram into a document does not.

## 6. Worked example (I do)

**Task:** send money to a new recipient.

**Three flows requested:**

- A: single screen with all fields and a final "Send" button.
- B: three-step wizard (recipient → amount → confirm).
- C: chat-style assistant that asks for details one at a time.

**Critique:**

| Criterion | A | B | C |
|---|---|---|---|
| Steps | 1 | 3 | 5–7 |
| Cognitive load | High (all at once) | Medium | Low per step, high overall |
| Error recovery | Weak (no dedicated confirm) | Strong | Medium |
| Offline | Weak | Partial | Weak |
| Build complexity | Low | Medium | High |
| Fits evidence | Weak (name is easy to miss) | Strong | Unknown |

**Selection:** B, because the evidence showed the name check is the critical moment and B makes it a dedicated step. A hides it; C adds conversational complexity without evidence that users want chat for money transfers.

**What I removed:** the AI added "Scan recipient's QR code" and "Split the fee with a friend". Neither exists in the product or the problem brief. Removed and logged.

**What I merged:** C's "Check status" after an unknown outcome, because it solves the duplicate-retry risk better than B's original "Try again".

**What I kept from A:** the single-screen amount entry, because entering an amount does not need its own step; the wizard is three steps, not five.

**The result is not any of the three AI flows.** It is a deliberate hybrid, with each borrowed part justified by evidence or risk. That is the skill.

## 7. We do it together

1. Write the divergence prompt with your task, user and constraints.
2. Generate three flows with different structures.
3. Generate the IA separately.
4. Generate edge cases and failure paths for each flow.
5. Build the critique matrix with justifications.
6. Mark every step as Have / Build / Assume / Invent.
7. Remove invented steps and note them.
8. Run the pre-mortem on the leading flow.
9. Select and write the decision log.
10. Draw the selected flow yourself, including failure paths.

## 8. Your turn (You do)

**Independent task.** Produce an **AI-assisted flow pack** for your project.

Submit:

1. The prompts used.
2. Three AI-generated flows with genuinely different structures.
3. An IA proposal with no more than five top-level destinations.
4. A critique matrix with at least six criteria and justifications.
5. A Have/Build/Assume/Invent marking for every step.
6. A list of at least three hallucinated or unsupported features, with what you did.
7. A pre-mortem with five failure reasons.
8. Your selected flow, drawn by hand or in FigJam, including failure paths.
9. A 200-word decision log: kept, changed, rejected, and why.

**Do not** copy an AI flow directly. Do not include a feature the product does not have without marking it as an assumption. Do not select the most complex flow because it looks impressive.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** Why ask for three structurally different flows rather than "three options"?
- A. To make the prompt longer, because detailed prompts are treated as higher quality.
- B. To give the assistant enough examples that it can produce one usable flow.
- C. To postpone critique, since comparing options feels more productive than judging one.
- D. To force real divergence rather than three cosmetic variations of the same structure.

**Q2.** What is a hallucinated feature?
- A. A capability the AI invents that the product does not have or support.
- B. A feature that is technically hard to build within the current project timeline.
- C. A feature that users dislike, according to the research themes already gathered.
- D. A feature already listed in the product backlog but not yet designed.

**Q3.** What does the Have/Build/Assume/Invent marking do?
- A. Scores each step for visual quality, so the most polished flow can be selected.
- B. Separates what already exists from what is feasible, assumed or invented.
- C. Counts the screens in each flow, so the shortest path can be identified.
- D. Measures accessibility risk per step, using contrast and target sizes as criteria.

**Q4.** Why generate IA separately from the flow?
- A. Because IA only applies to websites, while mobile products rely on flows instead.
- B. Because flows cannot contain screens, so their structure has to be described elsewhere.
- C. Because IA covers structure and naming while a flow covers sequence, and mixing hides structural faults.
- D. Because the assistant can only handle one artefact per prompt and cannot do both.

**Q5.** What is a pre-mortem?
- A. Imagining the flow has failed in production and listing the most likely reasons.
- B. Testing the flow with five users and recording where they hesitate or stop.
- C. Critiquing the visual hierarchy, spacing and consistency of each screen.
- D. Mapping the project timeline, including design, build and release milestones.

**Q6.** A flow has six steps and low cognitive load per step. Is it automatically better than a three-step flow?
- A. Yes, because more steps keep each screen simpler and users rarely mind the extra taps.
- B. No, because total effort, abandonment and context switching matter more than per-step load.
- C. Yes, because users prefer wizards and will abandon a flow that asks for everything at once.
- D. No, because step count is irrelevant and only the visual design of each screen matters.

**Q7.** What belongs in a decision log?
- A. Only the final flow, presented cleanly so the choice needs no further explanation.
- B. What was selected, what was kept, changed or rejected, and the reason for each.
- C. The AI model's name and version, so the output can be reproduced later.
- D. A list of the colours and components used in the selected flow.

**Q8.** Why draw the selected flow yourself?
- A. Because drawing forces you to notice gaps and dependencies that copying hides.
- B. Because AI diagrams are usually wrong, so redrawing is the only way to correct them.
- C. Because the export process requires a hand-drawn frame before the file can be shared.
- D. Because a hand-drawn flow looks more professional in a portfolio case study.

**Q9.** An AI produces three flows that are almost identical. Which follow-up prompt is most likely to produce genuinely different options?
- A. Ask for three more flows with no additional constraints and compare them again.
- B. Ask the assistant to make the three screens prettier, then choose the clearest one.
- C. Ask for one flow minimising steps, one maximising control, one working offline, with trade-offs stated.
- D. Ask for one flow, then copy it three times and label the copies as alternatives.

**Q10.** A generated flow includes a 'Scan QR to pay' step, but the product has no camera permissions or QR feature. What is the defect?
- A. The flow has too few steps for the task and skips the confirmation stage.
- B. The flow uses a modal where a full page would be clearer on small screens.
- C. The flow lacks a colour palette, so the payment action is not visually distinct.
- D. The flow invents a capability the product lacks, namely camera access and a QR feature.

## 10. Practical task and pass criteria

**Task.** Submit the nine-part flow pack.

**Pass criteria — all must be met:**

- [ ] Three flows with genuinely different structures.
- [ ] An IA with five or fewer top-level destinations.
- [ ] A critique matrix with six criteria and justifications.
- [ ] Every step marked Have/Build/Assume/Invent.
- [ ] At least three unsupported features identified and handled.
- [ ] A pre-mortem with five reasons.
- [ ] A hand-drawn or FigJam flow including failure paths.
- [ ] A decision log explaining kept, changed and rejected.
- [ ] No unmarked invented capability.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Accepting the first flow | It looks complete | Ask for structural alternatives; critique. |
| Three cosmetic variants | The prompt was vague | Name the structural differences. |
| Ignoring failure paths | The happy path is exciting | Generate edge cases explicitly; draw them. |
| Missing invented features | They look plausible | Mark every step Have/Build/Assume/Invent. |
| Choosing the most complex flow | Complexity feels professional | Score against evidence and constraints. |
| No decision log | The choice feels obvious | Record kept, changed, rejected. |
| Copying the AI diagram | It is faster | Redraw it yourself. |

**Retry variant.** Generate flows for a **different task**: cancelling a subscription or disputing a charge. Focus on the failure and recovery paths, and include a regulatory or policy constraint. Submit three flows, a critique matrix, a decision log and a 150-word note on which assumption was most dangerous.

## 12. Proof artifact for your portfolio

**Artifact:** `Flow-Pack-v1` — stored in `03_Projects/<project>/design/flows`.

The decision log is the valuable part. It shows you directed the AI rather than following it.

## 13. Low-data and low-cost path

- Use text prompts and paper diagrams; no diagramming tool required.
- If AI is unavailable, generate three flows yourself using the same structural constraints and complete the critique.
- The video is optional and seven minutes; the divergence and critique method above is the lesson.

## 14. Watch and read more

**Recommended video (optional, 7:07):** *I Created Complete User Journeys in Minutes Using ChatGPT + Figma* — UX For AI. `https://www.youtube.com/watch?v=YYvZ2_TIcHA`. Verified available on 2026-10-30. It demonstrates a fast workflow; the critique and Have/Build/Assume/Invent discipline here are the course's own.

**Read (verified 2026-10-30):**

- Nielsen Norman Group, *Journey Mapping 101* — `https://www.nngroup.com/articles/journey-mapping-101/`. Defines the actor, scenario, phases, actions, emotions and opportunities that a journey map must contain.
- GOV.UK Design System — `https://design-system.service.gov.uk/patterns/`. Strong examples of flows and patterns with documented reasons.

## 15. What comes next

Stop 4.3 moves from flows to screens: prompting AI to generate UI, importing it, and then reviewing every output for accessibility, consistency and fit.