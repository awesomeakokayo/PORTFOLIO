# Stop 3.1 — Figma Essentials

> **Phase 3 · Figma fluency and design systems** · Prerequisite: Phase 2 gate · Suggested session: 70–90 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Move around a Figma file without hunting: pages, frames, layers, panels and search.
2. Use the ten shortcuts that remove most mouse work.
3. Organise a file so a stranger can find the current design, the archive and the components.
4. Create and apply text and colour styles.
5. Use version history and file naming to avoid "final-final" chaos.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **File** | A Figma document containing pages, frames and layers. |
| **Page** | A top-level section inside a file, shown in the left sidebar. Use pages to separate workstreams, not screens. |
| **Canvas** | The grey area where frames sit. |
| **Frame** | A container with size, clipping and export, used as a screen or component. |
| **Section** | A labelled area on the canvas that groups frames visually. |
| **Layer** | Any object: frame, group, shape, text, image, component. |
| **Layers panel** | The tree of objects on the current page. |
| **Design panel** | The right-hand panel for size, position, fill, stroke, effects, typography and export. |
| **Local styles** | Saved text, colour, effect and grid styles reused across the file. |
| **Component** | A reusable object with a main version and instances. |
| **Instance** | A copy of a component that stays linked to the main. |
| **Asset** | A saved component or style available in the Assets panel. |
| **Version history** | Figma's record of saved versions, allowing restore. |
| **Autosave** | Figma saves changes to the cloud automatically. |
| **Community** | Figma's public library of files, plugins and templates. |
| **Plugin** | A third-party add-on that runs inside Figma. |
| **Dev Mode** | A view for developers to inspect measurements, styles and code. |
| **Boolean operation** | Combining shapes (union, subtract, intersect, exclude) to make a new shape. |
| **Mask** | Using one layer to reveal or hide parts of another. |

## 3. Why this matters

Figma is not difficult to open; it is difficult to keep clean. A beginner file after two weeks often has twelve pages called "Page 1", forty frames called "Frame 42", and three versions of the same button that look almost identical. The design may be good, but the file is unusable by anyone else — including future you.

Professional speed is not typing fast. It is **not searching**. Named layers, a small shortcut set, styles instead of repeated values, and a clear page structure remove most of the friction. That is what lets you spend your attention on the design problem.

> **Everyday example.** A kitchen where every utensil has a place and the knives are sharp cooks faster than a kitchen with better ingredients and no organisation. Figma is your kitchen.

## 4. Before you start

- Open Figma and create a new design file called `03_Figma-Essentials`.
- If you are on the free plan, check the current file and collaboration limits on Figma's pricing page. Do not upgrade for this course.
- Keep the Figma Help Centre open in a tab: `https://help.figma.com/`.

> **Interface warning.** Figma's UI changes. The names below match the current interface at the time of writing. If something has moved, press `Ctrl/Cmd + /` and search the command by name. Do not rely on memorised button positions.

## 5. Teaching, step by step

### Step 1 — Learn the five regions

1. **Left sidebar:** pages, layers, assets.
2. **Top toolbar:** move, frame, shape, pen, text, comments, present, zoom.
3. **Canvas:** the work.
4. **Right panel:** design properties when nothing is selected; object properties when something is.
5. **Bottom-left:** help, zoom, and version history access.

Spend two minutes clicking each region. The goal is to know where to look, not to memorise every control.

### Step 2 — Master ten shortcuts

| Shortcut (Windows / Mac) | Action |
|---|---|
| `V` | Move/select |
| `F` | Frame |
| `R` | Rectangle |
| `T` | Text |
| `Ctrl/Cmd + /` | Search commands |
| `Ctrl/Cmd + G` | Group |
| `Ctrl/Cmd + Alt + G` | Frame selection |
| `Ctrl/Cmd + D` | Duplicate |
| `Ctrl/Cmd + Shift + K` | Place image |
| `Shift + 2` | Zoom to selection |
| `Ctrl/Cmd + '` | Pixel grid |
| `Shift + G` | Layout grid |
| `Alt` + drag | Duplicate while dragging |
| `Ctrl/Cmd + [` / `]` | Send backward / bring forward |

Pick five to practise today. Speed comes from a small set used automatically, not from a long list you have to look up.

### Step 3 — Use frames, not groups, for screens

A frame has a fixed size, can clip content, and exports cleanly. A group is only a container. For screens and components, use frames.

Name every frame with a consistent pattern:

```
00_Home
01_Search
02_Results
03_Detail
90_Archive_Home_v1
```

Numbering keeps the flow in order. The `90_` prefix moves old work to the bottom without deleting it.

### Step 4 — Structure pages by workstream

A good page structure for a product:

```
Cover
01_Research
02_Flows
03_Design
04_Components
05_Prototype
06_Handoff
90_Archive
```

Why not one page per screen? Because a page per screen multiplies navigation and makes comparison hard. Pages should separate **kinds of work**, not every artifact.

For a small practice file, three pages are enough: `Design`, `Components`, `Archive`.

### Step 5 — Use sections to label the canvas

A Section (`Ctrl/Cmd + Alt + S` or the Section tool) is a labelled area that groups frames on the canvas. Use sections for:

- a flow ("Send money — happy path");
- a state set ("Loading, error, success");
- a component family ("Buttons").

Sections make a dense canvas readable at a glance, and they move their contents together.

### Step 6 — Save styles instead of repeating values

Create text styles:

```
Display/40
H1/32
H2/24
Body/16
Label/13
```

Create colour styles:

```
text/primary
text/secondary
surface/default
surface/raised
action/primary
feedback/danger
```

Apply the style, not a manual value. When the brand colour changes, you edit one style, not every button. In Stop 3.3 you will convert these to variables for even more control.

### Step 7 — Use components for repeated objects

Select a button, press `Ctrl/Cmd + Alt + K` to create a component. Copies dragged from the Assets panel are instances. Edit the main to update all instances; override text or colour on an instance only when the difference is intentional.

Rule: if an object appears three or more times, make it a component. If it appears twice and will grow, make it now.

### Step 8 — Keep version history useful

Figma autosaves, but it does not name versions for you. Use the file menu to view version history and name a milestone when:

- a phase gate is passed;
- a design is sent for review;
- a major direction changes.

Name versions like `v1_gate2-approved` or `v2_before-usability-test`. In Stop 4.7 you will keep a decision log alongside these milestones.

### Step 9 — Work with images and assets without bloating the file

- Compress images before placing them; Figma stores the original.
- Crop with a mask or frame rather than placing a huge image and covering it.
- Use the same image once and duplicate the frame, not the file.
- Delete unused layers and hidden experiments before handoff (check with the layers panel).
- Do not paste screenshots of entire websites when a single component screenshot will do.

### Step 10 — Present and share without giving away edit access

Use the Present button to view a prototype or frame full-screen. For review, use "Copy link" and set permissions to "Can view" or "Can comment". Do not share edit access with a reviewer unless they need it.

For handoff, Dev Mode gives developers measurements and code hints, but it is a paid seat on some plans. A well-named file plus a spec document works on the free plan; you will do this in Stop 5.1.

## 6. Worked example (I do)

**Situation:** my `03_Figma-Essentials` file has 18 frames on one page, all named `Frame`, and a button copied 14 times with slightly different corner radii.

**Clean-up, reasoned aloud:**

1. I create pages: `Design`, `Components`, `Archive`. The 18 frames stay on `Design` for now.
2. I sort the frames into three sections: `Onboarding`, `Transfer`, `States`.
3. I rename the frames by flow order: `00_Welcome`, `01_Phone`, `02_Verify`, `03_Home`.
4. I find the most common button: 345 × 52, radius 12, `action/primary`. I make it a component named `Button/Primary/Default`.
5. I replace the other copies with instances. Where a copy had a different radius, I fix it to the component rather than creating a new variant — the difference was accidental, not a design decision.
6. I create text styles for the five sizes actually used. I discover six sizes, two of which differ by 1 px; I merge them. The file becomes calmer immediately.
7. I move the old exploration frames to `90_Archive` on the `Archive` page and name the version `v1_cleanup`.
8. I write a one-line file description: "Practice file for Figma essentials. Current design: page Design, section Transfer. Components: page Components."

**What changed in my speed:** I stopped using the layers panel to find the button; I drag from Assets. I stopped typing colours; I apply styles. The time saved is small per action and large per day.

## 7. We do it together

1. Create the file `03_Figma-Essentials`.
2. Create pages `Design`, `Components`, `Archive`.
3. On `Design`, create three sections: `Practice`, `States`, `Scratch`.
4. Create frames `00_Home`, `01_Detail`, `02_Success` at 393 × 852.
5. Rename every layer in `00_Home` using the pattern `area_element` (for example `header_title`).
6. Create five text styles and five colour styles from Stop 2.2.
7. Make one button component and place three instances.
8. Duplicate one frame, change one thing, and name it `01_Detail_v2`.
9. Open version history and name the current version `v1_organised`.
10. Copy the view link and check that it opens without edit access.

## 8. Your turn (You do)

**Independent task.** Build an **organised starter file** for your own project and submit the view link plus a PDF guide.

Requirements:

1. Pages: `Cover`, `Research`, `Design`, `Components`, `Archive` (or a documented equivalent).
2. A cover frame with the project name, your name, the date, and a one-sentence description.
3. At least three named sections on the Design page.
4. At least six frames named with the numbering pattern, in flow order.
5. At least five text styles and five colour styles, applied (not manual values).
6. At least two components with instances.
7. A named version in history.
8. A one-page "file guide" explaining where to find the current design, the components and the archive.
9. A shortcut sheet listing the eight shortcuts you actually used, with what each does.

**Do not** leave any layer named `Frame`, `Group` or `Rectangle` on the main design page. Do not use more than one page per workstream.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** What is the main difference between a frame and a group?
- A. A group can hold text layers and images, while a frame can hold only one shape.
- B. A frame is always transparent, so anything placed behind it stays visible through the canvas.
- C. A frame has size, clipping and export, while a group is only a container for its layers.
- D. A group cannot be renamed in the layers panel, so it always keeps its default name.

**Q2.** Why use pages for workstreams rather than one page per screen?
- A. Figma limits a file to five pages, so each screen must share a page with other screens.
- B. Pages per screen multiply navigation and make it harder to compare screens side by side.
- C. Screens cannot be placed on pages at all, so each screen needs its own separate file.
- D. Pages are reserved for components only, so screens belong on the canvas and not on pages.

**Q3.** What does a local text style do?
- A. It automatically writes sample copy into every text layer that uses the style.
- B. It exports each text layer as a separate image file when the frame is exported.
- C. It translates the file's text into another language whenever the style is applied.
- D. It saves reusable typography values that can be applied and updated in one place.

**Q4.** When should you create a component?
- A. Only when a designer on the team explicitly asks you to create one.
- B. When an object repeats and will need consistent updates across several screens.
- C. Only for buttons, because other objects change too often to be worth componentising.
- D. After handoff, once the final screens have been approved by the client.

**Q5.** What does naming a version in history help with?
- A. It makes the file smaller by compressing earlier versions of every page.
- B. It marks a meaningful milestone that can be restored or referenced later.
- C. It shares the file publicly with anyone who has the version name.
- D. It transfers ownership of the file to the person who named the version.

**Q6.** Which shortcut opens command search?
- A. Ctrl/Cmd+S, which saves the current file and shows the save confirmation.
- B. Shift+2, which zooms the canvas to the layer you have selected.
- C. Alt+F4, which closes the application window on a Windows machine.
- D. Ctrl/Cmd+/, which opens a search field for finding commands by name.

**Q7.** Why compress images before placing them?
- A. Figma rejects any image over 1 MB, so compression is required before placing.
- B. Figma stores the original, so large images bloat the file and slow collaboration.
- C. Compression raises image contrast, which keeps small text legible on busy photos.
- D. Compression converts every placed image into a lighter vector format automatically.

**Q8.** What is the best sharing setting for a reviewer who only needs to comment?
- A. Can edit, so the reviewer can fix small issues without waiting for you.
- B. Owner, so the reviewer has full control of the file during the review.
- C. Can view or can comment, which lets the reviewer read and respond without editing.
- D. A public edit link, so anyone who receives it can open and change the file.

**Q9.** A learner is organising a Figma file with explorations, final screens and a component library. Which page structure is most useful to a collaborator?
- A. One page holding every frame in creation order, with no sections or page names.
- B. One page for each colour used in the file, so the palette is easy to compare.
- C. Separate pages for exploration, final screens and the component library, with clear names.
- D. A separate file for every screen, with no index or shared navigation between them.

**Q10.** A learner shares a file with 40 frames named Frame 1 to Frame 40 and no page structure. What will most likely happen in review?
- A. Reviewers will struggle to find the current screen and may comment on the wrong version.
- B. Figma will automatically rename the frames by reading the text inside each one.
- C. The file will export faster, because unnamed layers take less time to process.
- D. The frames will convert themselves into components once the file is shared.

## 10. Practical task and pass criteria

**Task.** Submit the file link (view access) and the one-page file guide PDF.

**Pass criteria — all must be met:**

- [ ] Five pages with a clear purpose.
- [ ] A cover frame with project, name, date and description.
- [ ] Three named sections.
- [ ] Six numbered frames in flow order.
- [ ] Five text and five colour styles applied.
- [ ] Two components with instances.
- [ ] A named version in history.
- [ ] No unnamed frames or groups on the main design page.
- [ ] A file guide and shortcut sheet.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Every screen on one page | It feels simple at first | Split by workstream; use sections within a page. |
| `Frame 42` names | Renaming takes time | Rename on creation; use `area_element`. |
| Manual colours everywhere | Faster in the moment | Apply styles; fix one value later. |
| Detaching components to change one thing | It seems quicker | Use overrides or a variant. |
| Huge screenshots pasted in | Convenience | Crop and compress; place only what is needed. |
| Public edit links | Easy sharing | Use view/comment links. |
| No version names | Autosave feels enough | Name gate and review milestones. |

**Retry variant.** Take a messy file (your own or a practice file you deliberately mess up), clean it, and record a five-minute screen recording or a ten-step written log of every rename, style and component decision. Submit the cleaned file link and the log. The log must explain one decision you reversed.

## 12. Proof artifact for your portfolio

**Artifact:** `Figma-File-Guide` — the file link and guide, stored in `03_Projects/00_Foundations/figma`.

A clean file is evidence of professional habits. Reviewers often open the file before reading the case study.

## 13. Low-data and low-cost path

- Use the browser version; no desktop app.
- Avoid plugins; they add accounts and data.
- Work with shapes and text only; no image-heavy practice.
- If Figma is inaccessible, use Penpot (open source) and note the substitution; the concepts transfer, though shortcut names differ.
- The video is optional and 1.5 hours; use the written steps if data is low.

## 14. Watch and read more

**Recommended video (optional, 1:29:46):** *Free Figma Crash Course for Beginners 2026* — DesignWithArash. `https://www.youtube.com/watch?v=1SNZRCVNizg`. Verified available on 2026-10-30. It is long; watch the sections on frames, layers and components if you need video support. Interface details may have changed since publication.

**Read (verified 2026-10-30):**

- Figma Help, *Frames in Figma Design* — `https://help.figma.com/hc/en-us/articles/360041539473-Frames-in-Figma-Design`.
- Figma Help, *Guide to components* — `https://help.figma.com/hc/en-us/articles/360038662654-Guide-to-components-in-Figma`.

## 15. What comes next

Stop 3.2 makes layouts respond: auto layout, resizing, constraints and the difference between Hug, Fill and Fixed. This is where Figma stops being a drawing tool and becomes a layout system.