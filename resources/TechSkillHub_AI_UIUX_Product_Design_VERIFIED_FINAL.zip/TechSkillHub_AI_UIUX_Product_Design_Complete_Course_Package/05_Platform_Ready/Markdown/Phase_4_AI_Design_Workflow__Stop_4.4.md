# Stop 4.4 — AI for Critique

> **Phase 4 · The AI design workflow** · Prerequisite: Stop 4.3 · Suggested session: 70–90 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Brief an AI critic with the screen, the task, the heuristics and the constraints.
2. Ask for specific, evidence-based findings rather than generic advice.
3. Verify each finding against the screen and the standards.
4. Rate severity and decide what to fix.
5. Reject confident but wrong critique without dismissing the useful parts.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Critique** | A structured judgement against criteria, with evidence. |
| **Heuristic evaluation** | Reviewing an interface against recognised usability principles. |
| **Red teaming** | Deliberately attacking a design to find weaknesses. |
| **Severity** | How much harm a problem causes and how often. |
| **False positive** | A reported problem that is not actually a problem. |
| **False negative** | A real problem the critique missed. |
| **Actionable finding** | A finding specific enough to fix. |
| **Evidence** | The screen element, standard or behaviour that supports a finding. |
| **Consistency** | Whether similar things look and behave similarly. |
| **Affordance** | A visual cue about how something works. |
| **Cognitive walkthrough** | Stepping through a task as a user, asking what they know and see at each step. |
| **Severity rating** | A scale from cosmetic to critical. |
| **Triage** | Deciding what to fix now, later or never. |
| **Regression** | A fix that breaks something else. |

## 3. Why this matters

AI is a tireless critic. It will produce twenty findings in ten seconds. Some will be sharp; some will be generic ("improve visual hierarchy"); some will be wrong ("the button is too small" when it is 48 px). If you accept all of them, you will spend a day fixing non-problems and miss the real one.

The skill is **verification and triage**. A critique is only useful if each finding names the element, the principle, the harm and the fix. You then decide, with evidence, what deserves attention.

> **Everyday example.** A friend reviews your CV and says "make it pop". Another says "your phone number is in 8 pt grey at the bottom; a recruiter will miss it." The second is a finding; the first is noise. AI produces both.

## 4. Before you start

- Choose one screen with a clear task.
- Have the ten heuristics and the WCAG quick reference open.
- If your AI tool accepts images, upload a screenshot with no personal data. If not, describe the screen in structured detail.

## 5. Teaching, step by step

### Step 1 — Brief the critic properly

A weak prompt: "Review my design."

A strong prompt:

> "You are a senior product designer running a heuristic evaluation. The screen is a mobile confirmation step for sending ₦25,000 to a new recipient. The user is a first-time sender on a slow Android connection. Evaluate against Nielsen's 10 heuristics and WCAG 2.2 AA. For each finding, give: the exact element, the heuristic or criterion, what the user experiences, the evidence visible in the screenshot, severity (critical/high/medium/low), and a specific fix. Do not invent elements that are not visible. If you cannot see something, say 'not visible'. Limit to the ten most important findings."

Why this works: it sets the role, the task, the standard, the output format, the evidence requirement and the limit. The "not visible" rule reduces hallucination.

### Step 2 — Ask for categories separately

A single pass mixes visual, interaction and content issues. Run three passes:

1. **Heuristics:** visibility, match with the real world, control, consistency, error prevention, recognition, flexibility, aesthetics, error recovery, help.
2. **Accessibility:** contrast, targets, labels, focus, colour-only meaning, text resize.
3. **Content:** clarity, specificity, tone, honesty, local fit.

Separate passes produce more specific findings and make verification easier.

### Step 3 — Demand evidence, not adjectives

For every finding, require:

- **Element:** "the secondary 'Cancel' link".
- **Principle:** "H2 match between system and real world" or "SC 1.4.3".
- **Harm:** "a user may tap Cancel while aiming for Send".
- **Evidence:** "both actions are 48 px tall and adjacent".
- **Fix:** "separate them by 24 px and reduce Cancel to a text link".

If a finding cannot fill these fields, it is not actionable.

### Step 4 — Verify against the artifact

For each finding, mark:

- **Confirmed:** visible and correctly described.
- **Partly confirmed:** the issue exists but the description or severity is wrong.
- **False positive:** not present, or not a problem in this context.
- **Not verifiable:** needs a build or assistive technology.

Do not accept a finding because it sounds expert. Open the screen and look.

### Step 5 — Rate severity with a simple scale

| Severity | Meaning | Action |
|---|---|---|
| **Critical** | Blocks the task, causes harm, or violates a legal/accessibility requirement | Fix before release |
| **High** | Causes failure or significant confusion for many users | Fix in this iteration |
| **Medium** | Adds effort or confusion but has a workaround | Schedule |
| **Low** | Cosmetic or minor polish | Backlog |
| **Not a problem** | False positive or intentional trade-off | Document and close |

Severity is not the same as ease of fixing. A critical issue that takes five minutes still comes first.

### Step 6 — Run a red-team pass

Ask the AI to attack the design from specific adversarial roles:

> "Critique this screen as: (a) a first-time user with low literacy, (b) a user with low vision using 200% text, (c) a fraudster looking for a way to exploit the confirmation step, (d) a support agent receiving calls about it. For each, list the three most likely failures."

This produces findings that a generic review misses. The fraudster perspective is particularly useful for payment flows; it forces you to think about what the design enables, not just what it looks like.

### Step 7 — Check for false negatives

AI critique tends to miss:

- keyboard and screen-reader behaviour;
- real network failure;
- cultural and language context;
- the user's emotional state;
- legal or policy constraints;
- long-content and empty states.

Add these checks yourself. A critique that only covers the visible screenshot is incomplete.

### Step 8 — Turn findings into a plan

Group by severity, then by theme. For each accepted finding:

- what will change;
- who owns it;
- how you will verify the fix;
- what might regress.

Reject findings explicitly, with a reason. "Rejected: the AI claimed the button is 32 px; measured 48 px" is a useful record. It shows you checked.

## 6. Worked example (I do)

**Screen:** transfer confirmation.

**AI findings (excerpt):**

1. "The primary button lacks contrast." — **False positive.** Measured #FFFFFF on #1D4ED8 = 8.6:1.
2. "The warning is below the button, so users act before reading it." — **Confirmed.** The warning sits under the footer; move it above.
3. "The back arrow is decorative." — **Partly confirmed.** It has no label, but it is a standard pattern; the real issue is a 24 px target. Fix the target, add an accessible name.
4. "The screen lacks a loading state." — **Confirmed and important.** Add a processing state.
5. "Use a more modern gradient." — **Rejected.** Cosmetic and not tied to the task.
6. "The amount should be larger than the title." — **Confirmed.** Amount is 32 px, title 28 px; increase for first-time users.
7. "The account number should be masked for privacy." — **Rejected for this screen.** The user needs to verify the full number before sending; masking would defeat the task. Consider masking elsewhere.
8. "Add a QR scan option." — **Rejected.** Out of scope and invented.

**Severity:** #2 high, #4 critical (unknown outcome risk), #6 medium, #3 medium, #1/#5/#7/#8 not problems.

**What I fixed:** moved the warning, added the processing state, increased the amount to 40 px, enlarged the back target to 48 px, added an accessible name.

**What I learned:** the AI was strong on missing states and hierarchy, weak on measurements and context. It also suggested a privacy change that would have harmed the task. Verification was not optional.

## 7. We do it together

1. Write the critique brief with role, task, standards and output format.
2. Run the heuristics pass.
3. Run the accessibility pass.
4. Run the content pass.
5. Run the red-team pass with four roles.
6. Verify every finding and label it confirmed/partly/false/not verifiable.
7. Rate severity.
8. Build the action list with owner, fix and verification.
9. Apply three fixes and re-check for regressions.
10. Write the rejected-findings log with reasons.

## 8. Your turn (You do)

**Independent task.** Produce an **AI critique pack** for one screen.

Submit:

1. The critique brief.
2. The four passes (heuristics, accessibility, content, red team).
3. A verification table: finding, label, evidence, severity.
4. At least **two** false positives you rejected with evidence.
5. At least **one** false negative the AI missed, which you found yourself.
6. A prioritised action list with owner, fix and verification method.
7. A revised screen with at least three fixes.
8. A 150-word reflection on when the AI's critique was most and least useful.

**Do not** accept findings without checking. Do not apply cosmetic suggestions that are not tied to the task. Do not let the AI's confidence substitute for evidence.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** What makes a critique finding actionable?
- A. It names the element, principle, harm, evidence and the specific fix.
- B. It is written by an AI critic, which makes it thorough and consistent.
- C. It uses design jargon, which signals expertise to the reviewing team.
- D. It is long and detailed, covering every part of the screen at once.

**Q2.** The AI says a button fails contrast. What should you do first?
- A. Measure the actual colour pair, because the claim may be a false positive.
- B. Delete the button and rebuild it with a darker background colour.
- C. Change the colour first, then confirm the new pair meets the requirement.
- D. Ask the AI to suggest a corrected colour and apply its recommendation.

**Q3.** What is a false negative in critique?
- A. A real problem the critique missed because its method could not detect it.
- B. A problem that does not exist, reported confidently by the reviewing tool.
- C. A problem rated with a low severity because it affects very few users.
- D. A finding about colour contrast rather than about interaction behaviour.

**Q4.** Why run separate passes for heuristics, accessibility and content?
- A. Because a shorter prompt makes the assistant respond faster to each request.
- B. Because the assistant cannot run multiple checks in one prompt and stops early.
- C. Because WCAG requires separate passes, so accessibility is never mixed with heuristics.
- D. Because each pass produces more specific findings and makes verification easier.

**Q5.** What does a red-team pass add?
- A. A colour palette that makes the screen feel urgent to first-time users.
- B. Adversarial perspectives from specific roles that expose exploitation and failure modes.
- C. A faster prototype, because the tool generates the corrected screens itself.
- D. A guarantee that no usability problems remain before the design ships.

**Q6.** Severity should be based on…
- A. How easy the fix is, so quick improvements can be cleared from the list.
- B. The AI's ranking, because it has compared many similar screens before.
- C. The designer's own preference, since they know which issues matter most.
- D. Harm and frequency, not fix effort, because critical issues come first.

**Q7.** The AI suggests masking the full account number on a confirmation screen. Why might you reject it?
- A. Because masking is always wrong on any screen that shows a payment amount.
- B. Because the task requires verifying the full number, so masking defeats the purpose.
- C. Because masking is too easy to implement and adds no real design value.
- D. Because the AI cannot actually read numbers, so its suggestion is unreliable.

**Q8.** What should a rejected-findings log contain?
- A. Only the word rejected, so the table stays short and easy to scan.
- B. The finding and the specific evidence that justified rejecting it.
- C. The AI's apology and a note that it will try harder next time.
- D. A new design that resolves the finding without discussing it.

**Q9.** An AI critique returns 20 findings, including 'the design feels cluttered'. Which revision makes the critique usable?
- A. Keep all twenty, because a long list demonstrates thoroughness to stakeholders.
- B. Rewrite each as a specific observation with evidence, severity and next action.
- C. Delete every negative finding so the critique feels constructive to the team.
- D. Ask the AI to make the wording friendlier without changing the findings.

**Q10.** A review based only on screenshots misses a keyboard trap in the prototype. What kind of critique failure is this?
- A. A false positive, because the reviewer invented an issue that is not there.
- B. A visual hierarchy error, because the trap disrupts the reading order.
- C. A false negative, because the method could not observe the real issue.
- D. A content tone problem, because the keyboard behaviour confuses the copy.

## 10. Practical task and pass criteria

**Task.** Submit the eight-part critique pack.

**Pass criteria — all must be met:**

- [ ] A brief with role, task, standards and output format.
- [ ] Four passes completed.
- [ ] Verification table with labels and evidence.
- [ ] At least two false positives rejected with evidence.
- [ ] At least one false negative found independently.
- [ ] Severity ratings tied to harm and frequency.
- [ ] Action list with owner, fix and verification.
- [ ] Revised screen with at least three fixes.
- [ ] No accepted finding without evidence.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| "Review my design" prompt | It is quick | Brief role, task, standards, format. |
| Accepting every finding | It sounds expert | Verify against the artifact. |
| Fixing cosmetics first | They are easy | Triage by severity, not effort. |
| No false-negative check | The list feels complete | Add keyboard, network, culture and content checks. |
| Vague fixes | "Improve hierarchy" | Name element, value and behaviour. |
| No rejected log | It feels negative | Record rejections with evidence. |
| Ignoring regressions | Focus on the fix | Re-check related states after changes. |

**Retry variant.** Critique a **competitor's public screen** instead of your own. Run the same four passes, verify findings, and write a 150-word note on which findings were context-dependent and could not be judged from a screenshot alone. Submit the pack and the note.

## 12. Proof artifact for your portfolio

**Artifact:** `AI-Critique-Pack` — stored in `03_Projects/<project>/ai-workflow/critique`.

The verification table is the evidence. It shows you can direct a critic and disagree with it.

## 13. Low-data and low-cost path

- Use a text description if image input is unavailable or limited.
- Run the passes in separate short sessions to conserve data.
- The video is optional and five minutes; the verification method above is the lesson.
- If AI is unavailable, run the same passes yourself and document the method.

## 14. Watch and read more

**Recommended video (optional, 4:50):** *How to Conduct a Heuristic Evaluation* — NNgroup. `https://www.youtube.com/watch?v=sqi0-Lz_ZTY`. Verified available on 2026-10-30. It covers human heuristic evaluation; the AI-specific prompting and verification rules are the course's own.

**Read (verified 2026-10-30):**

- Nielsen Norman Group, *10 Usability Heuristics* — `https://www.nngroup.com/articles/ten-usability-heuristics/`. The criteria for the first pass.
- W3C WAI, *How to Meet WCAG 2.2 Quick Reference* — `https://www.w3.org/WAI/WCAG22/quickref/`. Use it to verify accessibility findings.

## 15. What comes next

Stop 4.5 focuses on words: microcopy, error messages, empty states and tone. AI can draft copy quickly; only a human can decide whether it is honest, clear and locally credible.