# Stop 7.4 — Getting Paid

> **Phase 7 · Capstone and career launch** · Prerequisite: Stop 7.3 · Suggested session: 90–120 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Calculate a minimum sustainable rate from your costs, time and desired income.
2. Choose a pricing model that fits the scope and risk.
3. Write a one-page proposal with deliverables, exclusions, timeline, revisions and payment terms.
4. Apply for remote roles with a targeted pack rather than a mass email.
5. Approach a design challenge and interview without giving away free work.
6. Negotiate with a walk-away number and clear priorities.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Rate** | What you charge per hour, day or project. |
| **Billable hours** | Hours you can charge, excluding admin, sales, learning and idle time. |
| **Utilisation** | The share of working time that is billable. |
| **Project fee** | A fixed price for a defined scope. |
| **Retainer** | A recurring fee for ongoing availability or work. |
| **Value-based pricing** | Pricing based on the value delivered, not the hours spent. |
| **Scope** | What is included, and by implication what is not. |
| **Deliverable** | A specific output, such as a prototype or a handoff pack. |
| **Revision** | A round of changes within the agreed scope. |
| **Deposit** | An upfront payment that secures the work and covers initial effort. |
| **Milestone** | A payment tied to a stage of delivery. |
| **Statement of work (SOW)** | The document defining scope, schedule, fees and responsibilities. |
| **Net 30** | Payment due 30 days after invoice. |
| **Walk-away number** | The lowest offer you will accept. |
| **Spec work** | Unpaid design work produced to win a project. |
| **NDA** | A non-disclosure agreement. |
| **Tax** | Money owed to a government authority on income or sales; rules vary by country. |
| **Invoice** | A document requesting payment for delivered work. |

## 3. Why this matters

Many designers can make good work and cannot make a living from it. They underprice because they compare themselves to competitors instead of calculating costs. They accept vague scopes and then work for free to finish. They send the same CV to fifty companies and hear nothing.

Pricing and negotiation are learnable skills, not personality traits. The goal is not to charge the most. It is to charge enough to sustain the work, to scope clearly enough to deliver it, and to communicate value well enough that the right clients say yes.

> **Everyday example.** A tailor who quotes by guessing either overcharges and loses the customer, or undercharges and cannot afford thread. A tailor who knows the cost of fabric, the hours per garment, the rent and the profit needed can quote with confidence and negotiate on delivery date rather than price.

This stop is education, not legal, tax or financial advice. Contracts, tax registration and payment rules differ by country. Check local requirements or ask a qualified professional before signing or invoicing.

## 4. Before you start

- Gather your real monthly costs: rent, food, transport, internet, electricity, software, equipment, health, savings, dependants.
- Estimate your billable hours per week. A freelancer often bills 20–25 hours out of a 40-hour week; the rest is sales, admin and learning.
- Decide your target annual income, before tax.
- Create a spreadsheet with tabs: `Costs`, `Rate`, `Proposal`, `Pipeline`, `Negotiation`.
- Choose a payment method that works in your country and for international clients, and understand its fees.
- Do not put bank details, ID numbers or signed contracts in the course package.

## 5. Teaching, step by step

### Step 1 — Calculate a minimum rate from the bottom up

A simple formula:

```
Annual costs (business + personal) + tax reserve + profit/savings
÷ billable hours per year
= minimum hourly rate
```

Example, fictional and in naira:

- Annual personal and business costs: ₦6,000,000.
- Tax and pension reserve: ₦1,200,000.
- Savings and reinvestment: ₦1,800,000.
- Total needed: ₦9,000,000.
- Billable hours: 22 per week × 46 weeks = 1,012.
- Minimum rate: about ₦8,900 per hour.

If you charge ₦5,000 per hour, you cannot cover the plan, no matter how busy you feel. If you charge ₦15,000, you have room for non-billable time and risk.

This is a floor, not a market price. Market price depends on value, specialism, client budget and competition. But you cannot negotiate well without knowing your floor.

### Step 2 — Choose a pricing model

| Model | Best for | Risk |
|---|---|---|
| Hourly | Unclear scope, ongoing support | Punishes efficiency; client fears open bill |
| Fixed project | Clear, bounded deliverables | Scope creep; your estimate risk |
| Weekly/daily rate | Longer engagements | Requires clear availability |
| Retainer | Ongoing design support | Must define capacity and response time |
| Value-based | High-impact work with measurable value | Hard to price; requires trust and evidence |

For beginners, **fixed project with a deposit and defined revision rounds** is easiest to explain. For ongoing work, a **monthly retainer with a capacity cap** protects both sides.

Avoid pricing by "what the client can afford" alone. It leads to resentment and inconsistent income.

### Step 3 — Write a one-page proposal

Include:

1. **Understanding:** the problem in your words, showing you listened.
2. **Goal and success measure:** what will be different.
3. **Scope:** deliverables, number of screens, revision rounds.
4. **Exclusions:** what is not included, such as copywriting, development or user recruitment.
5. **Process and timeline:** stages, client responsibilities, review windows.
6. **Fee and payment schedule:** deposit, milestones, final payment.
7. **Assumptions:** content provided, feedback within X days, one point of contact.
8. **Next step:** how to approve and what happens then.

A proposal is not a price list. It is a shared plan that reduces ambiguity.

### Step 4 — Protect the scope without being difficult

Use clear language:

- "Two rounds of revisions are included. Additional rounds are billed at ₦X per round."
- "The fee covers five screens at the agreed complexity. New screens are quoted separately."
- "Feedback is consolidated by one contact within three working days."
- "Content, photography and user recruitment are provided by the client."
- "Work pauses if feedback is outstanding for more than ten working days; the timeline shifts accordingly."

These are not hostile. They prevent the situation where you work weekends to cover someone else's delay.

### Step 5 — Ask for a deposit and stage payments

A common structure:

- 40% deposit to start;
- 30% at approved wireframes or mid-point;
- 30% before final handoff or on delivery.

For small projects, 50/50 is simple. For larger ones, milestone payments reduce risk. Never deliver all final files before the final payment unless you have a strong reason and a contract.

Invoice clearly: your name, client, invoice number, date, description, amount, payment details, due date. Keep copies. Follow up politely and promptly when overdue.

### Step 6 — Apply for remote roles with a targeted pack

A strong application has:

- a one-page CV tailored to the role;
- a portfolio link with three relevant case studies;
- a short cover note that names the company, the role and one specific problem you can help with;
- one example of relevant work, not a generic PDF;
- a clear time zone and availability statement.

Research the company for 20 minutes. Mention something real: a product decision, a recent launch, a design problem. Generic applications are easy to ignore because they are easy to send.

Track applications in a pipeline: `Company | Role | Date | Contact | Stage | Next action | Outcome`. Review weekly. Rejection data tells you where the pack is weak.

### Step 7 — Handle design challenges without giving away free work

Employers may ask for a take-home challenge. Acceptable:

- a time-boxed exercise of 2–4 hours;
- a fictional brief;
- a walkthrough of your process on an existing project;
- a paid trial task.

Concerning:

- a real, unpaid brief that produces usable work;
- an unlimited task with no time box;
- a request for final files before any interview;
- a "test" that mirrors their roadmap.

Ask: "What is the time expectation?" "Will this be used commercially?" "Is there a fee?" It is reasonable to decline unpaid work that has direct commercial value. Offer a short walkthrough or a paid trial instead.

### Step 8 — Interview with evidence, not adjectives

Prepare stories using **situation, decision, result, lesson**:

- the problem and who it affected;
- the decision you made and why;
- what happened, with evidence;
- what you would do differently.

Expect questions on:

- a project that failed;
- a disagreement with a developer or PM;
- how you prioritise;
- how you handle feedback;
- how you measure success;
- how you work with AI and verify output.

Be honest about scope. "I designed the flow; a developer built it; I ran the tests" is stronger than claiming everything.

### Step 9 — Negotiate with priorities and a walk-away

Before the call, write:

- **Target:** the number you want.
- **Walk-away:** the lowest you will accept.
- **Priorities:** cash, timeline, learning, flexibility, equity, title.
- **Tradeables:** start date, scope, payment schedule, revision rounds, case study rights.

When an offer is low:

- "Thank you. The number is below my minimum for this scope. I can do [reduced scope] at that budget, or the full scope at [target]."
- "I can be flexible on the start date if the fee stays at [target]."
- "Can we tie a portion to the outcome we agreed?"

Do not negotiate against yourself. Do not accept a number that breaks your floor and hope it improves. Get the agreement in writing before starting.

### Step 10 — Manage money like a business

- Separate business and personal accounts if possible.
- Keep receipts and invoices.
- Set aside tax as you earn; do not spend it.
- Build a buffer of three to six months of costs.
- Price in the currency you will be paid and account for conversion fees.
- Review your rate every six months.

This is not glamorous, but it is what makes the work sustainable.

## 6. Worked example (I do)

A learner, Tobi, wants to go freelance. He calculates:

- annual costs: ₦7,200,000;
- tax reserve: ₦1,400,000;
- savings: ₦1,400,000;
- total: ₦10,000,000;
- billable hours: 20 × 45 = 900;
- minimum rate: about ₦11,100/hour.

He decides a landing-page project takes 30 hours, so the floor is about ₦333,000. He quotes ₦450,000 fixed, with 50% deposit, two revision rounds and a two-week timeline. He excludes copywriting and development.

A client asks for ₦250,000. Tobi does not accept. He offers a reduced scope: one page, one revision round, no custom illustration, for ₦300,000, or the full scope at ₦450,000. The client chooses the reduced scope. Tobi delivers on time, invoices the balance, and asks for a testimonial and permission to publish an anonymised case study.

**Why this works:** the price is grounded in costs, the scope is explicit, the negotiation offers options rather than a flat refusal, and the agreement protects both sides.

## 7. We do it together

Using your own numbers:

1. Calculate your annual costs, tax reserve and savings target.
2. Estimate billable hours per year.
3. Calculate your minimum hourly rate.
4. Price a 20-hour project at that floor, then add 30% for risk and profit.
5. Write three sentences you would say to a client who offers 40% less.

**Hint:** if the number feels uncomfortably high, check whether your costs are complete. Most beginners forget tax, equipment replacement, unpaid admin and sick days.

## 8. Your turn (You do)

Submit a pricing and application pack:

- a costs and rate calculator with assumptions;
- a one-page proposal for a fictional project, including scope, exclusions, timeline, revisions and payment schedule;
- a remote application pack: tailored CV summary, cover note and portfolio link;
- a design-challenge response policy: what you accept, what you decline and how you ask;
- a negotiation plan with target, walk-away, priorities and three tradeables;
- a 150-word reflection on what you learned about your minimum rate.

Use fictional clients and figures. Do not include real bank details, ID numbers or signed contracts.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** Why calculate a minimum rate from costs rather than copying competitors?
- A. Competitors are always wrong, because they price by guesswork and rarely track their own expenses.
- B. Your costs and required income are specific to you, so copying may leave the work unsustainable.
- C. It is required by law, and freelancers who cannot show a cost-based rate may face penalties.
- D. It makes you the cheapest, so you win more work and can raise prices once demand grows.

**Q2.** What is a deposit?
- A. An upfront payment that secures the work and covers the initial effort before any delivery is made.
- B. A discount offered at the start, so the client commits early and the total price falls.
- C. A tax collected on the project fee and passed to the government at the end of the year.
- D. A revision round included in the agreed scope, so changes are settled before the work begins.

**Q3.** Which belongs in a proposal's exclusions?
- A. The client's name and project title, so the document is clearly identified as belonging to them.
- B. Your portfolio link and two client references, so the client can check your previous work before approving.
- C. Work that is not included, such as copywriting, development and recruiting users for the tests.
- D. The weather and travel time, so the client understands the daily conditions the work depends on.

**Q4.** What is a reasonable response to unpaid spec work with commercial value?
- A. Do it for free to prove yourself, because a strong sample often turns into a paid contract later.
- B. Send the final files immediately, so the employer can assess the quality and make a decision quickly.
- C. Ask about time, use and fee, then offer a short walkthrough or a paid trial instead.
- D. Ignore every employer who asks, because any request for sample work is simply exploitative by nature.

**Q5.** What is a walk-away number?
- A. The first number you say in the call, which sets the anchor for the whole negotiation.
- B. The client's stated budget, which tells you the most they are willing to spend on the project.
- C. Your hourly rate, multiplied by the hours you expect the project to take from start to finish.
- D. The lowest offer you are willing to accept, written down before the negotiation begins in earnest.

**Q6.** Why tailor a remote application?
- A. To send more applications in less time, so you reach more companies before the roles close.
- B. To show specific relevance to the role and increase the chance of a reply from the team.
- C. To hide your portfolio, because a targeted cover note matters far more than the work itself does.
- D. Because templates are now banned by most employers, and a generic application is rejected automatically.

**Q7.** A client offers 40% below your floor for the full scope. What is the best response?
- A. Accept and hope, because the relationship may lead to better-paid work once the client trusts you.
- B. Ignore the client entirely, because an offer that low shows they will never respect your rate.
- C. Offer a reduced scope within that budget, or deliver the full scope at your stated rate.
- D. Double the price, so the client learns that the original quote was already a fair deal.

**Q8.** Why separate business and personal money?
- A. To look professional, because separate accounts signal to clients that you run a serious design practice.
- B. To track costs, tax and buffer accurately, so you can make sustainable decisions about the work.
- C. Because clients require it, and invoices sent from a personal account may not be accepted.
- D. To avoid invoices, because keeping one account makes it hard to prove what was actually earned.

**Q9.** A client asks for a full brand and app design as an unpaid 'test' before any contract. What is the most professional response?
- A. Do the full project for free to win the client, because the contract will follow if the work is good.
- B. Refuse to speak to the client again, because the request shows they do not value design work.
- C. Offer a small paid discovery task or a time-boxed sample, and keep the full work behind a contract.
- D. Send a generic price list with no scope, so the client can choose what fits their budget.

**Q10.** A freelancer starts work with no deposit and no milestones, then the client stops responding after the first draft. What was missing?
- A. A larger portfolio, because more visible work would have made the client value the project more.
- B. A brighter proposal template, because a clearer layout would have kept the client more engaged.
- C. More free revisions, because generous changes would have persuaded the client to stay more involved.
- D. A payment schedule tied to milestones and a deposit that commits both sides before work starts.

## 10. Practical task and pass criteria

**Task.** Submit the pricing calculator, proposal, application pack and negotiation plan.

**Pass criteria — all must be met:**

- [ ] Rate calculation includes costs, tax reserve, savings, billable hours and assumptions.
- [ ] Proposal has scope, exclusions, deliverables, timeline, revisions and payment schedule.
- [ ] At least one deposit or milestone structure is defined.
- [ ] Application pack is tailored to a named role and company.
- [ ] Design-challenge policy states what you accept, decline and ask.
- [ ] Negotiation plan includes target, walk-away, priorities and three tradeables.
- [ ] Payment and tax responsibilities are acknowledged as country-specific.
- [ ] No real bank details, ID numbers or signed contracts are included.
- [ ] No promise of employment or income is made.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Pricing by competitor guess | Fear of being expensive | Calculate your floor first. |
| Vague scope | Wanting to seem flexible | Write deliverables and exclusions. |
| Unlimited revisions | Avoiding conflict | Define rounds and extra-round pricing. |
| No deposit | Wanting the client | Ask for 40–50% to start. |
| Delivering finals before payment | Trust | Hold final files until the balance clears. |
| Mass-applying | Volume feels productive | Tailor fewer applications. |
| Free spec work | Hoping to win | Ask about use and fee; offer alternatives. |
| Accepting below floor | Fear | Use scope trade-offs and walk away. |

**Retry variant.** Recalculate your rate assuming **only 15 billable hours per week** and a three-month buffer. Then write a 100-word note on how the number changes and what you would do differently. The constraint exposes hidden costs and unrealistic assumptions.

## 12. Proof artifact for your portfolio

Keep the calculator, proposal template, negotiation plan and a redacted sample invoice. These are professional artifacts, not portfolio pieces. Do not publish client contracts or personal financial details.

## 13. Low-data and low-cost path

- Use a spreadsheet; no paid finance tool is required.
- Use free invoicing templates and a payment method available in your country.
- Research local tax rules through official government sites or a qualified adviser.
- Apply to a small number of well-matched roles rather than paying for mass application tools.
- Skip the video if data is tight; the steps are complete.

## 14. Watch and read more

**Recommended video:** *Freelance Pricing Secrets Every Designer Should Know* by Rachel How (2023, 10 min 9 s) — `https://www.youtube.com/watch?v=B7YjIGZiA-Q`. A practical discussion of pricing psychology and positioning. Metadata checked 2026-10-30; embedded playback was verified in Chrome on 2026-10-30. Verify any specific figures against your own market.

**Read:**

- Nielsen Norman Group, *Portfolios and hiring* — `https://www.nngroup.com/articles/ux-design-portfolios/`. What employers assess.
- Freelancers Union, *Calculating Rates: Hourly vs. Project-based* — `https://blog.freelancersunion.org/2015/10/26/calculating-rates-hourly-vs-project-based/`. A free walkthrough of the arithmetic behind a rate. Published in 2015; the method still applies, but every figure must be replaced with your own costs and market.
- Freelancers Union, *A step-by-step guide to project proposals* — `https://blog.freelancersunion.org/2014/05/14/guide-freelance-project-proposals/`. Scope, deliverables and payment terms in a proposal. Published in 2014; use it as a structure, not as legal advice or a current price list.
- Your local tax authority's official site. Rules on registration, invoicing and tax vary; use primary sources.

## 15. What comes next

**The Capstone** brings everything together: one complete product, from research to a tested, deployed v2, presented live to a reviewer panel. Read `03_Assessments/Learner/Capstone.md` and the reviewer guidance in `04_Instructor_Only/`. Bring your case study, live prototype, test evidence and decision log.