# Stop 1.2 — User Research Basics

> **Phase 1 · Product thinking and research** · Prerequisite: Stop 1.1 · Suggested session: two sittings of 45–60 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Choose between interviews, observation and surveys for a given question.
2. Write open, non-leading interview questions and a short discussion guide.
3. Obtain informed consent and anonymise notes.
4. Separate a participant's **words** from your **interpretation**.
5. Run two practice interviews and produce findings that are traceable to notes.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **User research** | Learning about the people who use or might use a product, to reduce guesswork. |
| **Qualitative research** | Rich, small-sample data about *why* and *how*: interviews, observation, diary studies. |
| **Quantitative research** | Numbers from larger samples: surveys, analytics, task success rates. |
| **Interview** | A guided conversation to understand a person's experience, behaviour and reasoning. |
| **Semi-structured interview** | An interview with a guide and key questions, but freedom to follow interesting answers. |
| **Discussion guide** | The list of questions and prompts you plan to use. |
| **Open question** | A question that invites a story, usually starting with how, what or tell me. |
| **Closed question** | A question answerable with yes/no or a single fact. Useful for facts, poor for stories. |
| **Leading question** | A question that pushes the participant toward an answer you want. |
| **Observation** | Watching what people actually do, often in their own environment, rather than asking. |
| **Survey** | A set of written questions sent to many people; good for prevalence, weak for why. |
| **Sample** | The people you include. A small qualitative sample is chosen for relevance, not representativeness. |
| **Consent** | A participant's informed, voluntary agreement to take part and to how their data is used. |
| **Anonymisation** | Removing names and identifying details so a participant cannot be recognised. |
| **Saturation** | The point where new interviews stop producing new themes. |
| **Bias** | A systematic error in your research, for example only asking friends who share your views. |
| **Affinity mapping** | Grouping individual observations into themes on notes or a board. |

## 3. Why this matters

Every product decision is a guess until it meets a real person. Research reduces the size and cost of the guess. It does not remove uncertainty; it replaces "I think" with "we saw, in these five conversations, that…".

Beginners usually make one of three mistakes:

1. **Asking for opinions about a solution** ("Would you use an app that…?"). People are kind and imaginatively optimistic; they will say yes.
2. **Asking leading questions** ("Don't you find the current process frustrating?"). You get the frustration you implied.
3. **Recording interpretations as facts** ("Users want a simpler app" when the participant actually said, "I gave up because the page kept reloading").

Good research is mostly about **behaviour that already happened**. Ask what the person did last time, not what they would do in an imaginary future.

> **Everyday example.** A food vendor wants to know why customers stop ordering. Asking "Would you order more if we had an app?" produces polite yeses. Asking "Tell me about the last time you ordered from us" produces the real story: the delivery fee was unclear, or the vendor stopped replying after 9 pm. The second answer is usable.

## 4. Before you start

- Choose a **practice topic** you can ask about safely: how someone pays for transport, buys data, orders food, sends money to family, or studies online. Avoid health, money amounts, immigration status or anything that could expose a participant.
- Recruit **two practice participants** from people you can talk to easily. They are practice, not a representative sample. Do not call them "users" in your portfolio as if they were representative.
- Decide how you will record: written notes only (lowest data, most ethical), audio with consent, or a video call recording with consent. Written notes are enough for this stop.
- Read the consent script in Step 4 aloud once before the interview.

> **Safety and ethics.** Do not interview anyone under 18 without guardian consent. Do not record without explicit permission. Do not publish names, faces, phone numbers, account details or employers. If a participant becomes uncomfortable, stop. Research is voluntary at every moment.

## 5. Teaching, step by step

### Step 1 — Choose the method that fits the question

| Question | Best first method | Why |
|---|---|---|
| "What actually happens when someone tries to pay?" | Observation or contextual interview | Behaviour is visible and full of workarounds. |
| "Why did this person abandon the form?" | Interview | You need the reasoning and the story. |
| "How many people abandon at step 2?" | Analytics or survey | You need prevalence, not a story. |
| "Which wording is clearer?" | Usability test or A/B test | You need behaviour under controlled conditions. |
| "What do people in this market believe about trust?" | Interviews plus observation | Beliefs are nuanced and context-dependent. |

A useful default for beginners: **interview first, then survey** to check whether the themes are widespread. The reverse order (survey first) tends to produce questions you later wish you had asked differently.

### Step 2 — Write questions that collect stories

Replace opinion questions with experience questions:

| Weak | Stronger |
|---|---|
| "Would you use a budgeting app?" | "Tell me about the last time you tried to track your spending." |
| "Do you find transfer fees confusing?" | "Walk me through the last transfer you made, including how you found out the fee." |
| "What features do you want?" | "What was the hardest part of the last time you did this?" |
| "Don't you hate long forms?" | "How did you feel when you saw the form? What did you do next?" |

Rules for questions:

1. Ask about **the last time**, not "usually" — memory of a specific event is more reliable.
2. Ask **how**, **what** and **tell me**; avoid **why** at the start, because it can feel like an accusation. "What made you decide…" is gentler.
3. **One question at a time.** Double-barrelled questions get one answer.
4. **Follow the emotion.** If the participant sighs or pauses, ask "What was going through your mind there?"
5. **Silence is a tool.** Count to five before rescuing them.

### Step 3 — Build a 20-minute discussion guide

A simple structure:

1. **Warm-up (2 min):** "Tell me a little about how you normally handle [topic]."
2. **Recent story (7 min):** "Walk me through the last time you did [specific task]."
3. **Friction (5 min):** "What was the hardest part? What did you do when that happened?"
4. **Workarounds (3 min):** "Did you use anything else to help? Show me if you can."
5. **Wrap (3 min):** "If you could change one thing about that experience, what would it be? Anything I should have asked?"

Have 8–10 questions ready but expect to use only 5–6. The guide is a safety net, not a script to read robotically.

### Step 4 — Get consent properly

Read this aloud and record the answer:

> "I'm practising user research for a design course. I'd like to ask about your experience with [topic]. It should take about 20 minutes. I'll take notes [and record audio if agreed]. I won't use your name or anything that identifies you in my work. You can skip any question or stop at any time, and you don't need to give a reason. Is it okay to continue? Do you agree to me taking notes? Do you agree to audio recording — yes or no?"

Record: date, method, consent to notes (yes/no), consent to recording (yes/no), and the participant's chosen pseudonym. Do **not** record their real name in the notes file. Keep the consent record separate from the anonymised notes.

### Step 5 — Run the interview without leading

During the interview:

- Ask the question, then **stop talking**.
- Reflect back: "So the page kept reloading, and you tried three times?"
- Ask for specifics: "What exactly did the screen say?"
- Do not defend the product, explain the design, or finish their sentences.
- Do not say "that's interesting" after every answer; it teaches them what you want to hear.
- If they ask "what do you think?", say "I'm curious what you think — there's no right answer."

### Step 6 — Write notes in two columns

Use a page split down the middle:

| What they said or did (evidence) | What I think it means (interpretation) |
|---|---|
| "I took a screenshot and sent it to my sister to check the name before I paid." | The confirmation screen does not give enough confidence on its own; a second person is used as a check. |
| "It said 'processing' for a long time, so I closed it and tried again." | Ambiguous waiting state leads to duplicate attempts. |

This is the most important habit in the stop. The left column is defensible. The right column is your thinking, and must be labelled as such. When you write a report, keep the distinction.

### Step 7 — Code and cluster without inventing

After two interviews:

1. Read both sets of notes.
2. Copy each **observation** onto a separate note (physical or digital).
3. Group similar observations. Name each group with a plain phrase: "cannot tell if payment worked", "asks someone else to check", "fears losing money".
4. Count how many participants showed each theme. With two participants, the number is 1 or 2, not a percentage.
5. Write findings in this form: "**2 of 2 participants** described checking the recipient name with another person before paying. *Evidence: P1 quote, P2 quote.*"
6. Add a separate "Interpretation" section for what you think it means, and a "What this does not tell us" section.

Never write "users want…" from two interviews. Write "in this small practice sample, both participants…". The honesty is part of the skill and will be assessed.

### Step 8 — Handle local context with care

If you are researching in Nigeria or elsewhere in Africa, useful context to explore **without assuming**:

- **Data cost:** do people avoid loading images, or switch apps to save data?
- **Connectivity:** what happens when the connection drops mid-transaction?
- **Trust:** how do people verify a recipient, a seller or a payment?
- **Informal commerce:** are orders placed by WhatsApp, DM, phone call or in person?
- **Shared devices:** does someone else use the same phone or account?
- **Language:** does the interface use English, Pidgin, Yoruba, Hausa, Igbo or a mix, and where does that cause confusion?

Ask about these as possibilities, not as facts about a group. A participant who has never had a connection drop is still valid data.

## 6. Worked example (I do)

**Topic:** how people send money to family.

**Guide (excerpt):**

1. "Tell me about the last time you sent money to a family member."
2. "How did you decide which app or method to use?"
3. "Walk me through what you did, step by step, starting from opening your phone."
4. "What did you check before you pressed send?"
5. "What happened after you sent it? How did you know it worked?"
6. "Was there any moment you felt unsure? What did you do?"
7. "If you could change one thing about that experience, what would it be?"

**Participant P1 (pseudonym) — excerpt from notes:**

- Left column: "I usually send to my mother. Last time I sent ₦15,000. I copied the account number from a WhatsApp message. Before I sent, I called her to confirm the name. The app showed the name but I still called."
- Left column: "After I pressed send, it said 'processing'. I waited. Then I checked my balance and her message. It took maybe two minutes."
- Right column: "The app's name check is not trusted alone; a phone call is the real verification step."
- Right column: "The waiting state creates uncertainty but the participant had a workaround: check balance and ask recipient."

**Finding written honestly:**

> **2 of 2 participants** used a second channel (phone call or message) to confirm the recipient before sending. **Evidence:** P1 called her mother; P2 sent a screenshot to her sister. **Interpretation:** the in-app name display is not sufficient as a confidence signal in this sample. **Not established:** whether this is caused by the name display, a past fraud experience, or general caution. **Next step:** ask about a past transfer that went wrong, and test a confirmation screen that shows the recipient's photo and bank name.

Notice what the finding does **not** say: it does not say "Nigerians don't trust banks" or "users want a photo". It reports behaviour, offers an interpretation, and names the limit.

## 7. We do it together

1. Pick your practice topic.
2. Write a seven-question guide using the structure in Step 3.
3. Highlight any question that is closed, leading or double-barrelled, and rewrite it.
4. Read the consent script aloud to a friend or into your phone's recorder. Fix anything you stumble over.
5. Run **Interview 1**. Take two-column notes.
6. Immediately afterwards, write three sentences: what surprised you, what you would ask differently, and what you are tempted to conclude but cannot.
7. Revise the guide based on that reflection. Remove one question that did not work and add one that follows a theme.
8. Run **Interview 2** with the revised guide.
9. Create the findings table with themes, counts (1 or 2), evidence and interpretation.
10. Write the "what this does not tell us" section.

## 8. Your turn (You do)

**Independent task.** Submit a **research pack** containing:

1. Your final discussion guide (7–10 questions).
2. Two anonymised interview notes in the two-column format.
3. The consent record for each participant (date, method, consent to notes, consent to recording, pseudonym) — no real names.
4. A findings table with 3–5 themes, each with a count (1 or 2), at least one direct quote per theme, and a separate interpretation column.
5. A "Limits" section of 100–150 words: who you did **not** speak to, what two interviews cannot establish, and what you would do next.
6. A short note on which question worked best and which failed, with the revision you made.

**Rules:**

- Do not fabricate a participant, quote or finding. If a planned interview does not happen, report the pack as incomplete rather than inventing data. Fabrication is a critical issue and forces rework.
- Do not include identifying details, even in the "anonymised" notes. Change names, employers, locations and amounts that could identify someone.
- Do not generalise from two people to a market.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** Which question is most likely to produce a useful story?
- A. Would you use a savings app if it reminded you to put money aside every Friday evening?
- B. Don't you find saving difficult, given how prices have risen in the market this year?
- C. Do you like saving money, or do you prefer to spend it on things you need immediately?
- D. Tell me about the last time you tried to save money and what made it hard or easy.

**Q2.** What makes a question leading?
- A. It has more than five words, so the participant must hold too much in mind before answering.
- B. It asks about the past, so the participant reports a memory rather than a current opinion.
- C. It suggests the answer the researcher wants, so the participant agrees to be helpful and quick.
- D. It is asked in an interview rather than a survey, so the researcher is present when answering.

**Q3.** Which method best answers "how many users abandon at step 2?"
- A. A heuristic evaluation, because an expert reviewer can count the steps where users get stuck.
- B. Two interviews, because two people can explain why they personally abandoned the form.
- C. A focus group, because discussion reveals how common the abandonment problem really is.
- D. Analytics or a survey, because prevalence needs numbers from a larger sample of users.

**Q4.** What must be recorded before an interview begins?
- A. The participant's full name and address, so the notes can be matched to the right person later.
- B. The final design of the feature, so the participant can react to the screen during the conversation.
- C. The competitor analysis for the product, so the interview can focus on where rivals do better.
- D. Informed consent, including written permission to take notes and to record the audio if needed.

**Q5.** In two-column notes, which belongs in the left column?
- A. Users want a simpler app, because several participants mentioned that the flow felt long.
- B. This proves the flow is broken, because nobody completed the transfer without asking for help.
- C. The design should use a spinner, because waiting without feedback caused most of the doubt.
- D. I closed it and tried again because it said 'processing' for a long time.

**Q6.** Two interviews both mention calling the recipient before sending money. What is the most honest finding?
- A. All Nigerian users distrust banks, as shown by both participants calling before they send.
- B. Users want a photo of the recipient, since both participants checked the name before paying.
- C. The app is unusable, because both participants needed another channel to feel confident.
- D. 2 of 2 participants in this practice sample used a second channel to confirm the recipient.

**Q7.** What is the main risk of asking "Would you use this feature?"
- A. It takes too long to answer, so the interview runs over and later questions get rushed.
- B. People tend to say yes to imagined future use, which is weak evidence of real behaviour.
- C. It requires a survey tool, so the interview cannot be run in person with written notes.
- D. It is illegal without written consent, so the researcher must get approval before asking it.

**Q8.** Why keep the consent record separate from the notes?
- A. Because the consent record may contain identifying details that must not travel with anonymised notes.
- B. To save space, because the notes file should stay short enough to read during the analysis.
- C. Because Figma requires it, since shared design files are not allowed to hold participant information.
- D. Because consent expires in 24 hours, so the record is useless once the interview is over.

**Q9.** A learner wants to understand why people abandon a money-transfer form. Which interview question is most useful?
- A. Tell me about the last time you started a transfer and did not finish it. What happened?
- B. Would you finish the form if it had fewer steps and a clearer summary before you confirm?
- C. Do you agree the form is too long, and that the summary arrives far too late in the flow?
- D. Why do users always abandon forms, and what should the team change to stop that happening?

**Q10.** A learner interviews two friends who say they would use a new feature, then reports 'users want this feature'. What is the main research error?
- A. The learner should have used a survey instead of interviews, so the sample could be larger.
- B. Two interviews are never useful, so the learner should have run at least ten before reporting.
- C. The learner did not record the friends' names, so the findings cannot be traced back later.
- D. Hypothetical enthusiasm from two people is being presented as evidence of a broader need.

## 10. Practical task and pass criteria

**Task.** Submit the six-part research pack from section 8.

**Pass criteria — all must be met:**

- [ ] Two real practice interviews, or an honest statement that one did not happen.
- [ ] A discussion guide with at least seven open, non-leading questions.
- [ ] Two-column notes for each interview.
- [ ] Consent recorded for each participant, with no real names in the notes.
- [ ] 3–5 themes, each with a count, a direct quote and a separate interpretation.
- [ ] A Limits section that names who was not included and what cannot be concluded.
- [ ] No fabricated participant, quote, number or finding.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Asking "would you use…" | It feels like the obvious question | Ask about the last real occasion. |
| Explaining the design mid-interview | Enthusiasm or defensiveness | Stay in question mode; save explanations for later. |
| Recording interpretations as findings | The insight feels obvious | Keep the two columns; label interpretation explicitly. |
| Generalising from two people | The pattern feels strong | State the sample size and the limits. |
| Publishing names or faces | Convenience | Anonymise at the point of writing, not later. |
| Asking five questions at once | Nervousness | One question, then silence. |
| Only interviewing people like you | Easy recruitment | Name the bias in the Limits section and plan the next sample. |

**Retry variant.** Run **one** new interview on a different topic with a participant who is **not** a close friend (a classmate, colleague or family member you do not usually discuss this with). Use a guide of five questions, all about a specific past event. Submit the two-column notes, the consent record, a three-theme findings table, and a 120-word note on how the stranger's answers differed from what you expected. If you cannot find a participant, do not invent one; instead submit a revised guide and a written plan for recruitment, and mark the task as not yet passed.

## 12. Proof artifact for your portfolio

**Artifact:** `Practice-Research-Pack` — stored in `03_Projects/00_Foundations/research`.

Do **not** present these two practice interviews as a representative study. In a portfolio, label them "practice interviews (n=2)" and keep the consent records private. The artifact proves method, not market truth.

## 13. Low-data and low-cost path

- Use written notes instead of audio or video. This is lower data and lower privacy risk.
- Conduct interviews in person or by voice note; no video call needed.
- If you cannot travel, use a phone call and take notes by hand.
- The video is optional. The guide, consent script and two-column method above are the lesson.
- If data is very low, do one interview per week and combine the pack later.

## 14. Watch and read more

**Recommended video (optional, 9:05):** *How To Conduct User Interviews Like A Pro (UX Design)* — CareerFoundry. `https://www.youtube.com/watch?v=5tVbFfGDQCk`. Verified available on 2026-10-30. Published in 2019; the method is stable, though some tool recommendations may be dated.

**Read (verified 2026-10-30):**

- Nielsen Norman Group, *User Interviews 101* — `https://www.nngroup.com/articles/user-interviews/`. The clearest short reference on interview structure and pitfalls.
- GOV.UK Service Manual, *User research* — `https://www.gov.uk/service-manual/user-research`. Useful on consent, sampling and ethical handling in public services.

## 15. What comes next

Stop 1.3 turns raw notes into a **problem brief**: a one-page statement of who has the problem, what they are trying to do, what success looks like, and what you are deliberately not solving.