# Stop 5.0 — Web Basics

> **Phase 5 · Design to build** · Prerequisite: Phase 4 gate · Suggested session: 60–80 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Say what HTML, CSS and JavaScript each do, using a plain-language analogy.
2. Describe the journey from a file on a computer to a page in a browser.
3. Open a ready-made page, change its text, its colours and its layout, and see the result.
4. Publish that page to a live URL with GitHub Pages.
5. Explain why a designer should understand the medium they design for, even if they never become a developer.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **HTML** | HyperText Markup Language. The structure and meaning of a page: headings, paragraphs, lists, buttons, images. |
| **Element** | One piece of HTML, such as a paragraph `<p>` or a heading `<h1>`. |
| **Tag** | The label in angle brackets that marks where an element starts and ends, such as `<p>` and `</p>`. |
| **Attribute** | Extra information inside a tag, such as `href` (link target) or `alt` (image description). |
| **CSS** | Cascading Style Sheets. The rules that control appearance: colour, type, spacing, layout. |
| **Rule** | A selector plus declarations, for example `h1 { color: navy; }`. |
| **Selector** | The part of a CSS rule that says which elements it applies to. |
| **Property / value** | The thing being styled and its setting: `color` is the property, `navy` is the value. |
| **JavaScript** | The programming language that adds behaviour: responding to clicks, validating a form, fetching data. |
| **DOM** | Document Object Model. The browser's live, editable version of the HTML tree. |
| **Server** | A computer that sends files to browsers when asked. |
| **Hosting** | A service that keeps your files on a server so other people can reach them. |
| **URL** | The address of a page, such as `https://example.github.io/my-page/`. |
| **Repository (repo)** | A project folder tracked by Git, usually stored on a service such as GitHub. |
| **Commit** | A saved snapshot of changes, with a message describing them. |
| **Deploy** | To publish the current version of your files so the public can load them. |
| **HTTPS** | The encrypted version of HTTP; browsers mark unencrypted pages as "not secure". |
| **Viewport** | The visible area of the page in the browser window or on a phone screen. |

## 3. Why this matters

Designers who do not understand the medium make requests that cannot be built, underestimate the cost of a "small" change, and hand over screens that fall apart on a real phone. Designers who understand it ask better questions, spot impossible states early, and can fix small things without waiting three days.

You are not being trained to become a front-end developer. You are being trained to **design for the thing that actually ships**. The gap between a beautiful Figma frame and a working page is where most beginner portfolios lose credibility.

> **Everyday example.** A tailor who has never touched cloth can draw a lovely dress, but cannot tell you that the fabric will not hold the shape, that the seams need extra allowance, or that the customer cannot raise her arms. Learning the cloth does not make you less of a designer. It makes your drawings wearable.

The same page, in the three languages:

- **HTML** says: this is a heading, this is a paragraph, this is a button, this image is a photo of a market stall.
- **CSS** says: the heading is dark green, the paragraph is 18 pixels, the button has rounded corners and enough space around it.
- **JavaScript** says: when the button is pressed, show the message "Saved" and disable the button for two seconds.

A useful analogy is a human body: HTML is the skeleton and organs, CSS is skin, clothing and posture, JavaScript is the nervous system that makes things happen. None of the three is "the real one". A page without HTML has nothing to show; without CSS it is readable but plain; without JavaScript it can still be read but cannot react.

## 4. Before you start

- Install a plain-text editor. **Do not use Microsoft Word** to write HTML; it inserts formatting that breaks the file. Notepad is enough; VS Code is easier because it colours the code.
- Create a folder called `my-first-page` somewhere you can find again, for example `Documents/design-course/my-first-page`.
- Download the starter page for this stop from the course files: `05_Platform_Ready/HTML/sample_lesson_page.html` is a full example you can copy, or use the minimal starter below.
- Create a free GitHub account if you do not have one. You will need it to publish.
- Check that you can see file extensions. On Windows, open File Explorer, View, and tick "File name extensions". On macOS, Finder, Settings, Advanced, "Show all filename extensions". Without this, `index.html` may secretly be `index.html.txt`.

Minimal starter file, `index.html`:

```html
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>My first page</title>
  <style>
    body { font-family: system-ui, sans-serif; margin: 0; background: #f7f5f0; color: #171717; }
    header { background: #0b5d3b; color: white; padding: 24px; }
    main { max-width: 640px; margin: 0 auto; padding: 24px; }
    .card { background: white; border: 1px solid #ddd; border-radius: 12px; padding: 20px; }
    button { font: inherit; padding: 12px 20px; border-radius: 8px; border: 0; background: #0b5d3b; color: white; }
  </style>
</head>
<body>
  <header>
    <h1>Adaeze's Market Stall</h1>
    <p>Fresh produce, fair prices, open 8am to 6pm.</p>
  </header>
  <main>
    <div class="card">
      <h2>This week</h2>
      <p>Tomatoes, peppers, okra and plantain. Delivery within 5 km.</p>
      <button type="button">Copy order number</button>
      <p id="copy-status" role="status" aria-live="polite"></p>
    </div>
  </main>
  <script>
    const button = document.querySelector('.card button');
    const status = document.getElementById('copy-status');
    button.addEventListener('click', async function () {
      const orderNumber = 'TSH-0000';
      try {
        if (!navigator.clipboard || !window.isSecureContext) {
          throw new Error('Clipboard API is not available in this context.');
        }
        await navigator.clipboard.writeText(orderNumber);
        status.textContent = 'Order number copied: ' + orderNumber;
      } catch (error) {
        status.textContent = 'Could not copy automatically. Your order number is ' + orderNumber + '. Select it and copy it manually.';
      }
    });
  </script>
</body>
</html>
```

The order number above is fictional. Replace it with another made-up reference. Never publish a real customer's order number, phone number or address without permission. The script only says "copied" after `navigator.clipboard.writeText()` succeeds. If the browser is not in a secure context (HTTPS or localhost), or the user denies clipboard permission, the `catch` block tells the user the number and asks them to copy it manually. That is honest feedback: the label never claims success before the operation actually succeeds.

## 5. Teaching, step by step

### Step 1 — See the structure before the style

Open the file in your browser by double-clicking it. You should see a green header, a heading, a paragraph, a white card and a button. Now open the same file in your editor. The text between `<body>` and `</body>` is the content a screen reader would read aloud, in order:

1. `h1` — the page's main heading.
2. `p` — a supporting sentence.
3. `h2` — a section heading.
4. `p` — body text.
5. `button` — an interactive control.

Headings are not "big bold text". They are the outline of the page. A screen-reader user can jump between headings the way you skim a document. If you use a heading because it looks nice, or skip from `h1` to `h4`, you break that outline. This is why "make it bigger" is a CSS job, not an HTML job.

**Check yourself:** in the starter, which element tells the browser the page language? Answer: `<html lang="en">`. That attribute helps screen readers pronounce words correctly and helps translation tools.

### Step 2 — Change text without breaking meaning

Change the stall name, the opening hours and the delivery sentence. Keep the tags intact. Save, then refresh the browser.

Rules that prevent quiet damage:

- All visible text goes between tags, never inside an attribute by accident.
- Every `<h1>` should describe the page; there should normally be one per page.
- Every image needs `alt` text that describes its purpose, or `alt=""` if it is purely decorative.
- Every button needs a label that says what it does. "Click here" is not a label; "Call to order" is.

**Try this:** change the button text to "Submit". Notice how much less clear it becomes. That is not a style problem. It is a meaning problem, and CSS cannot fix it.

### Step 3 — Change appearance with CSS

CSS lives in the `<style>` block for now. A rule has a selector and a set of declarations:

```css
h1 {
  font-size: 32px;
  letter-spacing: -0.5px;
}
```

Change `#0b5d3b` (a dark green) in `header` to a colour of your choice. Use a contrast checker afterwards. White text on a mid-green may pass, white on yellow will not. The WCAG 2.2 AA minimum is **4.5:1** for normal text and **3:1** for large text (24px regular or 18.66px bold and above). Your header text is large, so 3:1 is the floor, but aim higher.

Change the page background. Change the card border radius. Then change the `max-width` from `640px` to `900px` and refresh at full screen and at a narrow window. At 900px the line length becomes long and harder to read. That is a design decision you just made with one number.

### Step 4 — See how layout actually works

The `main` element has `max-width: 640px` and `margin: 0 auto`. That combination centres the content and stops it stretching on wide screens. The card has `padding: 20px`, which creates space *inside* the border. Margin creates space *outside*.

Try removing `margin: 0 auto`. The content jumps to the left. Try removing `padding` from the card. The text touches the border. These two properties are the source of most "why is this spacing wrong?" conversations in handoff. Knowing them makes your specs believable.

The header uses normal document flow: it is as tall as its content plus padding. Nothing is absolutely positioned. Most robust layouts are built this way, with flexbox or grid added when items need to sit side by side. You will meet both in Stop 5.4.

### Step 5 — Understand the journey to the browser

When you type a URL and press Enter:

1. **DNS lookup** turns the domain name into an IP address, like a phone book.
2. **Connection** is made, encrypted with HTTPS.
3. **Request** asks the server for a file, usually `index.html`.
4. **Response** returns HTML, then the browser requests CSS, images, fonts and scripts it finds.
5. **Parsing** builds the DOM; CSS is applied; JavaScript runs.
6. **Paint** draws pixels on the screen.

Two practical consequences:

- The first file is not the whole page. A page with ten images makes eleven or more requests. On a slow connection, that is why the text appears before the photos.
- If a script is slow or broken, the page can appear frozen even though the HTML arrived. This is why designers and developers argue about "just one more animation".

### Step 6 — Publish to a live URL

You will use **GitHub Pages** because it is free, stable and shows your work in public.

1. Sign in to GitHub and create a new **public** repository called `my-first-page`.
2. Choose "uploading an existing file" and upload `index.html`.
3. Commit the file with a message such as `Add first page`.
4. Open **Settings → Pages**.
5. Under "Build and deployment", choose **Deploy from a branch**, branch `main`, folder `/ (root)`, then Save.
6. Wait one to three minutes. The page will show a URL like `https://yourusername.github.io/my-first-page/`.
7. Open it on your phone as well as your computer.

If the URL returns 404, wait two more minutes and refresh. If it still fails, check that the file is named exactly `index.html`, in the root of the repository, and that Pages is enabled on the right branch.

**Alternative, no account:** Netlify Drop (`https://app.netlify.com/drop`) lets you drag a folder and get a temporary URL. It is fine for practice. GitHub Pages is better for a portfolio because the repository is visible and the URL is stable.

### Step 7 — Check the published page like a designer

Before you call it done:

- **Phone width:** does the text fit without horizontal scrolling? The viewport meta tag is what makes this work.
- **Keyboard:** press Tab. Can you reach the button? Is there a visible focus ring? If your CSS removed it, put it back.
- **Zoom:** press Ctrl/Cmd and `+` to 200%. Does content still fit and remain readable?
- **Contrast:** check the header text and the button with a contrast checker.
- **Slow connection:** open browser developer tools, Network tab, set throttling to "Slow 3G", reload. How long until the text is readable?
- **Link:** send the URL to one person and ask them to open it. A link that only works on your machine is not published.

## 6. Worked example (I do)

A learner, Tunde, wants a page for a fictional laundry service. He starts from the starter and makes four changes:

1. **Text:** "Adaeze's Market Stall" becomes "Tunde's Wash & Fold"; the supporting line becomes "Pickup and delivery in Yaba, Lagos. Fictional practice business."
2. **Colour:** the header green `#0b5d3b` becomes a deep blue `#123a63`. He checks white on blue: contrast is about 9:1, comfortably above 4.5:1.
3. **Layout:** `max-width` goes from `640px` to `720px`, and he adds `display: grid; gap: 16px;` to `main` so two cards could sit in a column with consistent spacing.
4. **Behaviour:** he changes the script so the button shows "Pickup requested — we will call you" and then reverts after three seconds, so the page can be used twice.

Then he publishes. His URL is live, and he writes a four-line note:

> Changed the business name and copy to a fictional laundry. Changed the header to blue for contrast 9:1. Widened content to 720px and added 16px grid gap. Changed button feedback so it resets. Published with GitHub Pages.

**Why this is a good worked example:** every change is small, explained, and checked. He did not redesign the page. He proved he can operate the medium. That is the outcome of this stop.

## 7. We do it together

Open your starter file and complete these steps with me. Do not skip the checks.

1. Change the `<title>` to your own name plus "practice page". Look at the browser tab. That is what bookmarks and search results show.
2. Change the `h1` to a fictional business or project name. Add the word "fictional" in the supporting paragraph so nobody mistakes it for a real client.
3. Change the header background and check contrast with a checker. Write the ratio in a comment: `/* header contrast: 8.9:1 */`.
4. Change `max-width` to `720px`. Resize the window slowly. At what width does the line become uncomfortable to read? Write that width down.
5. Add `padding: 16px` to `button` and `border-radius: 999px`. Compare before and after. Which feels more tappable? The WCAG 2.2 minimum target size is 24×24 CSS pixels; 44×44 is the safer, more common recommendation.
6. Add a second card by copying the `<div class="card">...</div>` block. Change its heading to "How it works" and list three steps using `<ol><li>...</li></ol>`. Check that the list reads correctly with a screen reader if you have one, or at least that the numbers appear.
7. Publish and open the URL on a phone. Fix anything that overflows.

**Hint if you get stuck:** if the second card sits beside the first instead of below it, you probably added `display: flex` somewhere. Remove it, or add `flex-direction: column`. If the page shows raw code, your file was saved as `.txt`; rename it to `.html`.

## 8. Your turn (You do)

Build a one-page profile for a **fictional** small business or a **fictional** version of yourself as a designer. It must:

- use the starter's structure but change all visible text;
- have at least one heading, one paragraph, one list, one image or icon, and one button;
- use a colour palette you chose, with a recorded contrast ratio for body text;
- include `alt` text on any image;
- work at 320px width without horizontal scrolling;
- be published to a live URL;
- include a short note (5–8 sentences) explaining what you changed and why, including one thing you tried that did not work and how you fixed it.

Do not use a real business's logo, photos or claims. If you use a photo, use one you took or a clearly licensed free image, and credit it.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** Which language is responsible for the structure and meaning of a page?
- A. CSS, because it sets colour, type and spacing for the headings and paragraphs on the page.
- B. JavaScript, because it runs first and builds the headings, paragraphs and buttons the visitor sees.
- C. HTML, because it marks each heading, paragraph, list and button with tags that carry meaning.
- D. SQL, because it stores the page's headings and paragraphs in a table the browser reads.

**Q2.** What does CSS primarily control?
- A. The server's location and the domain name that visitors type to reach the page.
- B. The appearance and layout: colour, type, spacing, and how boxes sit on the page.
- C. The database queries that fetch records before the page is assembled for the visitor.
- D. The encrypted connection and the address the browser resolves before downloading any files.

**Q3.** A page looks fine on a laptop but requires horizontal scrolling on a phone. Which is the most likely missing piece?
- A. A JavaScript framework that redraws the layout whenever the screen is resized or rotated.
- B. The viewport meta tag, plus layouts that use max-width instead of fixed pixel widths.
- C. More images and larger headings, so the page fills the narrow screen instead of looking empty.
- D. A larger base font size, so the text scales down automatically on smaller phone screens.

**Q4.** What is the difference between padding and margin?
- A. Nothing meaningful: both add space around a box, so the two words describe the same property.
- B. Margin is the space reserved for text only, while padding applies to images and buttons.
- C. Padding only works on images, while margin is the property used to space paragraphs and headings.
- D. Padding is the space inside the border, while margin is the space outside it, between boxes.

**Q5.** Why is "Click here" a weak button label?
- A. It is too short to fill the button, so it looks unbalanced beside longer text on the page.
- B. It never says what will happen, so screen-reader users hear an identical label on every link on the page.
- C. Buttons are limited to one word in HTML, so a label like 'Call to order' is invalid.
- D. The phrase is not valid HTML markup, so browsers ignore it and announce an empty button.

**Q6.** What does GitHub Pages do?
- A. It designs the page automatically from a short description, then keeps the layout updated as content changes.
- B. It replaces the stylesheet with a generated theme, so you no longer write colour or spacing rules.
- C. It hosts the static files in a public repository and serves them at a shareable public URL.
- D. It compresses images and strips unused CSS on every upload, so pages load faster automatically.

**Q7.** Why should you never commit an API key to a public repository?
- A. Because the key adds several kilobytes to the file, which slows every clone and download of the repository.
- B. Because anyone who opens the public repository can read the key and use it, spending your quota or exposing data.
- C. Because GitHub deletes accounts that contain secrets, and you lose every repository along with the page you published.
- D. Because keys only function inside private repositories, so a public one silently disables the integration you built.

**Q8.** A page's text is readable but the layout breaks at 200% zoom. What is the main problem?
- A. Content and containers are fixed in ways that cannot reflow, so they push past the viewport when text grows.
- B. The font is too small at the default size, so increasing zoom exposes how little text fits on screen.
- C. HTML is the wrong language for a zoomable page, so the browser cannot recalculate the layout correctly.
- D. The server is slow to respond, so the browser draws the layout before all the styles have arrived.

**Q9.** A learner's page overflows horizontally at 320 px, forcing users to scroll sideways. Which check should they make first?
- A. Check that the viewport meta tag is present and that no container has a fixed width wider than 320px.
- B. Add more images and cards to fill the empty space, which usually stops the page stretching sideways.
- C. Increase the body font size to 24px so the text wraps sooner and no longer pushes the layout wider.
- D. Remove the `lang` attribute from the html element, which lets the browser recalculate the page width.

**Q10.** A button says 'Copied' but the clipboard is empty, and the code changes the label before any copy operation finishes. What is the defect?
- A. The button uses the wrong font, so the browser cannot attach the clipboard permission prompt to that element.
- B. The interface claims success before the asynchronous copy has finished, and there is no error fallback.
- C. The page has too many headings, which interrupts the script that writes the order number to the clipboard.
- D. The copy should run on page load rather than on click, so the clipboard is already filled.

## 10. Practical task and pass criteria

**Task.** Publish your edited one-page profile and submit the URL, a screenshot, and your "what I changed and why" note.

**Pass criteria — all must be met:**

- [ ] The page loads from a public URL on a device other than the one you built it on.
- [ ] All visible text has been changed from the starter; nothing identifies a real person or business without permission.
- [ ] At least one heading, paragraph, list, image or icon, and button are present and meaningful.
- [ ] Body text contrast is at least 4.5:1 and is recorded.
- [ ] Images have appropriate `alt` text, or `alt=""` if decorative.
- [ ] The page works at 320px width without horizontal scrolling.
- [ ] The button has a visible focus state and a label that describes its action.
- [ ] The note explains at least one failed attempt and the fix.
- [ ] No passwords, keys, phone numbers or personal addresses are in the repository.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| File saved as `.txt` | Editor appends an extension | Rename to `index.html`; enable file extensions. |
| Page shows code instead of rendering | Opened the file in the editor, not the browser | Double-click the file, or drag it into a browser tab. |
| Styles not applying | Typo in selector or missing `;` | Check the selector matches the element; check the declaration ends with a semicolon. |
| Published URL shows 404 | Wrong branch, wrong folder, or Pages not finished | Confirm `index.html` is in the repo root and Pages is set to `main` / root; wait and refresh. |
| Text overflows on mobile | Fixed pixel widths | Use `max-width`, percentages, and let text wrap; add the viewport meta tag. |
| Low contrast | Colour chosen by eye | Check with a contrast tool; aim for 4.5:1. |
| Removed focus outline | It looked ugly | Never remove it without a visible replacement. |
| Real business details used | Convenience | Use a clearly labelled fictional business. |

**Retry variant.** If you do not pass, take a different starter page (a simple event invitation) and make the same four kinds of change — text, colour, layout, and one behaviour — then publish it to a **new** repository. Submit the new URL plus a two-column table listing each change and the check you ran on it. This proves the skill transferred, not just that you can repeat one file.

## 12. Proof artifact for your portfolio

Keep:

- the live URL;
- a full-page screenshot at desktop and at 375px mobile width;
- the short change note;
- the repository link.

Add these to a folder named `05_Web_Basics`. In your portfolio, this is evidence that you can operate the medium. It is not yet a case study; it is a foundation artifact.

## 13. Low-data and low-cost path

- GitHub Pages and Netlify Drop are free. You do not need a domain name.
- You can complete the whole stop offline except the final publish. Write the file, test it locally, then publish once.
- If data is expensive, turn off auto-play and image loading in your browser, and use text-only resources.
- If you cannot create a GitHub account, use Netlify Drop or ask your instructor for a course-hosted folder. The learning outcome is the same: a page you edited, live at a URL.
- Keep the page under 1 MB by avoiding large photos. A 200 KB image is plenty for practice.

## 14. Watch and read more

**Recommended video:** *HTML, CSS, JavaScript Explained [in 4 minutes for beginners]* by Danielle Thé (2016, 3 min 57 s) — `https://www.youtube.com/watch?v=gT0Lh1eYk78`. A fast, plain-language overview of the three languages. Watch it before Step 1, then return to this lesson for the hands-on work. Metadata was checked on 2026-10-30; embedded playback was verified in Chrome on 2026-10-30; if the player is blocked in your region or browser, use the direct link.

**Read:**

- MDN, *Your first website* — `https://developer.mozilla.org/en-US/docs/Learn_web_development/Getting_started/Your_first_website`. The most reliable beginner path, with runnable examples.
- MDN, *Structuring content with HTML* — `https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Structuring_content`. Elements and meaning.
- MDN, *CSS styling basics* — `https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Styling_basics`. Selectors, the box model, colour.
- GitHub Docs, *GitHub Pages* — `https://docs.github.com/en/pages`. Official hosting instructions.
- W3C WAI, *WCAG 2.2 Quick Reference* — `https://www.w3.org/WAI/WCAG22/quickref/`. Use it for contrast and target-size checks.

## 15. What comes next

You can now make and publish a page. Stop 5.1 is about handing a design to a developer so they can build the right page the first time: specs, states, naming, assets and edge cases. Bring one screen from your Phase 3 or Phase 4 work to that stop.