# Stop 0.2 — How This Course Works

> **Phase 0 · Getting started** · Prerequisite: Stop 0.1 · Suggested session: 40–55 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Explain the difference between a stop, a check, a task, a gate and a retry.
2. State the mastery rule: what must be true before the next stop unlocks.
3. Take notes that let you revise without rereading the whole lesson.
4. Ask for help in a way that gets a useful answer.
5. Build a weekly routine based on sessions, not deadlines.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Stop** | One lesson with its own outcome, teaching, check and task. There are 38 stops in this course. |
| **Comprehension check** | A short quiz at the end of a stop. It tests whether you understood the teaching. |
| **Task** | The practical work you submit. It is always different from the worked example. |
| **Rubric** | The written description of what a pass looks like, criterion by criterion. |
| **Gate** | A larger checkpoint at the end of a phase. It combines several stops and is reviewed by a person on at least a sample. |
| **Retry** | A second attempt with a *different* task or question set, after targeted feedback. |
| **Mastery** | You can do the thing now, at the required standard, without copying an example. |
| **Prerequisite** | A stop or skill you should complete before starting this one. |
| **Formative feedback** | Feedback meant to improve your work while you are still learning, not a final grade. |
| **Summative assessment** | A final judgement against criteria, such as a phase gate or the capstone. |
| **Portfolio artifact** | The file you keep as proof of the skill, usually after a pass. |
| **Academic honesty** | Doing and explaining your own work. Using AI is allowed where stated; pretending AI work is yours is not. |

## 3. Why this matters

Most online courses are measured in videos watched. You press play, you nod, you finish, and you cannot do anything. This course is measured in **demonstrated ability**. That is why every stop ends with a check and a task, and why a phase does not open until the previous gate is passed.

The design has three consequences you should expect:

1. **You will fail something.** That is normal, planned for, and not a punishment. The retry exists because the first attempt is where learning happens.
2. **Time is not the measure.** There is no deadline and no "week 1". You move when you can do the work. A learner with two hours a week and a learner with twenty hours a week both finish when they meet the same standard.
3. **AI can help you learn but cannot pass for you.** You will be asked to explain decisions in your own words. Copied output is usually obvious and always useless in an interview.

> **Everyday example.** Think of learning to drive. Watching ten hours of driving videos does not make you a driver. A examiner does not ask how many videos you watched; they watch you handle a junction. The quiz is the theory test; the task is the junction.

## 4. Before you start

- Finish Stop 0.1, or at least have your workspace folders open.
- Decide where your notes will live: a paper notebook, a notes app, or a markdown file in `01_Lessons`.
- Be honest about your week. Count the realistic hours, not the ideal ones.

## 5. Teaching, step by step

### Step 1 — See the shape of a stop

Every stop has the same anatomy:

1. **Outcome** — one sentence describing what you can do afterwards.
2. **New words** — plain-English definitions, so jargon never blocks you.
3. **Why it matters** — the real-world reason, with an example.
4. **Teaching in small steps** — the actual explanation, in order.
5. **Worked example (I do)** — an expert reasoning aloud.
6. **We do** — you follow along with support.
7. **You do** — an independent task.
8. **Comprehension check** - 10 questions, 80% to pass.
9. **Task and pass criteria** — what you submit and how it is judged.
10. **Common mistakes and a retry variant** — what usually goes wrong and a fresh attempt.
11. **Proof artifact** — what goes into your portfolio.
12. **Low-data path and resources** — how to continue without video or heavy downloads.

When you open a new stop, read the outcome first and the task second. Knowing what you must produce changes how you read the teaching.

### Step 2 — Understand the pass rule

A stop is passed only when **both** are true:

- your comprehension check score is at least 80% (8 of 10); and
- your task meets **all essential rubric criteria**.

A high quiz score cannot rescue a task that fabricates research, exposes a participant's identity, or ships an inaccessible design. Those are **critical issues**: they force a rework regardless of the average.

Phase gates add a human review. The reviewer samples stop work, checks the gate project against its rubric, and decides: pass, pass with notes, or rework. The capstone is reviewed by a person every time, ideally in a live session with questions.

### Step 3 — Know what happens when you fail

Failure triggers a loop, not a dead end:

1. You receive **pinpointed feedback**: which question or criterion, and why.
2. You are sent to the **specific lesson section or exercise** that teaches it — not the whole stop.
3. You receive a **fresh variant** of the task. The same task repeated measures memory of the answer, not ability.
4. You resubmit. There is no penalty and no limit on retries, but repeated failure on the same criterion triggers mentor contact.

Write this rule somewhere visible: **feedback → targeted re-study → new variant → resubmit.**

### Step 4 — Take notes that work

Use four fields for every stop. This is the minimum, not a style preference:

```
STOP: 2.4 Interaction and states
IN ONE SENTENCE: Every screen can be loading, empty, full, partial, error, offline or success, and each needs a designed version.
THE IDEA I ALMOST GOT WRONG: Disabled buttons are not the same as loading buttons.
MY EXAMPLE: A transfer screen that shows "sending" but leaves the button active, so users tap twice.
QUESTION I STILL HAVE: How long before a spinner should become a skeleton?
```

Why these fields? The sentence forces compression. The "almost got wrong" line catches illusions of understanding. Your own example transfers the idea to your context. The open question gives you something to ask.

Do not copy paragraphs from the lesson. Copying feels productive and leaves nothing behind.

### Step 5 — Ask for help well

A useless request: "I don't get Figma."

A useful request contains four things:

1. **What you were doing** — "I was adding auto layout to a card."
2. **What you expected** — "The card should grow with the text."
3. **What happened** — "The text overflows and the frame stays 320 px wide."
4. **What you tried** — "I set width to Fill, then Hug; both failed. Screenshot attached."

This works with a mentor, a community forum, or an AI assistant. It also often helps you solve the problem before you send it.

### Step 6 — Plan by sessions, not deadlines

Because the course is self-paced, a calendar with dates is a trap. Plan **sessions**:

- Choose a realistic session length: 30, 45 or 60 minutes. The lessons are written for roughly 20–30 minutes of reading plus practice, so one stop may take one or two sessions.
- Choose fixed-ish days and times, but treat them as appointments you can move, not deadlines that produce guilt.
- Keep one weekly **review session** of 20 minutes: reread your notes, check what is unsubmitted, and choose the next stop.
- Track **stops passed**, not hours watched.

A sample week for someone with a full-time job:

| Day | Time | Activity |
|---|---|---|
| Tuesday | 45 min | New stop: read and do the "we do" steps |
| Thursday | 45 min | Finish the task and submit |
| Saturday | 60 min | Retry or catch-up, plus 20-minute review |
| Sunday | 20 min | Rest and preview the next stop |

This is an example, not a requirement. The requirement is that the plan is written down and realistic.

### Step 7 — Use AI honestly

AI is allowed as a tutor, a drafting partner and a first-pass critic, with three rules:

1. **Declare it.** When AI contributed to a submitted artifact, say what it did in one line.
2. **Verify it.** Any fact, source, quote or number from AI must be checked against a primary source or real data.
3. **Explain it.** If you cannot explain a decision without the chat log, you do not own the work yet.

Never paste other people's personal data into an AI tool. Never ask AI to invent interviews, users, metrics or client work. Fabrication in a portfolio is a career risk, not a shortcut.

### Step 8 — Understand what the certificate does and does not prove

A certificate from this course says you completed assessed work against published criteria. It does **not** guarantee a job, a salary or a client. Employment depends on the market, your portfolio, your communication and factors outside any course. What you will own at the end is more useful than the certificate: a design system, a deployed prototype, a usability report, three case studies and a capstone reviewed by a human.

## 6. Worked example (I do)

**Situation:** Tunde works six days a week and has about three hours a week. He starts Phase 0 on a Monday and immediately falls behind an imaginary "one stop per day" schedule.

**His correction, reasoned aloud:**

1. He deletes the day-by-day schedule. It was copied from a bootcamp and does not match his life.
2. He books Tuesday and Thursday, 8:00–8:45 pm, and Saturday 9:00–10:00 am. He puts them in his phone calendar as recurring events.
3. He sets a minimum: **one session per week, no matter what.** A missed week is a missed week, not a failure of the course.
4. He uses the first ten minutes of each session to reread his last note's "question I still have". Often he can answer it now.
5. He tracks stops in a simple table: stop, date started, date passed, retry count.
6. When he fails a check, he does not restart the phase. He reads the feedback, opens the named section, and books the retry for the next session so the learning has time to settle.

**The reasoning:** the plan is designed around the constraint (time), not around an ideal learner. The tracking measures mastery, not effort.

## 7. We do it together

1. Open your notes app and create a page called `Course log`.
2. Create the tracking table: `Stop | Started | Check score | Task submitted | Passed | Retry count | Note link`.
3. Add Stop 0.1 and Stop 0.2 with their real dates.
4. Write the four-field note for Stop 0.1 now, from memory. If you cannot, skim the lesson and try again.
5. Open your calendar and book three sessions this week. Name them "TechSkillHub".
6. Write your minimum commitment in one sentence, for example: "I will do at least one 30-minute session every week, even in a bad week."
7. Write a help request template in your notes: what I was doing / expected / happened / tried.
8. Copy the pass rule into your notes: **80% + all essential criteria = pass; critical issues force rework.**

## 8. Your turn (You do)

**Independent task.** Write a one-page study plan with these sections:

- **My realistic week:** the days and times you can actually study, with the constraints named (work, school, caregiving, power cuts, data limits).
- **My minimum:** the smallest commitment that still counts as progress.
- **My session shape:** what you will do in the first 10 minutes, the middle 30, the last 10.
- **My note system:** where notes live and the four fields you will use.
- **My help route:** who or what you will ask, and the four-part request template.
- **My AI rule:** one sentence stating when you will and will not use AI.
- **My review ritual:** when you will look back at the week and choose the next stop.

Then write a full four-field note for **Stop 0.2** in your own words, including one question you still have.

**Do not** copy the sample week table. Your plan must survive your actual week, including a bad one.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** A learner scores 8/10 on the comprehension check but their task misses two essential rubric criteria. What happens?
- A. They pass, because the quiz score is above the required 80% threshold.
- B. They rework the task, because the stop is not passed until it is met.
- C. They pass with a warning that is recorded on their permanent course record.
- D. They skip to the phase gate and submit the missing criteria there instead.

**Q2.** What is the purpose of a retry variant?
- A. To repeat the identical task until every answer is memorised correctly.
- B. To lower the pass mark slightly so the learner can move on sooner.
- C. To test the same ability with a fresh task after receiving targeted feedback.
- D. To replace the phase gate with a shorter check that needs no reviewer.

**Q3.** Which is a critical issue that cannot be averaged away by high marks elsewhere?
- A. Fabricated interview quotes that are presented in a case study as real.
- B. A spelling mistake in the label of one secondary button.
- C. A brand colour that is slightly off the palette used elsewhere.
- D. A missing favicon on a prototype that is otherwise complete.

**Q4.** Which note field is designed to catch an illusion of understanding?
- A. The stop title, written at the top of the page before you begin reading.
- B. The date, recorded when you first open the lesson and when you finish.
- C. The idea I almost got wrong, written from memory after the lesson ends.
- D. The resource list, added at the end from the links in the lesson.

**Q5.** What makes a help request useful?
- A. Describing what you were doing, expected, observed and had already tried.
- B. Saying that it does not work and attaching a screenshot of the screen.
- C. Sending the whole project file with no message and letting them explore it.
- D. Asking directly for the final answer so you can compare it with your own.

**Q6.** Why does the course avoid a week-by-week deadline?
- A. Because progress is judged by mastery, and learners start with different time and constraints.
- B. Because learners cannot read calendars reliably and often miss the dates they set.
- C. Because the course has no phases, gates or fixed order of lessons at all.
- D. Because videos are optional and most learners choose to skip them entirely.

**Q7.** A learner uses AI to draft a case study and submits it without checking. Which rule did they break first?
- A. Use only paper notes, never a chat tool, when drafting a case study.
- B. Declare it, verify it, explain it, and above all verify every claim before submitting.
- C. Never use AI for writing, even when it is only a first draft.
- D. Submit only on Sundays, after the weekly review session has finished completely.

**Q8.** What does a course certificate honestly prove?
- A. That the learner will get a job offer soon after finishing the course.
- B. That the learner is better than designers who have no certificate.
- C. That the learner's portfolio is complete and ready for interviews.
- D. That the learner completed assessed work against the published criteria.

**Q9.** A learner scores 8/10 on a stop check but their practical submission is missing the required screenshot evidence. What should happen next?
- A. The learner passes because 8/10 meets the 80% threshold for the stop.
- B. The learner skips the stop and returns to the same work at the capstone.
- C. The instructor lowers the practical criteria for this learner and records the change.
- D. The learner supplies the missing evidence and the task is re-marked against the same criteria.

**Q10.** A learner fails a retry by submitting the same file with a new date. Which problem does this reveal?
- A. The learner has not watched enough of the optional videos for the stop.
- B. The instructor marked the first attempt more strictly than the rubric allows.
- C. The learner is repeating a memorised answer instead of transferring the skill to new work.
- D. The course needs a longer deadline so learners can revise before resubmitting.

## 10. Practical task and pass criteria

**Task.** Submit your one-page study plan, your tracking table with Stops 0.1 and 0.2 entered, and a full four-field note for Stop 0.2.

**Pass criteria — all must be met:**

- [ ] The plan names real days/times and at least one real constraint.
- [ ] A minimum commitment is stated in one sentence.
- [ ] The note contains all four fields and the "almost got wrong" field is specific, not "nothing".
- [ ] The pass rule is stated correctly: 80% plus all essential criteria.
- [ ] The help request template contains the four parts.
- [ ] The AI rule says when AI will and will not be used.
- [ ] The tracking table includes a retry count column.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Planning an ideal week | Optimism, or copying a bootcamp schedule | Plan for the week you actually have; name the constraint. |
| Copying lesson paragraphs into notes | It feels like learning | Use the four fields; write from memory, then check. |
| Restarting the whole phase after a fail | Shame or confusion | Read the pinpointed feedback and redo only the named section. |
| Treating the quiz as the whole assessment | It is easy to measure | The task is where ability shows; both are required. |
| Asking AI for answers instead of explanations | Faster | Ask "explain why", then verify; you must be able to restate it. |
| Skipping the review session | No visible deadline | Book 20 minutes weekly; choose the next stop there. |

**Retry variant.** Rewrite your study plan for a week that goes badly: two missed sessions, one power cut, and half your usual data. It must still contain a minimum commitment and a recovery rule ("if I miss Tuesday, I do X"). Add a note explaining which part of the original plan was unrealistic and why. Submit the revised plan plus a new four-field note for Stop 0.1 written from memory.

## 12. Proof artifact for your portfolio

**Artifact:** `Study-System` — your study plan, tracking table and one sample note, exported as a PDF into `03_Projects/00_Foundations`.

At the end of the course, this becomes evidence for Stop 7.3's "how I work" section. It shows planning and reflection, which are employable behaviours.

## 13. Low-data and low-cost path

- This stop needs no video. The recommended video is context, not content.
- If you have no calendar app, write the sessions on paper and photograph it.
- If your notes are on paper, photograph the four-field note and keep the photo in `01_Lessons`.
- If data is very low, do the reading in two sittings and skip the video entirely.

## 14. Watch and read more

**Recommended video (optional, 9:22):** *How to teach yourself UX Design (no bootcamps, no courses)* — Andres The Designer. `https://www.youtube.com/watch?v=hvBGy8ewZNc`. Verified available on 2026-10-30. It is opinion and advice from a practitioner, not evidence about hiring outcomes; treat the claims as one person's experience.

**Read (verified 2026-10-30):**

- Cornell University Learning Strategies Center, *Effective Study Strategies* — `https://lsc.cornell.edu/how-to-study/studying-for-and-taking-exams/effective-study-strategies/`. Short, free, beginner-level advice on retrieval practice, spacing and interleaving. Use it to choose one study habit for this course; it is not a productivity guarantee.

## 15. What comes next

Stop 0.3 teaches you to *see* an interface: the names for the parts you already use every day. It is the vocabulary stop, and it makes every later lesson easier to read.