# Stop 4.6 — Verification and Judgment

> **Phase 4 · The AI design workflow** · Prerequisite: Stop 4.5 · Suggested session: 80–100 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Name the five common AI design failures and recognise them in a screen.
2. Check an AI research summary against raw notes.
3. Explain, in plain words, why a generated design would confuse a real user.
4. Fix the failure and justify the fix.
5. Write a review that separates evidence from opinion.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Verification** | Checking a claim against evidence before relying on it. |
| **Judgment** | The human decision about what is true, useful and appropriate. |
| **Plausibility** | How believable something looks, which is not the same as being correct. |
| **Fabrication** | An invented fact, quote, source or result. |
| **Generic visual style** | A default look produced by a model, often unrelated to the product's context. |
| **Accessibility violation** | A design that excludes people with disabilities. |
| **Inconsistency** | Similar elements behaving or looking differently without reason. |
| **Broken flow** | A sequence that looks right but fails the real task. |
| **Severity** | The harm and frequency of a problem. |
| **Evidence trail** | The record linking a claim to its source. |
| **Review checklist** | A repeatable list of checks applied to every output. |
| **Override** | A human decision to reject or change AI output. |
| **Regression** | A new problem introduced by a fix. |
| **Uncanny specificity** | Invented details that sound precise, such as a fake statistic. |

## 3. Why this matters

This is the stop that separates a designer who uses AI from one who is replaced by it. Anyone can generate a screen. The valuable skill is knowing whether it is right, why, and what to change.

The five failure types are not hypothetical. They appear in real generated work:

1. **Invented facts** — fake statistics, quotes, sources, user counts.
2. **Generic visual style** — the same centred hero, gradient and rounded cards regardless of context.
3. **Accessibility violations** — low contrast, tiny targets, missing labels, colour-only meaning.
4. **Inconsistent components** — five button styles, three corner radii, mismatched spacing.
5. **Flows that look right but break real tasks** — a success screen with no failure path, a retry that duplicates a payment, a confirmation that hides the fee.

> **Everyday example.** A forged document can look more official than a real one: crisp letterhead, precise numbers, a signature. Plausibility is a design property, not a truth property. Your job is to check the registry, not admire the paper.

## 4. Before you start

- Use three screens you generated in Stop 4.3, or create three practice screens with deliberate flaws. If you use someone else's output, label it.
- Have your checklist from Stop 4.4 and the WCAG quick reference open.
- Do not use real user data in the screens.

## 5. Teaching, step by step

### Step 1 — Failure type 1: invented facts

Look for:

- statistics without a source ("87% of users…");
- quotes attributed to users;
- "trusted by" claims;
- citations that do not resolve;
- precise numbers that appear from nowhere.

Check: search the exact phrase, open the source, ask for the raw data. If it cannot be traced, remove it or label it as fictional practice content. Never ship an invented statistic, even in a portfolio mockup, without a visible "fictional data" label.

### Step 2 — Failure type 2: generic visual style

Symptoms:

- centred hero with a gradient;
- identical card grids for unrelated content;
- stock imagery of smiling people;
- decorative icons that carry no meaning;
- a style that would suit any product in any industry.

The problem is not that it is ugly; it is that it communicates nothing about the specific user, task and context. A payment confirmation for low-bandwidth users should look different from a fashion landing page.

Fix: remove decoration, apply your tokens, make the key fact dominant, and use content from the real task.

### Step 3 — Failure type 3: accessibility violations

Check:

- contrast on every text pair, especially secondary text;
- target sizes;
- persistent labels;
- focus states;
- colour-only meaning;
- text at 200%;
- alt text and accessible names;
- heading order.

Generated screens frequently use light grey text, 12 px labels and icon-only buttons. These are not minor; they exclude people.

### Step 4 — Failure type 4: inconsistent components

Compare:

- button heights, radii and padding;
- input heights and border colours;
- spacing between sections;
- icon sizes and stroke weights;
- type sizes and line heights;
- terminology ("Send" vs "Transfer" vs "Pay").

Fix by mapping every element to a component or token. If a value is not in the system, either add it deliberately or change the element.

### Step 5 — Failure type 5: flows that break real tasks

Look for:

- no failure state;
- no way back;
- a retry that can duplicate an action;
- a confirmation that hides a fee or consequence;
- a success state with no reference or next step;
- a flow that assumes a capability the product lacks;
- a step that requires information the user does not have.

Walk the flow as a real user with a real constraint: no data, a failed bank lookup, a double tap, a shared phone, a 2G connection.

### Step 6 — Build your review checklist

A good checklist is short enough to use and specific enough to catch real problems. Ten items:

1. Every factual claim is sourced or labelled fictional.
2. The screen's key fact is the most prominent element.
3. All text passes 4.5:1 (or 3:1 large).
4. Interactive targets are at least 44 px.
5. Labels are persistent; errors are specific.
6. Focus is visible; keyboard order is logical.
7. States cover loading, empty, error, success, offline.
8. Components match the system (radius, spacing, type).
9. The flow can be completed without help.
10. No invented feature or capability.

Add a "stop" rule: if any of items 1, 3, 6 or 7 fails critically, the screen cannot be accepted regardless of how good it looks.

### Step 7 — Write the review with evidence

Use a table:

| # | Failure type | Element | Evidence | Severity | Fix | Verified? |
|---|---|---|---|---|---|---|
| 1 | Invented fact | Hero subtitle | "87% of users" with no source | Critical | Remove or cite real data | Yes |
| 2 | Accessibility | Helper text | #9CA3AF on white, 2.6:1 | High | Darken to #4B5563 | Yes |
| 3 | Broken flow | Success | No reference number | Medium | Add reference and next step | Yes |

Every row needs evidence you can point to. "Looks bad" is not evidence.

### Step 8 — Fix and justify

For each fix, write one sentence:

> "I moved the warning above the button because the action is irreversible and the user should read the consequence before acting, not after."

This is the rationale. It names the change, the user effect and the reason. A list of fixes without rationale is craft without judgment.

### Step 9 — Check for regressions

After fixing:

- re-check contrast on changed elements;
- re-test the flow end to end;
- check that the fix did not break a state;
- confirm the fix did not introduce a new inconsistency.

A fix that creates a new problem is not a fix.

## 6. Worked example (I do)

**Screen 1 (generated):** a "smart savings" dashboard.

**Findings:**

- "Join 2 million savers" — invented social proof. No source. **Critical.**
- Secondary text `#A1A1AA` on white at 12 px — 2.3:1. **High.**
- A "Withdraw all" button next to "Withdraw" with the same weight. **High.**
- Three different card radii (8, 12, 16). **Medium.**
- An empty state that says "No data" with no action. **Medium.**
- A chart with red/green only and no labels. **High.**

**Fix:** remove the claim, darken secondary text, separate the destructive action, standardise radius to 12, rewrite the empty state, add labels and patterns to the chart.

**Screen 2 (generated):** a checkout flow.

**Finding:** the success screen says "Payment successful" but the flow has no failure state, and the "Try again" button appears on a timeout screen where the payment may have succeeded. **Critical.** The fix is a status-check state, not a retry.

**Screen 3 (generated):** a booking screen.

**Finding:** the date picker uses placeholder-only labels and a 20 px tap target. **High.** The fix is persistent labels and a 44 px target.

**The judgment call:** Screen 1 is visually the most impressive and has the most integrity problems. Screen 3 is the least impressive and the easiest to fix. I would ship Screen 3 first, because its problems are contained and its flow is sound. Visual impressiveness is not the ranking criterion.

## 7. We do it together

1. Choose three generated screens.
2. Run the ten-item checklist on each.
3. Label every finding by failure type.
4. Verify each finding against the screen or a standard.
5. Rate severity.
6. Fix two screens.
7. Write a rationale for every fix.
8. Re-check for regressions.
9. Write a 150-word verdict on which screen you would trust least and why.
10. Add one new item to your checklist based on something you missed.

## 8. Your turn (You do)

**Independent task.** Produce a **verification review** of three AI-generated screens.

Submit:

1. The three screens with annotations.
2. A findings table with failure type, element, evidence, severity and fix.
3. At least one example of each of the five failure types, or a note that a type was absent and how you checked.
4. Corrected versions of two screens.
5. A rationale for every fix, one sentence each.
6. A regression check.
7. Your personal ten-item checklist with a "stop" rule.
8. A 150-word verdict on which screen you would trust least.

**Rules:** do not invent findings; do not accept a screen because it looks good; do not fix only cosmetics. If a failure type is genuinely absent, say so and show how you checked.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** Which is the best definition of plausibility?
- A. How accessible a design is for users with low vision or motor limits.
- B. How fast a screen loads on a slow connection with limited data.
- C. How consistent a component is with the rest of the design system.
- D. How believable something looks, which is not proof that it is correct.

**Q2.** A generated screen says "87% of users prefer this". What is the first check?
- A. Whether the number looks realistic for a product of this size.
- B. Whether the font is large enough for the figure to be read.
- C. Whether the claim has a traceable source in real data.
- D. Whether the colour of the figure is on-brand and consistent.

**Q3.** Which is an accessibility failure commonly found in generated UI?
- A. A 48 px button that exceeds the minimum target size for touch.
- B. A visible focus ring that appears when the user tabs to a control.
- C. A persistent label that stays above the field while the user types.
- D. Light grey 12 px text that measures only 2.6:1 against white.

**Q4.** Why is a "Try again" button dangerous on an unknown payment outcome?
- A. It may duplicate a transfer that has already succeeded at the bank.
- B. It is too small for a primary action and hard to tap accurately.
- C. It is not accessible to screen reader users in its current state.
- D. It is not part of the design system, so it will look inconsistent.

**Q5.** What makes a review finding defensible?
- A. It names the element, the evidence and the standard or user effect.
- B. It is written confidently, in language that sounds expert to stakeholders.
- C. It uses technical terms that show familiarity with accessibility standards.
- D. It comes from an AI critic that has reviewed many similar screens.

**Q6.** What is a regression check?
- A. Re-running the original AI prompt to see whether the output stays stable.
- B. Checking the file size and export settings before the handover meeting.
- C. Confirming that a fix did not introduce a new problem elsewhere.
- D. Comparing two AI models to see which one produces fewer defects.

**Q7.** A screen is visually impressive but has invented social proof and no error state. What should you do?
- A. Reject it until the integrity and flow failures are fixed, whatever it looks like.
- B. Add more decoration so the screen feels more finished before release.
- C. Ask the AI to make the layout prettier and keep the current content.
- D. Ship it, because visual quality is what users judge in the first seconds.

**Q8.** What should a fix rationale contain?
- A. The change, the user effect and the reason for making it.
- B. The tool used and its version, so the output can be reproduced.
- C. The file name and folder, so reviewers can find the corrected screen.
- D. The colour code only, since the change is visible in the file.

**Q9.** A generated screen has an invented testimonial, no error state and a low-contrast button. Which issue must be fixed before any aesthetic discussion?
- A. The button colour, because visual polish shapes the first impression.
- B. The spacing between sections, which makes the page feel unfinished.
- C. The choice of font, which affects how trustworthy the content appears.
- D. The invented testimonial, because fabricated evidence is a critical integrity failure.

**Q10.** A learner fixes a button label but does not re-check the loading state, which now overlaps the new text. What check was missed?
- A. A competitor review, comparing the screen with two rival products.
- B. A brand colour audit, checking the palette against the guidelines.
- C. A user interview, asking people what they think of the new label.
- D. A regression check across the states and sizes the change affected.

## 10. Practical task and pass criteria

**Task.** Submit the eight-part verification review.

**Pass criteria — all must be met:**

- [ ] Three screens reviewed with annotations.
- [ ] Findings table with type, element, evidence, severity and fix.
- [ ] All five failure types addressed or explicitly checked.
- [ ] Two corrected screens.
- [ ] A rationale for every fix.
- [ ] A regression check.
- [ ] A personal checklist with a stop rule.
- [ ] No invented finding, and no unsourced claim left in a corrected screen.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Judging by visual polish | Polish is persuasive | Check facts, accessibility and flow first. |
| Accepting an unsourced stat | It looks precise | Trace or remove it. |
| Fixing colours only | Visual fixes are easy | Address flow and integrity failures too. |
| No severity | Everything feels equally bad | Rate by harm and frequency. |
| Rationale missing | The fix feels obvious | Write change + effect + reason. |
| Skipping regression | Focus on the fix | Re-test related states. |
| Checklist too long to use | Completeness | Keep ten items; make stop rules explicit. |

**Retry variant.** Review **three screens generated by a different tool or person**, and include one screen that is mostly correct. Your job is to avoid inventing problems in the good screen while still catching real ones. Submit the review and a 150-word note on how you calibrated.

## 12. Proof artifact for your portfolio

**Artifact:** `Verification-Review-v1` — stored in `03_Projects/<project>/ai-workflow/verification`.

This is the single most important AI-workflow artifact. It shows you can be trusted with generated work.

## 13. Low-data and low-cost path

- Use screenshots and text; no tool subscription.
- If you have no generated screens, create three practice screens with deliberate flaws and label them.
- The video is optional and 16 minutes; the five failure types and checklist above are the lesson.
- Work offline; verification needs only the screen and the standard.

## 14. Watch and read more

**Recommended video (optional, 16:16):** *How to Fact-Check AI: Verify Claims, Citations, and Sources* — Prof. Ghassemi. `https://www.youtube.com/watch?v=cUUei_rH5Os`. Verified available on 2026-10-30. It focuses on text claims; the design-specific failure types here are the course's own.

**Read (verified 2026-10-30):**

- W3C, *WCAG 2.2* — `https://www.w3.org/TR/WCAG22/`. For accessibility verification.
- NIST, *AI Risk Management Framework* — `https://www.nist.gov/itl/ai-risk-management-framework`. For a structured view of AI risk, including validity and reliability.
- Nielsen Norman Group, *10 Usability Heuristics* — `https://www.nngroup.com/articles/ten-usability-heuristics/`. For flow and consistency checks.

## 15. What comes next

Stop 4.7 turns these habits into a repeatable personal workflow: a prompt library, a decision log, and a rule for when **not** to use AI.