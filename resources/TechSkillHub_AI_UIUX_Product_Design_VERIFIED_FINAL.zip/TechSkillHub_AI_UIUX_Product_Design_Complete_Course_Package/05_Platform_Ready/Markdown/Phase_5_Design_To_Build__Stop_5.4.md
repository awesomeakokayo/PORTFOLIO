# Stop 5.4 — Responsive, Mobile-First and Low-Bandwidth Design

> **Phase 5 · Design to build** · Prerequisite: Stop 5.2 · Suggested session: 90–120 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Design and build mobile-first, then enhance for larger screens.
2. Use fluid layout, sensible breakpoints and relative units instead of fixed widths.
3. Reduce page weight with compressed images, correct formats and lazy loading.
4. Set and measure a simple performance budget.
5. Design honest loading, offline, slow and error states.
6. Test on a throttled connection and a small screen, and explain the results.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Responsive design** | Layouts that adapt to screen size, orientation and input method. |
| **Mobile-first** | Start with the smallest screen and add complexity as space allows. |
| **Breakpoint** | A width at which the layout changes, chosen because the content needs it. |
| **Fluid layout** | Layout that stretches and shrinks using percentages, `fr` units or `clamp()`. |
| **Viewport** | The visible page area; controlled on mobile by the viewport meta tag. |
| **Reflow** | Content rearranging into one column without horizontal scrolling. |
| **Media query** | CSS that applies when a condition is true, such as `min-width: 48rem`. |
| **Container query** | CSS that responds to a component's container size rather than the viewport. |
| **`srcset` / `sizes`** | HTML attributes that let the browser choose an appropriately sized image. |
| **Lazy loading** | Deferring off-screen images or iframes until needed. |
| **Core Web Vitals** | Google's user-experience metrics: LCP, INP and CLS. |
| **LCP** | Largest Contentful Paint: when the main content appears. Target 2.5 s or less. |
| **INP** | Interaction to Next Paint: responsiveness to input. Target 200 ms or less. |
| **CLS** | Cumulative Layout Shift: unexpected movement. Target 0.1 or less. |
| **Performance budget** | A limit on page weight, requests or load time that the team agrees to. |
| **Progressive enhancement** | A working baseline that improves when more capability is available. |
| **Offline state** | What the user sees when the network is unavailable. |
| **Cache** | A local store of files so repeat visits need less data. |

## 3. Why this matters

Most of your users will not be on a fast fibre connection with a large screen. They will be on a mid-range Android phone, on a mobile network, possibly with data they paid for, possibly with intermittent power. A page that takes eight seconds and 4 MB is not "a bit slow". It is expensive and sometimes impossible.

Designing for this context is not a downgrade. It forces clarity: fewer decorative images, clearer hierarchy, honest loading states, and content that works before the JavaScript arrives. The result is better for everyone.

> **Everyday example.** A market trader selling from a phone does not need a 12 MB video banner. They need the price, the item, the location and a way to call, readable in three seconds on a cracked screen with one bar of signal. Design for that person and the desktop user is still served well.

Nigerian and wider African context: data costs vary, connections can drop, and many users share devices. Do not assume unlimited data, constant connectivity, or that a page can phone home to five third-party scripts. Design the low-data path as a first-class path, not an afterthought.

## 4. Before you start

- Use the page from Stop 5.2 or 5.3. It should have at least one image, one card and one interactive element.
- Open browser developer tools. Learn three panels: **Device toolbar** (responsive mode), **Network** (throttling), **Lighthouse** (performance report).
- Have an image compressor ready. Squoosh (`https://squoosh.app/`) runs in the browser and is free.
- Decide a budget: for this exercise, target **under 500 KB total** and **LCP under 2.5 s on Slow 4G**. Write it down before you optimise.
- Test with fictional content; do not add analytics or tracking scripts.

## 5. Teaching, step by step

### Step 1 — Start at 320px, not at desktop

Open the page at 320px width. Ask:

- Is there horizontal scrolling? (Check `document.documentElement.scrollWidth > window.innerWidth`.)
- Is the primary action visible without zooming?
- Does the text wrap, or does it overflow?
- Are tap targets at least 44×44 CSS pixels?
- Is the reading order still logical?

Most beginner pages fail at 320px because they were designed at 1440px and squeezed. Starting small forces you to decide what matters.

### Step 2 — Use a fluid base and add breakpoints where content breaks

A mobile-first stylesheet starts with the small layout and uses `min-width` queries:

```css
/* Base: mobile */
.wrap { width: 100%; max-width: 72rem; margin-inline: auto; padding-inline: 1rem; }
.grid { display: grid; gap: 1rem; grid-template-columns: 1fr; }

/* Tablet and up */
@media (min-width: 40rem) {
  .grid { grid-template-columns: repeat(2, 1fr); }
}

/* Desktop and up */
@media (min-width: 64rem) {
  .grid { grid-template-columns: repeat(3, 1fr); }
}
```

Breakpoints are not device names. They are points where **your content** needs more room. Choose them by resizing slowly and watching for awkward line lengths, cramped cards or overlapping elements.

Use `rem` in media queries so zoom and user font settings are respected. Avoid `max-width` queries unless you are deliberately removing an enhancement.

### Step 3 — Prefer intrinsic layout to many breakpoints

Modern CSS can adapt without a query:

```css
.grid {
  display: grid;
  gap: 1rem;
  grid-template-columns: repeat(auto-fit, minmax(min(16rem, 100%), 1fr));
}
```

This creates as many columns as fit, and never overflows. `min(16rem, 100%)` prevents the track from being wider than the container on a 320px screen.

For type, `clamp()` gives a fluid range:

```css
h1 { font-size: clamp(1.75rem, 1.2rem + 2vw, 2.5rem); line-height: 1.15; }
```

Do not make body text fluid below 16px. Small text is an accessibility problem, not a style choice.

### Step 4 — Handle images properly

Images are usually the largest part of a page.

```html
<img
  src="market-640.jpg"
  srcset="market-320.jpg 320w, market-640.jpg 640w, market-1280.jpg 1280w"
  sizes="(min-width: 64rem) 50vw, 100vw"
  width="640" height="427"
  loading="lazy"
  decoding="async"
  alt="Fictional market stall with tomatoes and peppers">
```

Key points:

- Provide `width` and `height` to reserve space and prevent layout shift.
- Use `srcset` and `sizes` so a phone does not download a desktop image.
- Lazy-load below-the-fold images; do **not** lazy-load the hero image, because it delays LCP.
- Use WebP or AVIF with a fallback if needed; compress to the size actually displayed.
- Write `alt` for purpose, not for keywords. Decorative images get `alt=""`.

A 3 MB phone photo can often become a 90 KB WebP with no visible difference at display size.

### Step 5 — Control fonts and third parties

Each font file and third-party script is a request that can fail or cost data.

- Prefer system fonts for body text.
- If you must use a custom font, subset it, use `font-display: swap`, and load only the weights you use.
- Remove unused icon fonts; use inline SVG.
- Question every third-party script: analytics, chat widgets, social embeds, A/B tools. Each one adds weight, privacy risk and a failure point.
- If an embed is essential, use a click-to-load facade so the third party loads only after interaction.

### Step 6 — Set a performance budget and measure it

Write the budget down:

| Metric | Budget | How to measure |
|---|---|---|
| Total page weight | ≤ 500 KB | Network panel, "Disable cache", reload |
| Requests | ≤ 20 | Network panel |
| LCP on Slow 4G | ≤ 2.5 s | Lighthouse, mobile preset |
| CLS | ≤ 0.1 | Lighthouse |
| INP | ≤ 200 ms | Lighthouse / real interaction test |
| Main-thread long tasks | none over 50 ms | Performance panel |

Measure before and after. Record the numbers in a table. "It feels faster" is not evidence.

Lighthouse scores are a guide, not a grade. A 100 score with an unusable layout is still a failure. Use the metrics to find problems, then test with a human.

### Step 7 — Design honest loading, offline and error states

Networks fail. Design for it:

- **Loading:** show a skeleton or a clear "Loading…" label; do not show a blank screen. Announce loading to assistive tech with `aria-busy`.
- **Slow:** after a few seconds, show "This is taking longer than usual" with a retry.
- **Offline:** show what is available and what needs a connection. Do not pretend an action succeeded.
- **Error:** say what happened, what the user can do, and whether their data was saved.
- **Retry:** preserve the user's input. Never make them retype a form because the network dropped.

If you build a service worker for offline caching, keep it simple and test it. For this stop, a visible offline banner and honest messaging is enough.

```html
<div id="offline" hidden role="status">
  You are offline. You can still read this page. Saving will resume when you reconnect.
</div>
```

```js
function updateOnlineStatus() {
  document.getElementById('offline').hidden = navigator.onLine;
}
window.addEventListener('online', updateOnlineStatus);
window.addEventListener('offline', updateOnlineStatus);
updateOnlineStatus();
```

This is a small enhancement, not a full offline app. It tells the truth, which is the design requirement.

### Step 8 — Test with constraints, not just at your desk

Run these tests and record the results:

1. **320px width:** no horizontal scroll, primary action visible, tap targets adequate.
2. **200% zoom:** content reflows, nothing clipped.
3. **Slow 4G, cache disabled:** time to readable content, LCP, total weight.
4. **Offline:** what appears? Is it honest?
5. **Keyboard only:** can you reach and operate everything?
6. **Reduced motion:** enable it in the OS; do animations stop?
7. **Large text:** increase the browser font size; does the layout hold?

If you have access to a low-end Android phone, test on it. Emulation is useful but not identical.

### Step 9 — Document the trade-offs

Every performance decision is a trade-off. Write down:

- what you removed and what it cost (a decorative video, a custom font, a chat widget);
- what you kept and why;
- what you would do with more budget;
- what you could not test.

This honesty is part of the artifact. It shows judgment, not just technique.

## 6. Worked example (I do)

A learner, Emeka, built a restaurant page with a 2.8 MB hero photo, two Google Fonts, an embedded map, a chat widget and a 12-item gallery. It took 9.4 s to become readable on Slow 4G.

He sets a budget of 500 KB and 2.5 s LCP, then:

1. Replaces the hero with a 120 KB WebP at 1280px, plus a 45 KB 640px version via `srcset`.
2. Removes one font family and subsets the other to Latin; body text uses system fonts.
3. Replaces the live map with a static image and a "Get directions" link.
4. Replaces the chat widget with a "Call us" link and a contact form.
5. Lazy-loads gallery images below the fold and gives every image width and height.
6. Adds an offline banner and a retry on the contact form.

New measurements: 310 KB total, 11 requests, LCP 2.1 s on Slow 4G, CLS 0.02. The page looks almost identical at desktop size and is dramatically better on a phone.

**The reasoning:** he did not make it ugly. He removed weight that served the designer's ego more than the user's task. The map, chat widget and second font were all "nice"; none was essential.

## 7. We do it together

Use your page and complete this with me:

1. Resize to 320px and list every overflow or cramped element.
2. Convert one fixed-width container to `max-width` plus fluid padding.
3. Replace one desktop-only image with `srcset` and `sizes`.
4. Add `width` and `height` to every image and check CLS.
5. Run Lighthouse on mobile with cache disabled. Record LCP, CLS and total weight.
6. Add one honest offline or error message.

**Hint:** if the page still overflows, search the CSS for `width:` values in pixels and replace the likely culprits with `max-width: 100%`. Then check for long unbroken strings, tables and `white-space: nowrap`.

## 8. Your turn (You do)

Adapt your page and submit:

- the updated page or live URL;
- screenshots at 320px, 768px and 1280px;
- a before/after table of total weight, requests, LCP, CLS and INP;
- a list of what you removed or compressed and why;
- a description of loading, offline and error behaviour;
- a note on what you could not test and how you would test it with more resources.

Use fictional content. Do not add tracking scripts or collect real user data.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** What does mobile-first mean?
- A. Designing only for phones, since that is where most visitors to a site will arrive.
- B. Shipping a mobile app instead of a website, because apps handle small screens better.
- C. Starting with the smallest layout and adding complexity only as the screen allows.
- D. Hiding the least important content on desktop, so the phone version stays the reference.

**Q2.** When should you add a breakpoint?
- A. When the content needs more room or becomes hard to read at the current width.
- B. At every popular device width, so the layout matches the phones and tablets people own.
- C. Every 100 pixels, so the layout changes smoothly as the window is resized.
- D. Only at 1024 pixels, because that is where desktop browsers usually start.

**Q3.** Why provide `width` and `height` on images?
- A. To make them load faster, because the browser can request a smaller file for the slot.
- B. To improve the alt text, since the description is generated from the image's proportions.
- C. To enable lazy loading, which only works when dimensions are declared in the markup.
- D. To reserve the right space before the file arrives, so the page does not shift while loading.

**Q4.** Which image should generally NOT be lazy-loaded?
- A. The hero image that is the largest contentful paint element on first load.
- B. A gallery image far below the fold, which nobody sees until they scroll.
- C. A footer logo that sits at the very bottom of every page on the site.
- D. A decorative image at the bottom of the page, hidden from assistive technology.

**Q5.** What is a performance budget?
- A. The money spent on hosting and bandwidth each month, tracked against the project's running costs.
- B. An agreed limit on page weight, requests or timing metrics that the team measures against.
- C. The number of designers assigned to a team, which determines how much polish a page receives.
- D. A CSS framework that ships with performance defaults, so teams do not configure them.

**Q6.** A page shows a blank screen for six seconds on a slow network. What is the design failure?
- A. The brand colour is wrong for the audience, so the page feels unfamiliar when it appears.
- B. The font is too large, so fewer words fit and the text takes longer to wrap.
- C. The page has too many headings, so the browser waits for all of them to render.
- D. There is no honest loading state and no prioritised content, so the screen stays blank.

**Q7.** Why is `clamp()` useful for headings?
- A. It makes text bold automatically, so headings stand out without a separate font-weight rule.
- B. It replaces media queries entirely, so a page needs no breakpoints for any layout change.
- C. It creates a fluid size range with minimum and maximum bounds, so headings stay legible.
- D. It compresses images automatically, so large photos no longer slow the heading down.

**Q8.** Which is the most honest offline behaviour?
- A. Pretending the save worked, so the interface stays optimistic and the user is not distracted.
- B. Showing that the user is offline and that saving will resume when the connection returns.
- C. Hiding the page until the network returns, so the user never sees a stale or partial state.
- D. Reloading the page continuously until it succeeds, so the user sees the freshest data.

**Q9.** A page's large hero image is lazy-loaded below the fold, but it is actually the first visible element. What is the likely effect?
- A. The largest contentful paint is delayed, because the browser waits before requesting the image.
- B. The image will be sharper, because the browser can pick a higher-resolution file.
- C. The page will use less data and look identical immediately, since the image is deferred.
- D. The HTML will become invalid, because loading is not allowed on the first visible element.

**Q10.** A page shows a blank white screen for six seconds on a slow connection before any text appears. What is the design failure?
- A. The text is too large, so the browser needs longer to lay out each paragraph.
- B. The page uses too many headings, which delays the first paint of the content.
- C. No early readable content or loading state, so the user cannot tell whether it is working.
- D. The logo is the wrong colour, so the page looks broken before the text arrives.

## 10. Practical task and pass criteria

**Task.** Submit the responsive, low-bandwidth page with before/after measurements and a trade-off note.

**Pass criteria — all must be met:**

- [ ] No horizontal scrolling at 320px; primary action is reachable.
- [ ] Layout remains usable at 200% zoom.
- [ ] At least one image uses `srcset`/`sizes` or is correctly compressed for display size.
- [ ] All images have dimensions and appropriate `alt`.
- [ ] Total page weight is at or below 500 KB, or the overage is explained with a plan.
- [ ] LCP on Slow 4G is 2.5 s or less, or the miss is measured and explained.
- [ ] CLS is 0.1 or less.
- [ ] Loading, offline and error behaviour are described and at least one is implemented.
- [ ] Before/after table includes weight, requests, LCP, CLS and INP.
- [ ] The note states what was removed, what was kept and what could not be tested.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Designing desktop-first and squeezing | Desktop is the default canvas | Start at 320px and enhance. |
| Fixed widths | Easier to control | Use `max-width`, percentages and `min()`/`clamp()`. |
| Too many breakpoints | Chasing devices | Add queries only where content breaks. |
| Uncompressed photos | Phone cameras produce large files | Compress to display size; use WebP. |
| Lazy-loading the hero | Copy-paste of a pattern | Load the LCP image eagerly. |
| Third-party bloat | "Everyone uses it" | Question each script; use a facade or remove it. |
| Fake success when offline | Optimistic UI without truth | Show pending/failed states; preserve input. |
| Testing only on wifi | Convenience | Throttle and test on a low-end device if possible. |

**Retry variant.** Take a different page — a simple article page with one image — and hit the same budget of 300 KB and LCP 2 s. Because there is less to remove, you must focus on image strategy, font loading and critical CSS. Submit the measurements and a 100-word explanation of the hardest trade-off.

## 12. Proof artifact for your portfolio

Keep the before/after table, screenshots, the performance report and the trade-off note. In a portfolio, this is evidence that you design for real conditions, not just a fast laptop. State the test conditions clearly so nobody assumes the numbers apply to every network.

## 13. Low-data and low-cost path

- All testing tools are built into browsers; no paid service is needed.
- Use Squoosh offline in the browser to compress images.
- Use system fonts and inline SVG to avoid downloads.
- Test with throttling instead of buying a low-end device; note the limitation.
- If data is expensive, do the work offline and upload the final page once.
- Skip the video if needed; the steps are self-contained.

## 14. Watch and read more

**Recommended video:** *A practical guide to responsive web design* by Kevin Powell (2024, 23 min 13 s) — `https://www.youtube.com/watch?v=x4u1yp3Msao`. A hands-on explanation of fluid layout, breakpoints and modern CSS. Metadata checked 2026-10-30; embedded playback was verified in Chrome on 2026-10-30.

**Read:**

- web.dev, *Responsive web design basics* — `https://web.dev/articles/responsive-web-design-basics`. Layout, viewport and media queries.
- web.dev, *Core Web Vitals* — `https://web.dev/articles/vitals`. LCP, INP, CLS and thresholds.
- MDN, *Responsive images* — `https://developer.mozilla.org/en-US/docs/Web/HTML/Guides/Responsive_images`. `srcset`, `sizes` and art direction.
- W3C WAI, *WCAG 2.2 Quick Reference* — `https://www.w3.org/WAI/WCAG22/quickref/`. Reflow, contrast, target size and motion.
- WebAIM, *Articles* — `https://webaim.org/articles/`. Practical accessibility checks.

## 15. What comes next

**Gate 5** asks you to deploy a working, responsive front-end prototype of a Phase 3 or 4 design to a live URL with a public repository. Read `03_Assessments/Learner/Phase_5_Gate.md`. Phase 6 then tests the prototype with real people and turns what you learn into a v2.