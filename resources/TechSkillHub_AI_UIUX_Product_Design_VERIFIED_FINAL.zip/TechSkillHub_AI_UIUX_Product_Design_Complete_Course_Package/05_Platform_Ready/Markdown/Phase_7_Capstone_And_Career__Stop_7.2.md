# Stop 7.2 — Working With Developers and Product Managers

> **Phase 7 · Capstone and career launch** · Prerequisite: Stop 7.1 · Suggested session: 75–95 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Explain a design decision in terms of user outcome, cost and risk.
2. Write a ticket a developer can start without a meeting.
3. Run a critique that produces actionable changes, not opinions.
4. Scope work with a product manager by separating must-have from later.
5. Disagree productively and escalate with evidence rather than emotion.
6. Keep a decision log that survives staff changes.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Cross-functional team** | Designers, developers, product managers, researchers, QA and others working on one product. |
| **Product manager (PM)** | The person responsible for what to build, why, and in what order. |
| **Developer / engineer** | The person who builds and maintains the software. |
| **Scope** | The boundary of what is included in a piece of work. |
| **Scope creep** | Unplanned additions that expand the work without adjusting time or quality. |
| **Trade-off** | Giving up one benefit to gain another. |
| **Estimate** | A prediction of effort, always uncertain. |
| **Ticket** | A tracked unit of work with context, acceptance criteria and owner. |
| **Acceptance criteria** | Testable conditions for "done". |
| **Critique** | Structured feedback focused on the work and the goal, not the person. |
| **Decision log** | A record of decisions, rationale, owner and date. |
| **Stakeholder** | Anyone affected by or accountable for the work. |
| **Escalation** | Raising a blocked decision to someone with authority to resolve it. |
| **Definition of done** | The shared checklist that says a ticket is complete. |
| **Spike** | A short investigation to reduce uncertainty before building. |

## 3. Why this matters

Design does not ship alone. A good design that cannot be built, scoped or agreed is a drawing. The difference between a designer who is trusted and one who is tolerated is rarely visual skill. It is whether meetings end with clear decisions, whether tickets are buildable, and whether disagreement stays about the work.

> **Everyday example.** A builder and an architect who argue about everything will finish late. One who says "this wall can be load-bearing for this cost, or decorative for less; here is the trade-off; which do you want?" gets a decision in five minutes. The second is not less creative. They are more useful.

## 4. Before you start

- Bring the handoff pack from Stop 5.1 and the v2 plan from Stop 6.3.
- Choose one feature that requires design and engineering work.
- Create a decision log: `Date | Decision | Options considered | Rationale | Owner | Revisit`.
- Create a ticket template with: context, user story, acceptance criteria, design link, edge cases, analytics, accessibility, open questions.
- Identify the PM and developer perspectives: what each is measured on, what constraints they face.

## 5. Teaching, step by step

### Step 1 — Learn the other person's constraints

A PM is usually balancing user value, business value, delivery risk and stakeholder expectations. A developer is balancing correctness, maintainability, performance, deadlines and unknowns. Neither is being difficult on purpose.

Before a meeting, ask:

- What outcome is the PM accountable for this quarter?
- What is the developer worried about in this feature?
- What is the deadline and what is driving it?
- What has already been tried?

Designers who understand constraints propose better options. Designers who ignore them become a source of unplanned work.

### Step 2 — Frame decisions as options with consequences

Instead of "we should do X", present two or three options:

| Option | User benefit | Cost | Risk |
|---|---|---|---|
| A: Full redesign of checkout | Best clarity | 3 weeks, 2 engineers | Delays launch; regression risk |
| B: Fee estimate on product page | Addresses main drop | 2 days, 1 engineer | Estimate may differ from final fee |
| C: Copy change only | Cheapest | 1 hour | Does not fix late-fee surprise |

Recommend one and say why. A recommendation with a rationale is easier to approve than a demand.

### Step 3 — Write tickets that stand alone

A good ticket:

- **Title:** verb + object, for example "Show delivery fee estimate on product page".
- **Context:** the user problem and evidence link.
- **User story:** "As a first-time buyer, I want to see an estimated delivery fee before checkout so that I can decide without surprise."
- **Scope:** what is in and out.
- **Acceptance criteria:** testable conditions.
- **Design link:** the exact frame or handoff section.
- **Edge cases:** estimate unavailable, different regions, free delivery threshold.
- **Accessibility:** labels, focus, announcement of the estimate.
- **Analytics:** event names and properties.
- **Open questions:** owner and default.

If a developer has to ask "where is the design?", the ticket is incomplete.

### Step 4 — Run a critique that changes something

A critique is not a presentation with comments. Use a structure:

1. **Goal (2 min):** the user problem and what success looks like.
2. **Context (2 min):** constraints and stage.
3. **Walkthrough (5 min):** the work, without defending.
4. **Clarifying questions (5 min):** facts only.
5. **Feedback (10 min):** each person gives one strength and one specific improvement, tied to the goal.
6. **Decisions (5 min):** what will change, who owns it, by when.

Rules:

- Critique the work, not the person.
- "I would..." is an opinion; "At 320px the button is below the fold, so a user may not see it" is evidence.
- Do not redesign in the meeting. Note the issue and explore after.
- End with a written list of changes.

### Step 5 — Scope with the PM, explicitly

Use a three-column scope:

- **Must have:** required for the user to complete the core task or for safety/accessibility.
- **Should have:** improves the experience, can ship shortly after.
- **Later:** valuable but not now.

Say what happens to quality if scope grows: "If we add saved cards, the fee estimate slips a week and we lose the payday launch." Making the cost visible turns a scope argument into a trade-off decision.

### Step 6 — Handle disagreement without heat

Separate three kinds of disagreement:

1. **Facts:** resolvable with evidence. "Does the API return a fee before address entry?"
2. **Values:** different priorities. "Speed versus completeness." Name the values.
3. **Taste:** preferences. Acknowledge and defer to the owner or the evidence.

For facts, go and check. For values, ask who owns the decision and what would change their mind. For taste, do not spend a meeting.

Useful phrases:

- "What would we need to see to change our minds?"
- "I hear the deadline constraint. If we keep it, here is what I would cut."
- "Can we timebox a spike for two days and decide with the result?"
- "Let us write the decision down so we do not relitigate it next week."

### Step 7 — Escalate with a one-page brief

Escalation is not complaining. It is asking someone with authority to decide. A one-page brief:

- **Decision needed:** one sentence.
- **Why now:** deadline or risk.
- **Options:** two or three, with user impact, cost and risk.
- **Recommendation:** one option and why.
- **What we need from you:** a decision by a date.
- **What happens if we do not decide:** the default.

This respects everyone's time and makes the trade-off visible.

### Step 8 — Keep a decision log

Log decisions as they happen:

| Date | Decision | Options | Rationale | Owner | Revisit |
|---|---|---|---|---|---|
| 3 Nov | Fee estimate on product page | Copy only / estimate / full redesign | Addresses main drop within 2 days | PM | After 4 weeks |

The log prevents the same debate every sprint, helps new team members, and gives you evidence for your case study.

### Step 9 — Build trust through reliability

Trust is built by small, consistent behaviours:

- say when you will deliver and deliver;
- flag risks early, not at the deadline;
- admit when you do not know;
- credit others;
- update the design when decisions change;
- attend the build review, not just the design review.

A designer who is reliable gets more influence than one who is merely talented.

## 6. Worked example (I do)

A learner, Kelechi, is told by a developer that the animated onboarding cannot ship before the deadline. His first reaction is "but the animation is the experience". He reframes:

- **User outcome:** new users understand how savings goals work.
- **Constraint:** two days of engineering time.
- **Options:** A) full animation, 4 days; B) static three-step illustration, 1 day; C) short copy with one illustration, half a day.

He recommends B, with A scheduled for the next release if the onboarding data shows confusion. He writes the ticket with acceptance criteria, updates the decision log, and tells the PM what is deferred.

The developer ships B on time. Two weeks later, task success in onboarding is unchanged, which suggests the animation was not the active ingredient. Kelechi records that in the decision log and uses it in his case study.

**Why this is good:** he protected the user outcome, respected the constraint, made a reversible decision, and learned from the result.

## 7. We do it together

With a peer, role-play a 10-minute scope conversation:

1. State the user outcome in one sentence.
2. Present two options with cost and risk.
3. Ask, "What would we need to see to choose the other option?"
4. Agree a must-have and a later item.
5. Write the decision in one line with an owner.

Then swap and play the PM. Notice which questions produced a decision and which produced defensiveness.

**Hint:** if the conversation loops, you are probably arguing about values while pretending it is about facts. Name the value.

## 8. Your turn (You do)

Produce a collaboration pack:

- a scoped ticket with context, user story, acceptance criteria, edge cases, accessibility and analytics;
- a decision log with at least four decisions and rationale;
- a critique note for a peer's work with one strength and three specific, actionable improvements;
- a one-page escalation brief for one disagreement, including options and a default;
- a 150-word reflection on one constraint you had to respect and how it changed the design.

Use a fictional product and fictional colleagues. Do not include real personnel issues or confidential roadmap details.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** What is the most useful way to present a design decision to a PM?
- A. As two or three options with user benefit, cost and risk, plus one recommendation and its rationale.
- B. As a firm demand supported by your professional judgement, so the team can move forward without further debate.
- C. As a finished screen with no written context, so the PM can react to the visual result immediately.
- D. As a complaint about the deadline, so the PM understands the pressure the design team is facing.

**Q2.** What makes a ticket buildable?
- A. A clear title alone, because the developer can ask for the rest of the context during stand-up.
- B. Context, scope, acceptance criteria, a design link, edge cases and open questions with named owners.
- C. A screenshot and a deadline, so the developer can see the target and plan the work backwards.
- D. A link to a competitor's page, so the developer can copy the behaviour that already works there.

**Q3.** In a critique, which comment is most useful?
- A. I don't like green, because it makes the whole product feel cheaper than the competitors' products.
- B. Make it pop, so the primary action stands out more clearly against everything else on the page.
- C. At 320px the primary button sits below the fold, so users may never see it on a small phone.
- D. My old team did it differently, and their version tested better with the users we surveyed.

**Q4.** What is scope creep?
- A. A design pattern where components grow in size as the screen width increases across breakpoints.
- B. Unplanned additions that expand the work without adjusting the agreed timeline, cost or quality.
- C. A type of estimate that assumes the team will work faster than the original forecast allowed.
- D. A critique method where reviewers keep adding suggestions until the design has changed substantially.

**Q5.** A disagreement is about speed versus completeness. What kind is it?
- A. A fact disagreement, because one side must be wrong about how long the work will actually take.
- B. A values disagreement, because the two sides are prioritising different things and neither is factually wrong.
- C. A taste disagreement, because the argument is really about which visual style looks more finished.
- D. A technical bug, because the disagreement will disappear once the underlying defect has been fixed.

**Q6.** What should an escalation brief include?
- A. A long history of the conflict, so the decision maker understands how the disagreement developed.
- B. Only the designer's preferred option, stated clearly enough that the decision maker can approve it.
- C. The decision needed, the options, a recommendation, a deadline and the default if nobody decides.
- D. A list of everyone who is wrong, so responsibility for the delay can be assigned properly.

**Q7.** Why keep a decision log?
- A. To fill the project documentation, so the repository looks maintained when a new manager reviews it.
- B. To prove you attended the meetings, which is useful when performance and contribution are reviewed each quarter.
- C. To replace the design file, so nobody needs to open the source frames once a decision is recorded.
- D. To preserve the rationale behind choices, prevent relitigating and help new team members understand earlier decisions.

**Q8.** What builds trust fastest with a developer?
- A. Beautiful mockups, because visual quality is what convinces engineers that a designer is worth listening to.
- B. Reliable delivery, early risk flags, updated designs and turning up to the build review each sprint.
- C. More meetings, because frequent contact shows the developer that the designer is engaged and reliable.
- D. Avoiding all constraints, because a designer who never compromises keeps the original product vision intact.

**Q9.** A developer says a design interaction is technically impossible in the current sprint. What is the most useful response?
- A. Insist that the original design ships exactly as drawn, because the interaction carries the whole experience.
- B. Remove the feature without telling the product manager, so the sprint stays on schedule and nobody notices.
- C. Escalate immediately without asking a question, because the developer is blocking work that was already agreed.
- D. Ask what constraint makes it impossible, then offer a smaller or alternative interaction with its trade-off.

**Q10.** A ticket says 'make the settings page nicer' and gives no acceptance criteria. What will most likely happen?
- A. The page will automatically become accessible, because the design system handles labels and focus order.
- B. The developer and designer will interpret 'nicer' differently, causing rework and a much slower review.
- C. The design system will update itself, because vague requests usually trigger a routine component refresh.
- D. The sprint will end early, because the developer can stop once the page looks better than before.

## 10. Practical task and pass criteria

**Task.** Submit the collaboration pack and reflection.

**Pass criteria — all must be met:**

- [ ] Ticket is self-contained with testable acceptance criteria.
- [ ] Decision log has at least four entries with rationale and owner.
- [ ] Critique note has one strength and three specific improvements tied to the goal.
- [ ] Escalation brief states the decision, options, recommendation, deadline and default.
- [ ] At least one trade-off is explained in user, cost and risk terms.
- [ ] The reflection names a constraint and its effect on the design.
- [ ] No confidential or personnel information is included.
- [ ] Language is professional and focused on the work.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Presenting one option as inevitable | Fear of rejection | Present two or three with consequences. |
| Tickets with only a screenshot | Assumed context is obvious | Add context, criteria and edge cases. |
| Critique as taste debate | No structure | Use goal, evidence, specific change. |
| Saying yes to everything | Wanting to be helpful | Show the cost of added scope. |
| Escalating without options | Frustration | Bring a one-page decision brief. |
| No decision log | Busy team | Log one line per decision. |
| Treating estimates as promises | Planning pressure | Call them estimates and re-check. |
| Avoiding the build review | Time pressure | Attend; fix issues while they are cheap. |

**Retry variant.** Rewrite a real or imagined disagreement as a **one-page decision brief** with no mention of personalities. Then write a 100-word note on what changed when you removed emotion from the framing. This targets the most common collaboration failure.

## 12. Proof artifact for your portfolio

Keep the ticket, decision log and escalation brief as evidence of collaboration. In a case study, quote one decision and its rationale. Do not publish internal names or confidential details.

## 13. Low-data and low-cost path

- Use a shared document or spreadsheet; no paid tool is required.
- Run critiques asynchronously with written comments and a 15-minute call.
- Use a two-day spike instead of a long debate when facts are missing.
- Skip the video if data is tight; the steps are complete.
- If you have no team, simulate the PM and developer perspectives in writing.

## 14. Watch and read more

**Recommended video:** *How to Work with Product Managers as a Senior Designer | Collaboration tips* by femke.design (2025, 18 min 1 s) — `https://www.youtube.com/watch?v=crAaxd30NMg`. Practical collaboration habits from a designer working with PMs. Metadata checked 2026-10-30; embedded playback was verified in Chrome on 2026-10-30.

**Read:**

- Nielsen Norman Group, *Design critique* — `https://www.nngroup.com/articles/design-critiques/`. Structures for useful feedback.
- Nielsen Norman Group, *From Confrontation to Collaboration: The Developer-Designer Relationship* — `https://www.nngroup.com/articles/developer-designer-relationship/`. Practical habits for reducing friction and making decisions together.
- Atlassian, *User stories* — `https://www.atlassian.com/agile/project-management/user-stories`. A practical ticket format.
- W3C WAI, *WCAG 2.2 Quick Reference* — `https://www.w3.org/WAI/WCAG22/quickref/`. Accessibility criteria to put in tickets.

## 15. What comes next

Stop 7.3 turns your case studies into a live portfolio and a professional presence: a site, a profile, and a clear story that survives a 30-second scan.