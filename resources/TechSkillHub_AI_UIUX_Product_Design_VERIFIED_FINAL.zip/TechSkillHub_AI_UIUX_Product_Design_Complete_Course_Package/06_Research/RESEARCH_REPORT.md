# Research Report

**Course:** AI-Assisted UI/UX and Product Design
**Prepared:** 2026-10-30
**Sources registered:** 66
**Videos registered:** 38
**Verification method:** live HTTP request, watch-page metadata extraction, real-browser embedded playback and WCAG 2.2 AA automated checks
**Author:** TechSkillHub course package build

## 1. Purpose

This report explains how the course's factual claims, standards and external resources were selected and checked. It is a record of method and limits, not a literature review. The course is a practical beginner programme, so the research question was narrow:

> Which stable, first-party or expert sources best support a beginner's understanding of UI/UX, accessibility, AI-assisted design and front-end delivery, and what can honestly be claimed about them?

## 2. Method

### 2.1 Source-first, not citation-first

The lessons were written around practices that could be sourced, not decorated with citations after the fact. Where a claim could not be supported by a stable source, it was either:

- framed as a design judgment or a course policy;
- labelled as fictional practice data;
- removed.

Examples of claims deliberately framed as policy rather than fact:

- the 80% mastery target;
- the 8/10 pass threshold for ten-question checks;
- the capstone's 80% overall / 60% per-criterion rule;
- suggested session times;
- the 500 KB / 2.5 s performance budget used in exercises.

These are course design decisions, not external standards. The audit records them as such.

### 2.2 Source selection criteria

A source was included when it met at least three of these:

1. **First-party or expert:** the organisation owns the standard, tool or method it describes.
2. **Stable:** a documentation page, standard or established article, not a social post or a news snippet.
3. **Accessible:** free to read, no login, readable on a low-data connection.
4. **Specific:** supports a teachable claim, not a general vibe.
5. **Non-promotional:** explains a practice rather than selling a product.

Where a commercial tool is taught (Figma, GitHub, Netlify), its own documentation is used for mechanics, while the course remains tool-agnostic about outcomes.

### 2.3 Verification procedure

For each non-video URL:

1. Request the URL with redirects followed.
2. Record the final URL and HTTP status.
3. Accept only HTTP 200.
4. Record the date checked and the stops where it is used.

For each video:

1. Fetch the YouTube watch page with an English locale.
2. Read the page title, channel name, upload date, length, playability status, available countries and caption tracks.
3. Record the exact title, including punctuation and decoded entities.
4. Load the video inside the real lesson page and confirm that the iframe loads, the media element reaches `readyState 4`, playback is not paused and `currentTime` advances.
5. Record direct watch-page playback where advertisements did not consume the test window.

All checks were run on **2026-10-30**. The source register records the final URL for redirects.

### 2.4 What was not done

- Video content was not watched end to end, so no claim is made about the accuracy or currency of every statement, or about timestamps.
- Captions were listed as available for all 38 videos, but caption accuracy was not reviewed; YouTube transcript endpoints returned empty or `FAILED_PRECONDITION` from this environment.
- Playback was verified from the build environment and all 38 embeds played; playback from a Nigerian network was **not** tested, so regional availability remains unconfirmed.
- Direct watch-page content playback was confirmed for 13 of 38 videos; for 25, pre-roll advertising exceeded the test window. Embedded playback is the stronger evidence and covers all 38.
- No live learner cohort was run for this package build.
- No claim is made that the source list is exhaustive.
- No local legal, tax or medical advice was sourced; the course explicitly directs learners to local professionals.

## 3. Coverage

### 3.1 By phase

| Phase | Source focus | Example sources |
|---|---|---|
| 0 | Workspace, study habits, observation, AI tutoring, publishing | Figma frames, Cornell LSC study strategies, NN/g heuristics, IBM AI hallucinations, NIST AI RMF, MDN |
| 1 | Research ethics, interviews, problem framing, competition | GOV.UK user research, NN/g interviews, NN/g problem statements, GOV.UK Design System |
| 2 | Layout, type, colour, components, interaction, accessibility | Material 3, WCAG 2.2, WebAIM, GOV.UK components, NN/g empty states |
| 3 | Figma mechanics, components, variables, prototyping, systems | Figma Help, NN/g prototyping case study |
| 4 | AI synthesis, ideation, UI, critique, copy, verification | Microsoft HAX, NIST, OECD, WCAG, NN/g research with AI |
| 5 | Web basics, handoff, AI code, tokens, responsive performance | MDN, Figma Dev Mode, web.dev, GitHub Pages |
| 6 | Usability testing, metrics, prioritisation | NN/g, GOV.UK, Google HEART, Amplitude North Star |
| 7 | Case studies, collaboration, portfolio, pricing | NN/g, Atlassian, Freelancers Union, GitHub Pages |

### 3.2 By type

| Type | Count (approx.) | Role |
|---|---|---|
| Standards and principles | 5 | WCAG, NIST AI RMF, OECD AI Principles |
| Official product documentation | 18 | Figma, GitHub, MDN, Netlify |
| Design systems | 2 | Material 3, GOV.UK Design System |
| Expert articles and guidance | 34 | NN/g, GOV.UK Service Manual, WebAIM, Atlassian, Amplitude, Cornell, IBM |
| Tools | 4 | WebAIM contrast checker, Squoosh, Netlify Drop, GitHub Pages |
| Research paper | 1 | Google HEART |
| Professional body | 2 | Freelancers Union guidance |

Counts are approximate because some pages serve multiple roles, and the same source can be used by more than one stop.

## 4. Key findings used in the course

### 4.1 Accessibility thresholds

WCAG 2.2 is used as the normative reference. The course teaches:

- **4.5:1** contrast for normal text;
- **3:1** for large text and essential non-text UI;
- **24×24 CSS pixels** minimum target size (SC 2.5.8), with 44×44 recommended;
- reflow at 320px and 200% zoom;
- visible focus, labels, error identification and status not conveyed by colour alone.

The lessons do not claim full conformance from a partial checklist. Gate 2 and Gate 5 require evidence and a statement of what was not tested.

### 4.2 Five-user testing

NN/g's five-user rationale is presented as a starting round for qualitative testing, not a statistical guarantee. The course repeatedly requires counts ("3 of 5") rather than "users want", and requires limitations in every test summary.

### 4.3 AI risk and human oversight

NIST AI RMF, OECD AI Principles and Microsoft HAX Guidelines for Human-AI Interaction inform the course's position:

- AI output is a draft, not evidence;
- humans verify facts, accessibility, privacy and safety;
- AI use must be disclosed in gates and the capstone;
- high-stakes decisions stay with a human.

These are governance concepts adapted for a beginner workflow, not a claim of compliance with any framework.

### 4.4 Performance

Core Web Vitals thresholds are used as exercise targets:

- LCP ≤ 2.5 s;
- INP ≤ 200 ms;
- CLS ≤ 0.1.

The 500 KB page-weight budget is a course constraint, not a Google standard. The lessons say so.

### 4.5 Handoff and systems

Figma's documentation informs the mechanics of auto layout, components, variables, Dev Mode and prototyping. The course adds a design judgment layer: what to specify, what to leave to code, and how to detect drift. The judgment layer is course-authored, not sourced.

## 5. Fabrication controls

The package was built with explicit rules:

- No invented video IDs, titles, creators, dates or runtimes. Every row was read from a watch page.
- No invented quotes, participants, statistics, clients or outcomes. Practice data is labelled fictional.
- No claim that a video's content was fully reviewed or that its captions are accurate.
- No claim that an accessibility or performance test was run when it was not.
- No claim of employment outcomes.
- Redirected URLs are recorded with their final destination.
- Sources that returned 404 were replaced, not hidden.
- Sources that could not be read in this environment were replaced or marked as access-limited rather than described as verified.

Three URLs initially returned 404 during checking and were replaced:

- a Material 3 layout page → `https://m3.material.io/foundations/layout`;
- an NN/g case-study URL → `https://www.nngroup.com/videos/ux-design-portfolio-case-study/`;
- an NN/g portfolio URL → `https://www.nngroup.com/articles/ux-design-portfolios/`.

The final register contains no 404s. One W3C page returns HTTP 403 to scripted clients but loads normally in a browser; that limitation is recorded in the register and the resource review rather than being smoothed over.

### 5.1 What changed after the first resource review

The original package cited 54 non-video sources. Each was re-read against its stop outcome for beginner fit, cost, login requirement, currency and relevance. The outcome:

- **49** original sources remain in the current register;
- **5** were removed or replaced because they were unreadable, too advanced, promotional, outdated or a poor fit for the stop;
- several stops gained a second, stronger source rather than keeping a single adjacent-fit reading — for example NN/g roles and study guidance at 1.1, NN/g problem statements at 1.3, NN/g empty states at 2.4, NN/g research with AI at 4.1, NN/g journey mapping at 4.2, Amplitude's North Star playbook at 6.2 and Freelancers Union rate guidance at 7.4;
- Google PAIR was replaced by the Microsoft HAX Guidelines for Human-AI Interaction because PAIR's application shell could not be read reliably in this environment.

`07_Resources/ORIGINAL_RESOURCE_REVIEW.csv` records the 54 original entries one by one. `07_Resources/RESOURCE_REVIEW.csv` records the current 66, and `07_Resources/RESOURCE_SUFFICIENCY_MATRIX.csv` records coverage for all 38 stops.

## 6. Limitations

1. **Metadata is not content.** A video's title and duration do not prove its claims are accurate or current. Content fit was judged from the watch-page description and topic, not from a full viewing.
2. **Regional playback is unconfirmed.** All 38 embeds played in the build environment and every video's metadata lists Nigeria, but playback from a Nigerian network was not tested. The HTML provides a direct link and a text alternative.
3. **Captions exist but were not reviewed.** Every video lists an English caption track; accuracy and completeness were not checked.
4. **Sources change.** Documentation URLs, page titles and recommendations can change after 2026-10-30.
5. **No learner trial.** The course has not been tested with a live cohort for this build; difficulty, pacing and clarity are reasoned, not measured. The beginner-quality review is a simulated expert review, not learner evidence.
6. **Regional specificity.** Nigerian and wider African examples are illustrative and fictional. Local payment, tax and legal details must be checked locally.
7. **Tool versions.** Figma, browsers and AI tools change quickly; the mechanics described may drift.
8. **Partial accessibility testing.** The package passed automated WCAG 2.2 AA checks on 40 pages and a keyboard/structure review, but not a full assistive-technology matrix with disabled users.
9. **No statistical claims.** Five-user tests and fictional funnels are teaching devices, not evidence about a population.
10. **One access limitation.** W3C pages returned HTTP 403 to Node and Puppeteer; they were reviewed through a real browser and `webfetch` instead. The register records the 403 honestly.

## 7. Maintenance plan

- Re-check every URL and video every six months, or before each cohort.
- Replace dead sources rather than leaving a broken link.
- Re-run the link checker and update `SOURCE_REGISTER.csv` and `VERIFICATION_LOG.md`.
- Recompute `FILE_MANIFEST_SHA256.txt` after any change.
- Record the change and the reason in the verification log.
- If a video becomes private or blocked, mark it "unavailable" and keep the lesson text as the primary source.

## 8. Conclusion

The package's factual base is deliberately modest: standards, official documentation and established practitioner guidance. The course's value lies in the sequence, the practice and the verification habits, not in novel research claims. Where the course makes a policy choice, it says so. Where it has not tested something, it says so. That is the standard the audit applies.
