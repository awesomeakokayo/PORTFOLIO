---
stop_id: 1.3
title: Problem Framing
phase: 1
prerequisites: Stop 1.2
outcome: Write a one-page problem brief with a job story, a problem statement, success metrics, scope and assumptions, all traceable to evidence or labelled as hypotheses.
time: 60-80 minutes
artifact: A one-page problem brief for a real product idea, with evidence links, success metrics, scope, non-goals, assumptions and risks.
---

# Stop 1.3 — Problem Framing

> **Phase 1 · Product thinking and research** · Prerequisite: Stop 1.2 · Suggested session: 60–80 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Write a **job story** that describes a situation, motivation and expected outcome.
2. Write a problem statement that contains no solution.
3. Define success metrics that could actually be measured.
4. Set scope and non-goals, and list assumptions and risks separately from evidence.
5. Produce a one-page brief that a stranger could use to decide what to build.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Problem framing** | Defining the problem precisely enough that a solution can be judged against it. |
| **Jobs to be done (JTBD)** | A way of describing what a person is trying to accomplish in a situation, independent of your product. |
| **Job story** | A short format: "When [situation], I want to [motivation], so I can [expected outcome]." |
| **User story** | A backlog format: "As a [role], I want [capability], so that [benefit]." More solution-shaped than a job story. |
| **Problem statement** | A concise description of who is affected, what they cannot do, and why it matters. |
| **Hypothesis** | A testable belief you hold before you have evidence. |
| **Assumption** | Something you are treating as true without proof. |
| **Risk** | Something that could make the project fail or cause harm. |
| **Success metric** | A measure that tells you whether the problem is being solved. |
| **Baseline** | The current value of a metric before you change anything. |
| **Target** | The value you want to reach, with a date or condition. |
| **Scope** | What is included in this version. |
| **Non-goal** | Something deliberately excluded, with a reason. |
| **Guardrail metric** | A measure you must not make worse while improving the main metric. |
| **North star metric** | The one measure that best represents value delivered to users. |
| **Constraint** | A limit you must design within. |

## 3. Why this matters

A vague problem produces a beautiful, useless design. "Improve the food ordering experience" cannot be judged. "Reduce the number of customers who call support because they cannot tell whether their order was received, from 40% of orders to under 10%" can be judged, scoped and tested.

Framing is also a defence. When a stakeholder asks for a feature, a clear problem statement lets you ask: *which part of the problem does this solve, and how would we know?* Sometimes the feature is right. Sometimes a cheaper fix is better. Without a frame, every request sounds equally valid.

> **Everyday example.** A carpenter does not start cutting because someone says "the table wobbles". They turn it over, find the short leg, and decide whether to sand, shim or rebuild. The problem statement is the diagnosis; the feature is the cut.

## 4. Before you start

- Have your practice research pack from Stop 1.2 open.
- Choose **one** product idea to frame. It can come from your interviews or from a real frustration you have observed. Do not choose something that requires confidential client data.
- If your research is thin, that is fine — label the gaps as assumptions. Do not invent evidence to fill them.

## 5. Teaching, step by step

### Step 1 — Write the job story before the feature

Format:

> **When** [situation], **I want to** [motivation], **so I can** [expected outcome].

Example: "When I am about to send money to a new account, I want to confirm I have the right person without calling them, so I can pay quickly without fear of losing money."

Why this format works: it encodes the **situation**, which is where design opportunities live. "Send money" is not a job; "send money to a new account without fear" is.

Write two or three job stories from your interviews. Use the participant's language where you can, in quotes.

### Step 2 — Write the problem statement

Use this structure:

> **[Who]** cannot **[do what]** because **[barrier]**, which leads to **[consequence]**. Today they cope by **[workaround]**.

Example: "First-time senders cannot confirm a new recipient's identity inside the app because the name display is easy to miss and feels unverified, which leads to abandoned transfers or duplicate payments. Today they cope by calling the recipient or asking a relative to check."

Check the statement against three tests:

1. **No solution nouns.** Remove "app", "button", "dashboard", "AI", "notification".
2. **A consequence.** If nothing bad happens, it is not a problem worth solving.
3. **Traceable.** Each clause should point to a note, quote or observation, or be marked as a hypothesis.

### Step 3 — Choose the evidence you actually have

Make a small table:

| Claim in the brief | Evidence | Strength |
|---|---|---|
| Senders call the recipient to verify | P1 and P2 notes, 2026-11-04 | Weak (n=2) but direct |
| Duplicate payments are common | No data | Assumption — needs support tickets or analytics |
| Users want a photo of the recipient | Not tested | Hypothesis — do not state as fact |

Strength labels protect you. "Weak but direct" is honest. "Common" without data is not.

### Step 4 — Define success in measurable terms

A good metric has four parts: **name, definition, baseline, target**.

Example:

> **Primary metric:** completed transfers without a support contact within 24 hours.
> **Definition:** transfers marked successful where the user does not open a support chat or call about that transfer.
> **Baseline:** unknown; estimate from 30 days of support logs before launch.
> **Target:** reduce support contacts per 100 transfers by 30% within 60 days of launch.

If you have no baseline, say so and explain how you will get one. Never invent a baseline.

Add:

- **Guardrail metric:** fraud reports per 1,000 transfers must not increase.
- **Counter-metric:** time to complete a transfer must not increase by more than 10 seconds.
- **Qualitative signal:** in usability tests, at least 4 of 5 participants can state the recipient's name before confirming without help.

### Step 5 — Set scope and non-goals

Scope is a promise; non-goals are a protection.

Example scope for a first version:

- confirm recipient name and bank before sending;
- show a clear "sending / sent / failed" state;
- allow retry after failure without duplicating the transfer.

Non-goals, with reasons:

- **Not** adding a social feed — not needed for the job and adds moderation cost.
- **Not** supporting international transfers — different regulatory and currency problems.
- **Not** redesigning the whole app — the problem is local to the confirmation step.

A non-goal without a reason is just a wish. Write the reason.

### Step 6 — List assumptions and risks

Assumptions:

- "Users notice the recipient name when it is displayed prominently." (Untested.)
- "Most duplicate payments happen because the waiting state is ambiguous." (Hypothesis.)

Risks:

- **User harm:** a confirmation step that adds friction could cause users to abandon legitimate transfers.
- **Business:** support cost may rise during the transition.
- **Technical:** name lookup may fail for some banks; the design must handle "name unavailable".
- **Ethical/privacy:** showing a recipient's photo requires consent and could enable harassment. If you cannot source photos ethically, do not use them.
- **Accessibility:** the confirmation must work with a screen reader and at 200% text size.

### Step 7 — Write the one-page brief

Use this exact order; it forces clarity:

1. **Title and date.**
2. **Job story** (1–2).
3. **Problem statement** (3–4 sentences).
4. **Who is affected** and who is not.
5. **Evidence** (with links to notes) and **what is still assumed**.
6. **Success metrics** (primary, guardrail, counter, qualitative).
7. **Scope** and **non-goals** with reasons.
8. **Constraints** (time, budget, devices, regulation, team).
9. **Risks and mitigations.**
10. **Open questions** for the next research round.

One page means one page. If it spills, you are explaining rather than deciding.

## 6. Worked example (I do)

**Title:** Confirming a new recipient before a transfer — problem brief v1 — 2026-11-06.

**Job story:** "When I am about to send money to a new account, I want to confirm I have the right person without calling them, so I can pay quickly without fear of losing money."

**Problem statement:** "First-time senders cannot confirm a new recipient's identity inside the app because the name display appears late and is visually weak, which leads to abandoned transfers or duplicate payments. Today they cope by calling the recipient or asking a relative to check."

**Who is affected:** people sending to a new account, especially first-time users and older users. **Not affected:** people sending regularly to saved beneficiaries, who already have a trusted pattern.

**Evidence:** two practice interviews (n=2), both described a second-channel check. **Assumption:** duplicate payments are common; no support data yet. **Hypothesis:** a stronger confirmation screen reduces the second-channel check. Note: reducing the check is not automatically good — the check may be a healthy trust behaviour. The real goal is reducing *failed or duplicated* transfers, not eliminating the call.

**That last sentence is the kind of correction a good brief contains.** It notices that the obvious metric ("fewer calls") could reward the wrong outcome.

**Metrics:**

- Primary: support contacts per 100 new-recipient transfers, baseline to be measured, target −30% in 60 days.
- Guardrail: fraud reports per 1,000 transfers must not rise.
- Counter: median time to complete must not rise by more than 10 seconds.
- Qualitative: 4 of 5 usability participants can state the recipient name before confirming, unaided.

**Scope:** recipient name and bank on the confirmation screen; clear sending/sent/failed states; safe retry.

**Non-goals:** no social features (not needed for the job); no international transfers (regulatory scope); no full app redesign (problem is local).

**Risks:** added friction → abandonment; name lookup failure → must design an "unavailable" state; photo consent → do not use photos without a lawful, consented source; screen-reader access → test with keyboard and a screen reader.

**Open questions:** how often do duplicate payments actually occur? Do users trust a bank name more than an account name? Does the second-channel check reduce fraud or just anxiety?

## 7. We do it together

1. Draft three job stories from your notes. Circle the one with the strongest evidence.
2. Write the problem statement using the four-part structure. Remove every solution noun.
3. Build the evidence table with strength labels.
4. Define one primary metric with name, definition, baseline and target. If the baseline is unknown, write how you will get it.
5. Add one guardrail and one counter-metric.
6. Write three scope items and three non-goals with reasons.
7. List three assumptions and three risks with mitigations.
8. Read the brief aloud. Cut anything that explains rather than decides.
9. Ask a friend to read it and tell you what they think you are building. If they name a feature, your brief is too solution-shaped.

## 8. Your turn (You do)

**Independent task.** Write a **one-page problem brief** for a real product idea, using the ten-part structure in Step 7.

Requirements:

- It must be based on either your Stop 1.2 interviews or a documented real observation (for example, watching a family member use an app, with their permission). If neither is available, use a clearly labelled **fictional practice scenario** and say so at the top.
- Every factual claim must link to a note, quote or observation, or be labelled **assumption** or **hypothesis**.
- Include at least one metric with a baseline and target; if the baseline is unknown, state the plan to measure it.
- Include at least two non-goals with reasons.
- Include at least one accessibility risk and one privacy/ethical risk.
- Include three open questions.
- It must fit on one page (roughly 500–650 words; tables count).

Then write a 120-word "What I am not solving" note explaining why the excluded parts are excluded **now**, not forever.

**Do not** invent a baseline, a statistic or a user quote. Do not write a feature list and call it a brief.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** Which is a job story?
- A. As a user, I want a dashboard, so that I can see my money and check every payment that leaves.
- B. Build a confirmation modal that repeats the amount and the recipient name before the sender finally taps send.
- C. Users need trust, because sending money to a new account feels risky without a visible confirmation before paying.
- D. When I pay a new seller, I want to check who I am paying, so I can avoid losing money.

**Q2.** What is wrong with "Users need a notification feature" as a problem statement?
- A. It names a solution, not the problem, so no alternative response can be judged against it.
- B. It is too short, so it cannot explain who is affected by the missing notification and why.
- C. It has no metric, so nobody can tell whether the notification reduced the confusion it targets.
- D. It is not in English, so the brief cannot be reviewed by the stakeholders who approve scope.

**Q3.** A metric has a target but no baseline. What should the brief do?
- A. State that the baseline is unknown and describe how it will be measured before launch.
- B. Invent a plausible baseline, because a target only becomes meaningful once it has a number.
- C. Remove the metric, because a measure without a baseline cannot be tracked or reported.
- D. Use a competitor's number as your baseline, because their data reflects the same market.

**Q4.** What is a guardrail metric?
- A. A measure you must not make worse while improving the main metric, such as fraud reports.
- B. The main measure of success, the one number the team watches to judge whether the change worked.
- C. A metric that only applies to accessibility, such as whether labels remain visible at 200% text size.
- D. A target set by the finance team, because money and risk are their responsibility rather than design's.

**Q5.** Which is a well-written non-goal?
- A. We will not do social features, because they are not needed for the confirmation job and add moderation cost.
- B. We will not do social features, because the team has not decided whether they belong in this release.
- C. Maybe social later, once the confirmation work ships and the team has spare capacity to revisit it.
- D. No bad ideas, because the brief should stay open to whatever the team discovers during the research.

**Q6.** Why should a problem brief avoid solution nouns?
- A. They make the page longer, because each named component needs a sentence explaining how it works.
- B. They are grammatically incorrect, because a noun cannot follow the verb that introduces the problem.
- C. They close off better alternatives and make the problem impossible to judge independently of a fix.
- D. They confuse developers only, because stakeholders read the brief for budget rather than for detail.

**Q7.** Which is the strongest evidence label for "users want a recipient photo"?
- A. Evidence, because a participant suggested it during the interview and asked why it was missing.
- B. Fact, because it is a common pattern in banking apps and other products people already trust.
- C. Hypothesis, because no participant was shown or asked about a photo in a way that tests the claim.
- D. Metric, because it can be counted whenever a user taps the recipient photo in the app.

**Q8.** What does a good brief do when the research is thin?
- A. Fills gaps with confident language, because a brief that hedges will not convince anyone to fund it.
- B. Removes the problem statement, because a problem without evidence cannot be framed precisely enough to test.
- C. States the limits, labels assumptions and names the next research question to close the gap.
- D. Copies a competitor's brief, because their research already covers the same market conditions and users.

**Q9.** A brief has a target of 'reduce failed transfers by 20%' but no baseline. What is the most honest next step?
- A. Invent a baseline of 30% so the target looks achievable and the team can start planning work.
- B. State that the baseline is unknown, define how it will be measured, and call the target provisional.
- C. Remove the metric and rely on opinion, because a number nobody can verify invites false confidence.
- D. Change the target to 100% to motivate the team, since ambitious goals usually raise performance.

**Q10.** A problem brief lists 'users need a notification feature' as the problem. What is the specific framing defect?
- A. It is too short to be a problem statement, because a frame needs several sentences to explain context.
- B. It does not mention the colour of the notification, so the team cannot build the screen consistently.
- C. It names a solution before establishing the user situation and the barrier that design should address.
- D. It uses the word users, which is too broad for a brief that must name who is affected.

## 10. Practical task and pass criteria

**Task.** Submit the one-page brief and the 120-word "What I am not solving" note.

**Pass criteria — all must be met:**

- [ ] All ten sections present, in order, on one page.
- [ ] At least one job story and one problem statement with no solution nouns.
- [ ] Every factual claim traceable to evidence or labelled assumption/hypothesis.
- [ ] One primary metric with definition, baseline (or measurement plan) and target.
- [ ] One guardrail and one counter-metric.
- [ ] At least two non-goals with reasons.
- [ ] At least one accessibility risk and one privacy/ethical risk with mitigations.
- [ ] Three open questions.
- [ ] No invented statistics, quotes or baselines.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| A brief that is really a feature list | Features are easier to imagine | Start with the job story; ban solution nouns from the problem statement. |
| Metric with no definition | "Retention" feels obvious | Define exactly who counts, when and how. |
| Scope with no non-goals | Saying no feels negative | Write non-goals with reasons; they protect the scope. |
| Assumptions presented as evidence | Confidence | Use the strength column; label honestly. |
| Ignoring harmful side effects | Focus on the happy path | Add a guardrail and an ethical risk. |
| Brief runs to four pages | Explaining instead of deciding | Cut background; keep decisions and evidence. |
| No baseline | Data is hard to get | Describe how you will measure it before launch. |

**Retry variant.** Rewrite the brief for a **different** problem in the same product: not the confirmation step, but the **failed-transfer recovery** experience. Keep it to one page. Add a "decision I changed after writing v1" paragraph explaining what the new frame revealed. Submit the new brief plus a marked-up version of your first brief showing three cuts.

## 12. Proof artifact for your portfolio

**Artifact:** `Problem-Brief-v1` — stored in `03_Projects/<project>/research`.

This becomes the opening section of your case study. Keep the evidence links; in Stop 7.1 you will need to show how the problem was defined, not just what you designed.

## 13. Low-data and low-cost path

- The brief is text only; no tools are required.
- Use free word processing or markdown.
- The video is optional. The JTBD idea is fully explained above.
- If you cannot interview, use a documented observation or a clearly labelled fictional scenario; state the substitution at the top.

## 14. Watch and read more

**Recommended video (optional, 4:55):** *What is Jobs to Be Done Theory?* — Clayton Christensen Institute. `https://www.youtube.com/watch?v=k01edeNOC_U`. Verified available on 2026-10-30. It is a short institutional explainer; the job story format used here is a course adaptation, not a quote from the video.

**Read (verified 2026-10-30):**

- GOV.UK Service Manual, *User research* — `https://www.gov.uk/service-manual/user-research`. Look for how public services define problems and outcomes before building.
- Nielsen Norman Group, *Problem Statements in UX Discovery* — `https://www.nngroup.com/articles/problem-statements/`. Shows how a problem statement defines scope and what is out of scope; compare it with the job story you write.

## 15. What comes next

Stop 1.4 looks outward: how three real products handle the same job, what they do well, and where users are underserved. That evidence stops you from reinventing a worse version of something that already exists.