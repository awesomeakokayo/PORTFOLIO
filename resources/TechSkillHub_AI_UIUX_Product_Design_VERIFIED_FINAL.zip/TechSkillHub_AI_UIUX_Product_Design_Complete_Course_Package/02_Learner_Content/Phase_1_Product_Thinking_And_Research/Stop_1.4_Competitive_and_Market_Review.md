---
stop_id: 1.4
title: Competitive and Market Review
phase: 1
prerequisites: Stop 1.3
outcome: Audit three real products against the same user job, document patterns and gaps with dated evidence, and use the findings to justify a design direction without copying.
time: 80-110 minutes
artifact: A competitive review with three products, a pattern matrix, a gap analysis and a dated evidence log.
---

# Stop 1.4 — Competitive and Market Review

> **Phase 1 · Product thinking and research** · Prerequisite: Stop 1.3 · Suggested session: 80–110 minutes (can split across two) · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Choose comparable products for a specific user job, not just famous brands.
2. Audit the same task across three products using a consistent pattern matrix.
3. Distinguish a **pattern** from a **feature**, and a **gap** from a **difference**.
4. Record evidence with a date and source so your claims can be checked.
5. Recommend a direction that is informed by competitors without copying them.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Competitive review** | A structured study of products that serve the same or adjacent user job. |
| **Comparable product** | A product a user might realistically choose instead of yours, even if the industry differs. |
| **Direct competitor** | Serves the same job for the same people in a similar way. |
| **Indirect competitor** | Serves the same job differently, for example WhatsApp instead of a booking app. |
| **Substitute** | A non-product behaviour people use instead, such as asking a friend or keeping a paper list. |
| **Pattern** | A repeated solution to a recurring design problem, such as a bottom tab bar or a stepper. |
| **Feature** | A specific capability, such as "save beneficiary" or "schedule transfer". |
| **Heuristic** | A rule of thumb for judging usability, not a law. |
| **Gap** | A user need that the market serves poorly or not at all. |
| **Differentiation** | A deliberate difference that creates value, not difference for its own sake. |
| **Parity** | The features or patterns users expect every product in a category to have. |
| **Benchmark** | A reference point for comparison, often a known good example. |
| **Evidence log** | A dated record of what you observed, where, and how. |
| **Market context** | The conditions around the product: devices, connectivity, payment habits, regulation, language. |
| **Copying** | Reproducing a competitor's visual or interaction design without understanding the job. |

## 3. Why this matters

Competitors are free research. They have already spent money discovering what users expect, what confuses them and what the market will tolerate. A review saves you from designing a worse version of a pattern that already exists, and it shows you where everyone is failing.

But a review can also mislead. Beginners copy the most visible product and call it "best practice". A pattern is not good because it is common; it is good if it serves the job in that context. A bottom tab bar works for five destinations on a phone; it is wrong for a desktop admin tool with forty sections.

> **Everyday example.** A tailor opening a shop looks at other tailors: what they charge, how long they take, how they handle fittings, what customers complain about. They do not copy the shop across the road. They find the gap — perhaps reliable delivery dates — and build around it.

## 4. Before you start

- Use the job from your Stop 1.3 brief. If your brief is about confirming a recipient, your products are payment apps, not "all fintech".
- Choose three products: at least one **direct**, one **indirect or substitute**, and one that is respected for a specific strength (for example, clear error handling).
- Do not create paid accounts, make real purchases, or enter real card details. Use public screens, demo modes or your own existing accounts.
- Create `02_Exercises/1.4_competitive/` with subfolders for each product.

> **Ethics and legality.** Take screenshots for analysis, not for republication. Do not copy logos, illustrations or proprietary content into your portfolio. Do not scrape private data or bypass paywalls. If a product's terms forbid screenshots, describe the screen in words instead.

## 5. Teaching, step by step

### Step 1 — Define the job and the comparison set

Write the job in one sentence, then list products a real person might use to get it done:

> "Confirm I am paying the right person before sending money."
> Products: a bank app, a mobile-money app, a social chat with a payment link, and a cash agent.

Include the **substitute** (cash agent, asking a relative). Substitutes often reveal the real competition: convenience, trust and certainty, not features.

Choose three and say why each is included:

- **Product A:** direct competitor, largest user base.
- **Product B:** direct competitor, known for a different strength (speed, clarity).
- **Product C:** indirect competitor or substitute, reveals a different behaviour.

### Step 2 — Define the task you will audit

A review is only comparable if every product is tested on the same task. Write it precisely:

> "Send ₦5,000 to a new account, from opening the app to seeing a confirmed success state, without using a saved beneficiary."

Record the starting state (new account, no saved beneficiary) and what counts as success. If a product cannot complete the task without a real payment, stop at the confirmation screen and record that limit. Do not spend money to complete a review.

### Step 3 — Build a pattern matrix

Columns are the steps or criteria; rows are the products. Keep it to 8–12 rows.

Example for the transfer job:

| Criterion | Product A | Product B | Product C |
|---|---|---|---|
| Where the recipient name appears | After account number, below field | On a separate confirmation screen | Not shown; agent repeats name verbally |
| Warning before irreversible action | Yes, modal | Yes, inline text | Verbal |
| Loading state | Spinner, no text | Skeleton + "Checking…" | Waiting in queue |
| Failure recovery | "Try again" button | Returns to amount screen, loses input | Agent calls back |
| Fee disclosure | Before confirmation | After confirmation | Stated verbally, variable |
| Accessibility: labels visible | Yes | Placeholder only | N/A |
| Language | English only | English + Pidgin | Local language |

Fill each cell with **what you observed**, not what you assume. If you could not test it, write "not tested" and why.

### Step 4 — Separate pattern, feature and gap

- **Pattern:** "A confirmation screen that repeats the recipient name and amount." (A solution shape.)
- **Feature:** "Save beneficiary." (A capability.)
- **Gap:** "No product lets the sender verify the recipient through a trusted second channel inside the flow." (An unmet need.)

A difference is not automatically a gap. If Product A shows a fee before confirming and Product B shows it after, that is a difference. It becomes a gap only when you can show users are harmed — for example, they abandon when the fee appears late.

### Step 5 — Judge with heuristics, not taste

Use five checks from Nielsen's heuristics:

1. **Visibility of system status:** does the user know what is happening?
2. **Match with the real world:** does the language match how users speak?
3. **User control and freedom:** can the user undo or go back?
4. **Error prevention:** does the design stop mistakes before they happen?
5. **Recognition over recall:** does the user have to remember something the interface could show?

Score each product 1–5 on each, with a one-line justification and a screenshot reference. A score without evidence is an opinion with a number attached.

### Step 6 — Record evidence properly

For every screenshot or observation, log:

```
Date: 2026-11-06
Product: Product A, version 8.2.1, Android 13
Task step: confirmation screen
What I observed: recipient name shown in 14 px grey below the account number
Screenshot: 2026-11-06_productA_confirm.png
Limit: could not test a failed transfer without risking a real payment
```

The date matters because interfaces change. In six months, your review is a historical record, not a current claim.

### Step 7 — Find the underserved space

Write three candidate opportunities, each in this form:

> **[Who]** needs to **[job]** but **[current products fail because]**. A direction worth testing is **[design direction]**, because **[evidence]**.

Example: "First-time senders need to confirm a new recipient without calling them, but all three products show the name in low-emphasis text after the account number. A direction worth testing is a confirmation step that repeats the name in the same visual weight as the amount, because both participants described checking the name separately."

Then apply three filters:

- **Is it real?** Evidence from at least two sources (observation plus interview, or three products plus a complaint).
- **Is it ours to solve?** Within your scope and constraints.
- **Would it matter?** It affects completion, trust, cost or harm.

### Step 8 — Recommend without copying

Write a short direction statement:

> "We will keep the category-standard account-number entry (parity), because users expect it and it reduces learning cost. We will differentiate on confirmation: a full-screen check that shows name, bank and amount at equal weight, with a clear 'this cannot be reversed' warning. We will not copy Product B's animated success screen; it delays the confirmation users need."

This sentence separates **parity** (what you must match to be credible) from **differentiation** (where you choose to be better). It also names what you deliberately reject.

## 6. Worked example (I do)

**Job:** confirm the right recipient before sending money.

**Products:** A (bank app), B (mobile-money app), C (cash agent, substitute).

**Observation, Product A:** The account number field accepts 10 digits, then shows the recipient name in 13 px grey underneath. The name is easy to miss. There is no confirmation screen; the "Send" button is immediately active. A small toast says "Sent" after the action.

**Judgement:** Visibility of system status 2/5 — the success message is brief and does not include the amount. Error prevention 2/5 — the name is present but visually subordinate.

**Observation, Product B:** After entering the account number, a full screen shows the name, bank and amount. The primary button repeats the amount. A warning says "Check the name before you send." There is a spinner with "Checking account…" while the name loads.

**Judgement:** Error prevention 4/5 — the check is unavoidable. Visibility 3/5 — the loading state is clear but slow on a weak connection.

**Observation, Product C (agent):** The customer states the name and number verbally; the agent repeats both; the customer hands over cash and receives a printed receipt. No screen is involved.

**Judgement:** Error prevention 4/5 through human repetition, but visibility 1/5 after the transaction — the receipt is the only record, and it can be lost.

**The insight:** Product C's strength is **repetition by a second party**, not technology. Product B already approximates it with a confirmation screen. The gap is not "add a photo"; it is "make the confirmation unmissable and recoverable". A photo would introduce consent and privacy problems that the evidence does not justify.

**Direction:** parity on account entry, differentiation on a full-screen confirmation with equal-weight name and amount, plus a failure state that preserves the entered details. Do not copy the animated success screen.

**Why this is a review, not a copy:** every recommendation is tied to an observed failure and a user consequence, and one popular idea (photo) is rejected for a stated ethical and evidential reason.

## 7. We do it together

1. Write the job sentence and list six products or substitutes.
2. Choose three and justify each choice in one line.
3. Write the exact task, including the starting state and the success condition.
4. Build an 8-row pattern matrix. Fill it by actually using the products.
5. Mark every cell you could not test as "not tested" with a reason.
6. Score the three products on the five heuristics, with one-line evidence for each score.
7. Build the evidence log with dates and file names.
8. Write three opportunity statements and apply the three filters.
9. Write the parity/differentiation/reject paragraph.

## 8. Your turn (You do)

**Independent task.** Produce a **competitive review** for your own Stop 1.3 job, containing:

1. The job sentence and the comparison set, with a reason for each product.
2. The exact task and starting state.
3. An 8–12 row pattern matrix with "not tested" recorded honestly.
4. Five heuristic scores per product, each with evidence.
5. An evidence log with dates, product versions where visible, and screenshot file names.
6. Three opportunity statements, each filtered for real / ours / matters.
7. A 150-word direction statement separating parity, differentiation and what you deliberately reject.
8. A short "Limits" note: what you could not test, what may have changed, and what you would check next.

**Do not** review three products from the same company, do not use a product you have not opened, and do not recommend a feature simply because a competitor has it.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** What makes a product "comparable" in a competitive review?
- A. A real user might choose it for the same job, including substitutes like a cash agent.
- B. It is famous, because widely used products set the standard that smaller products must match.
- C. It has a similar logo, so users recognise it as part of the same category of products.
- D. It is in the same app store category, where the store groups products that compete directly.

**Q2.** Why must every product be tested on the same task?
- A. Otherwise the observations are not comparable, and the matrix cannot support a conclusion about any product.
- B. To make the table symmetrical, so each product has the same number of cells filled in.
- C. Because users only do one task, so testing more than one would not reflect their behaviour.
- D. To save time, because fewer distinct tasks mean fewer screenshots and notes to organise.

**Q3.** Which is a gap rather than a difference?
- A. Product A uses blue buttons while Product B uses green, and users notice the change immediately.
- B. All three products hide the fee until after confirmation, and users abandon when it appears.
- C. Product A has a dark mode while Product B does not, so night-time use feels harsher.
- D. Product C uses a different font from the others, which some reviewers found harder to read.

**Q4.** What is the purpose of the evidence log's date?
- A. To prove you worked on a certain day, so the review can be credited as your own effort.
- B. To sort screenshots alphabetically, so the folder stays tidy when the review grows larger over time.
- C. To mark the observation as a historical record, because interfaces change after you capture them.
- D. To satisfy app store rules, which require a capture date before a screenshot can be published.

**Q5.** What does "parity" mean in a direction statement?
- A. Matching the expectations users need to trust the product, before you differentiate anywhere else.
- B. Copying every competitor feature, so the product cannot be criticised for missing anything obvious.
- C. Having the same price as the market leader, so users compare the products on design alone.
- D. Using the same colours as competitors, so the product feels familiar the moment it opens.

**Q6.** A competitor has a feature. What is the best reason to include it?
- A. They have it, so users expect it, and its absence would make the product look incomplete beside rivals.
- B. It is easy to build, so the team can ship it quickly without delaying the rest of the release.
- C. It addresses an evidenced user problem within your scope and constraints, at a cost you can bear.
- D. It looks modern, so the interface feels current and reviewers are more likely to praise it.

**Q7.** Which is an indirect competitor for "book a tutor"?
- A. Another tutoring app that lets students search tutors, compare prices and book a lesson directly.
- B. A WhatsApp group where tutors and students arrange lessons by messaging each other directly.
- C. A school that assigns teachers to students and schedules lessons through its own academic timetable.
- D. A textbook that students study alone when no tutor is available to explain the difficult topics.

**Q8.** You cannot complete a transfer without spending money. What should you record?
- A. A guessed result, based on how the flow usually ends in apps with a similar confirmation screen.
- B. A note that the product failed, because stopping before the success screen means the flow could not work.
- C. Not tested up to the confirmation screen, with the limit and the reason stated clearly.
- D. A competitor's screenshot as if it were yours, since the screens look almost identical anyway.

**Q9.** A learner is comparing three money-transfer apps. Which comparison gives the most defensible evidence?
- A. Review each app's marketing page and score the visual style against the other two brands.
- B. Ask friends which brand they like best, then rank the three apps by stated preference.
- C. Compare only the features listed in each app store description, because those lists are standardised.
- D. Run the same transfer task with the same starting conditions in each app, recording steps and failures.

**Q10.** A competitive review tests a different task in each product, then concludes one product has the best checkout. What invalidates the conclusion?
- A. The tasks and starting conditions differ, so the comparison is not controlled across the three products.
- B. Three products is too many to review, so the scores cannot be checked by a second reviewer.
- C. The review did not include screenshots, so nobody can confirm what each checkout screen looked like.
- D. The reviewer used a laptop instead of a phone, so the checkout looked different from the mobile version.

## 10. Practical task and pass criteria

**Task.** Submit the eight-part competitive review.

**Pass criteria — all must be met:**

- [ ] Three products including at least one direct and one indirect/substitute.
- [ ] One precisely defined task and starting state.
- [ ] An 8–12 row pattern matrix with "not tested" where applicable.
- [ ] Five heuristic scores per product, each with evidence.
- [ ] A dated evidence log with screenshot references.
- [ ] Three filtered opportunity statements.
- [ ] A direction statement separating parity, differentiation and rejection.
- [ ] A Limits note naming what could not be tested.
- [ ] No copied logos, illustrations or proprietary content; no real payments.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Reviewing only famous global apps | They are easy to name | Include a local substitute and a product people actually use. |
| Turning the review into a feature list | Features are countable | Audit the same task and record behaviour. |
| Copying the market leader | It feels safe | Separate parity from differentiation; justify each choice. |
| No evidence dates | Screenshots feel permanent | Log date, version and file name. |
| Calling every difference a gap | Differences are visible | Require a user consequence and evidence. |
| Testing with real money | Wanting the full flow | Stop at confirmation; record the limit. |
| A score with no justification | Numbers feel objective | One line of evidence per score. |

**Retry variant.** Review **three products for a different job**: booking a bus or ride from a phone. Include one product that works mainly by WhatsApp or phone call. Produce the same eight parts, but add a "market context" paragraph (100 words) on device, data, payment and trust conditions that change what "good" means. Submit the new review plus a corrected version of one heuristic score from your first attempt, with the missing evidence supplied.

## 12. Proof artifact for your portfolio

**Artifact:** `Competitive-Review-v1` — stored in `03_Projects/<project>/research`.

In your case study, this review shows you did not design in a vacuum. Keep the screenshots out of public portfolio pages unless you have permission; use your own redrawn diagrams instead.

## 13. Low-data and low-cost path

- Use products already installed on your phone.
- Take screenshots at the moment of use, then work offline.
- If data is very low, review two products in depth and one by description, and say so.
- The video is optional. The matrix and evidence log are the lesson.
- Do not create paid accounts or make purchases; the review stops at the confirmation screen.

## 14. Watch and read more

**Recommended video (optional, 7:08):** *Competitive Analysis Guide for UX Designers* — Pierluigi Giglio. `https://www.youtube.com/watch?v=Vl0m3Y3hg80`. Verified available on 2026-10-30. It is an independent practitioner guide; the matrix and evidence-log structure in this lesson are the course's own.

**Read (verified 2026-10-30):**

- Nielsen Norman Group, *Competitive Usability Evaluations: Definition* — `https://www.nngroup.com/articles/competitive-usability-evaluations/`. Explains how to compare products on the same task and why evidence beats opinion.
- GOV.UK Design System — `https://design-system.service.gov.uk/`. A strong example of documented patterns with reasons, useful for seeing what good pattern documentation looks like.

## 15. What comes next

**Gate 1** requires a problem brief backed by at least five real user conversations and a competitive review. Read `03_Assessments/Learner/Phase_1_Gate.md`. No invented personas. Phase 2 then begins the craft: layout, type, colour, components, states and accessibility.