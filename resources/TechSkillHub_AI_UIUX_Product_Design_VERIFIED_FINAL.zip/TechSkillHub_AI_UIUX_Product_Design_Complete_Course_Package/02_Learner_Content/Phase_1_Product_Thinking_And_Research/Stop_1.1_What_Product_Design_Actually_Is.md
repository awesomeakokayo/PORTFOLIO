---
stop_id: 1.1
title: What Product Design Actually Is
phase: 1
prerequisites: Phase 0 gate passed
outcome: Distinguish research, UX, UI and business decisions in real products, and explain how a product designer connects a user problem to a business goal.
time: 45-60 minutes
artifact: A ten-item classification table (research / UX / UI / business) with a one-line justification for each, plus a short definition of product design in your own words.
---

# Stop 1.1 — What Product Design Actually Is

> **Phase 1 · Product thinking and research** · Prerequisite: Phase 0 gate · Suggested session: 45–60 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Define product design without using the words "make it look nice".
2. Separate a **problem** from a **solution**, and a **user need** from a **business goal**.
3. Classify ten real product decisions as research, UX, UI or business.
4. Explain where UI and UX sit inside product design, and why the boundaries are fuzzy in real teams.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Product** | Anything people use to get a job done: an app, a website, a service, even a form at a bank. |
| **Product design** | Deciding what to build, for whom, why, and how it should work and feel — then proving it works. |
| **User** | The person who uses the product to achieve something. Not always the person who pays. |
| **Customer** | The person or organisation that pays. Sometimes the same as the user, sometimes not. |
| **Stakeholder** | Anyone affected by or interested in the product: users, buyers, support staff, regulators, the business owner. |
| **Problem** | A gap between what someone needs to do and what they can currently do. |
| **Solution** | A specific thing you build to close that gap: a screen, a flow, a feature, a policy. |
| **UX (user experience)** | The whole experience of using the product, including speed, trust, clarity and what happens when things go wrong. |
| **UI (user interface)** | The visible and interactive layer: layout, type, colour, components, states. |
| **Business goal** | What the organisation needs: revenue, retention, lower support cost, compliance, reputation. |
| **Constraint** | A limit you cannot ignore: budget, timeline, regulation, device, bandwidth, team skill. |
| **Trade-off** | Giving up something to gain something else, such as speed versus completeness. |
| **Success metric** | A measurable sign that the product is doing its job. |
| **Scope** | What is inside this version and what is deliberately outside it. |

## 3. Why this matters

Beginners often start with a screen. Professionals start with a situation. "Design a food delivery app" is a solution looking for a problem. "Students near campus cannot tell how long a delivery will take, so they order from whoever answers first and often get cold food" is a problem you can research, design for and measure.

Product design sits between three pressures:

- what **users** need to do;
- what the **business** needs to survive;
- what **technology and constraints** allow.

A design that ignores users fails adoption. A design that ignores the business fails funding. A design that ignores constraints ships late or not at all. The designer's job is not to satisfy one pressure perfectly; it is to find a defensible balance and explain it.

> **Everyday example.** A neighbourhood pharmacy adds a WhatsApp ordering option. The UI is just a chat and a price list. The UX is whether a customer can order, pay, and know when to collect without calling three times. The business goal is fewer phone interruptions and more repeat customers. The product design question is not "what colour is the button?" but "where does trust break in this flow, and what is the smallest change that fixes it?"

## 4. Before you start

- Have your three teardown screenshots from Stop 0.3.
- Open a notes document with a table of four columns: Decision, Type, Why, Evidence.
- Accept that the categories overlap. You are learning to notice the dominant type, not to put every decision in a perfect box.

## 5. Teaching, step by step

### Step 1 — Start with the situation, not the screen

Write a situation sentence with four parts:

> **[Who]** is trying to **[do what]** but **[what gets in the way]**, which matters because **[consequence]**.

Example: "A first-time online shopper in Enugu is trying to pay for a ₦12,000 order but cannot tell whether the payment went through, which matters because they either pay twice or abandon the order."

Notice that no screen is mentioned. That is deliberate. Once the situation is clear, screens become one of several possible responses.

### Step 2 — Separate problem from solution

A problem statement contains no product nouns. If it contains "app", "button", "dashboard" or "AI", it is probably a solution in disguise.

| Solution in disguise | Problem underneath |
|---|---|
| "Users need a chatbot." | "Users cannot find the answer to a billing question in under five minutes." |
| "Add a progress bar." | "Users abandon the form because they cannot tell how much is left." |
| "Make a dashboard." | "Managers cannot see which branch is falling behind until the monthly report." |

The underlying problem allows several solutions. A better search, a clearer FAQ, or a shorter form might beat a chatbot. That is the value of separating them.

### Step 3 — Put UX, UI and product design in one sentence each

- **UX** asks: can the user complete the job with minimum friction, confusion and risk?
- **UI** asks: is the interface clear, consistent and accessible enough to support that job?
- **Product design** asks: should we build this at all, for whom, and how will we know it worked?

A useful analogy: UX is the route, UI is the signage and road surface, product design is deciding whether to build a road, a bridge or a bus route — and whether the destination is worth reaching.

### Step 4 — Name the business goal honestly

Every product has a business model, even a free one. Common goals:

- **Revenue:** subscriptions, commissions, ads.
- **Retention:** people come back.
- **Acquisition:** people sign up.
- **Cost reduction:** fewer support calls, fewer failed deliveries.
- **Risk and compliance:** avoid fraud, meet regulation.
- **Reputation:** trust, brand, public interest.

Write the goal as a sentence, not a slogan: "Reduce failed transfers caused by mistyped account numbers by making the recipient name visible before confirmation."

### Step 5 — Classify decisions by dominant type

Use these tests:

| If the decision is mainly about… | Classify as |
|---|---|
| Learning what users do, need or believe | Research |
| The flow, logic, information or effort | UX |
| The visual and interactive layer | UI |
| Money, risk, staffing, priorities or rules | Business |

Some decisions are genuinely mixed. Write the dominant type and note the second type in the "Why" column. For example, "Move the fee disclosure above the pay button" is UX-first, with a business/regulatory component.

### Step 6 — Find the trade-off

For every design decision, ask: *what does this make better, and what does it make worse?*

- A shorter signup form increases completion but may reduce fraud checks.
- A bigger "Buy now" button increases conversion but can feel pushy and damage trust.
- Hiding advanced settings simplifies the screen but can frustrate expert users.
- Adding a loading spinner clarifies waiting but does not shorten it.

If you cannot name a trade-off, you have not understood the decision yet.

### Step 7 — Tie the work to evidence

A product decision should be traceable to something: an interview, an observation, a support ticket, a metric, a legal requirement, or a documented assumption. "I think users will like it" is a hypothesis, not evidence. Label it as a hypothesis and plan how to test it. You will do this formally in Stop 1.3.

## 6. Worked example (I do)

**Situation:** A fictional Lagos-based tutoring service, `LearnLoop`, has a WhatsApp group where students ask for lessons. The owner wants an app.

**My analysis, spoken aloud:**

1. The request is a solution ("an app"). I ask what happens today. Students message at all hours; the owner replies manually; payment is by transfer; some students are forgotten; lessons are sometimes double-booked.
2. The problem is not "no app". It is "booking and payment are manual, so the owner loses track and students lose confidence".
3. The business goal is fewer admin hours and fewer missed lessons, not "an app".
4. A smaller solution might be a booking form plus a payment link plus a shared calendar. An app might be right later. The product design question is what to build **first**.
5. Classification of decisions:
   - Interview five students about how they choose a tutor — **research**.
   - Decide that a booking is confirmed only after payment — **UX and business**.
   - Design the booking form with a visible price and time slot — **UI**.
   - Choose to charge a deposit to reduce no-shows — **business**.
6. Trade-off: requiring prepayment reduces no-shows but may lose students who want to pay after the lesson. The evidence needed is how many students abandon at the payment step, and why.

**What a weak analysis would look like:** "Students need an app with a chat, a calendar and payments, in green because education apps are green." It starts with a solution, skips the evidence and cannot explain a trade-off.

## 7. We do it together

1. Pick one screen from your Stop 0.3 teardown.
2. Write its situation sentence using the four-part pattern.
3. List five decisions that shaped that screen. Examples: where the primary button sits, whether the fee is shown before or after tapping, whether the field has a label, whether the app asks for a phone number.
4. Classify each decision as research, UX, UI or business. Add a second type where relevant.
5. For each, write one sentence of evidence or mark it "assumption".
6. Name one trade-off the screen's designer made.
7. Rewrite the screen's purpose as a business goal sentence and a user goal sentence. Notice where they conflict.

## 8. Your turn (You do)

**Independent task.** Build a **ten-decision classification table** from **three different real products** (not only the one you analysed together). For each decision:

| # | Product | Decision | Type | Why (one line) | Evidence or assumption |
|---|---|---|---|---|---|

Rules:

- At least two decisions must be classified as **research**, two as **UX**, two as **UI**, and two as **business**.
- At least three decisions must be **mixed**, with the dominant type named and the secondary type noted.
- At least two decisions must be things the product **chose not to do** (for example, no guest checkout), because omissions are decisions too.
- For each product, write one sentence naming a trade-off.

Then write a 150-word answer to: *"What does a product designer actually decide that a UI designer does not?"* Use at least five terms from the glossary.

**Do not** use the LearnLoop example, and do not classify everything as "UX" — if all ten are UX, you have not distinguished the types.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** Which sentence is a problem statement rather than a solution?
- A. Users need a chatbot on the home screen so they can get answers without waiting for an email reply.
- B. Customers cannot tell whether their payment succeeded, so they either pay twice or abandon the order.
- C. Add a progress bar to checkout so customers can see how many steps remain before they pay.
- D. Build a dashboard for managers so they can compare branch performance before the monthly finance report.

**Q2.** What is the main difference between UX and UI?
- A. UI is only for mobile apps, while UX is only for websites that people use on a laptop.
- B. UX is done by researchers, while UI is done by developers who turn the files into code.
- C. There is no practical difference between the two terms, because both describe how a screen looks.
- D. UX is the whole experience of completing the job, while UI is the visible and interactive layer.

**Q3.** "Reduce support calls about failed transfers by 20%." What kind of goal is this?
- A. A user goal, because it describes what a customer wants to achieve when sending money.
- B. A UI pattern, because support calls usually drop when the confirmation screen is redesigned.
- C. A business goal with a measurable target, because it names an organisational outcome and a number.
- D. A research method, because it requires interviews with customers before the number can be set.

**Q4.** A team decides to hide advanced settings to simplify the first-run experience. What is the trade-off?
- A. Faster to build for the team, but more expensive to host once the simplified screens finally ship.
- B. Better accessibility for screen readers, but worse performance on older phones with slow connections.
- C. No real trade-off, because simplification only removes clutter and never costs any user anything.
- D. Simpler for beginners, but potentially frustrating for experts who rely on those settings daily.

**Q5.** Which decision is primarily **research**?
- A. Choosing the primary button colour so the call to action stands out against the booking form.
- B. Setting the commission rate so drivers earn enough to stay on the platform through the year.
- C. Interviewing five drivers about how they decide when to accept a trip on a busy evening.
- D. Writing the error message for a failed card payment so customers know what to try next.

**Q6.** Which is a **constraint**, not a goal?
- A. The team aims to increase retention by 15%, so more customers return and order again next quarter.
- B. The team wants to become the market leader in the city before any competitor establishes itself.
- C. The product must work on 2G connections and low-end Android phones sold in the local market.
- D. The team wants to improve trust so first-time users feel safe entering their card details.

**Q7.** Why is "the product chose not to offer guest checkout" a design decision?
- A. Because omissions never matter, since users only judge what they can see on the checkout screen.
- B. Because it is a UI colour choice that changes how the checkout button looks to returning users.
- C. Because what a product refuses to do shapes effort, privacy and conversion as much as what it adds.
- D. Because competitors already do it, so matching them proves the decision was made deliberately and safely.

**Q8.** A designer says "users will love this". What is missing?
- A. A colour palette that matches the brand and makes the new feature feel familiar to returning users.
- B. Evidence or an explicit hypothesis with a plan to test whether users actually respond that way.
- C. A Figma file that shows the feature in each state so the team can review the interaction.
- D. A business model that explains who pays for the feature and what it costs to run each month.

**Q9.** A team is deciding to add a saved-recipient list, measure transfer completion, and change the confirmation button colour. How should these be classified?
- A. Product/UX decision, business or product metric, and UI decision respectively, in that same order.
- B. All three are UI decisions because each one appears on a screen that users interact with.
- C. All three are research decisions, because each one involves learning something from real users.
- D. The list is a metric, completion is UI, and colour is research into what users prefer.

**Q10.** A brief says the team must 'increase revenue by 15%' and calls that the user problem. What is wrong with the framing?
- A. Revenue targets are always forbidden in a brief, because designers cannot influence how money is earned.
- B. The percentage is too precise, so the brief should round it to a range the team can remember.
- C. The brief lacks a colour palette, so the team cannot tell which direction the design should take.
- D. A business outcome is being substituted for the user problem the design can actually address.

## 10. Practical task and pass criteria

**Task.** Submit the ten-decision table, the three trade-off sentences and the 150-word answer.

**Pass criteria — all must be met:**

- [ ] Ten decisions from at least three real products.
- [ ] At least two of each type: research, UX, UI, business.
- [ ] At least three mixed decisions with dominant and secondary type.
- [ ] At least two omissions treated as decisions.
- [ ] Evidence or "assumption" recorded for every row, with no invented statistics.
- [ ] One trade-off sentence per product.
- [ ] The 150-word answer uses at least five glossary terms correctly.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Starting with "make an app" | Apps feel like the unit of design | Write the situation sentence first; list three non-app responses. |
| Calling every decision UX | UX is the widest term | Use the dominant-type test; note secondary types. |
| Inventing a statistic to support a point | Numbers feel persuasive | Write "assumption" and plan a check. Fabrication is a critical issue. |
| Ignoring the business model | Beginners focus on users | Ask "who pays, and what does this cost them?" |
| Treating constraints as excuses | Constraints feel negative | Constraints are design material; they force better trade-offs. |
| No trade-off named | It feels like criticism | Every choice gives something up; naming it shows judgment. |

**Retry variant.** Classify ten decisions from **one** product across its full journey (signup, first use, repeat use, failure, cancellation). Ensure at least one decision is about **pricing or policy**, not interface. Write a 120-word paragraph on which type of decision was hardest to classify and why. Submit the new table plus a corrected row from your first attempt.

## 12. Proof artifact for your portfolio

**Artifact:** `Decision-Types-Table` — stored in `03_Projects/00_Foundations/product-thinking`.

In Stop 7.1 you will reuse this skill to explain the decisions in your case study, so keep the table format.

## 13. Low-data and low-cost path

- No video is required.
- Use apps already installed on your phone; no new accounts.
- The table can be handwritten and photographed.
- If you cannot access three products, use three distinct flows within one product and say so.

## 14. Watch and read more

**Recommended video (optional, 5:23):** *What EXACTLY is Product Design?* — Andres The Designer. `https://www.youtube.com/watch?v=LckQ4VVjHDs`. Verified available on 2026-10-30. It is one practitioner's view, not a standard; the boundaries between UX, UI and product design differ by company.

**Read (verified 2026-10-30):**

- Nielsen Norman Group, *Setting UX Roles and Responsibilities in Product Development* — `https://www.nngroup.com/articles/ux-roles-responsibilities/`. Shows how product designers, researchers, UX designers and product managers divide research, design and business decisions.
- Nielsen Norman Group, *Product and UX: Study Guide* — `https://www.nngroup.com/articles/product-and-ux-study-guide/`. A curated starting point for how product thinking and UX work fit together.

## 15. What comes next

Stop 1.2 teaches you to find out what people actually do, instead of guessing. You will learn interviews, observation and surveys, and the specific mistake that ruins most beginner research: the leading question.