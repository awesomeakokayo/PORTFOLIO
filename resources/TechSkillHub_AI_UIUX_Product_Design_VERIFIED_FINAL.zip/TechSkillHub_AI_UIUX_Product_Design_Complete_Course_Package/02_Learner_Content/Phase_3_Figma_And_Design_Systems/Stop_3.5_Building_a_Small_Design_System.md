---
stop_id: 3.5
title: Building a Small Design System
phase: 3
prerequisites: Stop 3.4
outcome: Build and document a small design system with tokens, ten components with variants, usage guidance and a versioning rule, and apply it to a real screen.
time: 120-150 minutes across two sessions
artifact: A mini design system file: token pages, ten documented components, a documentation page and one screen built only from system components.
---

# Stop 3.5 — Building a Small Design System

> **Phase 3 · Figma fluency and design systems** · Prerequisite: Stop 3.4 · Suggested session: two sittings of 60–75 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Define a token set for colour, type, spacing, radius and elevation.
2. Build ten components with variants that cover real product needs.
3. Document each component with anatomy, usage, do/don't, accessibility and content rules.
4. Apply the system to a screen without local overrides.
5. Version and govern the system so it does not drift.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Design system** | A shared set of decisions, components and rules used to build products consistently. |
| **Token** | A named value for a design decision: colour, type, spacing, radius, shadow. |
| **Primitive token** | A raw value, such as `space.16` or `blue.600`. |
| **Semantic token** | A role that points to a primitive, such as `color.text.secondary`. |
| **Component library** | The published set of components available to a team. |
| **Documentation** | The guidance that explains when and how to use a component. |
| **Anatomy** | The named parts of a component. |
| **Usage guidance** | Rules for when to use, when not to use, and what to avoid. |
| **Governance** | Who can change the system, how changes are reviewed, and how versions are released. |
| **Adoption** | How much of the product actually uses the system. |
| **Drift** | The gap between the system and the product as people make local changes. |
| **Contribution** | A process for adding or changing a component from outside the core team. |
| **Deprecation** | Retiring a component or token while giving teams time to migrate. |
| **Versioning** | Naming and recording changes so teams know what changed and when. |
| **Accessibility annotation** | Notes on roles, labels, contrast and keyboard behaviour attached to a component. |
| **Single source of truth** | The one place where the current decision lives. |

## 3. Why this matters

A design system is not a component library with a nice cover. It is a set of **decisions with reasons**, encoded so they can be reused. The components are the visible part; the tokens and rules are the substance.

For a beginner, a small system is the fastest way to look and work like a professional. Instead of designing each screen from scratch, you compose from tested parts. Instead of arguing about a colour, you point to a token and its contrast ratio. Instead of a developer guessing, you hand over names that map to code.

> **Everyday example.** A tailor with a set of standard measurements, patterns and fabric rules can make a consistent uniform for a whole school. A tailor who starts from scratch for each student produces beautiful one-offs that do not match. A design system is the pattern set.

## 4. Before you start

- Have your Stop 3.3 component set and variables.
- Choose **ten** components that your product actually uses. A suggested set:
  1. Button
  2. Text field
  3. Select
  4. Checkbox / radio
  5. Card
  6. List row
  7. Badge / status
  8. Banner / alert
  9. Bottom navigation
  10. Modal / dialog
- Create a new Figma file `05_Mini-Design-System`. Do not build inside the product file; the system should be reusable.

## 5. Teaching, step by step

### Step 1 — Write the principles first

Five short principles, each with a consequence:

1. **Clarity before decoration.** Consequence: no decorative element may reduce label contrast.
2. **One primary action per view.** Consequence: the button set allows one filled primary per section.
3. **Accessible by default.** Consequence: every component ships with a focus state and AA contrast.
4. **Designed for low bandwidth.** Consequence: no component depends on a large image or web font to be usable.
5. **Composable, not clever.** Consequence: components use properties and slots, not bespoke one-offs.

Principles are only useful if they change a decision. If a principle never causes you to reject something, delete it.

### Step 2 — Build the token layers

**Primitives:**

```
color.blue.600, color.blue.100, color.grey.900 ... 
space.4, space.8, space.12, space.16, space.24, space.32, space.48
radius.4, radius.8, radius.12, radius.999
font.size.13, 16, 20, 24, 32, 40
font.weight.regular, medium, semibold, bold
shadow.1, shadow.2
```

**Semantics:**

```
color.text.primary, color.text.secondary, color.text.disabled
color.surface.default, color.surface.raised, color.surface.subtle
color.border.default, color.border.strong, color.border.focus
color.action.primary, color.action.on-primary, color.action.secondary
color.feedback.success, color.feedback.warning, color.feedback.danger, color.feedback.info
space.inline.xs/sm/md, space.stack.sm/md/lg, space.inset.sm/md/lg
```

Two layers, because primitives are the palette and semantics are the meaning. Components use semantics only.

### Step 3 — Build the ten components to a consistent template

For each component, create:

- a main component and variants;
- a 16 px grid layout on the documentation page;
- a title and a one-line purpose;
- an anatomy diagram with numbered parts;
- states shown in a row;
- a do/don't pair;
- accessibility notes;
- content rules (length, case, tone).

Consistency in documentation matters as much as consistency in components. A reader should be able to compare components quickly.

### Step 4 — Define component APIs

An API is what an instance can change. For each component, list:

| Component | Properties | Slots |
|---|---|---|
| Button | type, state, size, label, icon | leading icon |
| Text field | state, label, helper, error | leading/trailing icon |
| Card | variant (default/interactive), media | body, actions |
| Banner | tone (info/success/warning/danger), dismissible | message, action |
| Modal | size, dismissible | title, body, actions |

A component with too many properties is hard to use; one with too few forces overrides. Aim for the smallest set that covers real cases.

### Step 5 — Document usage, not just appearance

Each component page should answer:

1. **When to use it.**
2. **When not to use it, and what to use instead.**
3. **How it behaves with long content, no content and errors.**
4. **What it looks like on mobile and desktop.**
5. **What a developer needs to know.**
6. **What is accessible by default, and what the implementer must add.**

Example for Banner:

- Use for page-level status that persists until resolved.
- Do not use for transient confirmation; use a toast.
- Long messages wrap; the action moves below the text at narrow widths.
- Provide `role="status"` for polite updates and `role="alert"` for errors, depending on urgency.
- Do not rely on colour; include an icon and a text label.

### Step 6 — Compose one screen from the system only

Build a real screen using only system components. If you need something that does not exist, you have two choices:

1. Add it to the system (if it will recur).
2. Use a documented exception (if it is genuinely one-off).

Do not detach a component and call it a screen. That is how drift starts.

### Step 7 — Version and govern

Write a short governance page:

- **Owner:** who maintains the system (for this course, you).
- **Versioning:** `major.minor.patch`. Major for breaking changes, minor for additions, patch for fixes.
- **Change log:** date, version, what changed, why, migration note.
- **Review:** who approves a change and what evidence is required.
- **Deprecation:** how long an old component stays available and what replaces it.
- **Contribution:** how someone proposes a new component, with a checklist.

Even a one-person system needs this, because future-you is a different person with no memory of today's decisions.

### Step 8 — Measure adoption and drift

On the product screen, count:

- components used from the library;
- local overrides;
- detached instances;
- one-off colours or spacing values.

A simple adoption table:

| Screen | System components | Overrides | Detached | One-off values |
|---|---|---|---|---|
| Transfer confirm | 8 | 2 (amount size) | 0 | 1 (warning colour) |

The goal is not zero overrides; some are legitimate. The goal is to know where they are and why.

## 6. Worked example (I do)

**System name:** `Kudi UI` (fictional practice system).

**Principles:** clarity, one primary action, accessible by default, low bandwidth, composable.

**Tokens (excerpt):**

```
color.action.primary      → blue.600   #1D4ED8
color.action.on-primary   → white      #FFFFFF
color.text.primary        → grey.900   #111827
color.text.secondary      → grey.600   #4B5563
color.feedback.danger     → red.700    #B91C1C
space.inset.md            → 16
space.stack.lg            → 24
radius.control            → 12
```

**Components:** Button, Text field, Select, Checkbox, Card, List row, Badge, Banner, Bottom nav, Modal.

**Button documentation (excerpt):**

- **Purpose:** triggers an action.
- **Anatomy:** 1 container, 2 label, 3 optional leading icon.
- **Properties:** type, state, size, label, icon.
- **Use:** one primary per section; verb-first labels; destructive actions use the danger type with confirmation.
- **Don't:** two primaries side by side; "OK"; icon-only without an accessible name.
- **Accessibility:** 44 px minimum height; 4.5:1 label contrast; 2 px focus ring; `disabled` uses `aria-disabled`, not just colour.
- **Content:** sentence case, maximum 24 characters on mobile; if longer, shorten the label or move detail to the body.

**Composition:** the transfer confirmation screen uses Button (primary), List row ×2, Banner (warning), and Text (body). No local colour values. One override: the amount uses `font.size.40`, which is a system token, so it is not a one-off.

**Adoption:** 9 system components, 0 detached, 0 raw hex values, 1 legitimate override (amount emphasis).

**Governance:** v1.0.0 on 2026-11-10; owner: me; change log records the initial release; contribution requires a use case, a variant proposal and an accessibility check.

## 7. We do it together

1. Create the `05_Mini-Design-System` file and a cover page with principles.
2. Create token pages: Colour, Type, Spacing, Radius, Elevation.
3. Build the ten components, starting with the ones your screen needs.
4. For each, add a documentation section using the template.
5. Compose one screen from the system only.
6. Run the adoption count and record overrides.
7. Write the governance page with version, owner, change log and contribution rule.
8. Publish the library to your own drafts (or document how you would publish it).
9. Ask one person to find a component using only your documentation. Note where they struggled.
10. Fix the documentation, not the person.

## 8. Your turn (You do)

**Independent task.** Build and document a **mini design system** for your project.

Submit:

1. Five principles, each with a consequence.
2. Token pages with primitives and semantics (at least 20 primitives, 15 semantics).
3. Ten components with variants and properties.
4. A documentation section for each component covering purpose, anatomy, use, don't, accessibility, content and developer notes.
5. One screen composed only from system components.
6. An adoption table with overrides and detached instances counted.
7. A governance page: owner, versioning, change log, review, deprecation, contribution.
8. A 200-word reflection on the hardest component to document and why.

**Do not** include components you do not use. Do not document only appearance. Do not hide overrides; count them.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** What is the difference between a primitive and a semantic token?
- A. A primitive is a raw value, while a semantic token names a role and aliases it.
- B. A primitive is used for colour only, while semantics cover spacing and type.
- C. A semantic token is always darker, so it reads correctly on every surface.
- D. There is no difference, because both resolve to the same value in code.

**Q2.** What should component documentation include beyond appearance?
- A. Only a screenshot of the component in its default state, with a caption.
- B. Purpose, use, don't, accessibility, content and developer notes for each component.
- C. The designer's name and the date the component was last edited.
- D. The file size and the number of layers the component contains.

**Q3.** What is design system drift?
- A. A file becoming corrupted, so components no longer open correctly.
- B. A colour fading over time, so the palette gradually loses contrast.
- C. The gap between the system and the product as local changes accumulate.
- D. A component moving on the canvas, so the layout no longer aligns.

**Q4.** Why have a governance page for a one-person system?
- A. Because Figma requires a governance page before a library can be published.
- B. Because future-you will not remember today's decisions, and the system may be handed over.
- C. To increase the page count, so the file looks more thorough to reviewers.
- D. To satisfy clients only, since internal teams rarely read governance pages.

**Q5.** A screen needs a one-off component. What are the two legitimate options?
- A. Detach a component from the library and adapt it until it fits the screen.
- B. Use a raw hex value for that one element and record nothing about it.
- C. Add it to the system if it recurs, or document it as an exception.
- D. Copy a similar component from another product, then rename it locally to fit.

**Q6.** What does an adoption table reveal?
- A. How many pages the file contains, and which ones are out of date.
- B. How much of the product uses the system, and where overrides live.
- C. The total number of distinct colours used anywhere in the file.
- D. The number of contributors who have edited the library this month.

**Q7.** Why are principles only useful if they change a decision?
- A. Because Figma limits how much text a principles page can hold.
- B. Because clients dislike principles and prefer to see finished screens.
- C. Otherwise they are decoration and cannot guide real trade-offs in the work.
- D. Because principles must be numeric, so each one can be measured.

**Q8.** What does deprecation mean in a design system?
- A. Deleting a file without notice, so nobody keeps using the old version.
- B. Retiring a component or token while giving teams time to migrate.
- C. Renaming a colour, so the old name no longer appears in the index.
- D. Adding a variant, so the component covers one more state or size.

**Q9.** A team changes its primary colour in 12 separate components and misses two. What should the system have provided?
- A. A semantic colour token or variable that all components reference.
- B. A longer brand guidelines PDF, with the new colour specified precisely.
- C. More one-off components for each screen, so each can be edited separately.
- D. A rule that designers must remember all 12 places and check them.

**Q10.** A design system page lists component names and pictures but no usage rules. What is the main documentation gap?
- A. More decorative illustrations, so the page feels finished and on brand.
- B. Guidance on when to use each component, its states, content rules and accessibility.
- C. A larger logo, so readers recognise which team owns the system.
- D. A list of every file the team has made since the system started.

## 10. Practical task and pass criteria

**Task.** Submit the system file link and the documentation PDF.

**Pass criteria — all must be met:**

- [ ] Five principles, each with a consequence.
- [ ] 20+ primitives and 15+ semantic tokens.
- [ ] Ten components with variants and documented properties.
- [ ] Documentation covers purpose, anatomy, use, don't, accessibility, content and developer notes.
- [ ] One screen composed only from system components.
- [ ] Adoption table with overrides and detached instances counted.
- [ ] Governance page with version, owner, change log, review, deprecation and contribution.
- [ ] Reflection identifies a real documentation difficulty.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| A component library with no documentation | Components feel like the hard part | Document purpose, use, don't and accessibility. |
| Tokens named by appearance | Easier to generate | Name by role; alias primitives. |
| Ten components nobody uses | Completeness as a goal | Build what the screen needs; add only recurring parts. |
| Hiding overrides | It feels like failure | Count them; some are legitimate. |
| No governance | It feels bureaucratic | Write a one-page rule set; future-you needs it. |
| Detaching to compose | It is quick | Use slots, properties or a documented exception. |
| Docs that only show screenshots | Visuals are easy | Add decisions, rules and developer notes. |

**Retry variant.** Build a **second theme** (high-contrast or dark) for your system using variable modes, and document which components required structural changes. Submit the themed system, a migration note for developers and a 150-word reflection on what the theme revealed about hidden assumptions.

## 12. Proof artifact for your portfolio

**Artifact:** `Mini-Design-System-v1` — the file and documentation, stored in `03_Projects/<project>/design-system`.

This is a headline portfolio artifact. In Stop 7.1 you will write about the decisions behind it, not just show it.

## 13. Low-data and low-cost path

- Build one theme and ten components; skip the second theme if time is short.
- Use text-only documentation; no screenshots required.
- The video is optional and 15 minutes; the token structure and documentation template above are the lesson.
- If variable modes are unavailable, document the intended values and the limitation.

## 14. Watch and read more

**Recommended video (optional, 14:57):** *Your First Design System in Figma (Beginner Tutorial)* — Tim Gabe. `https://www.youtube.com/watch?v=_uva2dQPlV8`. Verified available on 2026-10-30. Published in 2023; Figma's variables interface has changed since, so use the Help Centre for current steps.

**Read (verified 2026-10-30):**

- Figma Help, *Guide to variables in Figma* — `https://help.figma.com/hc/en-us/articles/15339657135383-Guide-to-variables-in-Figma`.
- GOV.UK Design System — `https://design-system.service.gov.uk/`. A strong model for documentation, contribution and accessibility notes.
- Material Design 3 — `https://m3.material.io/`. Token structure and component anatomy at scale.

## 15. What comes next

**Gate 3** requires the mini design system plus a clickable prototype that uses it. Read `03_Assessments/Learner/Phase_3_Gate.md`. Phase 4 then puts AI into the workflow — as an accelerator you supervise, not an authority you obey.