---
stop_id: 3.3
title: Components, Variants and Variables
phase: 3
prerequisites: Stop 3.2
outcome: Build a component set with variants and properties, and connect colour, type and spacing decisions to variables so themes and states can change systematically.
time: 90-120 minutes
artifact: A button component set (3 variants × 4 states × 2 sizes) using variables, plus a one-page explanation of properties and naming.
---

# Stop 3.3 — Components, Variants and Variables

> **Phase 3 · Figma fluency and design systems** · Prerequisite: Stop 3.2 · Suggested session: 90–120 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Create a main component and use instances without detaching.
2. Build a component set with variants for type, size and state.
3. Add component properties: boolean, text, instance swap and variant.
4. Create variables for colour, number, string and boolean values.
5. Use variable modes for light and dark themes.
6. Name components and variables so another designer can find and use them.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Main component** | The original object that defines a component's structure. |
| **Instance** | A linked copy that inherits the main component's structure. |
| **Override** | A change made to an instance without changing the main. |
| **Detach** | Breaking the link between an instance and its main component. |
| **Component set** | A group of variants that share a name and can be swapped. |
| **Variant** | One version within a set, defined by properties such as state or size. |
| **Property** | A controllable attribute of a component: variant, boolean, text or instance swap. |
| **Boolean property** | A true/false switch, often used to show or hide an icon. |
| **Text property** | A property that lets an instance change a text layer's content. |
| **Instance swap** | A property that lets an instance replace a nested component, such as an icon. |
| **Variable** | A named, reusable value that can be applied to fills, strokes, text, effects or spacing. |
| **Collection** | A group of variables, often by theme or purpose. |
| **Mode** | A set of variable values, such as light or dark. |
| **Alias** | A variable that points to another variable, creating a semantic layer. |
| **Primitive token** | A raw value such as `blue.600` or `space.16`. |
| **Semantic token** | A role such as `color.action.primary` that aliases a primitive. |
| **Scoping** | Limiting where a variable can be used, to prevent mistakes. |
| **Theming** | Swapping modes to change appearance without editing components. |

## 3. Why this matters

Without variants, a button with three types, four states and two sizes becomes 24 separate components. Change the corner radius and you edit 24 objects. With a component set, it is one structure with properties; change the radius once and every variant follows.

Variables go further. A colour variable can hold `#1D4ED8` in light mode and `#93C5FD` in dark mode. The button points to `color.action.primary`; the theme decides the value. You can ship a dark mode without redesigning every component.

This is also how design systems scale to code. In Stop 5.3 you will export the same token names to CSS variables. If your Figma names are chaotic, your code will be too.

> **Everyday example.** A restaurant menu with "rice, beans, plantain" as separate items forces you to order three plates. A menu with "rice + choose one protein + choose one side" is a component with properties. Same kitchen, far fewer combinations to manage.

## 4. Before you start

- Open your Stop 3.2 file.
- Create a page `04_Components`.
- Decide your naming convention before building. Recommended: `Category/Type/Property=Value`.

## 5. Teaching, step by step

### Step 1 — Build the base component

Start with the simplest version: a medium, primary, default button.

- Frame with auto layout, horizontal, padding 12/20, gap 8, Hug.
- Fill `color.action.primary`.
- Label `Label` text layer, 16 medium, `color.action.on-primary`.
- Optional leading icon.

Name it `Button`. Make it a component (`Ctrl/Cmd + Alt + K`).

### Step 2 — Turn it into a set with variants

Select the component, then use "Add variant" in the right panel. Figma creates a set with a `State` property. Add variants:

- State: Default, Hover, Pressed, Focus, Disabled.
- Type: Primary, Secondary, Tertiary.
- Size: Small, Medium, Large.

You do **not** need every combination. Build the combinations that will actually be used, and note the rest as future work. A set of 3 types × 5 states × 2 sizes = 30 variants is a lot for a beginner; start with primary and secondary, three states, two sizes, and expand.

Name the set `Button`. Name each variant with property values, not free text: `Type=Primary, State=Default, Size=Medium`.

### Step 3 — Use component properties instead of overrides

Add properties:

- **Text property** for the label, so an instance can change "Continue" to "Send ₦25,000" without detaching.
- **Boolean property** for a leading icon, so the icon can be hidden.
- **Instance swap** for the icon itself, so different icons can be chosen.
- **Variant properties** for type, state and size.

Why? Because overrides are invisible rules. A text property exposes the change in the properties panel, and a designer knows what is allowed.

### Step 4 — Keep the structure identical across variants

Variants should differ in **values**, not structure. If the disabled variant removes the icon layer entirely, the property model breaks. Instead, keep the icon layer and change its opacity or visibility.

Rule: build the most complex variant first, then simplify. It is easier to hide an element than to add one that all variants must share.

### Step 5 — Create primitive variables

Open the Variables panel (in the left sidebar or via the file menu, depending on the current UI). Create a collection `Primitives`.

Add:

```
color/blue/600   #1D4ED8
color/blue/100   #DBEAFE
color/grey/900   #111827
color/grey/600   #4B5563
color/grey/200   #E5E7EB
color/white      #FFFFFF
space/4          4
space/8          8
space/12         12
space/16         16
space/24         24
radius/8         8
radius/12        12
```

Numbers can be used for padding, gap and radius where the UI supports it. If a property cannot take a variable in your plan or current UI, keep the value in the local style and record the limitation.

### Step 6 — Create semantic variables with aliases

Create a second collection `Semantic`:

```
color/text/primary      → color/grey/900
color/text/secondary    → color/grey/600
color/surface/default   → color/white
color/action/primary    → color/blue/600
color/action/on-primary → color/white
color/border/default    → color/grey/200
```

The arrow means "alias to". Now components use semantic variables. If the brand blue changes, you edit `color/blue/600` once; every semantic alias follows.

Why two layers? Primitives are the raw palette; semantics are the meaning. A component should never care that the brand colour is blue-600; it cares that it is the action colour.

### Step 7 — Add a dark mode

Create a mode `Dark` in the Semantic collection. Set:

```
color/text/primary      → color/grey/100 (add this primitive)
color/text/secondary    → color/grey/300
color/surface/default   → color/grey/900
color/action/primary    → color/blue/400
color/action/on-primary → color/grey/900
color/border/default    → color/grey/700
```

Apply the mode to a frame and check every contrast pair again. Dark mode is not an inversion; colours that pass on white may fail on dark.

### Step 8 — Name for humans and machines

Naming rules:

- Use lowercase with dots or slashes consistently: `color.action.primary`, not `colorActionPrimary` in one place and `action-primary` in another.
- Name by role, not appearance: `text.secondary`, not `grey-text`.
- Keep a one-page index of names and meanings.
- Version the system when names change, and provide a mapping table for old names.

### Step 9 — Document the component

For the button set, write:

- **Purpose:** triggers an action.
- **Anatomy:** container, label, optional icon.
- **Properties:** type, state, size, label, icon.
- **Do:** one primary per section; verb-first label.
- **Don't:** two primaries side by side; icon-only without an accessible name.
- **Accessibility:** 44 px minimum height, visible focus, 4.5:1 label contrast.
- **Code note:** maps to a `<button>` with `type`, `disabled` and `aria-busy` where relevant.

## 6. Worked example (I do)

**Goal:** a button set that covers the real needs of the transfer flow without exploding into 30 variants.

**Decision:** build 2 types (primary, secondary) × 3 states (default, focus, disabled) × 2 sizes (medium, large) = 12 variants. Hover and pressed are noted as future work because the prototype does not need them yet.

**Structure:**

```
Button (set)
  Type=Primary, State=Default, Size=Medium
  Type=Primary, State=Focus, Size=Medium
  ...
```

**Properties:**

- `Label` (text) — default "Continue".
- `Show icon` (boolean) — default false.
- `Icon` (instance swap) — default arrow.
- `Type`, `State`, `Size` (variants).

**Variables used:**

- Fill: `color.action.primary` (primary) or `color.surface.default` + border `color.border.strong` (secondary).
- Label: `color.action.on-primary` or `color.text.primary`.
- Focus ring: `color.focus.ring`, 2 px, offset 2.
- Radius: `radius.12`.
- Padding: `space.12` vertical, `space.20` horizontal.

**Reasoning:** the set covers the states that change behaviour and accessibility. Hover and pressed are valuable but can be added later without restructuring, because the property model already exists. Building 30 variants on day one would slow the learner and produce combinations no screen uses.

**What I rejected:** a separate `Button-Disabled` component outside the set. It would break the property model and force designers to remember a second component. Disabled is a state, not a different object.

## 7. We do it together

1. Build the base primary button with auto layout.
2. Add a variant set with Type, State and Size.
3. Create 12 variants: 2 types × 3 states × 2 sizes.
4. Add a text property for the label.
5. Add a boolean property for the icon and an instance swap for the icon.
6. Create the `Primitives` variable collection with at least 12 values.
7. Create the `Semantic` collection with at least 8 aliases.
8. Apply semantic variables to the button fills, text and border.
9. Add a `Dark` mode and check three contrast pairs.
10. Write the component documentation page with do/don't and accessibility notes.

## 8. Your turn (You do)

**Independent task.** Build a **component set and variable system** for your project.

Submit:

1. A button set with at least 3 types, 4 states and 2 sizes (24 variants), or a documented reduction with a reason.
2. Text, boolean and instance-swap properties used in at least one component.
3. A primitives collection with at least 15 values.
4. A semantic collection with at least 10 aliases.
5. A light and dark mode with three contrast checks recorded.
6. A naming index: every component and variable name, with its meaning.
7. A one-page component doc with anatomy, properties, do/don't and accessibility.
8. A 150-word note on one trade-off you made between completeness and maintainability.

**Do not** detach instances to make variants. Do not name variables by appearance only. Do not build variants that differ in structure.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** What is the difference between a main component and an instance?
- A. An instance cannot be edited at all, because its structure is owned by the main.
- B. A main component is always larger, since it holds every variant inside it.
- C. An instance inherits the main's structure, while the main defines what that structure is.
- D. There is no real difference, because both are copies of the same object.

**Q2.** Why use a component property instead of an override?
- A. Properties make the file smaller, because they remove the need for extra layers.
- B. Overrides are not allowed in Figma, so a property is the only option available.
- C. Properties are visible and repeatable, while overrides are hidden one-off changes.
- D. Properties change the font automatically, keeping every instance on the brand.

**Q3.** What does a semantic variable alias do?
- A. It deletes the primitive it pointed to, so the palette holds only role names.
- B. It points a role name at a primitive, separating meaning from raw values.
- C. It creates a new component that carries the role name in its title.
- D. It exports the aliased values as CSS custom properties for developers.

**Q4.** Why should variants differ in values, not structure?
- A. Because Figma cannot handle variants that contain different layers at all.
- B. To reduce the number of colours used across the component set.
- C. To make the file larger, so the library looks more complete to reviewers.
- D. So properties and swaps work consistently across every variant in the set.

**Q5.** What is a variable mode used for?
- A. Changing the file owner, so another designer can edit the collection.
- B. Adding new pages to the file, one for each theme you support.
- C. Compressing the images inside components so the file loads faster.
- D. Switching a set of values, such as light and dark themes.

**Q6.** Why check contrast again in dark mode?
- A. Dark mode is not an inversion, so pairs that pass on white may fail.
- B. Dark mode always fails contrast, so every dark theme needs a full redesign.
- C. Figma resets colours whenever a mode is applied, discarding the stored values.
- D. Contrast only applies to light mode, so dark values need no checking.

**Q7.** Which name follows the course convention?
- A. color.action.primary, lower-case with consistent dot separators and a role.
- B. BlueButtonColorFinal, which is descriptive but adds no role or separators.
- C. #1D4ED8, the exact hex value copied straight from the brand palette.
- D. primary-button-color-new, hyphenated and ending with a version word.

**Q8.** A disabled variant removes the icon layer. Why is this a problem?
- A. It makes the button too small, because the icon no longer adds width.
- B. It changes the button's colour, because the fill is tied to the icon.
- C. It is not a problem, since disabled buttons rarely show an icon anyway.
- D. It changes structure across variants, so the boolean property cannot work consistently.

**Q9.** A learner needs the same button to work in light and dark themes. Which structure is most maintainable?
- A. Use semantic colour variables and switch their values with a variable mode.
- B. Create a separate unconnected button for each theme and maintain both.
- C. Override the fill on every instance by hand whenever a theme is needed.
- D. Use one hard-coded hex value that works acceptably in both themes.

**Q10.** A designer detaches a button instance to change its icon, then the team updates the main component. What is the consequence?
- A. The main component is deleted, leaving the file without a source object.
- B. All other instances change automatically, including the detached copy in the file.
- C. The detached copy no longer receives the update and drifts from the system.
- D. The file becomes read-only, because detaching an instance changes its permission.

## 10. Practical task and pass criteria

**Task.** Submit the component set, variables, modes, naming index and documentation.

**Pass criteria — all must be met:**

- [ ] At least 12 variants, or a documented reduction with a reason.
- [ ] Text, boolean and instance-swap properties used.
- [ ] 15+ primitives and 10+ semantic aliases.
- [ ] Semantic variables applied to components, not raw hex values.
- [ ] Light and dark modes with three recorded contrast checks.
- [ ] Component structure consistent across variants.
- [ ] Naming index and component doc complete.
- [ ] The trade-off note is specific.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| 30 variants built before use | Completeness feels professional | Build what the flow needs; expand later. |
| Detaching to change one thing | It is quick | Use a property or an override. |
| Raw hex in components | Variables take time to set up | Apply semantic variables. |
| Different layer structures per variant | Each variant was drawn separately | Rebuild from one structure; hide, don't remove. |
| Appearance-based names | Easier to imagine | Name by role; keep an index. |
| Dark mode by inversion | It seems logical | Set explicit dark values and re-check contrast. |
| No documentation | It feels optional | Write purpose, properties, do/don't, accessibility. |

**Retry variant.** Build a **text field component set** with states default, focus, error, disabled and read-only, plus a boolean for helper text and a text property for the label. Add variables for border, surface and text. Submit the set, a light/dark comparison and a 120-word note on which state was hardest to model and why.

## 12. Proof artifact for your portfolio

**Artifact:** `Button-System-v1` — stored in `03_Projects/00_Foundations/design-system`.

This is direct evidence of design-system thinking. Keep the naming index; it becomes the mapping table for code in Stop 5.3.

## 13. Low-data and low-cost path

- Variables and variants are available on the free plan at the time of writing; check current limits.
- No plugins are needed.
- Work with one component family if time is short; depth beats breadth.
- The video is optional and 19 minutes; the naming and token structure above is the lesson.
- If variables are unavailable in your plan, use local styles and document the limitation; the concept still applies.

## 14. Watch and read more

**Recommended video (optional, 19:24):** *Master Figma Components and Variants in 20 Minutes* — DesignWithArash. `https://www.youtube.com/watch?v=bnoPAezI6cw`. Verified available on 2026-10-30. Interface details may have changed; the Figma Help pages below are authoritative for current behaviour.

**Read (verified 2026-10-30):**

- Figma Help, *Create and use variants* — `https://help.figma.com/hc/en-us/articles/360056440594-Create-and-use-variants`.
- Figma Help, *Guide to variables in Figma* — `https://help.figma.com/hc/en-us/articles/15339657135383-Guide-to-variables-in-Figma`.
- Figma Help, *Guide to components* — `https://help.figma.com/hc/en-us/articles/360038662654-Guide-to-components-in-Figma`.

## 15. What comes next

Stop 3.4 connects frames into a clickable prototype: triggers, actions, overlays, scrolling and flows. You will build something a real person can test without you explaining it.