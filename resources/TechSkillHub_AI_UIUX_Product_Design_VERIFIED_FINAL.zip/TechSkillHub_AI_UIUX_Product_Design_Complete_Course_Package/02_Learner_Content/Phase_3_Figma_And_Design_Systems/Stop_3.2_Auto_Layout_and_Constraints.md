---
stop_id: 3.2
title: Auto Layout and Constraints
phase: 3
prerequisites: Stop 3.1
outcome: Build responsive components and screens with auto layout and constraints, and explain how each container behaves when content or screen size changes.
time: 80-100 minutes
artifact: Three responsive components (a card, a list row, a form field) and one screen tested at 320, 393 and 430 px widths, with a behaviour note.
---

# Stop 3.2 — Auto Layout and Constraints

> **Phase 3 · Figma fluency and design systems** · Prerequisite: Stop 3.1 · Suggested session: 80–100 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Convert a static group into an auto layout frame with direction, gap and padding.
2. Use Hug, Fill and Fixed sizing deliberately.
3. Nest auto layout frames to build a card, a list row and a form field that survive content changes.
4. Use constraints in non-auto-layout frames for pinning and stretching.
5. Diagnose the five common auto layout breakages.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Auto layout** | A frame that arranges its children automatically in a row or column, with gap and padding. |
| **Direction** | Whether children stack vertically or horizontally. |
| **Gap** | Space between children. |
| **Padding** | Space between the frame edge and its children. |
| **Hug contents** | The frame shrinks or grows to fit its children. |
| **Fill container** | The child expands to fill the available space in its parent. |
| **Fixed** | The width or height stays at a set value. |
| **Min / max width** | A boundary that prevents a Hug or Fill element from becoming too small or too large. |
| **Wrap** | Children flow onto a new line when there is not enough horizontal space. |
| **Spacer** | An empty frame used to push children apart. |
| **Absolute position** | Taking a child out of the auto layout flow and placing it freely. |
| **Nested auto layout** | An auto layout frame inside another, each with its own rules. |
| **Constraints** | Rules for how a child of a normal frame moves or resizes when the frame resizes (left, right, centre, scale, stretch). |
| **Responsive** | The layout adapts to different sizes without breaking. |
| **Overflow** | Content that does not fit and is clipped or scrolls. |
| **Intrinsic size** | The natural size of content, such as the width of a text label. |

## 3. Why this matters

Without auto layout, every text change is a manual repositioning exercise. A button label gets longer in German, the text overflows, and someone nudges the rectangle. Multiply that by fifty screens and you have a file that cannot be maintained.

Auto layout encodes the **rules** of the layout: this label sits 8 px from that icon, the row fills the width, the button hugs its label, the card grows when the title wraps. When the content changes, the rules hold.

Constraints do the same for non-auto-layout frames: pin a header to the top, stretch a background with the frame, centre an icon. They are the older mechanism and still useful for backgrounds and overlays.

> **Everyday example.** A bookshelf with adjustable shelves adapts to new books. A shelf nailed at one height does not. Auto layout is the adjustable shelf; fixed positioning is the nail.

## 4. Before you start

- Open your Stop 3.1 file.
- Create a page `03_AutoLayout`.
- Have three components to work with: a button, a list row, a form field.

## 5. Teaching, step by step

### Step 1 — Add auto layout to an existing frame

Select the children, then press `Shift + A` (or right-click → Add auto layout). Figma wraps them in a frame with default padding and gap.

Then set, in order:

1. **Direction:** vertical for stacked content, horizontal for rows.
2. **Gap:** 8 or 12 for related items.
3. **Padding:** 16 or 24, consistent with your scale.
4. **Alignment:** top/left for text, centre for icons.
5. **Sizing:** Hug for the container if it should fit content, Fill if it should stretch.

Do not skip step 5. Most broken layouts are sizing problems, not spacing problems.

### Step 2 — Understand Hug, Fill and Fixed

| Setting | Behaviour | Use |
|---|---|---|
| **Hug** | Frame fits its children | Buttons, tags, chips, icons |
| **Fill** | Child expands to fill parent | Inputs, cards in a list, text blocks |
| **Fixed** | Stays at a set size | Avatars, icon buttons, fixed sidebars |

A common pattern:

- Screen frame: **Fixed** 393 × 852.
- Content container: **Fill** width, **Hug** height.
- Card: **Fill** width, **Hug** height.
- Card title: **Fill** width, **Hug** height.
- Avatar: **Fixed** 40 × 40.
- Button: **Hug** width or **Fill** width depending on hierarchy.

If everything is Fixed, nothing adapts. If everything is Fill, everything fights for space. The skill is choosing per level.

### Step 3 — Build a card with nested auto layout

Structure:

```
Card (vertical, padding 16, gap 12, Fill width, Hug height)
  Image (Fixed height 160, Fill width)
  Content (vertical, gap 4, Hug height)
    Title (Fill width, Hug height)
    Meta (horizontal, gap 8)
      Category (Hug)
      Dot (Hug)
      Time (Hug)
  Actions (horizontal, gap 8, Fill width)
    Button (Fill width)
    IconButton (Fixed 44)
```

Why nest? Because each group has its own spacing logic. The card's internal sections are 12 px apart; the title and meta are 4 px apart; the actions are 8 px apart. One flat frame cannot express three rhythms.

### Step 4 — Use min/max to stop ugly extremes

A Hug button with a very long label can become enormous. Set **max width** so it wraps or truncates at a sensible point. A Fill text block in a narrow column can become one word per line; set **min width** or a sensible breakpoint.

In Figma, min/max width are available on auto layout frames. Use them for:

- buttons with long labels;
- tags;
- cards in a responsive grid;
- text blocks beside an image.

### Step 5 — Use constraints for backgrounds and overlays

For a normal frame (no auto layout), select a child and set constraints in the right panel:

- **Left and right:** stretches horizontally with the frame.
- **Top:** stays pinned to the top.
- **Bottom:** stays pinned to the bottom.
- **Center:** stays centred.
- **Scale:** resizes proportionally.

Typical use:

- Header background: left + right + top.
- Bottom bar: left + right + bottom.
- Background image: left + right + top + bottom (stretch).
- Floating action button: right + bottom.

Constraints do not reflow content. For content, use auto layout.

### Step 6 — Handle text correctly

Text has its own sizing:

- **Auto width:** the box grows with the text; good for short labels.
- **Auto height:** the box has a fixed width and grows vertically; good for paragraphs.
- **Fixed size:** both dimensions are fixed; text can overflow.

For body text, use **Fill width + auto height**. For a button label, **Hug**. For a single-line title that must truncate, **Fill width + fixed height** plus ellipsis.

### Step 7 — Test by changing content

The only real test of auto layout is content change. Try:

1. Double the title length.
2. Delete the subtitle.
3. Add a second action.
4. Change the text size to 200%.
5. Reduce the frame to 320 px.

If the layout breaks, the rules are wrong, not the content. Fix the rules.

### Step 8 — Diagnose the five common breakages

| Symptom | Likely cause | Fix |
|---|---|---|
| Content overflows to the right | Child is Fixed and wider than parent | Set child to Fill or reduce fixed width |
| Everything is squashed | Parent is Fixed height with too much content | Set parent to Hug height |
| Gap looks different in each card | Manual spacing instead of gap/padding | Remove spacers; use gap |
| Button stretches across the screen | Button is Fill in a Fill parent | Set button to Hug or max width |
| Text disappears | Frame clips content and height is fixed | Set Hug height or allow overflow |

## 6. Worked example (I do)

**Component:** a beneficiary list row.

**Structure:**

```
Row (horizontal, padding 16, gap 12, Fill width, Hug height, stroke bottom)
  Avatar (Fixed 40)
  Text block (vertical, gap 2, Fill width, Hug height)
    Name (Fill width, Hug height, 16 medium)
    Bank (Fill width, Hug height, 13 regular, secondary)
  Chevron (Fixed 20, align centre)
```

**Reasoning:**

- The row is horizontal because the elements sit side by side.
- The text block fills the remaining width so long names wrap instead of pushing the chevron off-screen.
- The avatar and chevron are fixed because they should not distort.
- Padding is 16, gap is 12, both from the spacing scale.
- The bottom stroke is on the row, not on each text element.

**Test:** I rename the beneficiary to "Chinedu Okonkwo-Eze" and the bank to "United Bank for Africa". The name wraps to two lines, the row grows, the chevron stays aligned to the centre. Nothing overlaps.

**Second test:** at 320 px width, the name still wraps and the chevron remains visible. At 430 px, the extra space goes to the text block, not to the gaps.

**What I rejected:** a fixed 72 px row height. It looks tidy with short names and clips long ones. The correct rule is a minimum height with Hug growth.

## 7. We do it together

1. On `03_AutoLayout`, create a button: frame, padding 12/24, Hug, gap 8, icon + label.
2. Set a min width of 120 and a max width of 345.
3. Create a list row as in the worked example. Add a long name and check the wrap.
4. Create a form field: vertical, gap 6, label, input (Fill, height 48), helper text.
5. Add an error state variant with an icon and message.
6. Nest the field inside a form: vertical, gap 24, padding 24.
7. Add a fixed header with constraints: left + right + top.
8. Add a bottom bar with constraints: left + right + bottom.
9. Test the whole screen at 320, 393 and 430 px. Record what changes.
10. Break one component deliberately (set a fixed height) and write down the symptom and the fix.

## 8. Your turn (You do)

**Independent task.** Build **three responsive components** and one screen that contains them:

1. A card with an image, title, two-line description and two actions.
2. A list row with avatar, two lines of text and a trailing action.
3. A form field with label, input, helper and error state.
4. A screen at 393 px that uses all three.
5. The same screen at 320 px and 430 px, with a behaviour note explaining what changed and why.

Submit:

- the Figma link;
- screenshots at the three widths;
- a behaviour table: component, sizing rule, what happens at 320/393/430;
- a 120-word note on the one rule that was hardest to get right.

**Do not** use fixed heights on text containers. Do not use spacers where gap would work.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** What does "Hug contents" do?
- A. The child expands to fill all the space available inside its parent frame.
- B. The frame resizes itself to fit the children it contains, growing or shrinking.
- C. The text inside the frame becomes bold whenever the frame is resized.
- D. The frame locks in place so it cannot be moved or resized by accident.

**Q2.** A button stretches across the whole screen unexpectedly. What is the likely cause?
- A. It is set to Fill width inside a parent that is also Fill.
- B. It has a stroke applied, which adds width around the button's edges.
- C. The label text is too short, so the button expands to fill the gap.
- D. It is a component instance, and instances always stretch to the parent.

**Q3.** Which is the best sizing for body text in a card?
- A. Fixed width and fixed height, so the text block stays the same size.
- B. Hug width and fixed height, so the block grows sideways with the copy.
- C. Fill width and auto height, so the block fills the card and grows downward.
- D. Fixed width and Hug height, but only when the body text is short.

**Q4.** When are constraints more appropriate than auto layout?
- A. For every text block, because constraints keep copy inside its column.
- B. For lists, because constraints keep each row aligned as items change.
- C. For backgrounds, overlays and elements pinned to the frame's edges.
- D. Never, because auto layout has replaced constraints in current Figma.

**Q5.** Why nest auto layout frames?
- A. To increase the file size deliberately, so Figma reserves more space for layers.
- B. Because Figma requires nesting before auto layout can be applied to a frame.
- C. To avoid using components, since nested frames already behave like instances.
- D. To give different groups their own spacing rhythms, alignment rules and padding.

**Q6.** A fixed-height card clips a long title. What is the fix?
- A. Shrink the font until the title fits inside the existing fixed height.
- B. Set the card height to Hug and let the title wrap onto two lines.
- C. Remove the title from the card and rely on the description instead.
- D. Add a vertical scrollbar inside the card so the title can be scrolled.

**Q7.** What does min/max width protect against?
- A. Colour contrast failures, by widening the area behind low-contrast labels.
- B. Very long or very short content producing extreme, unusable layouts.
- C. Missing fonts, by reserving space for fallback typefaces in every label.
- D. Slow prototypes, by limiting how many elements load at each breakpoint.

**Q8.** What is the real test of an auto layout component?
- A. How it behaves when the content and the container size change.
- B. How clean and balanced it looks with the sample content in place.
- C. How many layers it contains when the component is fully expanded.
- D. Whether it is built as a component rather than a loose group.

**Q9.** A toolbar must keep 16 px padding and an 8 px gap while its buttons change. Which Figma structure best supports this?
- A. A group whose buttons are each positioned by eye at the correct spacing.
- B. A single exported image of the toolbar, placed once and reused on each screen.
- C. An auto layout frame with 16 px padding and an 8 px gap between buttons.
- D. A frame with absolutely positioned buttons and a height that never changes.

**Q10.** A card's title is clipped when translated into a longer language. The card has a fixed height. What is the most likely fix?
- A. Reduce the font size until the translated title fits the fixed height.
- B. Let the card height hug its content and allow the title to wrap.
- C. Shorten the translation without consulting the owner of the content.
- D. Add a horizontal scrollbar to the card so the title can be read.

## 10. Practical task and pass criteria

**Task.** Submit the three components, the screen at three widths, the behaviour table and the note.

**Pass criteria — all must be met:**

- [ ] Three components with auto layout and documented sizing rules.
- [ ] Card grows with long titles and description.
- [ ] List row keeps the trailing action visible at 320 px.
- [ ] Form field includes label, helper and error states.
- [ ] Screen tested at 320, 393 and 430 px.
- [ ] Behaviour table covers all three components.
- [ ] No fixed heights on text containers.
- [ ] The note names one rule that was hard to get right and how it was resolved.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Fixed heights everywhere | They look tidy with sample content | Use Hug for text containers. |
| Spacers instead of gap | Old habits | Remove spacer frames; set gap. |
| Everything Fill | It seems responsive | Use Hug for buttons and tags; Fill for content. |
| Text box too narrow | Nested frames without Fill | Set the text block to Fill width. |
| Constraints used for lists | Constraints are visible in the panel | Use auto layout for reflowing content. |
| Testing only at one width | The design looks fine | Test 320/393/430 and long content. |
| Detaching to fix a break | It seems quicker | Fix the main component's rules. |

**Retry variant.** Build a **responsive pricing card** that changes from a vertical stack at 320 px to a horizontal layout at 768 px. Use auto layout wrap or two variants, and explain the trade-off. Test with a long plan name and a missing price. Submit both widths and a 120-word note on which approach you chose and why.

## 12. Proof artifact for your portfolio

**Artifact:** `Responsive-Components` — stored in `03_Projects/00_Foundations/figma`.

This evidence is valuable because it shows systems thinking, not just visual styling.

## 13. Low-data and low-cost path

- Auto layout is a free Figma feature; no plugins needed.
- Work with text and shapes; no image assets required.
- The video is optional and 23 minutes; the rules above are the lesson.
- If Figma is unavailable, sketch the same structures on paper and annotate direction, gap, padding and sizing.

## 14. Watch and read more

**Recommended video (optional, 23:00):** *A Guide to Auto Layout: Best Practices, Tips & Tricks* — Figma. `https://www.youtube.com/watch?v=1odqpkfkDL8`. Verified available on 2026-10-30. It is first-party guidance and therefore preferred for tool behaviour, though the interface may have changed since publication.

**Read (verified 2026-10-30):**

- Figma Help, *Guide to auto layout* — `https://help.figma.com/hc/en-us/articles/360040451373-Guide-to-auto-layout-in-Figma`. The authoritative reference for sizing, wrapping and absolute position.
- Figma Help, *Frames in Figma Design* — `https://help.figma.com/hc/en-us/articles/360041539473-Frames-in-Figma-Design`. Constraints and frame behaviour.

## 15. What comes next

Stop 3.3 turns repeated objects into components with variants and variables. You will learn how a single button can carry size, state and theme without becoming twelve unrelated copies.