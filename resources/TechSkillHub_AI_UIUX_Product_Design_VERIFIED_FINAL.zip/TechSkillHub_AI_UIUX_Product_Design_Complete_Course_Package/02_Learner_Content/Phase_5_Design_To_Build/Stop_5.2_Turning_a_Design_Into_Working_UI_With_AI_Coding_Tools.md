---
stop_id: 5.2
title: Turning a Design Into Working UI With AI Coding Tools
phase: 5
prerequisites: Stops 5.0 and 5.1 passed
outcome: Prompt an AI coding tool from a design and a spec, then review the generated UI against semantics, accessibility, responsiveness and states, fixing what it gets wrong.
time: 90-120 minutes
artifact: A working page generated with AI, plus the prompt log, a review table of at least 10 checks, and the corrected final code.
---

# Stop 5.2 — Turning a Design Into Working UI With AI Coding Tools

> **Phase 5 · Design to build** · Prerequisites: Stops 5.0 and 5.1 · Suggested session: 90–120 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Write a build prompt that includes structure, tokens, states, content rules and constraints.
2. Generate a first version of a screen with an AI coding tool.
3. Review the output against a fixed checklist instead of trusting how it looks.
4. Fix semantic, accessibility and responsive problems in the generated code.
5. Decide when AI output is a useful draft and when it is a liability.
6. Record what you prompted, what you accepted and what you rejected.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **AI coding tool** | A tool that writes or edits code from a natural-language prompt, a screenshot or a design file. |
| **Prompt** | The instruction you give the tool, including context, constraints and expected output. |
| **Context window** | The amount of text and code the model can consider at once. |
| **Hallucination** | Confidently invented code, API names or design details that do not exist. |
| **Semantic HTML** | Using elements for their meaning: `<button>` for actions, `<nav>` for navigation, `<label>` for labels. |
| **ARIA** | Accessible Rich Internet Applications: attributes that add meaning where HTML alone cannot. |
| **Regression** | A working feature that breaks after a change. |
| **Diff** | The exact lines added and removed by an edit. |
| **Scaffold** | A basic working structure you then improve. |
| **Hard-coded** | Values written directly into the code instead of coming from tokens or data. |
| **Responsive** | Adapting layout and content to different screen sizes and input methods. |
| **Progressive enhancement** | Building a working baseline first, then adding enhancements that can fail safely. |
| **Code review** | Reading code for correctness, clarity, accessibility and maintainability before accepting it. |
| **Licence** | The legal terms that say how code or assets may be used. |

## 3. Why this matters

AI coding tools are genuinely useful. They can turn a described layout into a working page in minutes, which used to take hours. They are also confident, fast and sometimes wrong in ways that look right. A generated page can have beautiful spacing and a `<div>` where a button should be, no focus state, a form that cannot be submitted by keyboard, and text that overflows at 320px.

The skill is not "generate code". The skill is **directing and reviewing** generation. That is a design skill: you specify intent, judge output, and take responsibility for what ships.

> **Everyday example.** A tailor's apprentice can sew a garment quickly from a picture. If you do not check the seams, the measurements and whether the client can sit down in it, speed becomes embarrassment. You still own the fit.

There is also a practical boundary. AI tools work best when the task is small, the spec is explicit, and the codebase is visible to the tool. They work worst when the task is "build my whole app" and the only input is a vague screenshot. This stop teaches the small, explicit version first.

## 4. Before you start

- Use the handoff pack from Stop 5.1. You need the state matrix and acceptance criteria.
- Create a new folder `ai-build` with `index.html`, `styles.css` and `script.js`. Starting from separate files makes review easier than one giant file.
- Choose a tool. Any of these work: Claude or ChatGPT for copy-paste code, Cursor or VS Code with Copilot for in-editor edits, v0 for component drafts. The review process is the same.
- Check the tool's data policy. If you would not put the file on a public website, do not paste it into a free chat without checking.
- Prepare a screenshot or a clear description of the screen. If you upload a design, remove real user data first.
- Keep a `prompt-log.md` with four columns: `# | Prompt | Output summary | Accepted / rejected / changed`.

## 5. Teaching, step by step

### Step 1 — Write the build brief before the prompt

A good prompt is a compressed version of your handoff. It has six parts:

1. **Role and goal:** "You are building a single responsive card component for a savings app."
2. **Structure:** the elements and their order.
3. **Tokens:** exact colours, spacing, type and radius.
4. **States:** default, loading, error, success, empty, disabled where relevant.
5. **Constraints:** no frameworks, semantic HTML, keyboard accessible, mobile-first, no external assets.
6. **Output format:** files and what goes in each.

Example brief:

> Build a savings goal card as semantic HTML, CSS and vanilla JavaScript. Structure: article > header (h2 goal name, status chip) > progress element with label > paragraph with amount saved and target > button "Add money". Use these tokens: `--color-surface:#FFFFFF`, `--color-text:#171717`, `--color-muted:#5A5A5A`, `--color-brand:#0B5D3B`, `--radius-card:12px`, `--space-4:16px`. Font: system-ui. The card must work at 320px and at 200% zoom. Include loading and error states triggered by a simulated request. The button must be a real `<button>`, have a visible focus style, and be disabled while loading. Do not use a framework. Return three files: index.html, styles.css, script.js.

Notice what is absent: "make it beautiful", "modern", "clean". Those words invite the model to invent. Specific constraints produce reviewable output.

### Step 2 — Ask for one screen or one component

Large prompts produce large, tangled diffs. Start with one component, verify it, then compose. If you must do a full page, ask for structure first, then styling, then behaviour, in separate turns.

A useful sequence:

1. "Propose the HTML structure only, with comments explaining element choice. Do not write CSS yet."
2. "Now write the CSS using these tokens. Mobile-first. No fixed heights."
3. "Now add the loading and error behaviour with vanilla JS. Do not change the markup unless necessary."
4. "List every accessibility decision you made and every one you skipped."

This keeps each change reviewable.

### Step 3 — Review structure before appearance

Open the generated HTML and ask:

- Is the main action a `<button>`, not a clickable `<div>`?
- Is there one `<h1>` per page, and are headings in order?
- Are form inputs paired with `<label for="...">`?
- Are images given `alt` that describes purpose, not filename?
- Is the page language set with `<html lang="en">`?
- Are landmarks used: `<header>`, `<nav>`, `<main>`, `<footer>`?
- Is decorative content hidden from assistive tech with `aria-hidden="true"`?

A clickable `<div>` "works" with a mouse and fails with a keyboard. It is the most common AI-generated accessibility defect. Replace it with a `<button type="button">` and keep the styling.

### Step 4 — Review the CSS against the tokens

Search the CSS for hex values that are not in your token list. Models often invent `#333`, `#f5f5f5` and `12px` spacing that do not match your system. Replace hard-coded values with custom properties.

Check:

- **Spacing:** are gaps from your scale, or random values like `13px`?
- **Type:** are sizes and line heights from the spec?
- **Contrast:** does body text meet 4.5:1, large text 3:1?
- **Target size:** are interactive controls at least 24×24 CSS pixels, ideally 44×44?
- **Focus:** is there a visible `:focus-visible` style, not `outline: none`?
- **Reflow:** at 320px and 200% zoom, does content fit without horizontal scrolling?
- **Motion:** if there is animation, can it be reduced with `prefers-reduced-motion`?

### Step 5 — Test states, not just the default

Trigger every state in your matrix. If the model only built the default, ask for the missing ones one at a time.

For the savings card:

- Set the saved amount to zero. Does the progress bar show 0% and the copy still make sense?
- Set it above the target. Does the bar cap at 100% and the chip say "Goal reached"?
- Simulate a slow request. Is the button disabled and is there a loading label?
- Simulate a failure. Is there an inline error with a retry?
- Tab through with the keyboard. Is focus visible and in a logical order?
- Turn on a screen reader. Is the loading state announced?

### Step 6 — Fix the output like a designer, not a passenger

When you find a problem, decide which of three actions applies:

1. **Fix directly** if it is small and you understand it: swap a `<div>` for a `<button>`, add a label, change a token.
2. **Ask the tool to fix** if the change is repetitive or you need an explanation: "Replace all clickable divs with buttons and add focus styles. Show the diff."
3. **Reject and rebuild** if the structure is fundamentally wrong, for example a table-based layout or inline styles everywhere.

Do not accept code you cannot explain. If you cannot say why a line exists, either learn it or remove it. "The AI wrote it" is not a defence when it breaks in production.

### Step 7 — Check performance and assets

Generated pages often pull in a font from a third party, a huge icon library, or an image hotlinked from a stock site. Check:

- total page weight;
- number of requests;
- whether fonts are necessary and licensed;
- whether images are compressed and sized;
- whether any external script is required;
- whether the page works with JavaScript disabled (at least the content).

For a single card, the target is under 100 KB excluding images. If the model adds a framework to render one card, remove it.

### Step 8 — Record the human decisions

Your prompt log should show:

- what you asked for;
- what the tool returned;
- what you accepted;
- what you changed and why;
- what you rejected and why.

This log is the difference between "I used AI" and "I directed AI". It is also your evidence if a reviewer asks whether you understand the code.

## 6. Worked example (I do)

A learner, Chidi, builds the savings card from Stop 5.1. His first prompt asks for "a modern savings card with a progress bar and a nice button". The output looks good in a screenshot. Review finds five problems:

1. The "Add money" control is a `<div onclick="...">`. Keyboard users cannot reach it.
2. The progress bar is a `<div>` with a width percentage and no `role="progressbar"`, so screen readers announce nothing.
3. Body text is `#777` on white: contrast about 4.4:1, just below the 4.5:1 minimum.
4. At 320px, a fixed `width: 360px` causes horizontal scrolling.
5. The loading state replaces the button text with "..." and never restores it.

He fixes them:

- `<button type="button" id="add">Add money</button>` with `:focus-visible { outline: 2px solid #0B5D3B; outline-offset: 2px; }`.
- `<progress value="12000" max="50000" aria-label="Saved 12,000 of 50,000 naira"></progress>` — a native element with a text fallback.
- `--color-muted: #5A5A5A`, contrast 7.0:1.
- `width: 100%; max-width: 420px;` and `box-sizing: border-box`.
- A `finally` block that restores the label and re-enables the button.

He records each change in the prompt log with the reason. The final page passes his acceptance criteria, and he can explain every fix.

**Why this is the right standard:** the AI produced a plausible draft; Chidi produced a usable component. The value was in the review, not the generation.

## 7. We do it together

Use your own screen and do this with me:

1. Write the six-part brief. Keep it under 300 words.
2. Ask the tool for **HTML only**. Review the structure with the checklist in Step 3.
3. Ask for CSS using your tokens. Search for stray hex values and replace them.
4. Ask for one state — loading or error. Test it with the keyboard and a screen reader.
5. Write three lines in your prompt log: one acceptance, one change, one rejection.

**Hint:** if the tool returns a giant file, ask it to "return only the changed lines and explain each change". Smaller diffs are easier to judge.

## 8. Your turn (You do)

Build one screen from your handoff pack using an AI coding tool. Submit:

- the working page (files or a live URL);
- the prompt log with at least 6 prompts;
- a review table with at least 10 checks, each marked pass/fix/reject and linked to the change you made;
- the final code, with a short comment on any line you do not fully understand or removed;
- a 150-word reflection on where the tool helped and where it created risk.

Use fictional data. If you upload a design, confirm it contains no real personal data or confidential client material.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** What is the most important part of using an AI coding tool well?
- A. Writing the longest possible prompt, so the model has every detail it could ever need.
- B. Accepting the first result quickly, because speed is the main advantage these tools offer.
- C. Using the most expensive model, since higher price usually means fewer invented details.
- D. Specifying intent clearly and reviewing the output against explicit criteria before accepting it.

**Q2.** Why is a clickable `<div>` a problem?
- A. It renders more slowly than a native button, so the interaction feels delayed on older phones.
- B. It cannot be styled with CSS, so it never matches the visual design of the rest of the page.
- C. It breaks the CSS grid it sits in, which collapses the surrounding layout on narrow screens.
- D. It is not focusable or operable by keyboard, and it gives assistive tech no button role or name.

**Q3.** The generated CSS uses `#333` when your token is `#171717`. What should you do?
- A. Leave it as it is, since #333 and #171717 are visually close enough for most visitors.
- B. Delete all the generated CSS and start again, because one stray value proves the output is unreliable.
- C. Replace it with the token, so the theme stays consistent and later token changes still apply.
- D. Add a second token for #333, so both greys are documented and available for future screens.

**Q4.** Which is a reason to reject and rebuild rather than patch?
- A. One wrong colour, because repainting a single element by hand is slower than rebuilding.
- B. A missing semicolon, because broken syntax means the whole stylesheet cannot be trusted.
- C. A fundamentally wrong structure, such as a table-based layout with inline styles throughout.
- D. A typo in a comment, because comments are read by the model on every later prompt.

**Q5.** Why test at 320px and 200% zoom?
- A. To make the page load more slowly, which reveals how it behaves on a weak connection.
- B. To check that content reflows readably for small screens and for users with low vision.
- C. Because AI tools cannot write media queries, so the layout must be verified by hand.
- D. To increase the contrast ratio of body text, which improves as the layout gets narrower.

**Q6.** What belongs in a prompt log?
- A. Only the final code, so the log stays short and shows exactly what was shipped.
- B. The prompts, output summaries, and what you accepted, changed or rejected, with reasons.
- C. The model's marketing description, so readers know which product version produced the code.
- D. Your password and account details, so the tool can resume the session on another machine.

**Q7.** A generated page loads a 900 KB icon font for three icons. What is the best fix?
- A. Keep the font, because polished icons matter more than a few hundred kilobytes on a portfolio page.
- B. Add more icons to the page, so the 900 KB font is amortised across more visible content.
- C. Load a second icon font as a fallback, in case the first one fails to arrive.
- D. Replace the font with three inline SVGs or a small sprite, which draws only what you need.

**Q8.** You cannot explain what a generated JavaScript function does. What should you do?
- A. Ship it anyway, since the page works and users never see the code behind it.
- B. Ask the tool to explain it, then either understand it well enough or remove it.
- C. Rename the function so its purpose is clearer, and leave the body unchanged.
- D. Add a comment saying 'AI wrote this', so future readers know the code is unverified.

**Q9.** An AI coding tool generates a clickable card using a `<div>` with a click handler. What is the best correction?
- A. Add a cursor-pointer style so the card looks clickable, and leave the markup as it is.
- B. Add a tabindex to the div so it can receive focus, and change nothing else.
- C. Use a native button or link, keeping the styling, keyboard behaviour and visible focus style.
- D. Replace the card with an image of the action, which cannot be misused by a keyboard.

**Q10.** A generated page looks correct but cannot be operated with a keyboard, and focus disappears after the first field. What review was missed?
- A. A colour palette review, checking that every token used on the page matches the brand.
- B. A keyboard and focus review of the rendered page, not just a visual comparison with the design.
- C. A content word-count check, confirming that every label and paragraph fits inside its slot.
- D. A logo placement review, comparing its position on each breakpoint against the brand guide.

## 10. Practical task and pass criteria

**Task.** Build one screen with AI assistance and submit the page, prompt log, review table and reflection.

**Pass criteria — all must be met:**

- [ ] The page renders and matches the handoff's core layout and tokens.
- [ ] Semantic HTML is used for actions, headings, landmarks and form labels.
- [ ] All interactive elements are keyboard reachable with a visible focus state.
- [ ] Body text contrast is at least 4.5:1; large text and UI boundaries at least 3:1.
- [ ] The page reflows at 320px without horizontal scrolling and remains usable at 200% zoom.
- [ ] At least two non-default states work (for example loading and error).
- [ ] No unexplained hard-coded values that contradict the tokens.
- [ ] The prompt log covers at least 6 prompts with accept/change/reject decisions.
- [ ] The review table covers at least 10 checks.
- [ ] The reflection names one real risk the tool introduced and how you handled it.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Prompting with adjectives | It feels natural | Give structure, tokens, states and constraints. |
| Accepting the screenshot | It looks right | Test keyboard, screen reader, 320px and failure states. |
| One giant prompt | Wanting speed | Build in small turns with review between. |
| Keeping clickable divs | They work with a mouse | Use native buttons and links. |
| Hard-coded colours | The model fills gaps | Replace with tokens; search for `#`. |
| No loading state | The happy path is easy | Ask for it explicitly and test a slow network. |
| Uploading confidential designs | Convenience | Check policy; remove data; use a mock. |
| Shipping code you cannot explain | Trust in the tool | Ask for an explanation or remove the code. |

**Retry variant.** Rebuild the same screen **without AI**, using only your handoff pack, and then compare the two versions in a table: time taken, accessibility issues, responsiveness issues, code you understand. The comparison is the deliverable. It proves you can judge the tool rather than depend on it.

## 12. Proof artifact for your portfolio

Keep the working page, the prompt log and the review table. In your portfolio, present this as "AI-assisted build with human review" and show one specific defect you caught. That single example is more convincing than a claim that you "use AI".

## 13. Low-data and low-cost path

- Use a free chat tool and copy code into a local file. No paid editor is required.
- Work offline after generating: save the HTML, CSS and JS, then test locally.
- Avoid tools that require uploading large design files; describe the screen in text instead.
- Use system fonts and inline SVG to keep the page small.
- If you cannot run a screen reader, use the browser's accessibility tree inspector and keyboard testing, and say so in your reflection.

## 14. Watch and read more

**Recommended video:** *Turn Any Figma Design Into Code with Claude (tutorial)* by Ryan Hayward (2026, 12 min 10 s) — `https://www.youtube.com/watch?v=aAS_pZ5cgPA`. A practical walkthrough of design-to-code with an AI assistant. Metadata checked 2026-10-30; embedded playback was verified in Chrome on 2026-10-30. Treat the tutorial as a demo, not a quality standard: it does not replace your review checklist.

**Read:**

- MDN, *HTML: A good basis for accessibility* — `https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Accessibility/HTML`. Semantics and keyboard behaviour.
- W3C WAI, *WCAG 2.2 Quick Reference* — `https://www.w3.org/WAI/WCAG22/quickref/`. Contrast, focus, reflow and target size.
- web.dev, *Core Web Vitals* — `https://web.dev/articles/vitals`. Performance thresholds.
- Figma Help, *Guide to Dev Mode* — `https://help.figma.com/hc/en-us/articles/15023124644247-Guide-to-Dev-Mode-in-Figma`. Moving from design values to code values.

## 15. What comes next

Stop 5.3 takes the one-off page and turns its values and components into a small design system in code: tokens, reusable components and documentation that keep the built product aligned with the Figma file.