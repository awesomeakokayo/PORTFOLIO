---
stop_id: 5.1
title: Handoff That Developers Love
phase: 5
prerequisites: Stop 5.0 passed, or equivalent ability to publish a page
outcome: Turn a finished screen into a handoff pack a developer can build without asking what you meant, covering specs, states, naming, assets and edge cases.
time: 75-95 minutes
artifact: A handoff pack for one screen: annotated spec, state matrix, asset list, edge-case list, naming conventions and an open-questions log.
---

# Stop 5.1 — Handoff That Developers Love

> **Phase 5 · Design to build** · Prerequisite: Stop 5.0 · Suggested session: 75–95 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Write a handoff pack that answers the questions a developer would otherwise have to ask.
2. Specify spacing, type, colour and behaviour using names and values, not vague adjectives.
3. Map every interactive element to its states, including empty, loading, error, disabled and success.
4. Name layers, components and files so another person can find things.
5. List edge cases: long text, missing data, slow network, small screens, permissions and failure.
6. Run a handoff review and record open questions instead of hiding them.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Handoff** | The package of designs, specs and explanations a designer gives to the people who build and test the product. |
| **Spec / specification** | Exact values and behaviour: sizes, spacing, colours, states, rules. |
| **Redline** | A measurement annotation showing spacing, size or alignment. |
| **State** | A version of a component or screen caused by user action or system condition: default, hover, focus, pressed, disabled, loading, error, success, empty. |
| **Edge case** | An unusual but real situation the design must handle: very long name, no results, expired session, offline. |
| **Asset** | A file the build needs: icon, image, logo, font, illustration. |
| **Token** | A named design value, such as `color.surface.default` or `space.4`. |
| **Dev Mode** | Figma's inspection view that exposes measurements, styles and code hints to developers. |
| **Acceptance criteria** | Testable statements that define when a ticket is done. |
| **Ticket** | A unit of work in a tracking tool such as Jira, Linear or GitHub Issues. |
| **Naming convention** | An agreed pattern for naming layers, components, files and tokens. |
| **Source of truth** | The one place that is authoritative when files disagree. |
| **Drift** | When the design file and the built product stop matching. |
| **Open question** | A decision not yet made, recorded with an owner and a date. |

## 3. Why this matters

Most "the developer built it wrong" stories are not sabotage. They are missing information. The designer knew the card should show a skeleton while loading, knew the name could be 40 characters, knew the button is disabled until the terms box is ticked. None of that was written down, so the developer built the happy path and shipped.

Handoff is not a ceremony at the end. It is the moment your design becomes **specific enough to be built and tested**. A good handoff reduces meetings, reduces rework, and makes you the designer engineers want on their team.

> **Everyday example.** A catering order that says "rice for 50 people" is not an order. "Jollof rice, 50 portions, no beef, delivered to Hall B at 12:30, two serving spoons" is an order. The cook can act on the second one without calling you back. Handoff is the difference between a wish and an order.

There is also a career reason. Junior designers are often judged on visual craft. Mid-level designers are judged on whether their work ships correctly. Handoff is where that judgment happens.

## 4. Before you start

- Choose **one** screen from Phase 3 or Phase 4. A form, a checkout, a dashboard card or a profile screen all work. Avoid a marketing homepage; it has fewer states.
- Open it in Figma. If you built it elsewhere, recreate the key frame in Figma or use a screenshot plus a written spec.
- Create a new page in the file called `Handoff — [screen name]`.
- Make a document called `handoff.md` or a table with these columns: `Element | Spec | States | Content rules | Edge cases | Open question`.
- Decide the **target platform**: mobile web, desktop web, iOS or Android. Specs differ. Do not write "all platforms" unless you have specified each.

## 5. Teaching, step by step

### Step 1 — Separate the four kinds of information

A handoff pack contains four different things, and mixing them is the most common failure:

1. **Visual spec** — what it looks like: size, spacing, colour, type, radius, shadow, border.
2. **Behaviour spec** — what happens: click, hover, focus, submit, validation, transition, loading.
3. **Content spec** — what words appear, character limits, tone, empty-state copy, error copy.
4. **Build context** — assets, naming, links, constraints, browser support, accessibility requirements.

If your handoff is only a pretty frame, you have delivered one quarter of the job.

### Step 2 — Annotate with values, not adjectives

Bad: "Make the spacing generous and the heading bold."
Good: "Section padding 24px top/bottom, 16px left/right. Heading: 24px/32px, weight 700, colour `text.primary`."

Use a consistent unit. On the web, CSS pixels; on iOS, points; on Android, density-independent pixels. State which one you mean. Show measurements on the frame with redlines, or use Dev Mode inspection, but always add the intent in words. A developer can copy `16px`; they cannot copy "a bit more air".

For type, give size, line height, weight and, where it matters, letter spacing. For colour, give the token name and the hex value. For shadows, give the full value. For corner radius, give the value and say whether it is uniform.

### Step 3 — Build the state matrix

List every interactive element and every state it can be in. A minimum matrix for a button:

| State | Trigger | Visual change | Behaviour |
|---|---|---|---|
| Default | Page load | Filled brand colour | Enabled |
| Hover | Pointer over | 8% darker | Cursor pointer |
| Focus | Keyboard tab | 2px outline, 2px offset | Visible, not removed |
| Pressed | Mouse/touch down | 4% darker, 1px translate | Action fires on release |
| Disabled | Form invalid | 40% opacity, no shadow | Not clickable, still readable |
| Loading | Request sent | Spinner replaces label | Prevent double submit |
| Success | Request succeeds | Check icon for 2s | Announce to screen reader |
| Error | Request fails | Error text below | Retry available |

For a form field, add: empty, focused, filled, invalid, disabled, read-only, with helper text, with character count. For a list: loading, empty, partial, error, full, paginated. For a page: logged out, no permission, session expired, offline.

You do not need a separate Figma frame for every state if the behaviour is written clearly. But you do need to **decide** each one. Undecided states become developer guesses.

### Step 4 — Write content rules

For every text slot, state:

- maximum and minimum length;
- whether it is user-generated, translated or fixed;
- what happens when it is too long (wrap, truncate with ellipsis, scroll);
- what the empty version says;
- what the error version says;
- whether numbers, dates and currency are localised.

Example: "Business name: 1–60 characters. Wrap to two lines, then truncate with ellipsis. Do not shrink font below 14px. Empty state: 'Unnamed business'. Do not translate the brand name."

Nigerian context: if you show currency, state the format, for example `₦12,500`, and whether kobo are shown. If you show phone numbers, state the expected format and do not assume a country code. If you show addresses, do not assume a street-number-first format.

### Step 5 — Name things so they can be found

A naming convention is not bureaucracy. It is how a stranger finds the checkout error state at 11pm.

A workable pattern for layers and components:

`[area]/[component]/[variant]/[state]`

Examples:

- `checkout/payment-form/default`
- `checkout/payment-form/error-card-declined`
- `dashboard/stat-card/loading`
- `settings/avatar-upload/empty`

Rules:

- lower-case, hyphens between words, slashes for grouping;
- no `Frame 427`, `Rectangle 12`, `final-final-v3`;
- state last, so variants sort together;
- one source of truth for each component; do not keep three copies in different pages.

### Step 6 — Prepare assets properly

An asset list is part of handoff. For each asset give: file name, format, size, density, background, and licence or ownership.

- Icons: SVG, 24×24 viewBox, `currentColor` where possible, named `icon-search.svg`.
- Photos: JPG or WebP, at least 2× the display size, compressed, with alt text written by you.
- Logos: SVG primary, PNG fallback, clear-space rule.
- Fonts: state the family, weights, licence and fallback stack. Do not assume a paid font is available.
- Illustrations: editable source plus exported version.

Do not hand over a screenshot of an icon and call it an asset. Do not use a copyrighted image you found online. If the licence is unclear, replace it.

### Step 7 — Hunt edge cases systematically

Use this checklist on every screen:

1. **Content:** longest name, shortest name, no name, emoji, right-to-left text, numbers.
2. **Data:** zero items, one item, 1,000 items, missing image, broken image.
3. **Network:** slow, offline, timeout, retry, duplicate submit.
4. **Permission:** logged out, expired session, no access, admin versus member.
5. **Device:** 320px wide, large text, landscape, keyboard open, screen reader.
6. **Time:** first use, returning user, timezone, date format.
7. **Money:** zero, very large, refund, failed payment, currency change.
8. **Human:** mistake, impatience, double tap, back button, refresh mid-flow.

Write what should happen for each, or mark it as an open question. "Not handled" is a decision; silence is not.

### Step 8 — Write acceptance criteria and open questions

Acceptance criteria are testable. "Looks good" is not testable. "At 320px, the card does not overflow and the primary button remains visible without scrolling" is testable.

Write 5–10 per screen, covering layout, states, content, accessibility and performance. Then list open questions with an owner and date:

| Question | Owner | Needed by | Default if unanswered |
|---|---|---|---|
| Should the promo banner be dismissible? | Product | Before build | Yes, dismiss for 7 days |
| Is the API returning a total or per-item price? | Engineering | Before build | Per item |

A default prevents the build stalling. It also makes the decision visible.

### Step 9 — Run the handoff review

Before you send anything, do a 15-minute review with a developer or a peer playing the developer:

- Can they find the spec in under 30 seconds?
- Can they build the default state without asking a question?
- Can they build the error state?
- Do they know what happens on a slow connection?
- Do they know which file is the source of truth?
- Is every asset linked and licensed?
- Are the open questions actually open, or already answered somewhere?

Record what they asked. Every question is a missing line in your handoff.

## 6. Worked example (I do)

A learner, Ifeoma, designed a "savings goal" card for a fictional micro-savings app. Her first handoff was a single frame with a note: "Card shows goal, amount saved, progress bar, add money button."

A developer replied with six questions. She turned each into a spec:

1. **"What if the goal name is long?"** → Wrap to two lines, then truncate with ellipsis at 40 characters. Font stays 16px/24px.
2. **"What if saved is zero?"** → Progress bar at 0%, label "₦0 of ₦50,000", helper text "Start with any amount."
3. **"What if saved exceeds the goal?"** → Progress bar caps at 100%, label "₦52,000 of ₦50,000", success chip "Goal reached".
4. **"What happens while adding money?"** → Button shows spinner, label hidden, button disabled, card `aria-busy="true"`.
5. **"What if the request fails?"** → Inline error below the button: "That did not go through. Check your connection and try again." Retry keeps the amount.
6. **"Which green?"** → `color.action.primary` = `#0B5D3B`, contrast with white 8.1:1. Hover `#094D31`, pressed `#073D27`.

She added a state matrix with 8 rows, an asset list with one SVG icon and no photos, a naming convention, and 7 acceptance criteria. The second review produced zero blocking questions. That is the standard: not "no questions ever", but "no question that stops the build".

## 7. We do it together

Use your chosen screen and complete this with me:

1. Draw a box around the screen's primary action. Write its default, hover, focus, pressed, disabled and loading states.
2. Pick the longest realistic piece of text on the screen. Write what happens at 320px and at 200% zoom.
3. List every image and icon. Give each a file name and format.
4. Write three acceptance criteria that a tester could pass or fail without asking you.
5. Write two open questions with a default. If you cannot think of two, you have not looked at failure states.

**Hint:** if you are stuck on states, ask "what does the user see in the three seconds after they press the button?" Most missing states live in those three seconds.

## 8. Your turn (You do)

Produce a complete handoff pack for one screen. It must include:

- an annotated frame with spacing and type values;
- a state matrix covering at least 6 states;
- a content rules table for at least 4 text slots;
- an asset list with formats, sizes and licences;
- a naming convention applied to at least 8 layers or components;
- an edge-case list covering content, data, network, permission and device;
- 5–10 testable acceptance criteria;
- an open-questions table with owners and defaults;
- a one-paragraph "source of truth" statement.

Use a **fictional** product and fictional data. Do not include real customer names, real account numbers or a real company's unreleased designs.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** What is the main purpose of a handoff pack?
- A. To make the design file look tidy, with neat layers and frames that are easy to browse later.
- B. To replace usability testing by settling every question before the design reaches a real user.
- C. To prove the designer worked long hours by showing a detailed record of every revision made.
- D. To give builders the specs, states and rules they need to build the screen correctly without guessing.

**Q2.** Which is a testable acceptance criterion?
- A. "At 320px wide, the primary button stays visible without horizontal scrolling."
- B. "The page feels premium and modern, with generous spacing and a calm, confident tone."
- C. "Use nice spacing and a clean type scale throughout the checkout flow."
- D. "Make the primary button pop so the main action is obvious at a glance."

**Q3.** Why must disabled buttons still be readable?
- A. Because they are decorative placeholders that show the layout, so their contrast does not matter much.
- B. Because disabled buttons are always clickable, so users need to read the label before pressing them.
- C. Because users need to understand what is unavailable and why, and low contrast hides that information.
- D. Because screen readers skip disabled controls entirely, so the label must carry the meaning visually.

**Q4.** What belongs in a state matrix?
- A. Only the default state, drawn once, because the other states are left to the developer's judgment.
- B. Every relevant state, with its trigger, visual change and behaviour, including loading, error and empty.
- C. A list of the colour names used on the screen, so the palette stays consistent across builds.
- D. The project timeline, so the team knows which screens are finished and which are still in review.

**Q5.** A developer asks "what happens if the API fails?" What kind of gap is this?
- A. A visual gap about the size, spacing and colour of the elements on the screen.
- B. A naming gap about how the layers, components and files in the design are labelled.
- C. A pricing gap about what the feature costs to run and who pays for the extra requests.
- D. A behaviour and content gap: what the screen does and says after a failed request.

**Q6.** Why is `Frame 427` a bad layer name?
- A. It carries no meaning, so nobody can tell what it holds, find it later or reuse it.
- B. It is too long for Figma's layer field, so the name gets truncated before the useful part.
- C. Figma forbids names that contain numbers, so the layer stays unnamed and cannot be exported.
- D. It slows the file down, because the editor re-reads every numeric label on each save.

**Q7.** What should an open-questions table include?
- A. Only questions that are already answered, so the table reads as a settled record of decisions.
- B. A list of every layer in the file, so reviewers can trace each one back to a component.
- C. The designer's opinions about the product, recorded so the team knows what to prioritise next.
- D. The question, its owner, the date it is needed by, and a default if it stays unanswered.

**Q8.** Which asset handover is most useful?
- A. A screenshot of the icon, taken at the size it appears on the finished screen.
- B. A JPG of the whole screen, so the developer can crop the icons out of it later.
- C. A link to a competitor's site, where the same icon can be inspected and copied.
- D. A named SVG with a 24×24 viewBox and `currentColor`, so it scales and inherits text colour.

**Q9.** A developer asks what should happen when the payment API returns a timeout. What should the handoff provide?
- A. A higher-resolution screenshot of the happy path, so the developer can match the finished layout exactly.
- B. The relevant states, the exact message, the recovery action, and the rule preventing a duplicate payment.
- C. A note saying 'handle errors gracefully', leaving the wording and the retry logic to the developer.
- D. A link to the brand guidelines, so the error message uses the approved tone and colour palette.

**Q10.** A handoff contains final screens but no loading, empty or error states. What will the developer most likely have to do?
- A. Ship the happy path only and ignore failures, because nothing in the pack says they matter.
- B. Ask the designer for a colour palette, since the screens do not show which colours to use.
- C. Reduce the page weight automatically, because incomplete screens usually mean the build is unfinished.
- D. Invent behaviour and copy for those states, which creates rework and drifts from the design intent.

## 10. Practical task and pass criteria

**Task.** Submit the handoff pack for one screen, plus a short record of a review with a peer or developer.

**Pass criteria — all must be met:**

- [ ] One screen is fully specified, with values and units.
- [ ] At least 6 states are defined with triggers and behaviour.
- [ ] Content rules cover at least 4 text slots, including overflow.
- [ ] Assets are listed with names, formats, sizes and licence status.
- [ ] A naming convention is defined and applied.
- [ ] Edge cases cover content, data, network, permission and device.
- [ ] 5–10 acceptance criteria are testable.
- [ ] Open questions have owners and defaults.
- [ ] The review record shows at least three questions asked and how the pack was improved.
- [ ] No real personal or confidential data is included.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Handing over only the happy path | It is the screen you designed | Add loading, empty, error, disabled and success. |
| Specs in adjectives | Faster to write | Replace with values and tokens. |
| Three "final" files | No source-of-truth rule | Name one file as canonical and archive the rest. |
| Icons as screenshots | Convenience | Export SVG; name it; state colour behaviour. |
| Real customer data in mockups | Copied from research | Replace with fictional data and label it. |
| Open questions hidden in chat | Fear of looking unsure | Put them in the table with an owner and default. |
| No accessibility notes | Assumed to be "the developer's job" | Specify focus, labels, contrast, target size and announcements. |
| Handoff sent once, never updated | Treated as a ceremony | Update the pack when decisions change; note the version. |

**Retry variant.** Take a different screen — a login form or a search results page — and produce a **one-page** handoff using only a table and five annotations. The constraint forces you to prioritise the decisions that actually block a build. Submit the one-pager plus a list of what you deliberately left out and why.

## 12. Proof artifact for your portfolio

Keep the handoff pack, the review notes and a before/after comparison of the questions asked. In a portfolio, this is strong evidence of collaboration and shipping maturity. Label it "Handoff pack — fictional savings app" so no one mistakes it for client work.

## 13. Low-data and low-cost path

- Figma's free tier is enough. If Dev Mode is unavailable, use the inspect panel and type values manually.
- Work offline by exporting a PNG of the frame and writing the spec in a text file.
- Skip video if data is tight; the steps above are complete without it.
- Use system fonts in the spec so you do not need to license or download a font.
- If you have no developer to review with, use the checklist in Step 9 as a self-review and record your own answers.

## 14. Watch and read more

**Recommended video:** *Figma tutorial: Collaboration and handoff in Dev Mode* by Figma (2024, 6 min 32 s) — `https://www.youtube.com/watch?v=xCJsRuH7v9w`. Shows inspection, annotations and developer collaboration in Figma's own tool. Metadata checked 2026-10-30; embedded playback was verified in Chrome on 2026-10-30.

**Read:**

- Figma Help, *Guide to Dev Mode* — `https://help.figma.com/hc/en-us/articles/15023124644247-Guide-to-Dev-Mode-in-Figma`. Official inspection and handoff documentation.
- Figma, *Best practices* — `https://www.figma.com/best-practices/`. Naming, organisation and component hygiene.
- W3C WAI, *WCAG 2.2 Quick Reference* — `https://www.w3.org/WAI/WCAG22/quickref/`. Use it to write accessibility acceptance criteria.
- GOV.UK Design System, *Content design* — `https://design-system.service.gov.uk/`. Examples of precise, testable content rules.

## 15. What comes next

Stop 5.2 takes the handoff and turns it into working UI with an AI coding tool. You will use the state matrix and acceptance criteria from this stop as your review checklist, because the model will produce a convincing default state and quietly ignore the rest.