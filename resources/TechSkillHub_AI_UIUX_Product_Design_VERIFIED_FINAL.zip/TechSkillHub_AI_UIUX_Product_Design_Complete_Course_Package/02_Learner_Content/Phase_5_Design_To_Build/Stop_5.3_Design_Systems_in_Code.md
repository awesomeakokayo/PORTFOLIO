---
stop_id: 5.3
title: Design Systems in Code
phase: 5
prerequisites: Stop 5.2 passed; a small Figma component set from Phase 3
outcome: Turn Figma tokens and components into CSS custom properties and reusable coded components that stay aligned with the design file, with documentation and a drift check.
time: 90-120 minutes
artifact: A small coded design system: token file, two or more components, a usage page and a drift checklist comparing Figma values with code values.
---

# Stop 5.3 — Design Systems in Code

> **Phase 5 · Design to build** · Prerequisites: Stop 5.2 and a Phase 3 component set · Suggested session: 90–120 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Explain the difference between primitive and semantic tokens.
2. Convert a Figma colour, type and spacing set into CSS custom properties.
3. Build at least two reusable coded components that match Figma variants.
4. Document how to use the components, including accessibility behaviour.
5. Detect drift between the design file and the code.
6. Decide what belongs in a design system and what should stay local.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Design system** | The shared rules, tokens, components and documentation that keep a product consistent. |
| **Token** | A named value, such as a colour, spacing step, font size or radius. |
| **Primitive token** | A raw value with a neutral name: `green-700`, `space-4`, `radius-2`. |
| **Semantic token** | A name that describes use: `color-action-primary`, `space-card-padding`. |
| **CSS custom property** | A variable in CSS, written `--color-action-primary: #0B5D3B;` and used with `var(...)`. |
| **Component** | A reusable piece of UI with defined structure, styles and behaviour. |
| **Variant** | A version of a component: primary/secondary, small/large, default/error. |
| **Prop / attribute** | An input that changes a component's appearance or behaviour. |
| **API (component API)** | The agreed set of props, slots and events a component exposes. |
| **Slot** | A named place where content can be inserted. |
| **Drift** | A mismatch between the design source and the built product. |
| **Source of truth** | The authoritative source when design and code disagree. |
| **Documentation** | Instructions and examples that let someone use the system correctly. |
| **Governance** | The rules for who can change the system and how changes are reviewed. |

## 3. Why this matters

A design system is not a Figma library. It is an agreement between design and code. If the Figma button is 44px tall and the coded button is 38px, the system has already failed. If the Figma file has a "danger" colour that code does not have, someone will hard-code red.

For a beginner, a design system can feel like enterprise work. It is not. Even a three-component system with ten tokens prevents the most common inconsistency: every screen inventing its own spacing and colour. It also makes AI-generated code safer, because the model can be told to use the tokens instead of inventing values.

> **Everyday example.** A small restaurant does not need a 200-page brand manual. It needs a standard plate size, a standard garnish, a standard price format and a standard way to answer the phone. That is enough for customers to recognise it. A design system is the standard plate and garnish of your product.

## 4. Before you start

- Bring the Phase 3 component set: at least one button with variants, one input, and one card.
- Create a folder `design-system` with `tokens.css`, `components.css`, `index.html` and `README.md`.
- Decide the scope: **two components** is enough. Button and input are the best pair because they cover colour, type, spacing, states and accessibility.
- List the values from Figma: colour, type scale, spacing scale, radii, shadows, border widths.
- Check that your Figma names are consistent. If they are not, fix the names before translating them.

## 5. Teaching, step by step

### Step 1 — Separate primitives from semantics

A primitive is a raw value. A semantic token points to a primitive and describes a job.

```css
:root {
  /* Primitives */
  --green-700: #0B5D3B;
  --green-800: #094D31;
  --neutral-0: #FFFFFF;
  --neutral-900: #171717;
  --neutral-600: #5A5A5A;
  --space-1: 4px;
  --space-2: 8px;
  --space-3: 12px;
  --space-4: 16px;
  --space-6: 24px;
  --radius-2: 8px;
  --radius-3: 12px;

  /* Semantic */
  --color-surface: var(--neutral-0);
  --color-text: var(--neutral-900);
  --color-text-muted: var(--neutral-600);
  --color-action-primary: var(--green-700);
  --color-action-primary-hover: var(--green-800);
  --color-focus: var(--green-700);
  --space-card-padding: var(--space-6);
  --radius-card: var(--radius-3);
}
```

Why two layers? Because you may want to change the brand green in one place without renaming every use. Semantic names also survive a theme change: in dark mode, `--color-surface` can point to a dark neutral while every component keeps using the same name.

### Step 2 — Choose a naming pattern and stick to it

A workable pattern: `--[category]-[role]-[variant]-[state]`.

Examples:

- `--color-text-muted`
- `--color-action-primary-hover`
- `--space-card-padding`
- `--radius-button`
- `--font-body-size`

Rules:

- lower-case and hyphens;
- role before variant;
- state last;
- no colours in semantic names (`--color-action-primary`, not `--color-green-button`);
- no pixel values in names (`--space-4`, not `--space-16px`), because the value may change.

### Step 3 — Translate type and spacing scales

Do not copy every value from Figma. Copy the **scale**. If Figma has 13px, 15px, 17px and 19px, you probably have drift, not a scale. Choose a small set: 12, 14, 16, 18, 24, 32, 48. Map each to a token.

```css
:root {
  --font-family-body: system-ui, -apple-system, "Segoe UI", sans-serif;
  --font-size-body: 1rem;      /* 16px */
  --font-size-small: 0.875rem; /* 14px */
  --font-size-h2: 1.5rem;      /* 24px */
  --line-height-body: 1.5;
  --line-height-heading: 1.25;
  --font-weight-regular: 400;
  --font-weight-bold: 700;
}
```

Use `rem` for type so browser zoom and user font settings work. Use `px` for borders and small radii, and `rem` or `px` consistently for spacing. Document the choice.

### Step 4 — Build a component with a clear API

A button component in plain HTML and CSS is a class plus documented expectations:

```html
<button class="btn btn--primary" type="button">Add money</button>
<button class="btn btn--secondary" type="button">Cancel</button>
<button class="btn btn--primary" type="button" disabled>Processing…</button>
```

```css
.btn {
  font: var(--font-weight-bold) var(--font-size-body)/1.2 var(--font-family-body);
  min-height: 44px;
  padding: var(--space-3) var(--space-4);
  border: 2px solid transparent;
  border-radius: var(--radius-button, 8px);
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-2);
}
.btn:focus-visible {
  outline: 2px solid var(--color-focus);
  outline-offset: 2px;
}
.btn--primary { background: var(--color-action-primary); color: #fff; }
.btn--primary:hover { background: var(--color-action-primary-hover); }
.btn--secondary { background: transparent; color: var(--color-action-primary); border-color: currentColor; }
.btn:disabled { opacity: 0.6; cursor: not-allowed; }
@media (prefers-reduced-motion: reduce) { .btn { transition: none; } }
```

The API is: variant class, optional disabled attribute, optional icon slot, text content. Document it. Do not expose twenty modifiers for a beginner system.

### Step 5 — Match Figma variants to code variants

List the Figma variants and map each to a class or attribute:

| Figma variant | Code |
|---|---|
| Button / Primary / Default | `.btn.btn--primary` |
| Button / Primary / Hover | `.btn.btn--primary:hover` |
| Button / Secondary / Default | `.btn.btn--secondary` |
| Button / Primary / Disabled | `.btn.btn--primary[disabled]` |
| Button / Primary / Loading | `.btn.btn--primary[aria-busy="true"]` |

If Figma has a variant that code cannot express, either add it to code or remove it from Figma. A variant that exists only in the design file is a future bug.

### Step 6 — Build the second component and compose

An input needs: label, input, helper text, error text, focus style, disabled state and a clear relationship between them.

```html
<div class="field">
  <label class="field__label" for="amount">Amount to save</label>
  <input class="field__input" id="amount" name="amount" inputmode="numeric" aria-describedby="amount-help">
  <p class="field__help" id="amount-help">Enter an amount in naira, for example 5000.</p>
</div>
```

Then compose: a card that contains a heading, an input and a button. Composition is the test of a system. If the components only work alone, the system is incomplete.

### Step 7 — Document usage, not just appearance

A usage page should show:

- the component name and purpose;
- when to use it and when not to;
- the exact HTML;
- every variant and state;
- accessibility behaviour: keyboard, focus, labels, announcements;
- do/don't examples;
- token dependencies;
- known limitations.

Documentation that says only "Primary button: green" is a picture, not a system. The useful part is "use primary for the single main action on a screen; do not use two primary buttons side by side."

### Step 8 — Check for drift

Drift is inevitable unless you check. Create a table:

| Token | Figma value | Code value | Match? | Action |
|---|---|---|---|---|
| `color-action-primary` | `#0B5D3B` | `#0B5D3B` | Yes | — |
| `space-card-padding` | 24px | 24px | Yes | — |
| `radius-button` | 8px | 12px | No | Fix code to 8px |
| `font-size-h2` | 24px | 1.5rem (24px) | Yes | — |

Run this check after any change to either side. In a team, add it to the pull-request checklist. In a solo project, put it in your build notes.

### Step 9 — Decide what not to systematise

Not everything belongs in a system. Keep local:

- one-off marketing layouts;
- experimental concepts;
- content that changes weekly;
- components used once and unlikely to recur.

Premature systematisation creates maintenance work with no benefit. A good rule: systematise the third repeated use, not the first.

## 6. Worked example (I do)

A learner, Ngozi, has a Figma button with three variants and a card with two padding sizes. She builds a coded system:

1. **Primitives:** five greens, four neutrals, a six-step spacing scale, two radii.
2. **Semantics:** `color-action-primary`, `color-action-primary-hover`, `color-text`, `color-text-muted`, `color-surface`, `space-card-padding`, `radius-card`, `radius-button`.
3. **Components:** `.btn` with primary, secondary and disabled; `.field` with label, input, help and error; `.card` that composes them.
4. **Docs:** a page showing each variant, the HTML, the focus behaviour and one do/don't.
5. **Drift check:** she finds that Figma's card radius is 12px but her code used 16px. She fixes the code and records it.

She also removes a "tertiary ghost" button from Figma because it had no use case and no code equivalent. The system is smaller and true.

**The reasoning:** the goal is not maximum coverage. It is a small set of values and components that are actually used, documented and matched. A system with three true components beats a library with thirty broken ones.

## 7. We do it together

Using your own components:

1. Write five primitive colour tokens and three semantic ones.
2. Write a four-step spacing scale and apply it to one component.
3. Build a button with default, hover, focus-visible, disabled and loading states.
4. Build a field with label, input, help text and error text connected by `aria-describedby`.
5. Fill in a five-row drift table comparing Figma and code.
6. Write three "do/don't" rules for using the button.

**Hint:** if a value appears in three places, it is a token. If it appears once, leave it local until it repeats.

## 8. Your turn (You do)

Create a small coded design system with:

- at least 8 primitive tokens and 6 semantic tokens;
- a documented type and spacing scale;
- at least two components, each with at least three states;
- one composed example using both components;
- a usage page with HTML, do/don't rules and accessibility notes;
- a drift table with at least 6 rows and one real mismatch fixed;
- a short governance note: who can change a token, and what must be checked before merging.

Use a fictional product. Keep the scope small enough to finish and explain.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** When a token set moves from Figma into CSS, what is the difference between a primitive and a semantic token?
- A. Primitive tokens are only used in code, while semantic tokens exist only inside the Figma file.
- B. Semantic tokens always describe colours, while primitive tokens also cover spacing and radius values in the file.
- C. There is no real difference; the two names describe the same value at different points in the file.
- D. A primitive is a raw value like green-700; a semantic token names a job and points to it.

**Q2.** Why use `rem` for font sizes?
- A. Because it is shorter to type than pixels, keeping the stylesheet compact and easier to scan.
- B. Because it makes text bold by default, so headings need fewer separate font-weight declarations.
- C. Because HTML requires relative units for text, and pages using pixels fail validation.
- D. Because it respects browser zoom and user font settings, unlike a fixed pixel size.

**Q3.** A Figma variant has no code equivalent. What is the correct response?
- A. Ignore it for now, since the coded components already cover the main actions the product needs.
- B. Either implement the variant in code or remove it from the Figma file entirely.
- C. Add a screenshot of the variant to the code folder so developers can reference it.
- D. Rename the variant so it matches a code class, and leave the implementation unchanged.

**Q4.** What is drift?
- A. An animation that plays when a token changes, showing the old and new values.
- B. A type of token that stores a value the team wants to review before release.
- C. A Git branch where designers and developers merge their changes before a release.
- D. A mismatch between the value in the design source and the value in the built product.

**Q5.** Which is a good reason NOT to add a component to the system?
- A. It appears on every screen, so keeping one canonical version would reduce repeated work.
- B. It is used once, on a single page, and is unlikely to appear again.
- C. It carries accessibility requirements, such as labels, focus behaviour and announced errors.
- D. It has several variants, such as primary, secondary, disabled and loading states.

**Q6.** What should component documentation include?
- A. Purpose, usage rules, the exact HTML, states, accessibility behaviour, do/don't examples and known limitations.
- B. A single screenshot of the component, so readers can see what it looks like in use.
- C. The designer's name and contact details, so readers know who to ask about changes.
- D. A list of every colour in the company palette, with hex values and contrast ratios.

**Q7.** Why connect help text to an input with `aria-describedby`?
- A. So assistive technology announces the help text together with the field when it receives focus.
- B. So the input can be made wider, giving long help text more room beside the field.
- C. So the form can validate the answer before it is submitted to the server.
- D. So the input changes colour when the help text is present, matching the design spec.

**Q8.** A button's focus outline is removed because it "looks ugly". What is the problem?
- A. Nothing is wrong, because focus outlines are optional decoration that designers may remove.
- B. Keyboard users lose the only indication of which element is focused, so they cannot navigate reliably.
- C. The page becomes slower, because browsers recalculate the outline on every key press.
- D. The grid breaks, because the outline was contributing to the column widths of the layout.

**Q9.** A design token changes in Figma but the coded component still uses the old hex value. What should the team add?
- A. A larger component library, so the team has more ready-made parts to choose from.
- B. A rule that developers memorise every hex code, so they notice when a value changes.
- C. A drift check that compares the token source with the coded values and flags mismatches.
- D. A new logo, so users associate the refreshed visual identity with the updated colours.

**Q10.** A coded design system uses pixels for all font sizes, and users who increase their browser text size see no change. What is the problem?
- A. The page has too many semantic tokens, which override the browser's text-size preference.
- B. The CSS file is too small to hold the media queries that respond to larger text.
- C. The buttons use the wrong border radius, which stops the layout from scaling proportionally.
- D. Absolute pixel sizes ignore the user's text-size preference, so relative units such as rem are needed.

## 10. Practical task and pass criteria

**Task.** Submit the coded design system, usage page and drift table.

**Pass criteria — all must be met:**

- [ ] At least 8 primitive and 6 semantic tokens are defined and used.
- [ ] Type and spacing scales are documented, with units explained.
- [ ] Two components each support at least three states.
- [ ] One composed example uses both components together.
- [ ] A usage page shows HTML, variants, accessibility behaviour and do/don't rules.
- [ ] A drift table has at least 6 rows and one real mismatch corrected.
- [ ] Focus is visible, labels are connected, and contrast meets 4.5:1 for text and 3:1 for UI boundaries.
- [ ] A governance note states who changes tokens and what is checked before merging.
- [ ] No real client or personal data is present.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Tokens named after colours | Easy to write | Use role names: `color-action-primary`. |
| Every Figma value copied | Fidelity feels good | Copy the scale, not every outlier. |
| Components with no docs | Docs feel like extra work | Write the five-line usage note as you build. |
| Figma and code drift | No check | Fill the drift table after each change. |
| Too many variants | Enthusiasm | Keep only variants with a real use case. |
| Focus removed | Aesthetic preference | Add a visible `:focus-visible` style. |
| Semantics skipped | Visual focus | Use native elements and labels. |
| System built before use | Wanting to look professional | Systematise the third repeated use. |

**Retry variant.** Take a different pair of components (for example a badge and an alert) and build only the tokens and states, with no layout. The constrained version tests whether you can define an API and a state model without hiding behind visual design. Submit the token file, the state table and a 100-word note on what you left out.

## 12. Proof artifact for your portfolio

Keep the token file, components, usage page and drift table. In a portfolio, this shows systems thinking and engineering collaboration. Label the product as fictional and state that the tokens are a teaching scale, not a client system.

## 13. Low-data and low-cost path

- No build tools are needed: plain CSS custom properties work in every modern browser.
- Work offline; the only online step is optional video.
- Use system fonts to avoid font downloads and licensing.
- Keep components to two; skip a documentation site and use a single `index.html`.
- If Figma is unavailable, use a screenshot of your component and record values in a table.

## 14. Watch and read more

**Recommended video:** *Tokens, variables, and styles - Update: Introduction to design systems* by Figma (2023, 13 min 12 s) — `https://www.youtube.com/watch?v=JyCmacSyDY4`. Explains how Figma variables and styles map to token thinking. Metadata checked 2026-10-30; embedded playback was verified in Chrome on 2026-10-30.

**Read:**

- Figma Help, *Guide to components in Figma* — `https://help.figma.com/hc/en-us/articles/360038662654-Guide-to-components-in-Figma`. Component and variant fundamentals.
- MDN, *Using CSS custom properties* — `https://developer.mozilla.org/en-US/docs/Web/CSS/Guides/Cascading_variables/Using_custom_properties`. The code mechanism for tokens.
- W3C WAI, *WCAG 2.2 Quick Reference* — `https://www.w3.org/WAI/WCAG22/quickref/`. Focus, contrast, labels and target size.
- GOV.UK Design System — `https://design-system.service.gov.uk/`. A public example of components, patterns and documentation done well.

## 15. What comes next

Stop 5.4 makes the system responsive and resilient: mobile-first layout, fluid type and spacing, images that do not waste data, performance budgets, offline states and low-bandwidth behaviour.