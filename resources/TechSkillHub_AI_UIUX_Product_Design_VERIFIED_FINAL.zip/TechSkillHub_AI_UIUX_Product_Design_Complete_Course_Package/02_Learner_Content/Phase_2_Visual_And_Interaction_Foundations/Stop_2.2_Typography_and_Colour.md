---
stop_id: 2.2
title: Typography and Colour
phase: 2
prerequisites: Stop 2.1
outcome: Build a small type scale and a semantic colour system that pass WCAG AA contrast for their intended use, and justify the choices in plain language.
time: 70-90 minutes
artifact: A type scale and colour token sheet with contrast ratios recorded, applied to one screen, plus a rationale.
---

# Stop 2.2 — Typography and Colour

> **Phase 2 · Visual and interaction foundations** · Prerequisite: Stop 2.1 · Suggested session: 70–90 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Build a type scale with a stated ratio, and set line height and measure appropriate to the screen.
2. Choose and pair typefaces for legibility rather than fashion.
3. Build a semantic colour system with roles, not a palette of pretty hex codes.
4. Check contrast against WCAG 2.2 AA and record the ratios.
5. Explain why colour alone is never enough to communicate state.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Typeface** | The design of a set of letters, such as Inter or Roboto. Often called a font in everyday speech. |
| **Font** | A specific file or weight of a typeface, such as Inter Bold 700. |
| **Type scale** | A fixed set of text sizes related by a ratio. |
| **Ratio** | The multiplier between steps, for example 1.25 (major third) or 1.333 (perfect fourth). |
| **Line height (leading)** | The vertical space between lines of text, usually written as a multiple of the font size. |
| **Measure** | The length of a line of text, measured in characters. |
| **Weight** | How thick the strokes are: regular, medium, semibold, bold. |
| **Tracking** | Space between all letters, useful for small caps or large headings. |
| **Kerning** | Space between a specific pair of letters. |
| ** x-height** | The height of lowercase letters without ascenders; affects perceived size. |
| **Contrast ratio** | A number from 1:1 to 21:1 describing the luminance difference between two colours. |
| **WCAG** | The Web Content Accessibility Guidelines, the international standard for web accessibility. |
| **AA / AAA** | Conformance levels. AA is the common legal and professional baseline; AAA is stricter. |
| **Semantic colour** | A colour named by its job (`text-secondary`, `surface-danger`), not its appearance (`light grey`, `red`). |
| **Token** | A named value used across a design system, such as `color.text.primary`. |
| **Palette** | The full set of colours available before roles are assigned. |
| **Tint / shade** | A lighter or darker version of a colour. |
| **Dark mode** | A theme with dark surfaces and light text; it needs its own contrast checks. |

## 3. Why this matters

Text is most of the interface. If the type is hard to read, nothing else matters. If the colour system is a pile of one-off hex codes, the product will drift into inconsistency the moment a second designer or an AI tool touches it.

Colour also carries meaning. Red usually signals danger, green success, amber warning. But meaning is cultural and contextual, and about 1 in 12 men has some form of colour vision deficiency. A design that says "failed" only with red is inaccessible; a design that says "failed" with red **and** an icon **and** the word "Failed" is robust.

> **Everyday example.** A bus park with handwritten signs in five different sizes is harder to use than one with a consistent sign system, even if both contain the same information. Typography is the sign system of the screen.

## 4. Before you start

- Open your Stop 2.1 after-frame.
- Choose one typeface with several weights. Good free options: Inter, Source Sans 3, IBM Plex Sans, Noto Sans. For a distinct heading, a second family is optional; one well-used family is often better.
- Open WebAIM Contrast Checker in a browser tab: `https://webaim.org/resources/contrastchecker/`.

## 5. Teaching, step by step

### Step 1 — Choose a type scale

Start from a 16 px body and multiply by a ratio.

| Step | 1.2 ratio | 1.25 ratio | Use |
|---|---|---|---|
| Caption | 11 | 10 | Rare; avoid below 12 px on mobile |
| Small | 13 | 13 | Labels, metadata |
| Body | 16 | 16 | Default reading size |
| Lead | 19 | 20 | Intro paragraph |
| H3 | 23 | 25 | Section title |
| H2 | 28 | 31 | Page section |
| H1 | 33 | 39 | Screen title |
| Display | 40 | 49 | Amount or hero number |

For mobile product screens, a 1.2–1.25 ratio is usually enough. A 1.333 ratio creates dramatic jumps that suit marketing pages, not dense forms.

Why not pick sizes by feel? Because a scale keeps relationships stable when you add a new size. If you need a new size, add a step; do not invent 17 px.

### Step 2 — Set line height by text size

- Body text: 1.4–1.6× the font size. At 16 px, that is 22–26 px.
- Headings: 1.1–1.3×. At 32 px, that is 35–42 px.
- Small labels: 1.3–1.4×.

Too tight and lines collide; too loose and the paragraph loses cohesion. Long paragraphs need more line height than short labels.

### Step 3 — Control measure

On mobile, 30–45 characters per line. On desktop, 45–75. To check in Figma, count characters in a typical line, not the maximum possible.

If a paragraph is too wide, constrain the text box rather than shrinking the font. If it is too narrow, reduce side padding or font size — in that order.

### Step 4 — Pair typefaces with a job, not a mood

A safe pairing:

- **One family for everything**, using weight and size for hierarchy. Hard to get wrong, fast to load.
- **A second family for headings only**, if the brand needs character. Keep the body family highly legible.

If you pair, contrast the roles: a geometric or display heading with a neutral humanist body. Do not pair two similar sans-serifs; the difference reads as a mistake rather than a decision.

Avoid: very light weights for body text (especially on low-quality screens), all-caps for long text, and decorative fonts for anything a user must read quickly.

### Step 5 — Build a palette, then assign roles

Start with:

- **Neutrals:** 9 steps from near-white to near-black.
- **Brand:** one primary colour with 5–9 steps.
- **Semantic:** success, warning, danger, info, each with a surface and a text variant.

Then assign **roles**:

```
color.text.primary      near-black on light surface
color.text.secondary    mid-grey, still 4.5:1 on surface
color.text.disabled     low contrast, exempt from AA but must be recognisable
color.surface.default   page background
color.surface.raised    card background
color.border.default    subtle divider
color.action.primary    filled button background
color.action.primary-text  text on the button
color.feedback.danger   error text and icon
color.feedback.success  success text and icon
```

A role can point to a palette value. In Figma, this becomes a variable in Stop 3.3. The point is that a screen uses `text.secondary`, not `#6B7280`, so a theme change is one edit, not two hundred.

### Step 6 — Check contrast, and record it

WCAG 2.2 AA requirements for text:

- **Normal text:** at least **4.5:1**.
- **Large text** (18 pt regular or 14 pt bold, roughly 24 px or 18.66 px bold): at least **3:1**.
- **Non-text UI components and graphical objects** needed to understand content: at least **3:1** against adjacent colours (SC 1.4.11).
- **Focus indicators:** must be visible; WCAG 2.2 adds specific focus appearance requirements (SC 2.4.11/2.4.13).

Use WebAIM or Figma's contrast checker. Record the ratio next to each pair in your token sheet. Do not guess. Do not trust a palette generator's claim without checking the actual pair you will ship.

> **Common error:** checking `#111` on `#fff` (great) and then using `#999` on `#f5f5f5` for secondary text (often around 2.5:1, failing). Secondary text still needs 4.5:1 if it is normal-sized.

### Step 7 — Never rely on colour alone

For every state, use at least two signals:

| State | Colour | Additional signal |
|---|---|---|
| Error | Red | Icon + the word "Error" + message near the field |
| Success | Green | Check icon + "Payment sent" |
| Warning | Amber | Triangle icon + explicit consequence |
| Disabled | Grey | Reduced opacity + no pointer affordance + `aria-disabled` in code |
| Selected | Brand tint | Checkmark or border + `aria-selected` |

This is WCAG SC 1.4.1 (Use of Color). It also helps in bright sunlight, on poor screens, and for users who cannot distinguish the hues.

### Step 8 — Test in context

View the screen at 100% on a phone, outdoors if possible, and at 200% text size. Check:

- Does the body text remain readable?
- Do buttons grow rather than clip when text enlarges?
- Does secondary text still pass contrast?
- Does the design still make sense in greyscale?

Greyscale is a fast proxy for "is colour carrying meaning alone?"

## 6. Worked example (I do)

**Screen:** transfer confirmation.

**Type scale (1.25):** 13 / 16 / 20 / 25 / 31 / 39.

- Amount: 39 px, weight 700, line height 44.
- Recipient: 20 px, weight 500, line height 26.
- Labels: 13 px, weight 400, line height 18.
- Warning: 13 px, weight 500, line height 18.
- Button label: 16 px, weight 600.

**Why these choices:** the amount is the key verification fact, so it takes the display step. The recipient is secondary but still large enough to scan. Labels are small but not below 12 px, because mobile screens and low-quality displays punish tiny text.

**Colour roles:**

| Role | Value | On | Ratio | Use |
|---|---|---|---|---|
| `text.primary` | `#111827` | `#FFFFFF` | 17.7:1 | Amount, headings |
| `text.secondary` | `#4B5563` | `#FFFFFF` | 7.6:1 | Labels, helper text |
| `text.on-brand` | `#FFFFFF` | `#1D4ED8` | 8.6:1 | Button label |
| `border.default` | `#D1D5DB` | `#FFFFFF` | 1.5:1 | Dividers only, not essential |
| `feedback.danger` | `#B91C1C` | `#FFFFFF` | 6.4:1 | Error text |
| `surface.subtle` | `#F3F4F6` | `#111827` | 15.9:1 | Disabled field background with dark text |

The border at 1.5:1 is acceptable only because it is decorative; an input border that is the only cue for a field boundary would need 3:1.

**Error state:** red border, red icon, the word "Error", and the message "Enter a 10-digit account number" directly below the field. Four signals, one of which is text. A user who cannot see red still understands.

**What I rejected:** a light grey 14 px amount, because it failed hierarchy and contrast; a green "success" colour for the primary button, because green is semantically overloaded and the button is an action, not a status.

## 7. We do it together

1. Choose one typeface and list its available weights.
2. Build a scale in Figma as text styles: caption, small, body, lead, h3, h2, h1, display. Use a 1.25 ratio from 16 px.
3. Set line heights: body 1.5, headings 1.2, labels 1.35.
4. Apply the scale to your Stop 2.1 screen. Use no more than four styles on one screen.
5. Build a neutral ramp with nine steps. Name them `neutral.50` to `neutral.900`.
6. Choose one brand colour and generate five steps. Check each text pair you intend to use.
7. Assign roles in a table: text, surface, border, action, feedback.
8. Record the contrast ratio for every text/background pair. Mark any pair below 4.5:1 as "large text only" or fix it.
9. Convert the screen to greyscale. Does any meaning disappear?
10. Enlarge the text to 200% in the browser or Figma and note what breaks.

## 8. Your turn (You do)

**Independent task.** Produce a **type and colour specification** for your project, applied to one screen.

Submit:

1. The type scale table: name, size, weight, line height, use, and the ratio between steps.
2. A specimen image showing every style in a real sentence, not filler Latin text.
3. A palette with 9 neutrals, one brand ramp, and four semantic colours.
4. A role table mapping each token to a value and a use.
5. A contrast table with at least **eight** text/background pairs and their measured ratios, including at least one large-text pair and one non-text pair.
6. The applied screen, in colour and greyscale.
7. A 180-word rationale covering: why this typeface, why this ratio, why these colours, and one accessibility decision you made that you would not have made without checking.

**Rules:** no pair below 4.5:1 for normal text may be presented as body text. No meaning may depend on colour alone. Do not use a font you have not licensed; free and open-source fonts are fine.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** What does a type scale ratio of 1.25 mean?
- A. Every size in the scale is 1.25 px larger than the one before it.
- B. The line height for all text styles is fixed at a 1.25 multiplier.
- C. Each step in the scale is 1.25 times the size of the step below.
- D. The typeface provides 1.25 available weights, from light through to bold.

**Q2.** What is the WCAG 2.2 AA minimum contrast for normal body text?
- A. 2:1, a threshold that applies only to decorative borders and dividers.
- B. 3:1, the threshold shared by large text and essential icons.
- C. 4.5:1, the minimum SC 1.4.3 sets for normal-sized body text.
- D. 7:1, the stricter AAA target for normal text above the AA baseline.

**Q3.** What is the minimum for large text under AA?
- A. 2:1, the floor for decorative separators that carry no information.
- B. 4.5:1, the normal-text threshold applied here because large text is harder.
- C. 3:1, the lower threshold AA allows once text reaches large-text size.
- D. 7:1, the AAA target for small text that designers often over-apply.

**Q4.** Why is a placeholder not a label?
- A. It disappears once typing starts, so the field's instruction is lost.
- B. It is always set too small to read comfortably on a phone screen.
- C. It cannot be announced by screen readers, which skip placeholder text.
- D. It is not permitted in forms under the WCAG 2.2 AA standard.

**Q5.** A designer uses red text alone to indicate an error. Which principle is violated?
- A. The contrast minimum, because red text rarely reaches a 4.5:1 ratio.
- B. Use of colour alone (WCAG 1.4.1), because hue carries the meaning.
- C. Text resize, because the error message does not grow at 200% zoom.
- D. Focus visible, because the field shows no outline when tabbed to.

**Q6.** Why use semantic colour roles instead of raw hex values in screens?
- A. Roles survive theme changes and keep meaning consistent across every screen.
- B. Hex values take longer to load, so screens that use them render more slowly.
- C. Roles raise contrast automatically, so a failing pair passes once it is tokenised.
- D. Figma cannot store raw hex values reliably across shared team libraries.

**Q7.** Body text at 16 px with a line height of 16 px will most likely be…
- A. Perfectly readable, because the lines are spaced exactly one text size apart.
- B. Too tight, so ascenders and descenders collide and reading slows down.
- C. Too loose, because each line occupies a full 16 px of vertical space.
- D. Inaccessible, because the grey text colour fails the 4.5:1 threshold.

**Q8.** You check `#9CA3AF` grey text on white and get 2.6:1. It is used for 13 px helper text. What should you do?
- A. Keep it as it is, because helper text is exempt from contrast requirements.
- B. Darken it to at least 4.5:1, or enlarge it to the large-text threshold for 3:1.
- C. Make the helper text bold and keep the colour, since weight raises contrast.
- D. Add an icon beside the helper text so the low contrast no longer matters.

**Q9.** A learner needs a muted grey for 13 px helper text on a white card. Which action is correct?
- A. Pick a grey reaching 4.5:1 on white and confirm it with a checker.
- B. Pick any grey lighter than body text, since helper text is optional.
- C. Use 3:1, because all secondary text counts as large text.
- D. Trust your own screen; if the grey looks readable, it passes.

**Q10.** A form marks an invalid field only with a red border. Which user group is most directly excluded?
- A. People who cannot distinguish the red border from the surrounding border colour.
- B. People who use a mouse instead of a keyboard to complete the form.
- C. People on a fast internet connection who skip past the error message.
- D. People who prefer dark mode and see a different surface colour.

## 10. Practical task and pass criteria

**Task.** Submit the seven-part type and colour specification.

**Pass criteria — all must be met:**

- [ ] A type scale with a stated ratio and at least six steps.
- [ ] Line heights appropriate to size (body 1.4–1.6).
- [ ] A specimen using real sentences.
- [ ] Nine neutrals, one brand ramp and four semantic colours.
- [ ] A role table with at least ten tokens.
- [ ] Eight measured contrast pairs, with ratios and pass/fail labels.
- [ ] No normal text below 4.5:1 presented as body text.
- [ ] Greyscale version included and no meaning lost.
- [ ] A rationale that explains the accessibility decision.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Sixteen greys and no system | Each screen adds a shade | Build a 9-step ramp and assign roles. |
| Light grey body text | It looks elegant on a bright monitor | Check contrast at 4.5:1; test outdoors. |
| Placeholder used as label | It saves vertical space | Add a persistent label above the field. |
| Colour-only status | Red/green feels intuitive | Add icon and text; test in greyscale. |
| Too many font sizes | Every element seems unique | Limit to the scale; use weight for nuance. |
| Tiny text to fit more | Density pressure | Remove content or restructure; never go below 12 px for essential text. |
| Trusting a palette generator | It outputs pretty pairs | Measure the exact pair you will ship. |

**Retry variant.** Build a **dark-mode** version of the same specification. Every text/background pair must be re-measured; dark mode is not an inversion. Add a table of five pairs that passed in light mode but fail in dark mode, and explain how you fixed each. Submit the dark specification, the comparison table and a 120-word note on what surprised you.

## 12. Proof artifact for your portfolio

**Artifact:** `Type-and-Colour-Spec` — stored in `03_Projects/00_Foundations/visual-craft`.

This becomes the foundation of your design system in Stop 3.5 and your code tokens in Stop 5.3. Keep the measured ratios.

## 13. Low-data and low-cost path

- Use one system font (Inter, Roboto, system UI) instead of downloading a family.
- Check contrast with WebAIM in a browser; no plugin needed.
- Work in greyscale first if colour choice is slowing you down.
- The video is optional. The scale, roles and contrast rules are the lesson.
- If you have no Figma, build the spec as a table in a document and apply it to a paper sketch.

## 14. Watch and read more

**Recommended video (optional, 13:30):** *The ULTIMATE Guide To Typography For Beginners* — DesignSpo. `https://www.youtube.com/watch?v=AXpxZMRM1EY`. Verified available on 2026-10-30. It is a general typography guide; the WCAG thresholds and token structure here follow the standards cited below.

**Read (verified 2026-10-30):**

- W3C, *WCAG 2.2* — `https://www.w3.org/TR/WCAG22/`. See SC 1.4.1, 1.4.3, 1.4.11.
- W3C WAI, *How to Meet WCAG 2.2 Quick Reference* — `https://www.w3.org/WAI/WCAG22/quickref/`. Filter by "visual presentation" for a practical checklist.
- WebAIM, *Contrast Checker* — `https://webaim.org/resources/contrastchecker/`. Measure the exact pairs.

## 15. What comes next

Stop 2.3 turns these decisions into reusable **components and patterns**: buttons, forms, navigation, cards and lists, and the rules for choosing one over another.