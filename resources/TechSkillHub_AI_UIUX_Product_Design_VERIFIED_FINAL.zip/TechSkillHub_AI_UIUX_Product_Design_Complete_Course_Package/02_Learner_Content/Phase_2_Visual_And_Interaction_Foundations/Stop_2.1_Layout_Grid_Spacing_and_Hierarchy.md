---
stop_id: 2.1
title: Layout, Grid, Spacing and Hierarchy
phase: 2
prerequisites: Phase 1 gate passed
outcome: Lay out a screen on a consistent grid with a spacing scale and a clear visual hierarchy, and explain why it reads in the intended order.
time: 60-80 minutes
artifact: A before/after layout of one screen with a marked 8-point spacing scale, a 4-column mobile grid, and a one-paragraph explanation of the reading order.
---

# Stop 2.1 — Layout, Grid, Spacing and Hierarchy

> **Phase 2 · Visual and interaction foundations** · Prerequisite: Phase 1 gate · Suggested session: 60–80 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Set up a mobile grid with margins, columns and gutters, and place content on it.
2. Use a spacing scale instead of arbitrary values.
3. Control visual hierarchy with size, weight, colour and space — not decoration.
4. Explain the order in which a screen is read and why.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Layout** | The arrangement of elements on a screen. |
| **Grid** | A set of invisible columns and lines that keeps elements aligned. |
| **Column** | A vertical band in a grid. Mobile layouts often use 4 columns; desktop 12. |
| **Margin** | The space between the grid and the screen edge. |
| **Gutter** | The space between columns. |
| **Spacing scale** | A fixed set of allowed spacing values, usually multiples of 4 or 8. |
| **Padding** | Space inside a container, between its edge and its content. |
| **Gap** | Space between sibling items in a row or stack. |
| **Visual hierarchy** | The order in which the eye is drawn to elements, created deliberately. |
| **Contrast** | Difference between elements in size, weight, colour or space. |
| **Proximity** | Placing related items close together so they read as a group. |
| **Alignment** | Placing elements on shared edges or centres. |
| **Whitespace (negative space)** | Empty space used on purpose to separate and emphasise. |
| **Density** | How much content is packed into an area. |
| **Scan path** | The route the eye tends to take, often F-shaped or Z-shaped on text-heavy screens. |
| **Optical alignment** | Adjusting by eye where mathematical alignment looks wrong, such as round icons. |

## 3. Why this matters

Calm screens are not calm because of colour. They are calm because everything sits on a small number of shared lines and uses a small number of spacing values. Crowded screens are crowded because every element makes its own decision.

Hierarchy is how you answer the user's first question before they ask it. On a transfer confirmation, the first question is "how much?", the second is "to whom?". If the app name is the biggest thing on the screen and the amount is 14 px grey, the layout is answering the wrong question.

> **Everyday example.** A market stall with everything piled in one heap forces the buyer to dig. A stall with tomatoes in one crate, peppers in another and change in a third lets the buyer's eye go straight to what they need. Same goods, different arrangement, different speed.

## 4. Before you start

- Open your Stop 0.5 file or draw a phone frame on paper (393 × 852).
- Choose one screen with at least: a title, two pieces of content, and one action.
- If you are using Figma, turn on pixel grid and layout grid (`Shift + G` for layout grid).

## 5. Teaching, step by step

### Step 1 — Choose a spacing scale and never improvise

Use multiples of 4: `4, 8, 12, 16, 24, 32, 48, 64`.

Why 4? It divides evenly into common screen sizes, scales to different densities, and is small enough to express subtle differences. Many systems use 8; 4 is a finer base that still produces 8, 16, 24 and 32.

Rules:

- Gaps between closely related items: 4 or 8.
- Gaps between groups: 16 or 24.
- Screen margins: 16 or 24 (choose one and keep it).
- Section spacing: 32 or 48.

If a value is not on the scale, you need a reason. "It looked right at 13 px" is not a reason; it is a future inconsistency.

### Step 2 — Build the mobile grid

A practical mobile grid:

- Width: 393 px.
- Margin: 24 px each side.
- Columns: 4.
- Gutter: 16 px.
- Content width: 393 − 48 = 345 px.
- Column width: (345 − 3×16) / 4 = (345 − 48) / 4 = 74.25 px.

In Figma: select the frame, add a Layout grid, choose Columns, count 4, margin 24, gutter 16, and set the colour to a low-opacity red so you can see it without it dominating.

You do not need to place every element inside a column. The grid is a set of shared lines, not a cage. Full-width cards can span all four columns; a label and value can align to the outer margins.

### Step 3 — Establish three levels of hierarchy

Use only three levels to start:

| Level | Typical size | Weight | Use |
|---|---|---|---|
| Primary | 28–40 px | Bold | The one thing the screen is about: amount, headline, status. |
| Secondary | 16–20 px | Medium | Supporting facts: recipient, section titles. |
| Tertiary | 12–14 px | Regular | Labels, metadata, helper text, timestamps. |

Then add **one** accent signal: colour, a background block, or extra space. Not all three at once.

A useful test: blur the screen (or squint). Can you still tell what matters most? If everything becomes the same grey mush, your hierarchy depends on detail rather than structure.

### Step 4 — Use space to group

Proximity is stronger than lines. If a label sits 4 px above its value and 24 px below the previous row, it reads as belonging to the value. If it sits equidistant between two values, it belongs to neither.

Rules:

- Space **inside** a group < space **between** groups.
- Do not use a divider when space would do; too many lines create visual noise.
- Use a card when content needs a clear boundary (an image, a distinct action), not for every row.

### Step 5 — Align to fewer edges

Every element should align to one of a small number of edges: the left margin, the right margin, a centre line, or a column line.

Common beginner pattern: labels left-aligned at 24 px, values left-aligned right after the label, so the values form a ragged column. Better: labels at the left margin, values at the right margin, so the eye can compare values down the page.

### Step 6 — Control line length and density

For body text on mobile, aim for 30–45 characters per line. On desktop, 45–75. If a line runs the full width of a tablet, the eye loses its place on the return sweep.

Density is a choice: a banking app may be dense because users scan numbers; a meditation app may be spacious. Neither is universally better. Ask what the user is doing.

### Step 7 — Design the scan path

For a confirmation screen, the intended path is:

1. Amount (largest).
2. Recipient name and account (second).
3. Warning (third, but positioned in the path to the button).
4. Button (action).

Check the path by covering elements one at a time. If removing the title changes nothing, the title is not doing hierarchical work. If the button is the first thing the eye hits, the screen may be pushing action before verification.

### Step 8 — Fix a crowded screen with subtraction

When a screen feels crowded, do not shrink everything. Try, in order:

1. Remove what does not support the task.
2. Group related items and increase space between groups.
3. Reduce the number of font sizes.
4. Reduce the number of colours.
5. Only then reduce the size of secondary content.

Shrinking first produces tiny, unreadable screens that are still crowded.

## 6. Worked example (I do)

**Before:** a fictional transfer screen with a 14 px app name at the top, a 16 px title, the amount at 18 px, three dividers, four different margins (12, 18, 20, 24), and a green button that is the same size as a grey "Cancel" button.

**Problems, named:**

- No shared margin, so nothing lines up.
- The amount is smaller than the app name, so hierarchy answers the wrong question.
- Four font sizes within 6 px of each other create noise without meaning.
- Dividers plus spacing plus cards create three ways of grouping.
- Two equal-weight buttons make the risky action as easy as the safe one.

**After:**

- Margin fixed at 24 px.
- Amount at 40 px bold, recipient at 18 px medium, labels at 13 px regular.
- Dividers removed; 24 px gaps separate groups.
- One primary button, full width minus margins, 52 px tall; "Cancel" becomes a text link placed away from the button.
- Warning moved directly above the button.

**Reasoning, not just the answer:** the changes are not a style preference. Each one reduces the number of competing signals and increases the weight of the facts the user must verify. The design now has one margin, three type sizes, one grouping method and one clear action.

**How I would check it:** show the screen to three people for five seconds, then ask "how much and to whom?". If they cannot answer, the hierarchy is still wrong, regardless of how it looks.

## 7. We do it together

1. Draw or open a 393 × 852 frame.
2. Add a 4-column grid with 24 px margins and 16 px gutters.
3. Write your spacing scale at the side of the canvas: 4, 8, 12, 16, 24, 32, 48.
4. Place the title at the top margin, aligned to the left column line.
5. Place the most important fact at 40 px. Place the second at 18 px. Place labels at 13 px.
6. Set all outer margins to 24 px and check every element against the grid.
7. Remove one divider and replace it with 24 px of space. Does the grouping survive?
8. Squint at the screen. Identify the first, second and third things you see. Write them down.
9. If the order is wrong, change size or space — not colour first.

## 8. Your turn (You do)

**Independent task.** Take one screen from your own work (Stop 0.5 or a teardown screen) and produce a **before/after layout**.

Submit:

1. The before screenshot or frame.
2. The after frame with the grid visible and the spacing values annotated (at least eight annotations).
3. A list of every spacing value you changed and the scale value you replaced it with.
4. A 150-word explanation of the intended reading order and the three techniques you used to create it.
5. A five-second test: show both versions to one person and ask "what is this screen about, and what is the most important number or fact?" Record their answers verbatim. Do not explain the screen first.

**Do not** simply change colours; the task is structural. Do not use more than three type sizes and one accent colour.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** Why use a spacing scale instead of choosing each gap by eye?
- A. It creates consistency and removes arbitrary decisions that accumulate into visual noise.
- B. It keeps the design file smaller, because repeated gap values can be stored once.
- C. It is required by WCAG, which sets minimum spacing for all text blocks.
- D. It makes body text render larger, so fewer elements are needed per screen.

**Q2.** In a 4-column mobile grid with 24 px margins and 16 px gutters, what is the content width on a 393 px screen?
- A. 393 px, the width of the frame before either 24 px margin is deducted.
- B. 345 px, after subtracting both 24 px margins from the 393 px frame.
- C. 369 px, after subtracting a single 24 px margin from the 393 px frame.
- D. 321 px, after subtracting both margins and then one 24 px gutter again.

**Q3.** Which technique best groups a label with its value?
- A. Make the gap inside the pair smaller than the gap between neighbouring pairs.
- B. Draw a bordered box around each pair so the grouping is explicit.
- C. Give every label its own colour so related values are easy to spot.
- D. Centre each label and value in the row so the pair looks balanced.

**Q4.** A screen has a 36 px title, a 34 px subtitle, a 32 px amount and a 30 px button label. What is the main problem?
- A. The screen has too much contrast between its four main text elements.
- B. The text is too small to read, so each element needs a larger size.
- C. The four sizes are so close that hierarchy reads as noise instead of order.
- D. The elements sit on no shared grid, so nothing lines up vertically.

**Q5.** What is the fastest first response to a crowded screen?
- A. Reduce every text size by about 2 px so the screen holds more content.
- B. Remove or defer content that does not support the task at hand.
- C. Add divider lines between sections so the content is clearly separated.
- D. Add a second accent colour so the sections become easier to tell apart.

**Q6.** What does the squint test reveal?
- A. Whether the colour pairs on the screen reach the required contrast ratio.
- B. Whether the design file will export cleanly to a shareable image format.
- C. Whether the visible text has been proofread for spelling and grammar.
- D. Whether the intended hierarchy still survives once fine detail is blurred away.

**Q7.** Why is optical alignment sometimes needed?
- A. Because grids are optional once the designer trusts their own eye.
- B. Because users generally prefer deliberate asymmetry to perfectly even spacing.
- C. Because mathematically equal spacing can look uneven around round or irregular shapes.
- D. Because Figma cannot align circles and rounded icons to a grid.

**Q8.** A confirmation screen puts the primary button first in the reading order. Why is that a problem?
- A. Buttons should never be visible before the user has read every other element.
- B. It invites commitment before the facts are checked, which is risky for irreversible actions.
- C. It makes the screen taller than the viewport and forces the user to scroll.
- D. It breaks the spacing scale by placing a large element above smaller ones.

**Q9.** A learner is placing a balance label and value on a row. Which alignment choice best supports scanning?
- A. Centre every label and value independently so each row looks symmetrical.
- B. Place each value directly beneath its label with no gap between them.
- C. Align all labels to the left edge and all values to one right edge.
- D. Use a different alignment on each row so the list feels less repetitive.

**Q10.** A card's title, body text and button all have the same 16 px gap between them. What is the most likely hierarchy problem?
- A. The card uses too many colours, so the eye cannot tell which part matters.
- B. Equal spacing fails to group related content and separate the action from the description.
- C. The button is too large for the card and crowds the body text above it.
- D. The body text is written in sentence case, which flattens the card's hierarchy.

## 10. Practical task and pass criteria

**Task.** Submit the before/after layout, annotations, change list, 150-word explanation and five-second test notes.

**Pass criteria — all must be met:**

- [ ] Before and after versions of the same screen.
- [ ] A visible grid with consistent margins and gutters.
- [ ] At least eight spacing annotations using values from the scale.
- [ ] No more than three type sizes and one accent colour.
- [ ] A stated intended reading order that matches the design.
- [ ] Five-second test notes with verbatim answers from one person.
- [ ] The explanation links each technique to the reading order, not to taste.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Random 13/17/22 px spacing | Eyeballing feels precise | Snap to 4/8/12/16/24/32/48. |
| Every section in a card | Cards feel organised | Use space first; cards only where a boundary is meaningful. |
| Too many type sizes | Each element seems to need its own | Limit to three levels; use weight and colour for nuance. |
| Centring everything | It looks symmetrical | Left-align text for scanning; centre only short, isolated content. |
| Divider lines everywhere | They separate clearly | Space separates without adding ink. |
| Shrinking to fit | Fear of removing content | Remove or defer content; then adjust size. |
| Testing only by looking | Designers trust their eye | Use the squint test and a five-second recall test with a real person. |

**Retry variant.** Lay out a **settings screen** with eight rows, each with a label and a toggle, plus a section header and a destructive "Delete account" action. Use a 4-column grid and the same spacing scale. Then produce a second version for a **low-vision user** at 200% text size, and explain what breaks and how you fixed it. Submit both versions and a 120-word note on which layout decision was hardest.

## 12. Proof artifact for your portfolio

**Artifact:** `Layout-Before-After` — stored in `03_Projects/00_Foundations/visual-craft`.

This is a strong portfolio piece because it shows judgment, not just a final screen. Keep the annotations.

## 13. Low-data and low-cost path

- Paper works: draw the frame, mark the grid in pencil, and photograph the result.
- Use only one font family and three sizes; no font downloads.
- The video is optional. The scale, grid and hierarchy rules above are the lesson.
- The five-second test can be done in person with a classmate or family member; no recording needed.

## 14. Watch and read more

**Recommended video (optional, 10:23):** *Master Spacing in UI Design* — Jesse Showalter. `https://www.youtube.com/watch?v=cf95Z7Ngg8k`. Verified available on 2026-10-30. It covers spacing systems in Figma; the grid mathematics and hierarchy tests here are the course's own.

**Read (verified 2026-10-30):**

- Material Design 3, *Layout* — `https://m3.material.io/foundations/layout`. Official guidance on layout regions, spacing and adaptive design.
- GOV.UK Design System — `https://design-system.service.gov.uk/`. See how a mature system documents spacing and layout decisions.

## 15. What comes next

Stop 2.2 adds type and colour. You will learn why a 16 px body with 1.5 line height reads differently from a 16 px body with 1.1, and how to choose colours that pass contrast instead of merely looking pleasant.