---
stop_id: 2.3
title: Components and Patterns
phase: 2
prerequisites: Stop 2.2
outcome: Choose the right component or pattern for a task, build a small component set with consistent states, and explain the choice in terms of user goals.
time: 70-90 minutes
artifact: A component sheet with seven components (button, text field, select, checkbox/radio, card, list item, navigation), each with states and usage notes.
---

# Stop 2.3 — Components and Patterns

> **Phase 2 · Visual and interaction foundations** · Prerequisite: Stop 2.2 · Suggested session: 70–90 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Choose between a button, link, toggle, checkbox, radio and select for a given job.
2. Build seven components with default, hover/focus, pressed, disabled and error states where relevant.
3. Explain when to use a card, a list, a table or a plain section.
4. Name the pattern behind a flow and judge whether it fits the user's task.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Component** | A reusable interface part, such as a button or text field. |
| **Variant** | A version of a component for a different state or size. |
| **State** | The current condition of a component: default, hover, focus, pressed, disabled, loading, error, selected. |
| **Pattern** | A repeated solution to a recurring user problem, made of components. |
| **Affordance** | A visual cue that suggests how something can be used, such as a raised button or an underlined link. |
| **Button** | Triggers an action immediately. |
| **Link** | Navigates to another location or reveals more content. |
| **Toggle** | Changes a setting immediately, with an on/off state. |
| **Checkbox** | Selects zero, one or many options, usually applied later. |
| **Radio button** | Selects exactly one option from a small, visible set. |
| **Select / dropdown** | Chooses one option from a longer list, hidden until opened. |
| **Text field** | Accepts typed input. |
| **Stepper** | Moves through a sequence of steps, showing progress. |
| **Card** | A bounded container for related content and often one action. |
| **List** | A vertical sequence of similar items, efficient for scanning. |
| **Table** | Rows and columns for comparison across attributes. |
| **Navigation** | The system that lets users move between destinations. |
| **Breadcrumb** | A trail of links showing hierarchy. |
| **Empty state** | The screen or section shown when there is no content. |
| **Progressive disclosure** | Showing only what is needed now, revealing advanced options on request. |

## 3. Why this matters

Components are the vocabulary of an interface, and patterns are its grammar. Choosing wrong is not a cosmetic error; it changes what the user believes will happen. A toggle that requires a Save button breaks the user's mental model. A link styled as a button makes navigation feel like a commitment. A dropdown with three options hides choices that could have been visible.

Consistency is also a kindness. When every primary action looks the same across the product, users stop re-learning. When every error looks different, they slow down and lose trust.

> **Everyday example.** A door with a flat plate says "push". A door with a handle says "pull". If the plate is on a door that must be pulled, people will push it, then feel foolish. A button that looks pressable but does nothing is the same broken affordance.

## 4. Before you start

- Have your type and colour tokens from Stop 2.2.
- Create a new page in Figma called `02_Components`.
- Choose a base size: 44 px minimum height for touch controls, 16 px body text.

## 5. Teaching, step by step

### Step 1 — Choose the control by the job

| User's job | Control | Why |
|---|---|---|
| Trigger an action now | Button | Clear commitment, immediate effect. |
| Go somewhere else | Link | Navigation, not action. |
| Turn a setting on/off immediately | Toggle | No Save step; change applies at once. |
| Choose several options | Checkbox | Multiple selection. |
| Choose one of 2–4 options | Radio buttons | All options visible, easy comparison. |
| Choose one of 8+ options | Select | Saves space, but hides options. |
| Enter text | Text field | Direct input. |
| Move through a multi-step task | Stepper | Shows progress and remaining effort. |

Two rules that prevent most mistakes:

1. **Do not use a toggle for something that needs a Save button.** If the change is not immediate, use a checkbox or radio and a Save action.
2. **Do not hide three options in a dropdown.** If the set is small, show it. Visibility reduces errors.

### Step 2 — Build the button hierarchy

- **Primary:** one per screen or section. Filled, high contrast, specific label ("Send ₦25,000").
- **Secondary:** outlined or tonal, for a real alternative ("Save draft").
- **Tertiary:** text link, for low-emphasis or reversible actions ("Cancel").
- **Destructive:** danger colour, used only for irreversible actions, with confirmation.

Label rules: start with a verb, name the object, avoid "OK" and "Submit". "Delete 3 files" is clearer than "Confirm".

### Step 3 — Build the text field properly

A complete field has:

1. **Label** above the field, always visible.
2. **Input** with a clear boundary at 3:1 against the background.
3. **Helper text** below, for format or constraints.
4. **Error text** below, with an icon and specific instruction.
5. **Required/optional** marked in the label, not only with an asterisk.
6. **Autocomplete** and correct keyboard type in the eventual build.

States: default, focus (visible ring), filled, disabled, error, read-only, loading (for async validation).

### Step 4 — Decide card vs list vs table

| Content | Best default | Reason |
|---|---|---|
| Similar items scanned quickly, one line each | List | Efficient, predictable, accessible. |
| Items with an image, title, metadata and an action | Card | Groups varied content. |
| Comparison across several attributes | Table | Aligns values in columns. |
| A single section of a page | Plain section with a heading | No unnecessary container. |

Cards are overused. A card adds a border, padding and a shadow; if the content has no image and no action, a list row or a heading plus text is usually cleaner.

### Step 5 — Design navigation around destinations, not features

For a mobile app with 3–5 top destinations, a bottom tab bar is a strong default. For more, or for secondary items, use a "More" destination or a menu. For a desktop product with many sections, a side navigation with groups is often better.

Rules:

- Label every icon; an icon alone is a guess.
- Show the current location.
- Keep the number of top-level destinations small.
- Do not put destructive actions in navigation.

### Step 6 — Design the empty state as a first-class screen

An empty state needs:

- a short explanation of what would be here;
- one action to create the first item;
- a way to learn more, if needed;
- no fake data pretending the account has activity.

"We'll show your transfers here. Send your first transfer to get started." is better than a blank screen with a sad illustration and no route forward.

### Step 7 — Document usage, not just appearance

For each component, record:

- **Purpose:** what job it does.
- **Anatomy:** label, icon, container, helper text.
- **States:** default, hover, focus, pressed, disabled, error, loading.
- **Do:** one correct example.
- **Don't:** one incorrect example with the reason.
- **Accessibility:** keyboard behaviour, label, role, contrast.
- **Content rules:** sentence case, verb-first labels, maximum length.

This documentation is what turns a pile of components into a system. You will expand it in Stop 3.5.

## 6. Worked example (I do)

**Scenario:** a "Save beneficiary" form.

**Component choices, with reasoning:**

- **Name field:** text field with a visible label "Beneficiary name". Not a placeholder, because the label must persist.
- **Bank:** select, because there are many banks. Searchable in the eventual build.
- **Account number:** text field with `inputmode="numeric"`, an 10-digit helper, and inline validation after blur.
- **"Save as favourite":** checkbox, not a toggle, because it is part of a form that is submitted together.
- **Primary action:** "Save beneficiary" button, filled.
- **Secondary action:** "Cancel" text link, placed away from the primary.
- **Success:** a confirmation screen with the saved name and bank, plus "Add another" and "Done".

**Why not a toggle for favourite?** Because the whole form is submitted at once. A toggle implies immediate effect; if the user toggles it and then abandons the form, the setting would be ambiguous.

**Error state:** if the account number is 9 digits, the field shows a red border, an error icon, and the text "Account number must be 10 digits. You entered 9." The message names the rule and the current state. It does not say "Invalid input".

**Empty state for the beneficiary list:** "No saved beneficiaries yet. Save someone you pay often to skip entering their details next time." with a "Save beneficiary" button.

**What I rejected:** a card grid for beneficiaries, because each item has only a name and a bank; a list is faster to scan. A modal for the form, because it is a multi-field task that benefits from a full screen on mobile.

## 7. We do it together

1. On a new page, create a `Button` component with primary, secondary and tertiary variants.
2. Add default, hover, pressed, focus and disabled states. Use a visible focus ring at least 2 px thick.
3. Create a `Text field` component with label, input, helper and error variants.
4. Create a `Select`, a `Checkbox` and a `Radio` component, each with default, focus, selected and disabled states.
5. Create a `List item` with a leading icon, title, subtitle and trailing chevron.
6. Create a `Card` with image, title, metadata and one action.
7. Create a `Bottom navigation` with four destinations and a selected state.
8. For each component, write a four-line usage note: purpose, when to use, when not to use, accessibility note.
9. Place all seven on one page with labels. This is your component sheet.

## 8. Your turn (You do)

**Independent task.** Build a **seven-component sheet** for your own project and apply at least four of the components to one real screen.

Submit:

1. The component sheet with: button (3 variants × 5 states), text field (default, focus, error, disabled), select, checkbox/radio group, card, list item, bottom navigation.
2. A usage note for each component with purpose, do, don't and accessibility.
3. One screen using at least four components consistently.
4. A 150-word "choice defence": for two controls, explain why you chose that control over the nearest alternative (for example, checkbox over toggle).
5. A list of every state you did **not** design, and why it is acceptable for now.

**Do not** copy a component library wholesale. Build the seven yourself so you understand their anatomy. Do not use icon-only navigation without labels.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** Which control should turn a setting on immediately, with no Save step?
- A. A checkbox, because it records a choice that is applied when the form is saved.
- B. A radio button, because it shows a small set of options side by side.
- C. A dropdown, because it hides the list until the user opens it.
- D. A toggle, because it changes the setting at once with no confirmation step.

**Q2.** When is a dropdown a poor choice?
- A. When the list holds forty options and the user must find one bank.
- B. When the option labels are long enough to wrap onto two lines.
- C. When the user is on a mobile screen with limited vertical space.
- D. When only two or three options exist and all could be shown.

**Q3.** What is the difference between a button and a link?
- A. A link is always blue and underlined, while a button uses a filled background.
- B. A button can only be used once, whereas a link can be followed repeatedly.
- C. A button triggers an action, while a link navigates or reveals more content.
- D. There is no real difference; both simply respond when the user clicks them.

**Q4.** Which content is best as a list rather than a card?
- A. A product with an image, a price and an Add to cart action.
- B. A promotional banner announcing a seasonal discount across the store.
- C. A photo gallery of customer images from the past month.
- D. Ten beneficiaries, each with a name and a bank and nothing else.

**Q5.** What must a text field label do?
- A. Disappear once the user starts typing so the field looks less cluttered.
- B. Sit inside the field as grey placeholder text until the input begins.
- C. Stay optional, so only the fields a user cares about carry a label.
- D. Remain visible above the field so its purpose is never lost.

**Q6.** Which is a good empty-state message?
- A. 'No saved beneficiaries yet. Save someone you pay often to skip this next time,' plus an action.
- B. 'No data is available for this section right now,' with no explanation and no action.
- C. 'Nothing here yet,' shown with a small illustration but no route forward for the user.
- D. A sad face illustration on its own, with no text message and no button at all.

**Q7.** Why is a visible focus state essential?
- A. It makes the interface look modern and up to date with current design trends.
- B. It raises the control's contrast ratio automatically whenever the ring appears.
- C. Keyboard users need to see which control will receive their next input.
- D. It matters only on forms, where several fields sit close together.

**Q8.** A toggle is used for "Subscribe to marketing emails" inside a form with a Save button. What is wrong?
- A. The toggle implies immediate effect, yet the setting only applies after Save.
- B. Nothing is wrong, because toggles are always acceptable for binary settings.
- C. It should be a link, because subscribing is really a navigation choice.
- D. It should be a table, because the preference is one row of data.

**Q9.** A learner must let users choose one of three delivery speeds before confirming an order. Which control is the best fit?
- A. A dropdown that hides two of the three speeds until the user opens it.
- B. A toggle switch for each speed, so users can enable any they like.
- C. A free-text field where the user types the speed they want.
- D. A radio group showing all three speeds and what each one costs.

**Q10.** A learner uses a toggle for 'Email me offers' inside a form that only takes effect when the user presses Save. What is the interaction problem?
- A. The toggle is too small to see, so users miss it beside the longer fields.
- B. The label is written as a sentence rather than a short verb phrase.
- C. The form has no Submit button, so the setting can never be applied.
- D. The toggle implies an immediate change, but the setting only applies on Save.

## 10. Practical task and pass criteria

**Task.** Submit the component sheet, the applied screen, the choice defence and the missing-states list.

**Pass criteria — all must be met:**

- [ ] Seven components, each with the required states.
- [ ] Buttons have primary, secondary and tertiary variants.
- [ ] Text field includes visible label, helper, error and focus states.
- [ ] Usage notes include do, don't and an accessibility note.
- [ ] One screen uses at least four components consistently.
- [ ] The choice defence compares two controls and names the nearest alternative.
- [ ] Missing states are listed honestly.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Toggle for a form setting | Toggles look modern | Use checkbox/radio when a Save step exists. |
| Icon-only navigation | Icons save space | Add labels; test recognition. |
| Cards for everything | Cards look tidy | Use lists for uniform rows, sections for single content. |
| Placeholder as label | Saves vertical space | Add a visible label above. |
| No focus state | Mouse-first design | Add a 2 px visible ring; test with Tab. |
| Error text "Invalid input" | It is quick to write | Name the rule and the fix. |
| Components with no usage notes | Documentation feels secondary | Write purpose, do, don't, accessibility. |

**Retry variant.** Build a **five-component sheet for a desktop dashboard**: side navigation, table, filter bar, status badge and modal. Add a "density" variant for the table (comfortable and compact). Document when each density is appropriate. Submit the sheet plus a 120-word note on how desktop choices differ from mobile and why.

## 12. Proof artifact for your portfolio

**Artifact:** `Component-Sheet-v1` — stored in `03_Projects/00_Foundations/components`.

This becomes the core of your mini design system in Stop 3.5.

## 13. Low-data and low-cost path

- Use Figma's built-in shapes and text; no icon packs required.
- Draw icons as simple geometric shapes or use text labels.
- If Figma is unavailable, build the sheet on paper as a grid of drawings with state annotations.
- The video is optional. The control-choice table is the lesson.

## 14. Watch and read more

**Recommended video (optional, 7:53):** *40 UI elements every designer needs to know* — LogRocket. `https://www.youtube.com/watch?v=xCrhKzyxp0M`. Verified available on 2026-10-30. It is a rapid vocabulary tour; use this lesson's control-choice rules for decisions.

**Read (verified 2026-10-30):**

- GOV.UK Design System, *Components* — `https://design-system.service.gov.uk/components/`. Excellent examples of usage notes, do/don't guidance and accessibility.
- Material Design 3, *Components* — `https://m3.material.io/components`. Official anatomy and states for common components.

## 15. What comes next

Stop 2.4 designs the moments beginners skip: loading, empty, error, success, disabled and offline. These states are where trust is won or lost.