---
stop_id: 2.4
title: Interaction and States
phase: 2
prerequisites: Stop 2.3
outcome: Design the full set of states for a flow, including loading, empty, error, success, disabled and offline, and specify how the user recovers from each.
time: 70-90 minutes
artifact: A state map for one flow with at least seven states, each with a screen or component variant and a recovery path.
---

# Stop 2.4 — Interaction and States

> **Phase 2 · Visual and interaction foundations** · Prerequisite: Stop 2.3 · Suggested session: 70–90 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. List every state a flow needs, not just the happy path.
2. Design loading, empty, partial, error, success, disabled and offline states.
3. Write error messages that name the problem and the recovery action.
4. Decide when to block, warn, confirm or allow undo.
5. Explain why a dead-end error is a design failure.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **State** | A condition the interface can be in. |
| **Happy path** | The sequence when everything works as expected. |
| **Edge case** | An uncommon but real situation, such as a missing name lookup. |
| **Loading state** | What the user sees while waiting. |
| **Skeleton screen** | Grey placeholder shapes that preview the layout while content loads. |
| **Spinner** | A rotating indicator with no information about progress. |
| **Optimistic UI** | Showing success before the server confirms, then correcting if it fails. |
| **Empty state** | The state when there is no content. |
| **Partial state** | Some content loaded, some failed or is missing. |
| **Error state** | A failure the user needs to understand and recover from. |
| **Success state** | Confirmation that the action completed. |
| **Disabled state** | A control that cannot be used, ideally with a reason. |
| **Offline state** | The state when the device has no connection. |
| **Timeout** | Giving up after a defined wait. |
| **Retry** | Attempting the action again, ideally without re-entering data. |
| **Idempotency** | Designing an action so repeating it does not cause a duplicate effect. |
| **Undo** | Reversing an action after it happens. |
| **Confirmation** | Asking before an irreversible action. |
| **Dead end** | An error screen with no route forward. |

## 3. Why this matters

Beginners design the screen where everything works. Professionals design the screen where the network drops at 90%, the name lookup returns nothing, the user taps twice, and the payment succeeds but the confirmation fails. That is where trust is built or destroyed.

Consider a transfer that leaves the screen on "Processing" forever. The user does not know whether the money moved. They tap again. Now there are two transfers. The interface did not merely fail to inform; it caused a financial error. State design is risk design.

> **Everyday example.** A restaurant that says "your order is being prepared" with no estimate, no update and no way to ask is more stressful than one that says "25–35 minutes; we'll message you if it changes." The food may take the same time. The experience is completely different.

## 4. Before you start

- Choose one flow from your project: send money, place an order, book a slot, submit a form.
- Map the happy path in five steps or fewer.
- Have your component sheet open.

## 5. Teaching, step by step

### Step 1 — Map the happy path, then attack it

Write the happy path as a sequence:

> Enter recipient → enter amount → confirm → processing → success.

Then ask, at each step:

- What if the network is slow?
- What if it fails?
- What if it succeeds but the confirmation fails?
- What if the user leaves and comes back?
- What if the data is empty or partial?
- What if the user taps twice?
- What if the user has no connection at all?

Every answer is a state you must design.

### Step 2 — Design loading honestly

Match the indicator to the wait:

| Wait | Indicator | Why |
|---|---|---|
| Under 1 second | None, or a subtle inline change | A spinner that flashes is worse than no spinner. |
| 1–4 seconds | Spinner with a short label ("Checking account…") | The label says what is happening, not just that something is. |
| 4–10 seconds | Skeleton screen for content, or progress with an estimate | The user can see the shape of what is coming. |
| Over 10 seconds | Progress with explanation and a way to leave | Respect the user's time; do not trap them. |
| Unknown duration | "This is taking longer than usual" after a threshold, plus retry | Honest uncertainty beats a fake progress bar. |

Never combine a spinner with a button that remains active. Disable the button and change its label to "Sending…" so the user cannot submit twice.

### Step 3 — Prevent duplicates, not just apologise for them

For any action that moves money, creates an order or sends a message:

- disable the control on first press;
- use an idempotency key in the eventual build so a retry does not duplicate;
- show a clear processing state with the amount and recipient;
- if the result is unknown, say so and give a safe route ("Check status" rather than "Try again").

"Try again" is dangerous when the first attempt may have succeeded. The safer label is "Check status" until the system knows the outcome.

### Step 4 — Write errors that recover

An error message has four parts:

1. **What happened**, in plain language.
2. **Why**, if known.
3. **What to do now.**
4. **What will not be lost.**

Example:

> "We couldn't confirm the account name. The bank did not respond. Your details are saved. Try again in a moment, or continue without the name check."

Compare with: "Error 500." The second is a dead end.

Place the message near the cause. A form error belongs next to the field, not only in a toast at the top. A page-level error belongs where the content would have been.

### Step 5 — Design empty and partial states

Empty state checklist:

- explain why it is empty;
- offer the first action;
- do not fake content;
- keep it short.

Partial state checklist:

- show what loaded;
- mark what failed;
- allow retry for the failed part only;
- do not blank the whole screen because one section failed.

Example: a beneficiary list where the name lookup failed for two banks. Show the list, mark those rows "Name unavailable", and offer "Retry name check" per row.

### Step 6 — Make success unambiguous

A success state should confirm:

- what happened;
- the key details (amount, recipient, reference);
- what happens next;
- how to undo, if undo is possible;
- how to get a receipt.

"Payment sent" alone is weak. "₦25,000 sent to Adaeze O. Reference KUD-8842. She'll receive it within 2 minutes." is a confirmation the user can act on.

### Step 7 — Choose between block, warn, confirm and undo

| Situation | Best approach | Why |
|---|---|---|
| Reversible, low risk | Allow, with undo | Speed without harm. |
| Irreversible, high risk | Confirm with specific consequences | Forces deliberate action. |
| Recoverable mistake | Warn inline, allow correction | Avoids interruption. |
| Destructive, rare | Type-to-confirm or hold-to-confirm | Prevents accidental taps. |
| Unknown outcome | Check status, not retry | Avoids duplicates. |

Confirmation dialogs are overused. A confirmation that says "Are you sure?" trains users to tap "Yes" without reading. A confirmation that says "Delete 12 files? This cannot be undone." is more likely to be read.

### Step 8 — Test the states, not just the screens

For each state, ask:

- Can the user tell what happened?
- Can they recover without losing work?
- Is there a way forward that does not require support?
- Does it work offline, on a slow connection, and with a screen reader?
- Does it avoid blaming the user?

A state that cannot answer these is not finished, even if it looks good in Figma.

## 6. Worked example (I do)

**Flow:** send ₦25,000 to a new recipient.

**State map:**

| # | State | What the user sees | Recovery |
|---|---|---|---|
| 1 | Default | Recipient and amount fields, primary "Continue" | — |
| 2 | Validating | Button disabled, label "Checking account…", inline spinner | Wait; cancel returns to form with data intact |
| 3 | Name unavailable | "We couldn't confirm this name. The bank did not respond." | Retry, or continue with a warning |
| 4 | Confirm | Amount, name, bank, warning, "Send ₦25,000" | Back preserves data |
| 5 | Sending | Button disabled, "Sending…", progress after 5 s | Cannot tap twice; can leave and check status |
| 6 | Success | Amount, recipient, reference, "Done" and "Send another" | Receipt available |
| 7 | Failed | "The transfer did not go through. No money left your account." | "Try again" with data intact |
| 8 | Unknown | "We're not sure whether this transfer went through. Check status before trying again." | "Check status" primary, "Contact support" secondary |
| 9 | Offline | Banner: "You're offline. Your details are saved." | Reconnect and resume |
| 10 | Empty (beneficiaries) | "No saved beneficiaries yet." | "Save beneficiary" |

**The critical design decision:** state 8. Most beginners would show "Failed — try again". But if the request reached the server and the response was lost, "try again" can duplicate the transfer. The honest state is "unknown", with a status check as the primary action. This is the difference between a polished mockup and a safe product.

**Error copy, before and after:**

- Before: "Transaction error. Please try again."
- After: "The transfer did not go through. No money left your account. Your details are saved — try again."

The second tells the user what happened, what did not happen, and what to do. It also removes the worst fear: that money left but the app failed.

## 7. We do it together

1. Write your flow's happy path in five steps.
2. For each step, write the failure question and the state it creates.
3. Build a state map table with at least seven states.
4. Design the loading state: decide spinner, skeleton or progress, and justify the threshold.
5. Design the error state: write the four-part message.
6. Design the success state: include the key details and the next step.
7. Design the empty state: explanation plus first action.
8. Design the offline state: what is saved, what can wait, what cannot.
9. Check every destructive action: confirm, undo, or status check?
10. Test one state with a person: show the error and ask "what happened, and what would you do now?"

## 8. Your turn (You do)

**Independent task.** Produce a **state map and prototypes** for one flow in your project.

Submit:

1. The happy path in five steps or fewer.
2. A state table with at least **eight** states: default, loading, empty, partial, error, success, disabled, offline (or a justified equivalent).
3. A screen or component variant for each state.
4. For each error: the four-part message (what, why, what now, what is safe).
5. For each destructive action: your choice of confirm, undo or status check, with a reason.
6. A 150-word "worst moment" analysis: which state is most likely to cause harm, and how your design reduces it.
7. One usability observation: show the error state to a person and record what they say they would do. Do not explain it first.

**Do not** design only the happy path, and do not use "Something went wrong" as an error message.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** Why is "Try again" dangerous after an unknown transfer outcome?
- A. It is too long for the primary button and wraps onto two lines.
- B. It is inaccessible, because screen readers announce the two words poorly.
- C. It requires a confirmation dialog, which slows the recovery path down.
- D. The first attempt may have succeeded, so retrying can duplicate the transfer.

**Q2.** When is a spinner with no label acceptable?
- A. For waits of several minutes, when the user has nothing else to do.
- B. For very short waits, or when the activity is already obvious.
- C. Never, because an unlabelled spinner is always an accessibility failure.
- D. Only on desktop, where screens have room for a supporting caption.

**Q3.** What are the four parts of a good error message?
- A. Error code, timestamp, affected user name and the full stack trace.
- B. Apology, blame for the mistake, a retry prompt and a close button.
- C. A title, a supporting image, a primary button and a small footer.
- D. What happened, why it happened, what to do now, what is safe.

**Q4.** A dashboard loads six sections and one fails. What is the best state?
- A. Blank the whole page and show one generic error where the dashboard was.
- B. Show invented sample figures in the failed section so the layout looks complete.
- C. Redirect the user to the home page and ask them to try the dashboard later.
- D. Show the five loaded sections and mark the failed one with a retry.

**Q5.** Which action needs confirmation rather than undo?
- A. Liking a post, because the like appears instantly in other people's feeds.
- B. Adding an item to a cart, because the total updates on the next screen.
- C. Changing a filter, because the results list reloads with a new ordering.
- D. Permanently deleting an account, because all of the data is unrecoverable.

**Q6.** What is wrong with "Invalid input" as an error?
- A. It is too polite, so users do not realise that something has actually failed.
- B. It is too long to fit beside the field on a narrow mobile screen.
- C. It does not say what is wrong, why, or how to fix it.
- D. It relies on colour alone, and the message carries no icon.

**Q7.** Why disable the submit button during processing?
- A. To make the button look busy so the interface feels responsive.
- B. To improve the contrast between the button label and its background.
- C. Because WCAG 2.2 requires submit buttons to be disabled while loading.
- D. To prevent duplicate submissions and show that the action is underway.

**Q8.** What should an empty state avoid?
- A. An explanation of why the section is empty and what belongs here.
- B. Fake content that pretends the user already has activity to look at.
- C. A first action that lets the user create the first item.
- D. A short headline that names the state in a few words.

**Q9.** A transfer request times out and the app does not know whether the money left the account. What should the interface show?
- A. A Try again button as the primary action, with the amount still filled in.
- B. A success message, because the request left the device and reached the bank.
- C. An outcome-unknown state that checks status and tells the user not to retry yet.
- D. A blank screen until the user pulls to refresh and reload the balance.

**Q10.** A dashboard spinner has run for two minutes with no message, timeout or retry. What is missing?
- A. A bounded waiting state with an explanation, a timeout and a recovery action.
- B. A brighter spinner colour so the loading state stands out on the page.
- C. More animation around the spinner so the progress feels continuous to the user.
- D. A larger logo above the spinner so the brand remains visible while loading.

## 10. Practical task and pass criteria

**Task.** Submit the state map, variants, error messages, destructive-action decisions, worst-moment analysis and usability observation.

**Pass criteria — all must be met:**

- [ ] At least eight states, including loading, empty, error, success and offline.
- [ ] A visual variant for each state.
- [ ] Every error has the four parts and a recovery route.
- [ ] Every destructive action has a stated confirm/undo/status-check decision.
- [ ] No state is a dead end without a route forward.
- [ ] The worst-moment analysis identifies a real harm and a mitigation.
- [ ] The usability observation records a person's actual response.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Only the happy path | It is the exciting part | Map failures before polishing pixels. |
| "Something went wrong" | It is quick | Name the problem and the recovery. |
| Retry after unknown outcome | It seems helpful | Use "Check status" and explain the risk. |
| Fake data in empty states | It looks better in a demo | Show a real empty state with a first action. |
| Confirmation for everything | It feels safe | Reserve confirmations for irreversible, high-risk actions. |
| Spinner with an active button | No one thought about double taps | Disable and relabel the button. |
| Blanking the whole page on one failure | Simpler to build | Use a partial state with local retry. |

**Retry variant.** Design the states for a **booking flow** (book a seat on a bus) instead of a transfer. Include a "seat taken while you were paying" conflict state, a "payment succeeded but booking failed" state, and an offline state. Submit the map, the variants and a 120-word note on which conflict was hardest to resolve fairly.

## 12. Proof artifact for your portfolio

**Artifact:** `State-Map-v1` — stored in `03_Projects/<project>/design/states`.

This is one of the strongest portfolio artifacts you can own. Most junior portfolios show only success screens; a state map shows professional maturity.

## 13. Low-data and low-cost path

- Design states as wireframes; no images needed.
- Use text and simple shapes; skeleton screens can be grey blocks.
- The video is optional (and covers empty states only). The state table and error rules above are the lesson.
- Test with one person in person; no recording or paid tool required.

## 14. Watch and read more

**Recommended video (optional, 3:22):** *Empty States in Application Design: 3 Guidelines* — NNgroup. `https://www.youtube.com/watch?v=MUh3xyvEWDE`. Verified available on 2026-10-30. It covers empty states only; loading, error and offline guidance here draws on the sources below.

**Read (verified 2026-10-30):**

- Nielsen Norman Group, *Designing Empty States in Complex Applications: 3 Guidelines* — `https://www.nngroup.com/articles/empty-state-interface-design/`. Covers system status, learning cues and a direct route to the next task.
- W3C, *WCAG 2.2* — `https://www.w3.org/TR/WCAG22/`. See SC 3.3.1 (error identification) and 3.3.3 (error suggestion).

## 15. What comes next

Stop 2.5 makes all of this usable by more people: contrast, touch targets, keyboard access, screen readers and inclusive language. Accessibility is not a final checklist; it is a constraint on every state you just designed.