---
stop_id: 0.3
title: Seeing Like a Designer
phase: 0
prerequisites: Stop 0.1, Stop 0.2
outcome: Name the common parts of an interface using correct terms, and label the parts of three real screens with evidence from the apps you actually use.
time: 50-70 minutes
artifact: A three-screen annotated teardown with at least 20 correctly named interface parts and a short note on what each screen wants the user to do.
---

# Stop 0.3 — Seeing Like a Designer

> **Phase 0 · Getting started** · Prerequisites: Stops 0.1–0.2 · Suggested session: 50–70 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Point at a screen and name its regions, controls and content containers correctly.
2. Explain what a screen is trying to get the user to do, in one sentence.
3. Label at least 20 interface parts across three real screens.
4. Tell the difference between a component (a reusable part) and a pattern (a repeated solution to a problem).

## 2. New words in plain English

These are the 25 terms you must be able to use. Read the definition, then find one example of each in an app on your phone.

| # | Term | Plain-English meaning |
|---|---|---|
| 1 | **Screen** | One full view a user sees at a time, for example a login screen. |
| 2 | **Status bar** | The thin strip at the top of a phone showing time, battery and signal. The operating system draws it, not the app. |
| 3 | **App bar / header** | The top strip of an app screen that usually holds a title, a back arrow and one or two actions. |
| 4 | **Navigation bar** | The persistent set of destinations, often at the bottom on phones or the side on desktop. |
| 5 | **Tab bar** | A navigation bar that uses labelled tabs, such as Home, Search, Orders, Profile. |
| 6 | **Hamburger menu** | An icon of three horizontal lines that opens a hidden menu. It hides destinations, so use it for secondary items. |
| 7 | **Button** | A control you press to trigger an action, such as "Send" or "Continue". |
| 8 | **Primary button** | The one most important action on a screen. Usually filled and high contrast. |
| 9 | **Secondary button** | A less important action, often outlined or text-only. |
| 10 | **Tertiary action / text link** | A low-emphasis action, often just text, such as "Forgot password?". |
| 11 | **Icon** | A small symbol that represents an action or object. Icons without labels are often ambiguous. |
| 12 | **Card** | A container that groups related content, usually with an image, title and metadata. |
| 13 | **List item** | One row in a list, often with a leading icon, a label and a trailing chevron. |
| 14 | **Form field** | An input area where the user types or selects information. |
| 15 | **Label** | The text that says what a field is for. It must stay visible; a placeholder is not a label. |
| 16 | **Placeholder** | Faint example text inside an empty field. It disappears when the user types, so it cannot carry essential instructions. |
| 17 | **Helper text** | Small text near a field that explains a requirement, such as "Use 11 digits". |
| 18 | **Dropdown / select** | A control that opens a list of options and lets the user choose one. |
| 19 | **Toggle / switch** | A control with an on and off state, used for settings that apply immediately. |
| 20 | **Checkbox** | A small box for selecting zero, one or many options, usually submitted later. |
| 21 | **Radio button** | A round control for choosing exactly one option from a small set. |
| 22 | **Modal / dialog** | A layer that interrupts the screen and demands a decision before continuing. |
| 23 | **Toast / snackbar** | A brief message that appears at the edge of the screen and disappears, often confirming an action. |
| 24 | **Empty state** | The screen shown when there is no content yet, such as "No orders yet". |
| 25 | **Call to action (CTA)** | The action the screen most wants the user to take. Often, but not always, the primary button. |
| 26 | **Badge** | A small marker on an icon showing a count or status, such as unread messages. |
| 27 | **Breadcrumb** | A trail showing where you are in a hierarchy, such as Home > Orders > Receipt. |
| 28 | **Avatar** | A small image or initials representing a person or business. |

> **Note on screenshots.** This course does not reproduce screenshots from banking, messaging or delivery apps, because those images belong to their owners and go out of date. You will collect your own, from apps you legitimately use, and label them. That is better evidence anyway: it shows you can analyse, not just recognise a picture from a lesson.

## 3. Why this matters

You cannot improve what you cannot name. "Make it look better" is not a design instruction. "The primary button competes with the secondary button because both are filled and the same size" is an instruction a designer can act on.

Naming also changes what you notice. Once you know the difference between a placeholder and a label, you start seeing forms where the label vanishes as soon as you type — and you cannot unsee the problem. That is the beginning of design judgment.

> **Everyday example.** A mechanic hears an engine and names the part. You hear "a noise". Both of you heard the same thing; only one can act. This stop gives you the names.

## 4. Before you start

- Choose three apps you genuinely use. A good mix is: a **banking or payment app**, a **messaging app**, and a **food delivery or shopping app**. If you do not use delivery apps, use a transport, school or government app.
- Take one screenshot of a meaningful screen from each. Avoid the splash/loading screen; choose a screen with real content and controls.
- Do not include your account balance, phone number, address or a contact's name. Crop or blur private data **before** saving.
- Put the images in `02_Exercises/0.3_teardown/`.

## 5. Teaching, step by step

### Step 1 — Read a screen in layers

Every screen can be read in four layers, from outside in:

1. **System layer** — status bar, gesture bar, keyboard. The operating system owns these. Designers must leave room for them.
2. **Structure layer** — header, content area, navigation, footer. This is the skeleton.
3. **Content layer** — text, images, cards, lists, data.
4. **Action layer** — buttons, links, toggles, and anything the user can press.

When you look at a new screen, say the layers out loud in that order. It stops you from starting with colour, which is the least useful place to start.

### Step 2 — Separate component from pattern

A **component** is a reusable part: a button, a text field, a card.
A **pattern** is a reusable *solution*: "search, then filter, then results"; "add to cart, then checkout, then confirmation".

One pattern contains several components. "Login" is a pattern; it uses two text fields, a button, a link and possibly a checkbox. Beginners often say "component" for everything. Use the distinction and your critique becomes sharper: a broken button is a component problem; a checkout that asks for the address three times is a pattern problem.

### Step 3 — Identify the job of the screen

For each screenshot, complete this sentence:

> "This screen wants the user to ______, and the evidence is ______."

Example: "This screen wants the user to confirm the transfer amount, and the evidence is that the amount is the largest text and the primary button says 'Confirm'." The evidence part matters. It forces you to point at the design, not guess the intention.

### Step 4 — Label with a legend, not arrows everywhere

You will annotate three screenshots. Use a consistent method:

1. Put a small numbered circle on each part.
2. Put the number and the term in a legend beside or below the image.
3. Add one line of evidence for the three most important parts: why that part is there.

Do not write the label directly over the interface text; it becomes unreadable. Do not use more than 12 labels per screen; choose the parts that matter.

### Step 5 — Spot the missing state

Every screen you capture is in one state: full of content, empty, loading, error or success. Ask: *what would this screen look like with no data, with a slow connection, or after a failed action?* If the app has an obvious empty state (a new account, an empty cart), capture it too. It is often the most revealing screen in the product.

### Step 6 — Write the one-sentence verdict

For each screen, write one sentence: what works, and one thing you would change. Keep it concrete and tied to a named part.

Weak: "The design is nice but confusing."
Strong: "The primary button and the 'Cancel' link are the same visual weight, so the destructive action is as easy to tap as the safe one."

## 6. Worked example (I do)

**Screen:** the "Send money" confirmation screen of a fictional Nigerian payment app, `Kudi`. (Fictional example, created for teaching. No real product is being criticised.)

**What I see, layer by layer:**

- System: status bar at the top, gesture bar at the bottom. The app leaves 24 px of safe space above the header.
- Structure: a back arrow and title "Confirm transfer"; a content block with amount and recipient; a details list; a sticky footer with two actions.
- Content: the amount `₦25,000` is the largest text. The recipient name is second. The account number is grouped as `012 345 6789` to help checking.
- Action: a filled "Send ₦25,000" button and a text-only "Cancel" link.

**Labels I would attach:** app bar, back button, amount display, list item, avatar, divider, primary button, tertiary action, helper text ("This cannot be reversed"), status bar.

**Job of the screen:** "This screen wants the user to verify the recipient and amount before an irreversible action. The evidence is the large amount, the grouped account number, the warning helper text, and the specific primary button label that repeats the amount."

**One change I would make:** move "Cancel" further from the primary button and reduce its contrast, so a thumb aiming for "Send" does not hit "Cancel" by accident — or, better, keep the destructive action behind a confirmation rather than adjacent to a mis-tap zone.

**The reasoning, not just the answer:** I am not judging taste. I am comparing the visual weight of actions with the risk of each action. The risky action is irreversible, so it needs deliberate effort; the safe action should not compete for the same thumb space.

## 7. We do it together

1. Open your first screenshot. Name the four layers in your notes.
2. Mark the **structure**: header, content, navigation, footer. If a layer is missing, write "missing" and note what that costs the user.
3. Mark every **action** you can press. Classify each as primary, secondary or tertiary.
4. Mark every **input** (field, toggle, checkbox, dropdown). If a field has a placeholder but no label, write "label missing" in the legend.
5. Write the "wants the user to" sentence with evidence.
6. Repeat for the second screen, but this time label only the five parts a first-time user would need to understand.
7. For the third screen, label the parts *and* find one missing state: what happens when there is no data, no connection, or an error?
8. Count your labels. You need at least 20 across the three screens, with no term used incorrectly.

## 8. Your turn (You do)

**Independent task.** Produce a **three-screen teardown** of apps you actually use, in a single PDF or document:

- Screen 1: a payment or banking screen.
- Screen 2: a messaging or social screen.
- Screen 3: a shopping, delivery, transport or public-service screen.

For each screen include:

1. The screenshot with private data removed.
2. A numbered legend of at least 7 correctly used terms.
3. The "wants the user to…" sentence with evidence.
4. One concrete improvement, tied to a named part, and the reason.
5. The state of the screen (full, empty, loading, error, success) and what the missing states would need.

Finish with a half-page comparison: which of the three screens handles the **primary action** most clearly, and why? Use at least four terms from the glossary.

**Do not** annotate the same screen three times, and do not use a screen you have not actually opened. If you cannot use a banking app, use a payment feature inside another app and say so.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** Which part is drawn by the operating system rather than the app?
- A. The status bar at the top, showing the time, battery level and signal strength.
- B. The primary button at the bottom of the screen that submits the form.
- C. The card in the content area that groups an image with its title.
- D. The helper text under the field that explains the required format.

**Q2.** What is the difference between a component and a pattern?
- A. A component is a reusable part; a pattern is a reusable solution made of parts.
- B. A pattern is always larger than a screen, while a component fits inside one.
- C. A component is used only on mobile, while a pattern works on any platform.
- D. There is no real difference between the two terms in everyday design work.

**Q3.** A form field shows "Enter your 11-digit phone number" inside the box, and the text disappears when the user types. What is missing?
- A. A primary button that submits the completed form to the server.
- B. A visible label above the field and helper text that stays on screen.
- C. A toast that confirms the number was accepted after submission.
- D. A breadcrumb that shows where the form sits in the wider flow.

**Q4.** Which is the strongest annotation of a screen's purpose?
- A. "This screen is for transfers between two accounts that the same person holds at one local bank branch."
- B. "This screen is beautiful because the colours and the spacing feel very calm, modern and easy to read."
- C. "This screen has a blue button in the footer area of the layout, which looks clear and modern."
- D. "This screen wants the user to check the amount and recipient, because the amount is largest and the button repeats it."

**Q5.** A screen shows "No orders yet" with a "Start shopping" button. What is this called?
- A. An error state, because the message reports that something failed.
- B. A loading state, because the screen is waiting for data to arrive.
- C. A modal, because it interrupts the user and demands a decision.
- D. An empty state, because there is no content yet and a route forward.

**Q6.** Why should you annotate with a numbered legend instead of writing labels over the interface?
- A. Labels over the interface obscure the thing being analysed and become unreadable.
- B. Legends are required by Figma before a file can be exported or shared.
- C. Numbers look more professional than words on a design portfolio page.
- D. A numbered legend reduces the file size of the exported image noticeably.

**Q7.** Which action is tertiary?
- A. A plain text link under the form that says "Forgot password?" quietly.
- B. A large filled "Pay now" button that spans the width of the footer.
- C. An outlined "Save draft" button placed beside the primary action in the footer.
- D. A floating action button in the corner of the screen for a new message.

**Q8.** Why is the empty state often revealing?
- A. It is usually the prettiest screen because designers spend most of their time on it.
- B. It never contains buttons, so it shows the product without any actions at all.
- C. It shows how the product behaves before the user has data, which every new user sees first.
- D. It is required by app stores before an app can be published to the public.

**Q9.** A learner is annotating a checkout screen and wants to point out the order total, the primary button and a missing error message. Which annotation method keeps the evidence readable?
- A. Write long labels directly over the interface elements so the notes sit close to them.
- B. Replace the screen with a written paragraph that describes what it looks like in detail.
- C. Place numbered markers on a copy of the screen and put the explanations in a legend beside it.
- D. Use a different colour for every note without adding any single key to explain them.

**Q10.** A learner labels the phone's time, battery icon and signal bars as app interface elements. What is the conceptual error?
- A. They are system UI, drawn by the operating system rather than by the app.
- B. They are components because they appear on every screen of the same app.
- C. They are patterns because the same three items repeat across every screen.
- D. They are decorative images that carry no meaning for the person using the phone.

## 10. Practical task and pass criteria

**Task.** Submit the three-screen teardown described in section 8, as a PDF or a shared document.

**Pass criteria — all must be met:**

- [ ] Three different real screens from three different apps (or three clearly different flows).
- [ ] At least 20 labelled parts in total, with terms used correctly.
- [ ] Every screen has the "wants the user to…" sentence with evidence.
- [ ] Every screen has one concrete improvement tied to a named part.
- [ ] Private data is removed or blurred.
- [ ] The missing-state note identifies at least one absent state and what it would need.
- [ ] The comparison names the clearest primary action and uses at least four glossary terms.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Labelling everything "button" | Vocabulary is new | Use the primary/secondary/tertiary distinction and name the container. |
| Writing opinions with no evidence | Habit from social media critique | Every claim must point to a named part, spacing, weight or wording. |
| Leaving account numbers visible | Convenience | Crop or blur before saving; never upload raw banking screenshots. |
| Annotating 30 parts per screen | Enthusiasm | Choose the 7–12 parts that explain the screen's job. |
| Confusing placeholder with label | They look similar | Ask: does the text disappear when I type? Then it is a placeholder. |
| Describing colour first | Colour is the most noticeable | Read system → structure → content → action first. |

**Retry variant.** Do the teardown again with **three different screens from the same app**: its onboarding, its empty state, and its error state. Label at least 18 parts and write a paragraph on how the same product changes its visual language across those three moments. Submit the new teardown plus a corrected version of your original legend, with any misused terms fixed and explained.

## 12. Proof artifact for your portfolio

**Artifact:** `Three-Screen-Teardown` — the annotated PDF, stored in `03_Projects/00_Foundations`.

This becomes raw material for Stop 2.3 (components and patterns) and for your first case study, where you will need to describe existing products precisely.

## 13. Low-data and low-cost path

- Use screenshots you already have, as long as they are of real screens you use.
- If you cannot take screenshots, sketch the screen on paper and label the sketch; note that it is a sketch, not a capture.
- The recommended video is optional. The glossary above is the lesson.
- Work offline: the teardown needs no internet after the screenshots are taken.

## 14. Watch and read more

**Recommended video (optional, 9:23):** *Every UI/UX Concept Explained in Under 10 Minutes* — Kole Jain. `https://www.youtube.com/watch?v=EcbgbKtOELY`. Verified available on 2026-10-30. It is a fast overview; it moves quickly and uses some terms loosely, so use this lesson's glossary as the authority for definitions.

**Read (verified 2026-10-30):**

- Nielsen Norman Group, *10 Usability Heuristics for User Interface Design* — `https://www.nngroup.com/articles/ten-usability-heuristics/`. Read heuristics 1, 2 and 6; they explain visibility, language and recognition, which are the vocabulary you are practising.
- Material Design 3 — `https://m3.material.io/`. Browse the component gallery to see the official names for common parts. Names differ slightly between Apple, Google and web systems; that is normal.

## 15. What comes next

Stop 0.4 turns your AI assistant into a tutor — one whose answers you check. You will ask it to explain terms, then mark its answers right, partly right or wrong against this lesson's glossary.