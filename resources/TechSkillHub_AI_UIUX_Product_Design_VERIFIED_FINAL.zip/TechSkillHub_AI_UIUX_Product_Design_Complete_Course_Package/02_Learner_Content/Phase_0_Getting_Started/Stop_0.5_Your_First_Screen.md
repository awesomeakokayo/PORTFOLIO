---
stop_id: 0.5
title: Your First Screen
phase: 0
prerequisites: Stop 0.1 (Figma account), Stop 0.3 (interface vocabulary)
outcome: Recreate a simple mobile screen in Figma using frames, shapes and text, then make one deliberate change and explain why you made it.
time: 60-90 minutes
artifact: A Figma frame of the recreated screen plus a one-paragraph rationale for the change, exported as PNG and PDF.
---

# Stop 0.5 — Your First Screen

> **Phase 0 · Getting started** · Prerequisites: Stops 0.1 and 0.3 · Suggested session: 60–90 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Create a mobile-sized frame in Figma and explain why a frame is not the same as a group.
2. Add rectangles, text and an image placeholder, and align them using the alignment tools rather than dragging by eye.
3. Name layers so another person can understand the file.
4. Make one deliberate change to the screen and justify it in terms of the user's task.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Canvas** | The infinite grey work area where your designs sit. |
| **Frame** | A container with a fixed size that acts like a screen or an artboard. It can clip its contents and be exported. |
| **Group** | A container that simply keeps layers together. It has no fixed screen size and does not clip. |
| **Layer** | One object in the file: a frame, rectangle, text or image. |
| **Layers panel** | The list on the left that shows the structure of the file. |
| **Properties panel** | The panel on the right that shows size, position, fill, stroke and effects for the selected layer. |
| **Fill** | The inside colour of a shape. |
| **Stroke** | The outline of a shape. |
| **Corner radius** | How rounded a rectangle's corners are. |
| **Alignment** | Snapping objects to each other or to the frame edges. |
| **Distribution** | Spacing objects evenly. |
| **Text layer** | A layer containing editable text with a font, size, weight and line height. |
| **Auto width / fixed width** | Whether a text box grows with its content or stays at a set width and wraps. |
| **Export** | Saving a frame or layer as an image or PDF. |
| **Prototype** | A clickable simulation of the design. You will learn it in Phase 3; not needed today. |

## 3. Why this matters

Reading about frames and layers does nothing. Your first screen is where the vocabulary becomes muscle memory: you select, you name, you align, you export. The goal is not beauty. The goal is **control** — the ability to make the file do what you intended, and to explain the result.

This is also your first experience of the course's rhythm: copy closely (I do), copy with support (we do), then change something on your own (you do). The change is small on purpose. Beginners who try to invent a whole app on day one usually produce a mess and learn nothing about structure.

> **Everyday example.** A tailor's first lesson is not designing a wedding dress. It is cutting a straight seam and pressing it flat. The straight seam appears in every garment later. A clean frame with named layers appears in every screen you will ever make.

## 4. Before you start

- Sign in to Figma and open the `00_Practice` file you created in Stop 0.1.
- Choose your reference screen: a simple one from your Stop 0.3 screenshots, with a header, a title, two or three list items and one button. Avoid a screen with maps, charts or complex animation.
- If you have no suitable screenshot, use the fictional "Kudi transfer confirmation" described in section 6. Do not copy a real bank's branding.
- Close other tabs. Figma is easier to learn with one window.

> **Tool warning.** Figma's interface changes. The names below match the interface at the time of writing (2026). If a button has moved, use Figma's search (`Ctrl/Cmd + /`) and type the command name, or check the Figma Help Centre link in section 14. Do not spend an hour hunting; the concept is what matters.

## 5. Teaching, step by step

### Step 1 — Create the right frame

Press `F` to open the Frame tool, then choose a preset in the properties panel: **iPhone 14 Pro (393 × 852)** or **Android (360 × 800)**. Both are reasonable. Pick one and stay with it for the whole course unless a project says otherwise.

Why a frame rather than a blank canvas? A frame gives you a known screen size, clipping, export and a name in the layers panel. It is the closest thing in Figma to "a screen".

Rename it `00_Home` immediately. Unnamed frames become `Frame 42`, and by Friday you will have `Frame 42`, `Frame 43` and no idea which is which.

### Step 2 — Build the structure before the decoration

Add three regions:

1. **Header** — a rectangle 393 × 88 at the top, with a title text layer and a back arrow placeholder.
2. **Content** — a rectangle or empty area from y = 88 to y = 760.
3. **Footer** — a rectangle 393 × 92 at the bottom, holding the primary button.

Use exact numbers in the properties panel (X, Y, W, H) rather than dragging. Numbers are repeatable; dragging is not. This is the single biggest habit that separates a controlled file from a messy one.

### Step 3 — Add the content in reading order

Inside the content area, add:

- one **title** text layer, 24 px, bold;
- one **amount** text layer, 40 px, bold, because it is the most important information;
- two **list rows**, each with a label on the left and a value on the right;
- one **helper text** layer, 13 px, grey, explaining that the action cannot be reversed.

Alignment rule: left edges align to a single margin (for example x = 24). Right edges align to `width − 24`. Consistent margins make a screen feel calm even before you choose colours.

### Step 4 — Add the primary action

Draw a rectangle 345 × 52 at the bottom, centred, with a corner radius of 12. Add a text layer on top: "Send ₦25,000". Centre the text horizontally and vertically.

Why repeat the amount in the button? Because the action is irreversible, and repeating the amount forces the user to read it once more. That is a design decision, not decoration. You will learn to make these decisions deliberately in Phase 2.

### Step 5 — Name every layer

Rename as you go, not at the end:

```
00_Home                 (frame)
  Header
    Title
    Back
  Content
    Amount
    Recipient-row
    Account-row
    Warning-text
  Footer
    Primary-button
      Button-label
```

A useful test: hide the canvas and read only the layers panel. Can you tell what the screen does? If not, rename.

### Step 6 — Use alignment, not eyeballing

Select two objects and use the alignment icons in the top toolbar: align left, align horizontal centres, distribute horizontally. For a row with a label and a value, align the label left and the value right by aligning to the frame edges, not to each other.

Turn on pixel grid (`Ctrl/Cmd + '`) and layout grid if you like, but do not rely on snap alone for the main margins.

### Step 7 — Export and check

Select the frame, go to Export in the properties panel, choose PNG at 2x, and export. Open the PNG. Check:

- nothing is cut off at the edges;
- the button label is inside the button;
- the text is readable at phone size;
- the export is not blank and not a screenshot of the whole canvas.

### Step 8 — Make one deliberate change

Change exactly one thing, and write why. Good first changes:

- move the warning text above the button instead of below it, because warnings should be read before the action, not after;
- increase the amount text from 32 to 40 px, because it is the key verification detail;
- change the button label from "Confirm" to "Send ₦25,000", because the action should name the consequence.

Bad changes: "make it blue because I like blue", "add a shadow because it looks nice". Not because taste is forbidden, but because you cannot yet explain the effect on the user.

## 6. Worked example (I do)

**Reference screen (fictional):** a transfer confirmation for `Kudi`, a made-up payment app.

**My reasoning, step by step:**

1. I choose a 393 × 852 frame because it is a common modern phone size and fits a single confirmation task without scrolling.
2. I place the header at 0–88 px. The status bar occupies roughly the top 44 px, so the title sits below it, not under the clock.
3. I put the amount at the top of the content, 40 px bold. The user's main question is "how much?", so it gets the strongest visual weight.
4. I put the recipient and account number in a two-row list, labels left and values right, aligned to the same 24 px margin. The eye can compare label to value without hunting.
5. I put the warning in 13 px grey directly above the button. It is read in the path of the thumb, not after the action.
6. I make the button full-width minus 24 px margins, 52 px tall. That is a comfortable touch target and a clear primary action.
7. I name the layers as I go. When I later add states, I can find `Primary-button` instantly.
8. I export at 2x, open the PNG, and notice the button label is 2 px too low. I fix the vertical centring rather than nudging the rectangle.

**What I would say if asked "why is the amount so large?":** "Because the screen's job is verification before an irreversible action, and the amount is the fact most likely to be wrong. Size is the cheapest way to make it checked first." That sentence is the beginning of design rationale.

## 7. We do it together

Do these steps in your own file, at your own pace:

1. Create the frame at 393 × 852 and rename it `00_Home`.
2. Add the three region rectangles and name them `Header`, `Content`, `Footer`.
3. Add the title "Confirm transfer" at 20–24 px, positioned below the status bar.
4. Add the amount `₦25,000` at 40 px bold.
5. Add two list rows: `Recipient / Adaeze O.` and `Account / 012 345 6789`. Align labels left, values right, using the alignment tools.
6. Add the warning "This cannot be reversed" at 13 px, grey, above the footer.
7. Add the button rectangle and label. Centre the label with alignment, not by dragging.
8. Name every layer using the structure in Step 5.
9. Export at 2x and open the PNG. Fix anything that is cut off or misaligned by more than 2 px.
10. Duplicate the frame, rename the copy `00_Home_v2`, and make your one change there. Keep both versions so the change is visible.

## 8. Your turn (You do)

**Independent task.** Recreate a **different** simple screen from your own screenshots — not the transfer confirmation — and make one deliberate change.

Requirements:

1. A named frame at a phone size you state in the file (for example 393 × 852).
2. At least 12 named layers, using a consistent naming style.
3. At least one text hierarchy with three levels (title, body, supporting text).
4. One primary action, aligned with the alignment tools.
5. Exact X/Y/W/H values for the main regions, recorded in a short "build notes" section in the frame or in a separate note.
6. A second version of the frame with exactly one change.
7. A 120–180 word rationale: what you changed, what you expected it to do for the user, and how you would know whether it worked.
8. A PNG export of both versions.

**Do not** copy the transfer screen, and do not change more than one thing between versions. The constraint is the lesson: it forces you to isolate cause and effect.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** What is the main difference between a frame and a group in Figma?
- A. A frame has a fixed size and can clip and export; a group only keeps layers together.
- B. A group can contain text layers, while a frame can only contain shapes and images.
- C. A frame is always transparent, while a group takes the colour of its contents.
- D. A group appears in the layers panel, while a frame is hidden from that panel.

**Q2.** Why set X, Y, W and H with numbers instead of dragging?
- A. Dragging is not allowed in Figma once a frame has been created.
- B. Numbers make the file smaller because Figma stores fewer position values.
- C. Dragging changes the font of the layer that you are moving.
- D. Numbers are repeatable and precise, which makes later changes and handoff reliable.

**Q3.** You export a frame and get a blank white image. What is the most likely cause?
- A. PNG cannot export frames, so the format saves an empty white canvas instead.
- B. The font used in the frame is missing, so no text can be rendered.
- C. The file is too large, so Figma stops rendering before the export finishes.
- D. The frame has no fill and you exported the wrong layer or an empty area.

**Q4.** Which is a good reason to repeat the amount inside the primary button label?
- A. It makes the button wider, which makes it easier to tap with a thumb.
- B. It is required by app stores before a payment feature can be published.
- C. It forces a final read of the most error-prone detail before an irreversible action.
- D. It fills the empty space on the right side of the button rectangle.

**Q5.** Why name layers during the build rather than at the end?
- A. Names are needed to find, reuse and hand off objects later, and renaming at the end is error-prone.
- B. Figma deletes any layer that still has no name when you close and reopen the file.
- C. Named layers export faster because the renderer can skip over all of the unnamed items in the file.
- D. Naming changes the stacking order of the layers, which makes the whole file easier to read.

**Q6.** What makes a change "deliberate" rather than decorative?
- A. It uses a different colour from the one used in the first version.
- B. It states the expected effect on the user and how you would check it.
- C. It is reviewed and approved by an experienced designer before you continue.
- D. It makes the screen taller so that more content fits inside the frame.

**Q7.** Why keep both v1 and v2 frames?
- A. To keep a record of the older design in case the new one is rejected.
- B. To make the change and its effect visible and easy to review later.
- C. To satisfy Figma's requirement for a duplicate before any frame is exported.
- D. To practise exporting the same frame twice at two different image scales.

**Q8.** A beginner aligns a value to the label next to it, and the value ends up in the middle of the row. What should they align it to instead?
- A. The title at the top of the content area, which shares the same left edge.
- B. The primary button in the footer, which is centred across the screen.
- C. The status bar at the top, which the operating system draws for you.
- D. The frame's right margin, so values line up along a consistent edge.

**Q9.** A learner wants to build a 393 by 852 mobile screen in Figma. Which starting choice best supports later responsive work?
- A. Create a frame at 393 by 852 and place elements inside it using a layout structure.
- B. Draw loose rectangles directly on the canvas with no frame around them at all.
- C. Use a group as the screen and set a fixed width for the whole group.
- D. Start at 1440 pixels wide and shrink the export down to phone size later.

**Q10.** A learner's mobile mock-up looks correct at 393 px but every element overlaps when the frame is narrowed to 320 px. What is the most likely cause?
- A. The text uses a system font that is not installed on the phone.
- B. The file has too many pages, which slows down the layout engine.
- C. The export scale is set to 2x, so the exported image is twice as wide.
- D. Elements are positioned with fixed coordinates instead of a layout that can reflow.

## 10. Practical task and pass criteria

**Task.** Submit the Figma file link (view access) and a PDF containing the two PNG exports, your build notes and your 120–180 word rationale.

**Pass criteria — all must be met:**

- [ ] A named frame at a stated phone size.
- [ ] At least 12 named layers with consistent naming.
- [ ] Three levels of text hierarchy.
- [ ] One primary action aligned with alignment tools.
- [ ] Two versions with exactly one deliberate change.
- [ ] The rationale states the expected user effect and how it would be checked.
- [ ] Exports are not blank, not cut off, and readable at phone size.
- [ ] No real bank branding, logos or personal data.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Drawing directly on the canvas with no frame | The canvas looks like paper | Always start with a frame; move loose layers into it. |
| Using a group as a screen | Groups are the default when selecting multiple layers | Convert to frame (`Ctrl/Cmd + Alt + G`) or start with `F`. |
| Everything dragged by eye | It feels natural | Type X/Y/W/H; use alignment and distribution. |
| Text boxes that resize unexpectedly | Auto width vs fixed width confusion | Set fixed width for paragraphs; auto width for short labels. |
| Button label not centred | Text box and rectangle are separate | Select both and align horizontal/vertical centres, or make the button a frame with auto layout later. |
| One giant "final" version | Fear of losing work | Duplicate before changes; name versions. |
| Rationale that describes the change but not the effect | Describing rather than reasoning | Add "so that the user…" and "I would check by…". |

**Retry variant.** Recreate a **login screen** instead, with: a title, two fields with labels, a primary button, a tertiary "Forgot password?" link, and one helper text. Build it at 360 × 800. Then make one change that improves **error recovery** (for example, adding a password visibility toggle or moving the error message next to the field), and justify it. Submit both versions and a 150-word rationale.

## 12. Proof artifact for your portfolio

**Artifact:** `First-Screen` — the two exported PNGs, the Figma link and the rationale, stored in `03_Projects/00_Foundations/first-screen`.

This is the "before" in your progress story. Keep it. In Stop 7.1 you will compare it with later work to show growth, which is more convincing than claiming you improved.

## 13. Low-data and low-cost path

- Use Figma in the browser; the desktop app is optional.
- Do not download fonts or image packs. Use the default fonts and a grey rectangle as the image placeholder.
- The video is optional and 13 minutes long; if data is low, follow the written steps and skip it.
- Export one PNG per version, not a folder of assets. Two images are enough evidence.
- If you have no Figma account and cannot create one, draw the screen on paper with a ruler, photograph it, and label the layers on the drawing. State the substitution; the assessment criteria still apply.

## 14. Watch and read more

**Recommended video (optional, 13:22):** *Figma Tutorial for Beginners (13-min crash course!)* — Flux Academy. `https://www.youtube.com/watch?v=jQ1sfKIl50E`. Verified available on 2026-10-30. It was published in 2024, so some interface details may differ from the current Figma UI. The durable content — frames, shapes, text, alignment, export — remains valid.

**Read (verified 2026-10-30):**

- Figma Help, *Frames in Figma Design* — `https://help.figma.com/hc/en-us/articles/360041539473-Frames-in-Figma-Design`. The authoritative explanation of frames versus groups.
- Figma Help, *Guide to auto layout* — `https://help.figma.com/hc/en-us/articles/360040451373-Guide-to-auto-layout-in-Figma`. Skim only the first section; you will use it properly in Stop 3.2.

## 15. What comes next

Phase 0 ends with **Gate 0**: your workspace, your three-screen teardown, a glossary check at 80% or above, and your recreated screen. Read `03_Assessments/Learner/Phase_0_Gate.md` before you submit. Then Phase 1 begins the real work: deciding what to design before opening any tool.