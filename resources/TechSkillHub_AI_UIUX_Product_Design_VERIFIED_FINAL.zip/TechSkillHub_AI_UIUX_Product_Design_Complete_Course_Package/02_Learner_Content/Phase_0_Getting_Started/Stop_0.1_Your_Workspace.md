---
stop_id: 0.1
title: Your Workspace
phase: 0
prerequisites: None. This is the first stop.
outcome: Set up a working study workspace with organised folders, the accounts you need, and a file you can save and find again after closing the browser.
time: 45-60 minutes
artifact: A screenshot of your folder tree plus a one-page workspace checklist showing each account is active and one file was recovered after closing the browser.
---

# Stop 0.1 — Your Workspace

> **Phase 0 · Getting started** · Prerequisites: none · Suggested session: 45–60 minutes · Pass target: 80% on the comprehension check **and** all essential task criteria.

## 1. What you will be able to do

By the end of this stop you can:

1. Create a folder structure for the course and explain what belongs in each folder.
2. Save a file, close the browser completely, reopen it, and find that file again.
3. Create a free Figma account and a free AI assistant account, and sign back into both.
4. Explain two ways to reduce data use while studying.

You do **not** need to know anything about design yet. This stop is about removing the small practical problems that make beginners quit: lost files, forgotten passwords, and a browser with forty unlabelled tabs.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Browser** | The program you use to visit websites, for example Chrome, Edge, Firefox or Safari. |
| **Tab** | One page open inside a browser window. You can have many tabs, but only one is visible at a time. |
| **Cloud storage** | Files kept on a company's servers instead of only on your computer, for example Google Drive or OneDrive. You reach them through the internet. |
| **Local file** | A file that lives on your own computer's disk. It still opens when the internet is off. |
| **Folder (directory)** | A container for files inside your computer or cloud storage. |
| **File path** | The address of a file, such as `Documents/TechSkillHub/Phase_0/notes.md`. |
| **Account** | Your personal login (email plus password) for a service. |
| **Two-factor authentication (2FA)** | A second proof of identity at login, usually a code from your phone. It makes a stolen password much less useful. |
| **Free tier** | The limited version of a paid product that you can use without paying. Limits can change without notice. |
| **Autosave** | The tool saves your work automatically, usually to the cloud, without you pressing Save. |
| **Download** | Copying a file from the internet onto your device. |
| **Upload** | Copying a file from your device to the internet. |

## 3. Why this matters

Design work is file work. A beginner loses an afternoon because a file was saved in `Downloads` with the name `Untitled (3) (final) (2)`. A professional opens the right file in five seconds because the folder says what it holds and the file name says what changed.

Think about the last time you looked for a receipt, a school document or a photo on your phone. If you found it quickly, something in the naming or the album structure helped you. If you did not, you probably searched by date and hoped. Design files behave the same way — except you will produce hundreds of them, and clients or teammates may need to open them without you.

Your workspace is also a **trust signal**. When you eventually share a Figma file with a developer or a reviewer, an organised file with clear page names reads as professional before anyone looks at the pixels.

> **Everyday example.** A market trader in Kano keeps three baskets: one for tomatoes, one for peppers, one for change. She can serve a customer without emptying everything onto the table. Your folders are those baskets. The point is not tidiness for its own sake; it is speed and fewer mistakes.

## 4. Before you start

You need:

- A laptop or desktop. A phone can carry the reading part of this course, but Figma is painful on a small screen and this stop assumes a computer.
- A browser. Chrome, Edge or Firefox is fine. Keep one browser for study so your bookmarks and logins stay together.
- An email address you can open now. Gmail, Yahoo, Outlook or a school address all work.
- About 45 minutes without interruptions.
- A way to take a screenshot. On Windows press `Win + Shift + S`; on a Mac press `Cmd + Shift + 4`; on most Android phones press Power + Volume Down.

> **Cost and account warning.** Figma and the major AI assistants have free tiers, but their limits and paid features change often. This course never requires you to pay. If a screen asks for a card, stop and use the free path described in section 13.

## 5. Teaching, step by step

### Step 1 — Decide where your course work lives

You have two reasonable choices:

- **Computer-first:** a folder on your desktop called `TechSkillHub`. Fast, works offline, but only on that machine.
- **Cloud-first:** a folder inside Google Drive or OneDrive called `TechSkillHub`. Works across devices, but needs internet and may sync slowly.

Pick one as the **source of truth** — the single place where the real version of your work lives. If you use both, decide that the cloud folder is the source of truth and the computer copy is a working copy. Write that decision at the top of your checklist. Beginners get lost when two copies both look official.

### Step 2 — Build a folder tree you can explain

Create this structure inside your chosen place:

```
TechSkillHub/
  00_Admin/          passwords hint sheet (never real passwords), receipts, links
  01_Lessons/        downloaded lesson notes, one folder per phase
  02_Exercises/      practice files and screenshots
  03_Projects/       the real work that goes into your portfolio
  04_Research/       interview notes, consent records, source screenshots
  05_Exports/        PNGs, PDFs, zipped handoffs
```

Why this shape? It separates **input** (lessons), **practice** (exercises), **evidence** (research and projects) and **output** (exports). When a reviewer asks for "the research behind this screen", you go to `04_Research`, not to a pile of screenshots on your desktop.

Inside `01_Lessons`, create `Phase_0`, `Phase_1`, and so on up to `Phase_7`. Inside `03_Projects`, create one folder per project, and inside that: `research`, `design`, `build`, `tests`.

### Step 3 — Adopt one file-naming rule

Use this pattern:

```
YYYY-MM-DD_project_thing_version.extension
```

Examples:

- `2026-11-02_sendmoney_home-screen_v1.fig`
- `2026-11-04_sendmoney_interview-notes_participant-03.md`
- `2026-11-09_sendmoney_handoff_v2.pdf`

Rules that matter:

1. **Date first** so files sort chronologically by themselves.
2. **No spaces** in file names that will go on the web. Use hyphens. Spaces break links and annoy developers.
3. **Version at the end**, and never write "final" — there is always a v2. Use `v1`, `v2`, `v3`.
4. **Never rename a file to "new" or "copy".** Those words carry no information.

### Step 4 — Learn to save and recover

Saving is not one action. There are three different things beginners call "saving":

- **Autosave in a web app** (Figma, Google Docs): the work is stored online as you type. Closing the tab is usually safe, but you must be signed in and online.
- **Save As / Download**: you create a copy on your device. This is how you keep an offline backup or submit evidence.
- **Export**: you create a different format, such as a PNG from a Figma frame.

Practice all three in the "We do" section. The test of understanding is simple: close the browser completely, reopen it, and find the work without using the Back button.

### Step 5 — Create the design account and choose an AI route

**Figma:** go to `figma.com`, choose Sign up, and use the same email you will use for the course. Verify the email. When asked about your role, "Student" or "Designer" is fine; it does not change your access. Create one file called `00_Practice` and rename it `2026-11-02_practice_first-screen_v1`. You will use it in Stop 0.5.

**AI assistant (optional):** choose one — ChatGPT, Gemini, Claude or Copilot all have free access. Use the same email if you like, and verify the account. Do not pay for anything. Do not paste your password, bank details, national ID number or anyone else's personal information into an AI chat. You will learn how to use it as a tutor in Stop 0.4. **If you do not want an AI account, choose the no-AI route.** It is a full pass route: you use the lesson text, the verification method in Stop 0.4 applied to ordinary sources, and instructor feedback. No task or phase gate requires an AI account.

> **Official guidance, not a rule invented here:** Figma documents its plans at `figma.com/pricing`, and each AI provider documents data controls in its own help centre. Check the current page before you rely on a feature; free tiers and defaults change.

### Step 6 — Protect the accounts without overcomplicating it

- Use a **different password** for each account. Reusing one password means one leak opens everything.
- Turn on **two-factor authentication** if offered.
- Keep a **password hint sheet** in `00_Admin` — hints, not the passwords themselves. Better: use a password manager if you have one.
- Do **not** write account email addresses in the course checklist. If you forget which account you used, check the account avatar or your password manager; never paste an email, password, recovery code or token into a file you will submit.

### Step 7 — Reduce data use before you need to

- Prefer the text lesson and downloadable notes over video when data is low.
- In YouTube, set quality manually to 360p or 480p. Do not rely on "Auto".
- Turn off autoplay.
- Download once on Wi-Fi, then study offline.
- Close tabs you are not using; some pages keep downloading in the background.
- Use the browser's reading mode or print-to-PDF for long articles.

### Step 8 — Write your workspace checklist

On one page, record:

```
Source of truth: [cloud or computer folder]
Design tool selected: [Figma free plan / Penpot / other free tool]
Design account ready: yes/no  (do not write an email address or password)
AI assistant selected: [tool name, or "none - lesson text route"]
AI account ready: yes/no/not using AI  (do not write an email address or password)
No-AI route: [lesson text + instructor feedback / other]
Folder tree created: yes/no
Naming rule: YYYY-MM-DD_project_thing_version.ext
File recovered after closing browser: yes/no (file name: ...)
Two ways I will save data: ..., ...
```

This page is evidence. You will submit it at the Phase 0 gate. It deliberately records **readiness**, not account identifiers. Never write an email address, password, recovery code or authentication token in this file.

## 6. Worked example (I do)

**Situation:** Amaka is starting the course on a shared laptop in Lagos. Her downloads folder already holds 400 files. She has two hours a week and a 2 GB monthly data bundle.

**Her decisions, with the reasoning spoken aloud:**

1. She chooses **cloud-first** because the laptop is shared. If her brother uses it and the local folder is moved, her work still exists online. Cost: she needs internet to open files.
2. She creates `TechSkillHub` in Google Drive and the six subfolders. She does **not** create a second copy on the desktop, because two "official" copies cause version confusion.
3. She names the first practice file `2026-11-02_practice_first-screen_v1`. The date lets her see her progress in order; the word `practice` tells her it is not portfolio work.
4. She turns off YouTube autoplay and sets video quality to 360p. She downloads the Phase 0 notes once at a cybercafé and keeps them in `01_Lessons/Phase_0`.
5. She writes the checklist and screenshots the folder tree. The screenshot is not decoration; it proves the structure existed on the date she claims.

**What a weak version would look like:** a folder called `design stuff` on the desktop, a file called `final.fig`, and a password written in the browser. It works today and fails the moment someone else opens the laptop or a client asks for the research file.

## 7. We do it together

Do these actions now, in order. Tick each one.

1. Create `TechSkillHub` and the six subfolders. Screenshot the open tree.
2. Inside `01_Lessons`, create `Phase_0` through `Phase_7`.
3. Create a plain text file in `00_Admin` named `2026-11-02_workspace-checklist_v1.txt` and paste the checklist template from Step 8.
4. Open your browser, sign up for Figma, verify the email, and create one design file. Rename it with the naming rule.
5. In that Figma file, draw one rectangle and type your name. Wait for the "saved" state to settle.
6. Close the **entire browser**, not just the tab. Reopen the browser, go to `figma.com`, sign in, and open the file from your files list. If you cannot find it, use the search in Figma and check that you are in the right account.
7. Export the frame as PNG into `05_Exports`.
8. If you chose the AI route, sign up for one AI assistant, verify the email, and ask it: "Explain what a folder is to someone who has never used a computer, in three sentences." Do not paste anything personal. If you chose the no-AI route, write the same explanation yourself and check it against the lesson text.
9. Confirm in the checklist that the design tool and, if you chose one, the AI assistant are signed in and ready. Do **not** write email addresses, passwords, recovery codes or tokens in the checklist.

If step 6 fails, the most common causes are: you were signed into a different account, the file was created in a team space you are not viewing, or the browser was offline and the autosave did not complete. Fix the cause before moving on.

## 8. Your turn (You do)

**Independent task.** Set up a second, separate workspace for a fictional project called `Kudi` (a made-up money-transfer idea) **without looking back at the example**. It must contain:

- a project folder with `research`, `design`, `build` and `tests` subfolders;
- one file in each subfolder, correctly named using the rule, including one fake interview note;
- a `README.txt` inside the project folder that states, in two sentences, what the project is and which folder holds the latest design;
- a screenshot of the tree;
- proof that you recovered one file after closing the browser: the file name plus the time you reopened it.

Then answer this in your checklist: *If a reviewer asked for "the evidence behind your design decision", which exact folder would you open, and why?*

**Do not** copy Amaka's folder names word for word. The structure should make sense for your own machine and your own study habits.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** What is the main reason for choosing a single "source of truth" folder?
- A. It makes the folder structure look tidy and consistent in the screenshots you submit for review.
- B. It removes the need for descriptive file names because the folder itself records what each item is.
- C. It guarantees that every file is backed up automatically even if the computer is lost or replaced.
- D. It prevents two copies of the same work from competing as the official version of the file.

**Q2.** Which file name follows the course naming rule?
- A. `final design new.fig`, saved on the desktop after the latest changes.
- B. `2026-11-02_sendmoney_home-screen_v1.fig`, saved directly inside the project's design folder.
- C. `SendMoney-final-v2.fig`, saved in the shared team folder for review.
- D. `home screen.fig`, saved in Downloads immediately after the export finished.

**Q3.** You close the browser tab of a cloud design tool and reopen the site. The work is missing. Which cause is least likely?
- A. You are signed into a different account from the one that created the file.
- B. The file name put a date first, ahead of the project name and the version number.
- C. The file sits in a team or project space that is not currently open in the view.
- D. The autosave never completed because the connection dropped while you were still editing the file.

**Q4.** What is the difference between "Download" and "Export"?
- A. Export only works for text files, while download handles images and every other kind of media.
- B. They are the same action with different buttons, so either one produces an identical copy.
- C. Download copies a file to your device; export creates a file in a different format.
- D. Download only works for images, while export converts text into a printable document.

**Q5.** Why should you avoid writing real passwords in a plain text file?
- A. Text files cannot be opened again later, so the passwords would be lost permanently.
- B. Anyone who gets access to the device or the cloud account can read them.
- C. Passwords stored in text files stop autosave from working in the browser.
- D. The file becomes too large to open on an older computer or phone.

**Q6.** Which behaviour best reduces data use while studying?
- A. Leaving autoplay switched on so you never have to press play yourself.
- B. Watching every video at the highest quality so nothing looks blurred.
- C. Setting video quality manually and downloading the notes once on Wi-Fi.
- D. Keeping twenty tabs open so you can return to them later in the week.

**Q7.** A folder tree separates lessons, exercises, projects, research and exports. Which is the strongest reason?
- A. It keeps the total number of files on the computer much smaller over time.
- B. Reviewers require exactly six top-level folders before they will pass a project.
- C. Different kinds of work need different handling, and evidence must stay findable later.
- D. Cloud storage only allows six folders, so the tree has to match that limit.

**Q8.** You are on a shared computer and cannot rely on local files surviving. What is the most sensible workspace decision?
- A. Keep everything in the Downloads folder because it opens fastest on that machine.
- B. Email the files to yourself and delete the originals so nothing is left behind.
- C. Use a cloud folder as the source of truth and sign out when you finish.
- D. Save only screenshots of your work so the other user cannot open the files.

**Q9.** A learner keeps the official course folder in the cloud but edits a downloaded copy on the Desktop for a week. What should they do to restore one source of truth?
- A. Keep both copies and add the word final to the Desktop file name before submitting.
- B. Delete the cloud folder and work only on the Desktop copy from now on, permanently.
- C. Email the Desktop copy to yourself and leave both folders unchanged for another week.
- D. Upload the edited copy, replace the cloud version, and delete the Desktop copy once checked.

**Q10.** A learner saved a Figma file yesterday but cannot see it in Recents today. They are signed into the same account. Which check is most likely to explain the disappearance?
- A. Assume Figma deleted the file because the name contained a date at the start.
- B. Create a new account and start the same file again from the beginning of the process.
- C. Check whether the file sits in a team or project space that is not currently open.
- D. Clear the browser cache completely before searching for the file in Recents again.

## 10. Practical task and pass criteria

**Task.** Set up your course workspace, create the design account (and, if you choose, an AI account), and prove that you can recover a saved file. Submit:

1. A screenshot of your full folder tree with the folders expanded.
2. Your completed workspace checklist (the one-page text file).
3. The `Kudi` project folder from section 8, zipped, containing the four subfolders and the README.
4. One exported PNG from your Figma practice file.

**Pass criteria — all must be met:**

- [ ] A single source of truth is named in the checklist.
- [ ] The folder tree contains the six top-level folders and Phase 0–7 subfolders, or a documented equivalent that serves the same purposes.
- [ ] At least four files use the naming rule with date, project, item and version.
- [ ] The checklist records the selected tools and confirms each chosen account is ready; if the no-AI route is used, it is recorded as a valid choice. No email addresses, passwords or tokens appear.
- [ ] The screenshot shows the folders expanded, not just a closed parent folder.
- [ ] The recovered file is named and the recovery method is described in one sentence.
- [ ] The exported PNG opens and is not blank.
- [ ] No personal or client data appears in the AI chat screenshot (if the AI route is used) or the checklist. If the no-AI route is used, the equivalent written explanation and any source notes contain no personal data.

**What "meets" looks like:** a reviewer can open your folder and find the design, the research and the export in under a minute, using only the names.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Saving everything in `Downloads` | It is the browser's default and requires no decision | Change the save location once per download; move existing course files into `TechSkillHub` today. |
| Two "official" copies (desktop and cloud) | Fear of losing work | Declare one source of truth; keep the other as a dated backup, not a working copy. |
| Names like `final`, `final2`, `new` | Versioning feels like extra work | Use `v1`, `v2`, `v3`; never use "final". |
| Signing up with a different email than expected | Multiple accounts, autofill | Check the account avatar before creating another account; use a password manager or a private nickname hint. Do not copy the address into the checklist. |
| Losing a Figma file | Wrong account or wrong team space | Use the file search, check the account menu, then check the team/project breadcrumb. |
| Storing real passwords in a notes file | Convenience | Use hints or a password manager; enable 2FA. |
| Blank export | Exporting an empty frame or the wrong selection | Select the frame in the layers panel, then export; open the PNG to check. |

**Retry variant (different from the original task).** Create a workspace for a fictional **tailoring business** called `Stitch` instead of `Kudi`. It must include a `measurements` folder and a `client-photos` folder, a file named with yesterday's date, and a `README.txt` that names the source of truth. Then demonstrate recovery by signing out of Figma, signing back in, and opening the practice file from search rather than from recents. Submit a screenshot of the search result and the file's name.

## 12. Proof artifact for your portfolio

**Artifact:** `Workspace-Setup` — a single PDF containing the folder-tree screenshot, the checklist and a short paragraph titled "How I keep project evidence findable". Keep it in `03_Projects/00_Foundations`.

This is not a design portfolio piece. It is evidence of professional habits, and it becomes useful in Stop 7.3 when you need to show that your case-study evidence is organised.

## 13. Low-data and low-cost path

- Read this lesson and do the steps without watching the video. The video is a supplement, not the lesson.
- If you cannot download Figma's desktop app, use the browser version. It is slower but sufficient for this course.
- If you have no cloud account, use a local folder and make a weekly zip backup to a USB drive. Record that choice in the checklist.
- If you have no AI account, choose **"none - lesson text route"** in the checklist. This is a full pass route, not a penalty. You will use the lesson text, the verification method taught in Stop 0.4, and instructor feedback. No task or phase gate requires an AI account.
- Text alternative to the video: the five actions in the video are (1) open File Explorer, (2) create a folder, (3) name it, (4) drag files in, (5) use the address bar to see the path. You have already done all five.

## 14. Watch and read more

**Recommended video (optional, 2:16):** *How to Organize Files and Folders in Windows for Beginners* — LearnFree. `https://www.youtube.com/watch?v=BY1y_RQxIdg`. Verified as available on 2026-10-30; the interface shown is Windows 10, so the exact buttons differ on macOS and Windows 11. The transferable idea is the folder tree and the address bar.

**Read (verified 2026-10-30):**

- Figma Help, *Frames in Figma Design* — `https://help.figma.com/hc/en-us/articles/360041539473-Frames-in-Figma-Design`. Useful for understanding that a Figma file contains frames, not "pages" in the Word sense.
- MDN, *Accessibility* — `https://developer.mozilla.org/en-US/docs/Web/Accessibility`. Skim only the introduction; it explains why file and page structure matter to assistive technology.

## 15. What comes next

Stop 0.2 explains how the course works: stops, checks, tasks, gates, retries and the mastery rule. Do not skip it — it tells you what "passed" means and how to recover from a failed check without losing progress.