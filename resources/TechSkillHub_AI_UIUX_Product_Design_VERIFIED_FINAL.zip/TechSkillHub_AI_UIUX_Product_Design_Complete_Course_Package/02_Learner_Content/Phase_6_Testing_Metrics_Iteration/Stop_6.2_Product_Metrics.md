---
stop_id: 6.2
title: Product Metrics
phase: 6
prerequisites: Stop 6.1 passed
outcome: Define a small set of product metrics with precise formulas, connect them to user behaviour, and explain what each metric can and cannot tell you.
time: 75-95 minutes
artifact: A metric definition sheet with formulas, a fictional funnel with drop-off, and a one-page interpretation that separates what the data shows from what it does not.
---

# Stop 6.2 — Product Metrics

> **Phase 6 · Testing, metrics and iteration** · Prerequisite: Stop 6.1 · Suggested session: 75–95 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Define activation, retention, task success and drop-off with explicit formulas.
2. Distinguish a metric from a vanity number.
3. Build a simple funnel and read where people leave.
4. Explain what a metric can and cannot tell you.
5. Choose one primary metric and two guardrail metrics for a change.
6. Avoid false claims from small samples and badly defined events.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Metric** | A number that measures something specific, with a defined formula and time window. |
| **Event** | A recorded action, such as `order_started` or `order_completed`. |
| **Funnel** | The sequence of steps toward a goal, with counts at each step. |
| **Conversion rate** | The share of people who complete a step or goal. |
| **Activation** | The moment a new user first gets real value, defined by a specific action. |
| **Retention** | The share of users who return and keep using the product over time. |
| **Churn** | The share who stop using the product in a period. |
| **Task success rate** | The share of attempts where the user completes the task without help. |
| **Drop-off** | The share who leave between two steps. |
| **Cohort** | A group of users defined by a shared start period or behaviour. |
| **Segment** | A subgroup, such as new versus returning users, or mobile versus desktop. |
| **Vanity metric** | A number that looks impressive but does not guide a decision, such as total page views. |
| **Guardrail metric** | A metric you protect from harm while improving the primary metric. |
| **North-star metric** | The single measure that best represents delivered user value. |
| **Statistical significance** | The probability that an observed difference is not due to chance; it depends on sample size and variance. |
| **Instrumentation** | The events and properties you record to measure behaviour. |

## 3. Why this matters

Designers often say "we improved the experience" and have no way to show it. Metrics give you a shared language with product managers and engineers, and they expose the difference between a design that looks better and one that works better.

Metrics are also easy to abuse. A rising number can hide a worse experience: more clicks can mean more engagement or more confusion; more sign-ups can mean clearer value or a misleading promise. The skill is not reading a dashboard. It is **defining the number precisely and interpreting it honestly**.

> **Everyday example.** A bus company counts "passengers boarded" and calls it success. But if passengers board the wrong bus and have to pay again, the number went up while the service got worse. The useful metric is "passengers who reached their intended destination without a complaint", not "boardings".

## 4. Before you start

- Use the prototype and findings from Stop 6.1.
- Create a spreadsheet with four tabs: `Definitions`, `Funnel`, `Cohorts`, `Notes`.
- Invent a small dataset, clearly labelled fictional. For example, 1,000 simulated new users over four weeks.
- Write down the user's goal in one sentence. Every metric must connect to it.
- Do not use real user-level data. If you have access to real analytics, use only aggregated, permissioned numbers and do not paste them into unapproved tools.

## 5. Teaching, step by step

### Step 1 — Start from the user's job, not the dashboard

Write: "A new user wants to [goal] so that [benefit]." For a savings app: "A new user wants to set a savings goal and make a first deposit so that they can start saving regularly."

Then define the moment value is delivered. That is your activation event. It is not "signed up". It is not "opened the app". It is the first meaningful outcome, for example "created a goal and made a deposit of at least ₦1,000 within 7 days".

### Step 2 — Write definitions with formulas

A metric without a formula is an argument. Write each one precisely:

- **Activation rate** = users who complete the activation event within 7 days of sign-up ÷ users who signed up in the cohort.
- **Task success rate** = sessions where the user completes the defined task without moderator help ÷ sessions where the task was attempted.
- **Drop-off at step 2** = users who reached step 2 but not step 3 ÷ users who reached step 2.
- **Week-4 retention** = users active in week 4 ÷ users who signed up in the cohort.
- **Time to first value** = median minutes from sign-up to activation event.

State the window, the population and the exclusions. "Retention is 40%" means nothing without "week 4, users who signed up in January, excluding internal accounts".

### Step 3 — Build a funnel from real steps

A fictional checkout funnel:

| Step | Users | Conversion from previous | Drop-off |
|---|---|---|---|
| Opened product page | 1,000 | — | — |
| Added to cart | 420 | 42% | 58% |
| Started checkout | 260 | 62% | 38% |
| Entered delivery details | 190 | 73% | 27% |
| Entered payment | 120 | 63% | 37% |
| Completed order | 96 | 80% | 20% |

The largest absolute loss is between product page and cart: 580 people. The largest proportional loss is at the same step: 58%. That is where to investigate first, unless the business cares more about a later, higher-value step.

Funnels show *where*, not *why*. You still need usability testing, session observation or interviews to explain the drop.

### Step 4 — Separate acquisition, activation, retention and revenue

A simple lifecycle:

- **Acquisition:** how people arrive.
- **Activation:** whether they reach first value.
- **Retention:** whether they come back.
- **Revenue:** whether the product sustains itself.
- **Referral:** whether they bring others.

A design change usually targets one stage. Be explicit about which. A prettier onboarding screen might improve activation and do nothing for retention. That is fine if activation was the goal.

### Step 5 — Use cohorts, not just averages

An average hides change. If 1,000 users signed up over four weeks, track each weekly cohort separately:

| Cohort | Week 1 | Week 2 | Week 3 | Week 4 |
|---|---|---|---|---|
| Week 1 | 100% | 42% | 31% | 26% |
| Week 2 | 100% | 46% | 34% | 29% |
| Week 3 | 100% | 49% | 37% | — |
| Week 4 | 100% | 51% | — | — |

Rising week-2 retention across cohorts suggests the product is improving for new users. A flat overall average could hide that. Cohorts also expose seasonal effects and the impact of a release.

### Step 6 — Pick one primary metric and two guardrails

For a checkout redesign:

- **Primary:** order completion rate.
- **Guardrail 1:** refund rate (did we push people into bad purchases?).
- **Guardrail 2:** support contacts per 1,000 orders (did we create confusion?).
- Optional: **time to complete** and **error rate**.

Guardrails prevent you from "winning" by harming users. A completion rate that rises while refunds double is not a win.

### Step 7 — Question every number

Ask:

- **Who is counted?** New versus returning, internal versus external, bots.
- **When?** The window matters; 7-day activation differs from 30-day.
- **Compared to what?** Last week, last year, a control group.
- **How was the event fired?** Client-side events can be blocked; server-side events may be more reliable.
- **What is missing?** People who never reached the event, people who use assistive tech, people on slow networks.
- **Is the difference meaningful?** A 0.2% change on 200 users is noise.

### Step 8 — Understand sample size without becoming a statistician

You do not need to run a full power calculation for a course project, but you do need to avoid false confidence.

- With 20 users, a difference of 2 people is 10 percentage points but very uncertain.
- With 20,000 users, a 0.5-point difference may be real but commercially trivial.
- Splitting users by device, country and new/returning multiplies the groups and shrinks each one.

Rule of thumb for this course: report the count, the denominator and the uncertainty in plain words. Say "6 of 20 (30%), small sample" rather than "30% of users".

### Step 9 — Write the interpretation page

Use four headings:

1. **What we measured** — definitions and window.
2. **What we saw** — the numbers, with counts.
3. **What it might mean** — interpretations, labelled as such.
4. **What it does not tell us** — limits and alternative explanations.

Example: "Checkout completion rose from 62% to 68% after the change (n=1,240 vs n=1,190). This is consistent with the simplified form, but it could also reflect a seasonal shift. We did not run a controlled test, so we cannot attribute the change to the design alone."

That paragraph is more valuable than a dashboard screenshot because it is honest.

## 6. Worked example (I do)

A learner, Musa, works on a fictional farm-produce ordering app. The team says "engagement is up". He asks for definitions and finds that "engagement" means daily app opens, which rose after a push notification was added.

He reframes:

- **User goal:** order fresh produce for delivery without phoning the vendor.
- **Activation:** first completed order within 14 days.
- **Primary metric for the next change:** order completion rate.
- **Guardrails:** cancellation rate, support calls, average order value.

The funnel shows 1,000 product views → 380 carts → 210 checkouts → 150 completed orders. Completion from checkout is 71%. The biggest absolute loss is product view to cart (620 people). Session notes from Stop 6.1 show that delivery fees appear only at checkout, which surprises people.

He writes: "The data shows a large drop before cart. It does not tell us why. The usability sessions suggest fee surprise, but five participants cannot prove prevalence. Next step: show an estimated delivery fee on the product page and measure cart rate, with cancellations as a guardrail."

**Why this is good:** he does not claim causation from a funnel. He connects a metric pattern to a qualitative hypothesis and proposes a test.

## 7. We do it together

Using the fictional funnel above:

1. Calculate the overall conversion from product view to completed order. (Answer: 9.6%.)
2. Identify the step with the largest absolute loss. (Product view to cart: 580 users.)
3. Identify the step with the lowest conversion rate. (Also product view to cart: 42%.)
4. Write one hypothesis for that drop that could be tested qualitatively.
5. Choose one guardrail metric for a change that adds a discount banner to the product page. (For example, return rate or margin per order.)

**Hint:** if two steps tie, report both and explain which matters more for the user's goal.

## 8. Your turn (You do)

Create a metric pack for your prototype:

- one sentence describing the user's job;
- an activation event with a 7- or 14-day window;
- definitions and formulas for activation, task success, drop-off and week-4 retention;
- a fictional funnel with at least five steps and counts;
- one cohort table with at least three cohorts;
- one primary metric and two guardrails for a proposed change;
- a one-page interpretation using the four headings in Step 9, including at least three limitations.

Label all data as fictional. Do not imply that the numbers come from real users.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** What makes a metric useful?
- A. A precise definition, a stated formula and a time window tied to a decision someone will make.
- B. A large total that grows every month, so it looks impressive on the dashboard during reviews.
- C. A place on the main dashboard, so the whole team sees it every morning without extra work.
- D. A number that is easy to increase, so any change the team ships will show visible progress.

**Q2.** Which is the best activation event for a savings app?
- A. Creating a goal and making a first deposit of a set amount within the first week.
- B. Opening the app for the first time after installing it and reaching the home screen.
- C. Seeing the logo on the splash screen while the app loads for the first few seconds.
- D. Installing the app from the store and granting the permissions it asks for at start-up.

**Q3.** A funnel shows a 58% drop between product view and cart. What does it tell you?
- A. Why people left at that step, because the size of the drop shows what they were thinking.
- B. That the design is bad, because a loss that large cannot happen in a well-made interface.
- C. Where people left the sequence at that step, but not the reason, which needs observation or interviews.
- D. That the sample is significant, because a 58% difference is too large to be chance.

**Q4.** In a product metric tree, what is a guardrail metric?
- A. A metric you try to increase at any cost, because it is the main sign that the change worked.
- B. A metric that is always larger than the others, so it stands out when the dashboard is scanned.
- C. A metric you protect from harm while you try to improve the primary metric for the change.
- D. A vanity metric that looks impressive in a review but does not guide any product decision.

**Q5.** Why are cohorts more informative than a single average?
- A. They are easier to calculate, since the spreadsheet can total every user in one simple sum.
- B. They remove the need for definitions, because the groups already share a start period.
- C. They show change over time for comparable groups, which a flat overall average can hide.
- D. They increase the sample size, so every group has more users than the overall figure did.

**Q6.** "6 of 20 users completed the task" is better than "30% of users" because:
- A. It is shorter, so the finding fits more easily into a summary slide or a status email.
- B. Percentages are always wrong in usability work and should never appear in a written research report.
- C. It shows the count and the sample size, so readers can see how uncertain the result is.
- D. It sounds more technical, which makes the report more credible to the engineers and senior managers.

**Q7.** A completion rate rises while refunds double. What should you conclude?
- A. The change is a clear success, because completion is the primary metric the team chose.
- B. The guardrail signals possible harm, so investigate the refunds before celebrating the result or shipping anything.
- C. Refunds are unrelated to this change, so the doubling is probably seasonal and can be ignored.
- D. The sample is too small to read anything, so no conclusion is possible until next quarter.

**Q8.** Which is a vanity metric?
- A. Total cumulative page views with no decision attached to the number in any review.
- B. Week-4 retention for a defined cohort of users who signed up in the same month.
- C. Task success rate measured with a defined protocol and a stated denominator per task.
- D. Drop-off at a named step of the checkout funnel, compared with the previous release.

**Q9.** A savings app wants an activation metric. Which event best represents first real value?
- A. The user opens the app for the first time and reaches the welcome screen after installing it.
- B. The user completes a first deposit and sees the confirmed balance in the account view.
- C. The user taps the sign-up button on the landing page and starts filling in the form.
- D. The user views the marketing page before deciding whether to create an account at all.

**Q10.** A funnel shows a 58% drop between product view and cart, but the team does not know why. What can the funnel itself tell them?
- A. That the loss occurs between the steps, not the reason people left at that point.
- B. The exact emotional cause of the drop, because the size shows how people felt.
- C. That the product is definitely too expensive, since price is the usual reason for a drop.
- D. That the checkout code is broken, because a 58% loss points to a technical fault.

## 10. Practical task and pass criteria

**Task.** Submit the metric pack and interpretation page.

**Pass criteria — all must be met:**

- [ ] User job stated in one sentence.
- [ ] Activation event defined with a window.
- [ ] Four metrics have explicit formulas.
- [ ] Funnel has at least five steps with counts and conversion rates.
- [ ] Cohort table has at least three cohorts.
- [ ] One primary metric and two guardrails are chosen for a proposed change.
- [ ] Interpretation separates measurement, observation, interpretation and limits.
- [ ] At least three limitations are stated.
- [ ] All data is labelled fictional or clearly sourced and aggregated.
- [ ] No real user-level data is included.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| "Engagement" with no definition | It sounds impressive | Define the event, window and population. |
| Sign-up counted as activation | Easy to measure | Define first real value. |
| Funnel treated as explanation | It is visual | Pair it with qualitative evidence. |
| Averages hiding cohort change | Simpler to report | Break out cohorts. |
| No guardrails | Focus on the win | Add two harm metrics. |
| Tiny samples with big claims | Excitement | Report counts and uncertainty. |
| Real user data in a course file | Convenience | Use fictional or aggregated data. |
| Dashboard screenshots without context | Looks professional | Add definitions and interpretation. |

**Retry variant.** Take a different product — a public library booking system — and define only three metrics: activation, task success and one guardrail. Write a one-page memo explaining why those three and not others. The constraint tests whether you can choose metrics rather than list them.

## 12. Proof artifact for your portfolio

Keep the definition sheet, funnel, cohort table and interpretation memo. In a portfolio, this shows product thinking and the ability to work with data without overclaiming. Label fictional figures clearly.

## 13. Low-data and low-cost path

- Use a spreadsheet; no analytics licence is required.
- Simulate a dataset with a random number generator and label it fictional.
- Skip video if data is tight; the steps stand alone.
- If you have real aggregated data, use percentages and counts only, with permission.
- Keep the funnel to five steps to reduce complexity.

## 14. Watch and read more

**Recommended video:** *6 Key UX Metrics Explained* by Eleken (2024, 9 min 50 s) — `https://www.youtube.com/watch?v=UTNv6CNv82E`. A concise overview of common UX metrics and how they differ. Metadata checked 2026-10-30; embedded playback was verified in Chrome on 2026-10-30.

**Read:**

- Nielsen Norman Group, *UX metrics* — `https://www.nngroup.com/topic/analytics-and-metrics/`. Articles on task success, retention and measurement pitfalls.
- Google, *HEART framework* — `https://research.google/pubs/measuring-the-user-experience-on-a-large-scale-user-centered-metrics-for-web-applications/`. Happiness, Engagement, Adoption, Retention, Task success.
- GOV.UK Service Manual, *Measuring success* — `https://www.gov.uk/service-manual/measuring-success`. Public-sector performance measurement.
- Amplitude, *North Star Playbook* — `https://amplitude.com/north-star`. Explains how one outcome metric relates to supporting inputs. The playbook may offer a downloadable version; the web page is readable without an account.

## 15. What comes next

Stop 6.3 turns findings and metrics into a prioritised v2. You will decide what to fix, what to leave, how to frame an A/B test, and how to write the change with reasons rather than taste.