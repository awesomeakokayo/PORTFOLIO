---
stop_id: 6.1
title: Usability Testing
phase: 6
prerequisites: Phase 5 gate passed; a deployed prototype
outcome: Plan and run a five-participant usability test with a neutral script, record observations without leading, and turn them into prioritised, evidence-linked findings.
time: 90-120 minutes
artifact: A test pack: plan, consent script, task list, session notes for five participants, a findings table with severity and evidence, and a short summary.
---

# Stop 6.1 — Usability Testing

> **Phase 6 · Testing, metrics and iteration** · Prerequisite: Phase 5 gate · Suggested session: 90–120 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Write a test plan with a clear research question and realistic tasks.
2. Obtain informed consent and handle recordings responsibly.
3. Moderate without leading, and stay quiet when the participant struggles productively.
4. Record observations separately from interpretations.
5. Run five sessions and identify patterns rather than one-off comments.
6. Write findings with severity, evidence and a recommended next action.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Usability test** | Watching people attempt realistic tasks with your design to find where it fails. |
| **Participant** | The person being observed. Not a "user" in the abstract; a specific person who consented. |
| **Task** | A realistic goal given to the participant, such as "find out how much delivery costs". |
| **Scenario** | The short story that gives the task context. |
| **Moderator** | The person running the session and speaking with the participant. |
| **Think-aloud** | Asking the participant to say what they are thinking while they work. |
| **Leading question** | A question that suggests the answer, such as "Was that easy?" |
| **Probe** | A neutral follow-up, such as "What were you looking for just then?" |
| **Observation** | What happened: "She clicked Delivery, then went back twice." |
| **Interpretation** | What you think it means: "The delivery link may not look clickable." |
| **Severity** | How badly an issue blocks or slows the task. |
| **Consent** | Explicit permission to take part and to record, given before the session. |
| **Anonymisation** | Removing names and identifying details from notes and clips. |
| **Saturation** | The point where new sessions stop revealing new issues; five is a common starting round, not a guarantee. |
| **Pilot** | A rehearsal session to test your script and tasks. |

## 3. Why this matters

You cannot tell whether a design works by looking at it. You can tell whether it looks plausible. The gap between plausible and usable is where real users get stuck, and it is usually invisible to the person who made the design.

Five participants will not find every problem. They will reliably find the big ones, especially if you run more than one round. The purpose of a first round is not statistical proof. It is to replace opinion with observed behaviour, early, while changes are cheap.

> **Everyday example.** A tailor can look at a jacket on a mannequin and say it fits. The customer raises an arm and the seam pulls. Five minutes of watching someone move tells you more than an hour of looking.

There is also a professional reason. "I tested it with five people and here is what happened" is far stronger in a portfolio than "I think this is intuitive". Testing is evidence. Evidence is what separates a designer from a decorator.

## 4. Before you start

- Use your deployed prototype from Gate 5. If it is incomplete, test the part that exists and say so.
- Write one research question, for example: "Can a first-time user find the delivery cost and complete an order without help?"
- Recruit five people who are **not** close collaborators on the design. Classmates, friends of friends, or people from a community group are fine. Do not test your own team.
- Prepare a consent script and a private storage folder.
- Prepare a notes template: `Participant | Task | Observation | Quote | Interpretation | Severity`.
- Run one pilot with a friend and fix the script before the real sessions.

## 5. Teaching, step by step

### Step 1 — Write the plan before the script

A one-page plan:

- **Research question:** one sentence.
- **What is being tested:** the deployed prototype and its scope.
- **What is not being tested:** visual polish, content strategy, backend accuracy.
- **Participants:** five, with the relevant context (for example, "people who have ordered food online at least once").
- **Method:** moderated, remote or in person, think-aloud, 30 minutes.
- **Tasks:** 3–5 realistic tasks.
- **Metrics:** task success, time on task, number of errors, ease rating.
- **Ethics:** consent, recording, anonymisation, deletion date.
- **Limitations:** small sample, prototype gaps, no real payments.

The plan protects you from the most common failure: testing everything and learning nothing.

### Step 2 — Write tasks that do not give away the answer

Bad task: "Click the green Delivery button and read the fee."
Good task: "You want to order food to your house. Find out how much delivery will cost before you pay."

Bad task: "Use the search bar to find jollof rice."
Good task: "Find a jollof rice option for two people."

A task should state a goal and a context, not the interface path. If the participant cannot find the feature, that is the finding. Do not rescue them by naming the button.

Task order matters. Start with an easy, realistic task to settle nerves, then increase complexity. Do not put the most important task last when the participant is tired.

### Step 3 — Get consent properly

Consent is not a formality. It is a conversation with a record.

Say, and give in writing:

- what the session is for;
- that you are testing the design, not the person;
- that there are no wrong answers;
- that they can stop at any time and skip any question;
- whether you will record audio, video or screen;
- who will see the recording;
- how long you will keep it and when you will delete it;
- how their name will be replaced in notes;
- how to contact you afterwards.

If they decline recording, take written notes only. Do not record secretly. Do not publish a clip without specific permission. Do not include a participant's face, name or voice in a portfolio without a separate release.

For a course exercise, use a consent script template and store it with the test pack. If a participant is under 18, do not proceed without a guardian's consent and your instructor's approval.

### Step 4 — Set up the session

A 30-minute structure:

1. **Welcome (3 min):** thanks, consent confirmation, explain think-aloud.
2. **Warm-up (3 min):** "Tell me about the last time you ordered something online." This gets them talking.
3. **Tasks (18 min):** 3–5 tasks, one at a time. Read the task, then stop talking.
4. **Wrap-up (5 min):** "What was the most confusing part?" "Anything you expected that was not there?"
5. **Close (1 min):** thanks, explain what happens next, confirm deletion date.

Practical setup:

- Test the connection and screen sharing before the participant joins.
- Ask them to use their own device if possible; it is closer to real conditions.
- Keep your face visible but quiet. Nod, do not fill silence.
- Have a timer visible but do not rush them.
- Note the timestamp when something important happens, so you can find it later.

### Step 5 — Moderate without leading

The hardest skill is silence. When the participant pauses:

- Wait five seconds. Many people solve the problem themselves.
- If they ask "Is this right?", reply "What do you think?" or "What would you expect to happen?"
- If they are stuck for a long time, ask "What are you looking for right now?" not "Try the menu."
- If they apologise, say "You are not being tested; the design is."

Avoid:

- "Was that easy?" → "How was that?"
- "Did you see the button?" → "What did you notice?"
- "Most people click here." → say nothing.
- "Great job!" → neutral acknowledgement, because praise shapes behaviour.

Take notes in two columns: **observation** and **interpretation**. Keep them separate so you can check later whether the interpretation is supported.

### Step 6 — Record what happened, not what you hoped

Observation examples:

- "P1 read the heading, then scrolled past the fee section twice."
- "P2 clicked 'Continue' before selecting a payment method; error appeared; she re-read the page."
- "P3 asked whether delivery was free; the page said 'from ₦500' but she did not see it."

Interpretation examples:

- "The fee is visually buried below the fold."
- "The disabled state is not obvious enough to explain why Continue failed."
- "The 'from' qualifier is easy to miss."

A finding needs at least one observation. A recommendation needs a finding. Do not jump from "I think the colour is wrong" to "change the colour".

### Step 7 — Run five sessions and look for patterns

After each session, write a two-minute summary while it is fresh. After five, build a table:

| ID | Issue | Participants | Evidence | Severity | Recommendation |
|---|---|---|---|---|---|
| U1 | Delivery fee missed | P1, P2, P4 | Fee below fold; 3/5 scrolled past | High | Move fee summary above the CTA |
| U2 | Continue enabled too early | P2, P5 | Clicked before payment; error | Medium | Disable until valid, with reason |
| U3 | Address form unclear | P3 | Asked what "area" meant | Medium | Add example and helper text |

Count participants, not clicks. "3 of 5" is more honest than "most users". A single participant can reveal a severe issue; report it as a single observation, not a pattern.

Five users is a starting round, not a law. If the fifth session is still producing new severe issues, run more. If you need to compare segments, run more per segment.

### Step 8 — Rate severity consistently

Use a simple scale and define it before you start:

- **Critical:** prevents task completion or causes data loss; fix before release.
- **High:** major delay or confusion; most participants affected; fix in the next iteration.
- **Medium:** noticeable friction; workaround exists; schedule.
- **Low:** cosmetic or minor; batch with other work.

Severity is not the same as frequency. One participant losing a saved order is critical even if four did not. Frequency is evidence; severity is impact.

### Step 9 — Write the summary honestly

A useful summary has:

- the research question and method;
- who participated, in aggregate (no names);
- what worked;
- the top 3–5 issues with evidence and severity;
- what you will change and what you will not;
- limitations: sample size, prototype gaps, moderator bias, environment;
- what you would test next.

Do not write "users loved it". Write "4 of 5 completed the task without help; 3 of 5 missed the fee". Specific is credible.

## 6. Worked example (I do)

A learner, Zainab, tests a fictional parcel-tracking prototype with five classmates.

**Research question:** Can a first-time user find out where a parcel is and what to do if it is delayed?

**Tasks:**

1. "Your parcel was meant to arrive yesterday. Find out where it is."
2. "The page says it is delayed. Find out what you can do."
3. "Change the delivery address to your workplace."

**What happened:**

- P1 found the tracking number field but typed the order number. Error message said "Invalid". She did not know which number to use.
- P2 and P4 also used the order number. Same error.
- P3 found the tracking number in her email and completed task 1.
- P2 could not find the "delayed" help; the link was below a large illustration.
- P5 completed all three tasks but said she would not trust the page because the last update was "2 days ago" with no explanation.

**Findings:**

| ID | Issue | Participants | Severity |
|---|---|---|---|
| U1 | Error does not say which number is required | P1, P2, P4 | High |
| U2 | Delay help is below the fold and visually buried | P2, P3 | High |
| U3 | Stale tracking data is not explained | P5 | Medium |

**Changes:** rewrite the error to "Enter the 10-character tracking number from your confirmation email", move the delay help above the illustration, add "Last updated 2 days ago — updates may be delayed".

**Why this is a good test:** the tasks were realistic, the moderator did not name the field, and the findings are tied to observed behaviour. The sample was five, and the report says so.

## 7. We do it together

With a partner, run a 15-minute rehearsal:

1. Read your consent script aloud. Fix anything that sounds like a legal notice rather than a conversation.
2. Give one task. Do not explain the interface.
3. When your partner pauses, count five seconds before speaking.
4. Write one observation and one interpretation. Label which is which.
5. Ask one neutral probe: "What were you looking for just then?"
6. Swap roles.

**Hint:** if you feel uncomfortable with silence, put a sticky note on your screen that says "Wait 5 seconds". The silence is the method.

## 8. Your turn (You do)

Run a five-participant usability test on your deployed prototype. Submit:

- the one-page plan;
- the consent script and confirmation that consent was obtained;
- 3–5 tasks;
- anonymised notes for five sessions;
- a findings table with evidence, frequency, severity and recommendation;
- a 250-word summary with limitations;
- a statement of how recordings will be stored and when they will be deleted.

If you cannot find five people, run three and label the result "pilot, three participants"; do not claim five. A smaller honest sample is acceptable for the exercise; the limitation must be stated.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** What is the main purpose of a first usability test round?
- A. To prove that the design is already good, so the team can stop testing and move on to the next feature.
- B. To observe where real people actually struggle and replace the team's opinions with evidence early, while changes are still cheap.
- C. To collect complimentary quotes from participants that the team can reuse in marketing material and on sales pages later.
- D. To replace product analytics entirely, because watching five people shows how often every event happens for every user.

**Q2.** Which task is written correctly?
- A. Click the blue Delivery tab at the top of the basket page, then read the fee in the order summary.
- B. Find out how much delivery will cost before you pay, because you are ordering food to your house.
- C. Did you find the blue delivery button easy to use, or would you prefer a clearer label on it?
- D. Use the search bar on the menu page to look for a jollof rice option that serves two people.

**Q3.** A participant asks, "Is this right?" What is the best response?
- A. Yes, that is right, well done for finding it so quickly without any help from me today.
- B. Click the next button at the bottom of the form, then check whether the summary looks correct.
- C. What do you think, and what would you expect to happen next on this screen right now?
- D. Most people get that wrong on their first attempt, so do not worry about it at this stage.

**Q4.** Why separate observation from interpretation?
- A. To make each set of session notes longer and more detailed, so the final report looks thorough and professional.
- B. Because interpretations are not allowed in usability work and only recorded behaviour may appear in the findings.
- C. To hide the moderator's personal bias from readers, so the notes appear neutral even where judgement crept in.
- D. So that later claims and recommendations can be checked against what was actually seen in the session.

**Q5.** What does "3 of 5" communicate that "most users" does not?
- A. The exact count and the sample behind it, which is more honest than a vague majority claim.
- B. Nothing extra, since both phrases describe the same group of participants in a five-person round.
- C. Statistical significance, because a count out of five proves the difference is not due to chance.
- D. Severity, because the number of participants affected shows how badly the issue blocks the task.

**Q6.** One participant loses a saved order. Four do not. How should this be rated?
- A. Low, because only one of the five participants hit it, and rare problems can wait for a later release.
- B. Critical, because losing a saved order is severe impact even though only one participant saw it.
- C. Not rated at all, because a single participant cannot show a pattern that is worth acting on.
- D. Medium, because it affected one person only and the other four completed the same task fine.

**Q7.** What must be agreed before recording a session?
- A. Nothing in advance, because joining the call is generally taken as permission to record the screen.
- B. Only the participant's name, so the file can be labelled correctly when it is stored after the call.
- C. A small payment for their time, which stands in for written permission to keep and use the clip.
- D. Explicit consent covering the purpose, who will see the recording, and when it will be deleted.

**Q8.** Which is a limitation that belongs in the report?
- A. The brand colour used on the primary button, which was chosen before the sessions and never changed.
- B. The designer's name and role, so readers know who was responsible for the prototype that was tested.
- C. Five participants and a prototype that could not take real payments during the checkout tasks at all.
- D. The number of headings on the checkout page, which the team had reduced before the sessions.

**Q9.** A usability test task says: 'Click Settings, then Privacy, then turn off sharing.' What is wrong with the task?
- A. It is too short for the participant to understand what is being asked of them in the session.
- B. It does not mention the participant's name, so the moderator cannot personalise the instruction before reading it aloud.
- C. It uses the word Privacy, which gives away the name of the screen the participant must find.
- D. It prescribes the exact interface path instead of stating a goal and the context around it.

**Q10.** A report says 'most users struggled' after testing five people but gives no counts. What is the reporting problem?
- A. The report is too long, so readers lose the main finding among details that do not matter.
- B. The claim hides the small sample and gives no count, so the reader cannot judge its weight.
- C. Five participants is always too many for a first round, so the sessions should have been cut short.
- D. The report should say all instead of most, to make the finding sound stronger and more urgent.

## 10. Practical task and pass criteria

**Task.** Submit the complete test pack and summary.

**Pass criteria — all must be met:**

- [ ] A one-sentence research question and a one-page plan.
- [ ] Consent obtained and documented before each session.
- [ ] 3–5 realistic tasks that do not name interface controls.
- [ ] Five sessions (or three, clearly labelled as a pilot).
- [ ] Notes separate observation from interpretation.
- [ ] Findings table includes participants, evidence, severity and recommendation.
- [ ] Summary reports what worked, what failed and limitations.
- [ ] No participant's name, face or identifying detail appears without permission.
- [ ] Storage and deletion plan stated.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Leading the participant | Wanting them to succeed | Use neutral probes and wait five seconds. |
| Tasks that name buttons | It feels clearer | State the goal and context only. |
| Testing only friends who know the design | Easy recruitment | Recruit people outside the project. |
| Recording without consent | Assumed to be fine | Get explicit, written permission. |
| Reporting opinions as findings | Notes are messy | Require an observation for every finding. |
| Claiming "users want" from five people | Pattern excitement | Say "3 of 5 participants". |
| No severity scale | Every issue feels equal | Define critical/high/medium/low first. |
| Publishing a participant's face | Portfolio excitement | Use a release or blur/anonymise. |

**Retry variant.** Run a **three-participant pilot** on a different flow with a stricter constraint: you may not speak at all during tasks except to read the task and ask one probe. Submit the notes and a reflection on what the silence revealed. The constraint targets the most common moderation failure.

## 12. Proof artifact for your portfolio

Keep the plan, anonymised notes, findings table and summary. In a portfolio, show one finding, the evidence, the change and the re-test result. That chain is far more persuasive than a screenshot of a "user journey".

## 13. Low-data and low-cost path

- Run sessions in person with a notebook if video calls are expensive.
- Use screen recording only if consent is given; otherwise take timestamped notes.
- Test with five peers at no cost.
- Use a phone hotspot only if needed; keep sessions short.
- If you cannot record, ask a second person to take notes, and say so in the limitations.

## 14. Watch and read more

**Recommended video:** *Usability Testing w. 5 Users: Design Process (video 1 of 3)* by NNgroup (2018, 3 min 36 s) — `https://www.youtube.com/watch?v=RhgUirqki50`. Explains the five-user rationale and the limits of small samples. Metadata checked 2026-10-30; embedded playback was verified in Chrome on 2026-10-30.

**Read:**

- Nielsen Norman Group, *Usability testing* — `https://www.nngroup.com/articles/usability-testing-101/`. Method, moderation and analysis basics.
- GOV.UK Service Manual, *User research* — `https://www.gov.uk/service-manual/user-research`. Practical, public-sector guidance including consent and ethics.
- W3C WAI, *Involving users in evaluating web accessibility* — `https://www.w3.org/WAI/test-evaluate/involving-users/`. Including people with disabilities in testing.
- WebAIM, *Articles* — `https://webaim.org/articles/`. Accessibility checks to combine with usability sessions.

## 15. What comes next

Stop 6.2 connects what you observed to product metrics: activation, retention, task success and drop-off. Testing tells you *where* people struggle; metrics tell you how often and what it costs the product.