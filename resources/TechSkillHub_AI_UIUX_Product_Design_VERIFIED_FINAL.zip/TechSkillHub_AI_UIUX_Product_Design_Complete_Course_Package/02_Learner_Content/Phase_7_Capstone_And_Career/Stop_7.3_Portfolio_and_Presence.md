---
stop_id: 7.3
title: Portfolio and Presence
phase: 7
prerequisites: Stop 7.1 passed; at least two case studies drafted
outcome: Publish a live portfolio with three strong case studies, a clear positioning statement and a profile that survives a 30-second scan on a phone.
time: 90-120 minutes
artifact: A live portfolio URL with three case studies, an about page, contact method and a mobile check; plus a one-paragraph positioning statement.
---

# Stop 7.3 — Portfolio and Presence

> **Phase 7 · Capstone and career launch** · Prerequisite: Stop 7.1 · Suggested session: 90–120 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Write a positioning statement that says who you help and with what.
2. Choose three case studies that show range without diluting focus.
3. Structure a portfolio home page for a 30-second scan.
4. Publish a live site that works on a phone and loads on a slow connection.
5. Present yourself consistently across a portfolio and one professional profile.
6. Avoid the legal and ethical traps of publishing other people's work.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Portfolio** | A curated body of work that demonstrates your capability. |
| **Positioning** | The specific value you offer and to whom. |
| **Case study card** | A short summary tile that links to the full study. |
| **Above the fold** | What is visible before scrolling. |
| **Call to action (CTA)** | The next step you want a visitor to take, such as "View case study" or "Email me". |
| **Personal brand** | The consistent impression your work and communication create. |
| **Domain** | The address of your site, such as `yourname.com`. |
| **Hosting** | A service that serves your site files. |
| **Alt text** | A description of an image for people who cannot see it. |
| **Metadata** | The title and description search engines and link previews show. |
| **Scan pattern** | How people skim: headings, images, short lines, then detail. |
| **Proof** | Evidence of capability: case studies, artefacts, references, results. |
| **NDA** | A non-disclosure agreement that limits what you can publish. |
| **Attribution** | Crediting collaborators and tools accurately. |
| **Conversion** | The share of visitors who take the action you want. |

## 3. Why this matters

Your portfolio is not an archive. It is an argument: "I can find the right problem, make decisions, and produce work that holds up." Most visitors will give it less than a minute. If the first screen is a moody hero image and the words "I design meaningful experiences", they will leave without knowing what you do.

A focused portfolio with three honest case studies beats twenty dribbble shots. It also gives you something concrete to send in applications, proposals and conversations.

> **Everyday example.** A food seller with a handwritten sign listing "jollof, fried rice, beans, plantain" gets more orders than one with a beautiful banner that says "We serve joy". The second is memorable but not actionable. Your portfolio needs both: clarity first, beauty second.

## 4. Before you start

- Finish at least two case studies from Stop 7.1. A third can be a strong course project with a clear problem.
- Decide your focus: product design, UX research, UI design, design systems, or a combination. "Everything" is not a focus.
- Choose a publishing route: hand-coded HTML on GitHub Pages, a no-code site builder, or a platform such as Behance. GitHub Pages gives you control and costs nothing.
- Prepare a professional email address and a contact method. A form that silently fails is worse than an email link.
- Check permissions for every image and client name.

## 5. Teaching, step by step

### Step 1 — Write the positioning statement

Use: **I help [who] to [outcome] through [approach], with experience in [proof].**

Example: "I help small African fintech teams turn complex money flows into clear mobile experiences, through research-led product design and accessible design systems. I have shipped a savings onboarding flow and a checkout redesign, both tested with real users."

Avoid "passionate creative" and "I love solving problems". Those describe everyone. Specificity is what makes you memorable.

### Step 2 — Choose three case studies with a reason

A strong set shows:

1. **Depth:** one project where you went from research to tested iteration.
2. **Range:** a different context, such as a service, a dashboard or a design system.
3. **Judgment:** a project where you made a hard trade-off or changed direction.

Do not include every project. A weak fourth project lowers the average. If you have only two strong ones, publish two and label the site honestly.

### Step 3 — Design the home page for scanning

The first screen should answer:

- What do you do?
- Who do you do it for?
- What proof can I see immediately?

A simple structure:

1. **Name and one-line positioning.**
2. **Three case study cards**, each with a problem-led title, one-line result and a thumbnail.
3. **A short about section** with a photo or a simple graphic.
4. **Contact** with an email link and one professional profile.
5. **Footer** with a copyright line and credits.

Case study card example:

> **Making delivery costs visible before checkout**
> A fictional produce app lost 38% of users at payment. An early fee estimate cut fee-related confusion from 3/5 to 1/5 in a five-user re-test.
> *Product design · Research · Prototype*

The title names the problem, not the screen. "Checkout redesign" is weaker than "Making delivery costs visible before checkout".

### Step 4 — Write the about page like a person

Include:

- what you do and who you help;
- how you work: research, iteration, collaboration;
- relevant background, without a life story;
- tools you actually use;
- one or two human details that make you easy to talk to;
- a clear contact route.

Keep it under 250 words. Do not claim seniority you do not have. Do not list every tool; list the ones you can use well.

### Step 5 — Build for mobile and low data

Most visitors will arrive from a phone.

- Design at 320px first.
- Compress images to WebP, under 200 KB each.
- Use system fonts or one font family.
- Avoid autoplay video and heavy animation.
- Make tap targets at least 44×44.
- Test on a throttled connection.
- Ensure text contrast is at least 4.5:1.
- Add `alt` text to every meaningful image.

A portfolio that takes 12 seconds to load contradicts the skills it claims.

### Step 6 — Make it accessible

- One `h1` per page; headings in order.
- Descriptive link text, not "click here".
- Keyboard navigation with a visible focus state.
- Captions or transcripts for any video.
- No text baked into images without an accessible equivalent.
- A skip link if the navigation is long.
- Forms with labels and clear errors.

Accessibility is not a separate section. It is proof that you can do the job.

### Step 7 — Publish and check the live site

Publish with GitHub Pages, Netlify or your chosen platform. Then check:

- the URL works in a private browser window;
- every case study link works;
- the email link opens a mail client;
- the site works at 320px, 768px and 1280px;
- the page title and description are set;
- the favicon does not 404;
- there are no broken images;
- the site appears in a link preview.

Ask two people to open it and tell you what they think you do. If they cannot answer in 30 seconds, rewrite the first screen.

### Step 8 — Align one professional profile

Choose one network to maintain well, usually LinkedIn for most African and remote job markets, or Behance/Dribbble if your focus is visual. Use the same:

- name and photo;
- one-line positioning;
- three featured projects;
- contact method.

Do not spray the same generic post across five platforms. One coherent profile is stronger than five neglected ones.

### Step 9 — Protect yourself and others

- Do not publish client work without permission.
- Anonymise participants; blur faces; remove names and account numbers.
- Do not use a competitor's screenshots as your own.
- Credit collaborators and tools.
- Do not invent results, clients or job titles.
- Use a professional email; avoid unprofessional handles.
- Be careful with personal details such as your home address.

## 6. Worked example (I do)

A learner, Amina, has four projects: a savings app, a restaurant landing page, a design system and a course exercise. She chooses three:

1. **Savings app** — depth: research, prototype, five-user test, v2.
2. **Design system** — range: tokens, components, documentation, drift check.
3. **Restaurant page** — judgment: she removed a live map and chat widget to hit a 300 KB budget.

She drops the course exercise because it has no problem statement.

Her home page:

> **Amina Bello — Product designer for small fintech teams**
> I turn complex money flows into clear mobile experiences, tested with real users.
>
> **Case studies**
> - **Making savings goals feel achievable** — 4/5 users set unsustainable targets; a weekly preview changed their choices.
> - **A design system a developer can actually use** — 14 tokens, 3 components, one drift check.
> - **A restaurant page that works on one bar of signal** — 2.8 MB to 310 KB, LCP 9.4 s to 2.1 s.
>
> **About** — 120 words, one photo, email link.

She publishes on GitHub Pages, compresses images, tests at 320px, and asks two friends what she does. Both say "product designer for fintech". The positioning works.

## 7. We do it together

Using your work:

1. Write your positioning statement in the format from Step 1.
2. Choose three projects and give each a problem-led title.
3. Write a one-line result for each, with a number or a concrete change.
4. Sketch the home page in three blocks: positioning, case studies, contact.
5. Check one case study image for size and `alt` text.

**Hint:** if a project has no result, either find the evidence or reframe it as a process study. Do not invent a number.

## 8. Your turn (You do)

Publish a live portfolio with:

- a positioning statement;
- three case studies, each with a problem-led title and a result;
- an about section under 250 words;
- a contact method that works;
- a mobile layout that works at 320px;
- compressed images with `alt` text;
- accessible headings, links and focus states;
- a professional profile that matches the site.

Submit the URL, a 30-second screen recording or three screenshots, and a note on what you would improve next.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** What should the first screen of a portfolio answer?
- A. Your life story, told from childhood, so visitors understand the experiences that shaped your design taste.
- B. Every tool you have used, listed by category, so visitors can confirm you know the relevant software.
- C. What you do, who you do it for, and what proof the visitor can see immediately.
- D. Your favourite colour and typeface, so the page expresses a distinctive personal style right away.

**Q2.** Which case study title is strongest?
- A. Making delivery costs visible before checkout, and rebuilding trust in the final total.
- B. Checkout redesign, covering the payment form, the fee display and the confirmation screen.
- C. Project 3 final final, the version submitted after the last round of client feedback.
- D. UI exploration, a visual study of colours, cards and buttons for the checkout flow.

**Q3.** How many case studies should a beginner portfolio show?
- A. Three strong ones, or fewer if only fewer are strong, with the site labelled honestly.
- B. As many as possible, because a large archive shows range and proves you have shipped often.
- C. Exactly ten, because a round number signals a complete and well-organised body of work.
- D. Only one, because a single deep project is always stronger than several shallower ones.

**Q4.** Why compress portfolio images?
- A. To reduce load time and data cost on mobile, where most visitors first open the portfolio.
- B. To make the images slightly blurry, so visitors focus on the writing instead of the screenshots.
- C. To hide confidential details inside the screenshots without having to edit each image by hand.
- D. To improve search ranking only, since page speed does not affect how visitors judge the work.

**Q5.** A client project is under NDA. What should you do?
- A. Publish it anyway, because the portfolio is personal and the agreement binds the company rather than you.
- B. Change the client's name and publish, since the work is unrecognisable once the logo is removed.
- C. Publish the metrics only, because numbers are abstract and reveal nothing about the client's product.
- D. Get permission, anonymise the details, or publish a clearly labelled reconstruction of the project.

**Q6.** What makes a portfolio accessible?
- A. A dark theme, because high-contrast dark backgrounds are easier for everyone to read on a phone.
- B. A loading animation, because motion signals progress and keeps visitors patient on slower connections.
- C. A PDF download, because a fixed document preserves the layout for every visitor on every device.
- D. Proper headings, alt text, sufficient contrast, visible keyboard focus and captions for any embedded video.

**Q7.** Why align one professional profile with the portfolio?
- A. To post more often, because regular publishing is what keeps a profile visible in crowded feeds.
- B. To collect more followers, because a larger audience makes employers much more likely to reply.
- C. To create a consistent, recognisable impression and reduce confusion for anyone who checks both places.
- D. Because the platforms require it, and profiles that do not match a linked site may be restricted.

**Q8.** What is the best test of your home page?
- A. You like it, because your own judgement is the only reliable measure of clarity and visual quality.
- B. A stranger can say what you do within 30 seconds of opening the page on a phone.
- C. It has many animations, because motion keeps visitors on the page long enough to read the text.
- D. It uses the latest framework, because modern tooling signals to employers that your skills are current.

**Q9.** A portfolio home page opens with a large abstract illustration and the words 'I am passionate about design'. What should replace it first?
- A. A longer biography starting from childhood, so visitors understand the full path that led to design.
- B. More abstract illustrations, so the page feels visually consistent and memorable at first glance to visitors.
- C. A clear statement of who the designer helps, with what problem, and a link to proof.
- D. A list of every tool the designer has opened, ranked by how confidently each one is used.

**Q10.** A portfolio's case study images are 5 MB each and the home page takes 12 seconds to load on mobile data. What is the main problem?
- A. Uncompressed images make the portfolio slow on mobile and contradict the user-centred claims it makes.
- B. The case studies are too short, so visitors leave before they reach the results or the lesson.
- C. The portfolio has too many colours, which makes the layout feel busy on a small screen.
- D. The designer has too many case studies, and each one adds weight to the home page.

## 10. Practical task and pass criteria

**Task.** Publish the portfolio and submit the URL plus screenshots and an improvement note.

**Pass criteria — all must be met:**

- [ ] Live URL works in a private window.
- [ ] Positioning statement names who, outcome and approach.
- [ ] Three case studies (or fewer, with a reason) have problem-led titles and results.
- [ ] About section is under 250 words and includes a contact route.
- [ ] Site works at 320px with no horizontal scrolling.
- [ ] Images are compressed and have `alt` text.
- [ ] Headings, links, focus states and contrast pass basic accessibility checks.
- [ ] A professional profile matches the site's positioning.
- [ ] All work is published with permission and participants are anonymised.
- [ ] No invented clients, results or job titles.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| "Passionate designer" hero | It feels safe | State who you help and what you do. |
| Too many projects | Wanting to show range | Choose three strong ones. |
| Screenshots without context | Visual pride | Add problem, decision and result. |
| Heavy hero video | It looks impressive | Compress or remove; prioritise text. |
| Broken contact form | Set-and-forget | Use an email link and test it. |
| Client work without permission | Ownership confusion | Ask, anonymise or reconstruct. |
| Inconsistent profile | Different platforms | Align name, photo, line and projects. |
| No mobile check | Desktop design | Test at 320px and on a real phone. |

**Retry variant.** Build a **one-page text-only** portfolio with three case study summaries and contact details. No images, no animations. If the positioning and results are clear without visuals, the argument works; then add visuals selectively.

## 12. Proof artifact for your portfolio

The live site is the artifact. Keep the URL, screenshots, a PDF backup and the permission notes. Update it after each project; a portfolio is a practice, not a one-time deliverable.

## 13. Low-data and low-cost path

- GitHub Pages, Netlify and many site builders are free.
- Skip a custom domain until you have income; a `github.io` URL is acceptable.
- Use one font family and compressed images.
- Write case studies as text pages first; add images later.
- If you cannot publish, keep a local PDF portfolio and a private link, and say why.

## 14. Watch and read more

**Recommended video:** *How I'd Build A JOB READY UI/UX Design Portfolio In 2026. [FULL GUIDE]* by Saptarshi Prakash (2025, 19 min 13 s) — `https://www.youtube.com/watch?v=PNG0Qvl-PdQ`. A practical portfolio-building guide. Metadata checked 2026-10-30; embedded playback was verified in Chrome on 2026-10-30. Treat the advice as one perspective, not a rule.

**Read:**

- Nielsen Norman Group, *Portfolios* — `https://www.nngroup.com/articles/ux-design-portfolios/`. What reviewers look for.
- GitHub Pages — `https://pages.github.com/`. Free static hosting.
- W3C WAI, *WCAG 2.2 Quick Reference* — `https://www.w3.org/WAI/WCAG22/quickref/`. Accessibility checks for your site.
- WebAIM, *Articles* — `https://webaim.org/articles/`. Practical implementation guidance.

## 15. What comes next

Stop 7.4 is about getting paid: pricing, proposals, remote applications, design challenges, interviews and negotiation. The portfolio is your evidence; the next stop is how to turn a conversation into work.