---
stop_id: 7.1
title: Case Study Writing
phase: 7
prerequisites: Phase 6 gate passed
outcome: Write an honest, evidence-led case study that explains the problem, your decisions, what you tested, what changed and what you would do differently.
time: 90-120 minutes
artifact: A 900-1,200 word case study with a one-line summary, evidence images, decision rationale, results and limitations, plus a 150-word short version.
---

# Stop 7.1 — Case Study Writing

> **Phase 7 · Capstone and career launch** · Prerequisite: Phase 6 gate · Suggested session: 90–120 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Structure a case study around a problem and a decision, not a gallery of screens.
2. Write a one-line summary that states the problem, the action and the result.
3. Show evidence without exposing participants or clients.
4. Explain trade-offs and rejected options.
5. Report results honestly, including what did not work.
6. Produce a short version for a portfolio card and a long version for a page.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Case study** | A structured story of a project: context, problem, process, decisions, results, lessons. |
| **Problem statement** | A precise description of who is stuck, what they are trying to do, and why it matters. |
| **Constraint** | A limit: time, budget, technology, policy, skills, access. |
| **Trade-off** | What you gave up to get something else. |
| **Rationale** | The reason behind a decision, linked to evidence. |
| **Evidence** | Research notes, test clips, metrics, prototypes, before/after images. |
| **Outcome** | A change in user behaviour or capability, not just a delivered screen. |
| **Output** | What was produced: a prototype, a component, a page. |
| **Attribution** | Being clear about what you did versus what a team did. |
| **Confidentiality** | Protecting client and participant information. |
| **Anonymisation** | Removing names and identifying details. |
| **Narrative arc** | The sequence that makes the work understandable: context → problem → attempt → decision → result. |
| **Limitation** | An honest boundary on what the evidence supports. |
| **Hero image** | The single visual that communicates the project at a glance. |

## 3. Why this matters

A portfolio of beautiful screens says "I can make things look nice". A case study says "I can find a problem, make a decision, test it and explain the result". Employers and clients are buying the second thing, because the first is increasingly automated.

Most beginner case studies fail in predictable ways: they start with the solution, show every screen, hide the messy parts, claim results they cannot support, and never explain why a decision was made. The fix is not more design. It is better storytelling and more honesty.

> **Everyday example.** A mechanic who says "I fixed the car" is less convincing than one who says "The car stalled when hot; the sensor was reading wrong; I tested it twice; here is the before and after; it may return if the wiring corrodes, so check it in six months." The second story shows method, evidence and judgment.

## 4. Before you start

- Gather: the brief, research notes, early sketches, the final design, test findings, before/after data, and your change log.
- Confirm what you may publish. If the project was for a real client, ask for permission or anonymise it. If it was a course project, label it as such.
- Choose the **one** decision the case study will centre on. A case study is not a diary; it is an argument.
- Create a document with headings from Section 5.
- Choose 4–6 images that carry evidence, not decoration.

## 5. Teaching, step by step

### Step 1 — Write the one-line summary first

Format: **For [who], [the problem] meant [cost]. I [action], which [result], and I learned [lesson].**

Example: "For first-time buyers on a fictional produce app, delivery fees appeared only at payment, causing a 38% checkout drop. I moved an estimate to the product page and retested with five users; fee-related abandonment fell from 3/5 to 1/5, and I learned that cost transparency matters more than a polished checkout."

This sentence forces clarity. If you cannot write it, you do not yet know what the case study is about.

### Step 2 — Set the context in three short paragraphs

Cover:

- **The product and the user:** what it is, who it is for, what they are trying to do.
- **The constraint:** time, team, technology, access, budget.
- **Your role:** exactly what you did and what others did. "I led research and UI; a developer built the checkout; a PM set scope."

Do not spend 500 words on the company history. Context is scaffolding, not the building.

### Step 3 — State the problem precisely

A good problem statement has four parts:

1. **Who** is affected.
2. **What** they are trying to do.
3. **What** gets in the way.
4. **Why** it matters.

Example: "New users trying to order produce for the first time abandon at payment because the delivery fee appears late. This costs the business completed orders and leaves users unsure whether the total is trustworthy."

Avoid "the design was outdated" or "users wanted a better experience". Those are not problems; they are opinions about solutions.

### Step 4 — Show the process as decisions, not a timeline

Do not write "Week 1: research. Week 2: wireframes. Week 3: UI." Nobody learns from that. Instead, show three or four decision points:

- What you believed at the start.
- What evidence changed your mind.
- What you chose and why.
- What you rejected and why.

Example: "I assumed the problem was the payment form. Session notes showed users hesitating earlier, at the cart, when the total jumped. I moved the investigation upstream and rejected a form redesign that would have treated the wrong step."

That paragraph demonstrates judgment. A screen gallery cannot.

### Step 5 — Explain one trade-off honestly

Every real project involves giving something up. Name it:

- speed versus completeness;
- clarity versus density;
- brand expression versus accessibility;
- scope versus quality;
- a custom component versus a system component.

Example: "I used the existing design-system button instead of a custom style. It was less distinctive, but it shipped in a day, passed accessibility checks, and kept the checkout consistent. I would revisit the visual identity after the flow was stable."

Trade-offs show maturity. Designers who claim there were no trade-offs are usually hiding something.

### Step 6 — Present evidence without harming anyone

Use:

- anonymised quotes with participant codes;
- before/after screenshots with fictional data;
- test task success counts;
- funnel numbers with definitions;
- short clips with consent and blurring.

Do not use:

- a participant's name, face or voice without a release;
- a client's unreleased product or logo without permission;
- invented metrics;
- a stock photo presented as your user;
- "users loved it" without evidence.

If the work is under NDA, describe the method and the type of problem, and use a reconstructed example with a clear label: "Reconstructed to protect client confidentiality; numbers are illustrative."

### Step 7 — Report results with limits

Separate:

- **Output:** what you made.
- **Outcome:** what changed.
- **Evidence strength:** how sure you are.

Example: "Output: a revised checkout with an early fee estimate. Outcome: in a five-person re-test, fee-related confusion fell from 3/5 to 1/5. Limitation: small sample, prototype payments, no controlled experiment; the result is consistent with the change but not proof of causation."

This is more credible than "increased conversion by 40%" with no denominator.

### Step 8 — Write the lessons and the next step

Answer:

- What would you do differently?
- What did you learn about the user, the process or yourself?
- What would you test next?

A lesson such as "I should have tested the fee placement before polishing the payment screen" is specific and useful. "I learned to empathise with users" is a slogan.

### Step 9 — Edit for the reader

- Lead with the summary; do not make readers hunt.
- Use short paragraphs and descriptive headings.
- Put the most important image near the top.
- Cut any sentence that only says "I researched and designed".
- Read it aloud; if you stumble, rewrite.
- Ask one person to summarise it back to you. If they cannot, the structure is unclear.

## 6. Worked example (I do)

A learner, Bola, wrote this first draft:

> "I designed a beautiful savings app. I did user research, wireframes, and a high-fidelity prototype. The app has a dashboard, goals, and notifications. I used Figma and auto layout. The colour palette is green and white. Users said it was easy to use."

It is a list of outputs, with no problem and no evidence. She rewrites:

> **Summary:** For first-time savers using a fictional micro-savings app, the goal screen asked for a target amount without showing what a realistic weekly saving looked like, so 4 of 5 test participants set amounts they could not sustain. I added a weekly-equivalent preview and a suggested range; in a re-test, 4 of 5 set amounts within their stated budget, and 2 said the preview changed their choice.
>
> **Context:** A course project; I was the designer and researcher; a peer built the prototype.
>
> **Problem:** Users wanted to save but did not know how much to commit. The screen asked for a total, not a habit.
>
> **Decision:** I rejected adding more goal templates (more choice) and instead showed the weekly equivalent next to the amount field. I kept the free-entry field because users had different incomes.
>
> **Trade-off:** The preview adds visual density. At 320px it wraps below the field, which is acceptable but not elegant.
>
> **Evidence:** 5 participants before, 5 after; same task; counts reported; no controlled test.
>
> **Lesson:** The problem was not motivation; it was arithmetic under uncertainty. Next time I would test the preview with users on very low or irregular incomes before building it.

**Why the rewrite works:** it names a specific user, a specific problem, a decision, a rejected alternative, a trade-off, evidence and a limitation. The screens support the argument instead of replacing it.

## 7. We do it together

Using your project:

1. Write the one-line summary in the format from Step 1.
2. Write the problem statement with who, what, barrier and why.
3. Choose one decision and write why you made it and what you rejected.
4. Choose one trade-off and name what you gave up.
5. Write one result with a count, a denominator and a limitation.

**Hint:** if you cannot find a rejected option, you probably did not make a decision; you followed a default. Look at your early sketches for the alternative.

## 8. Your turn (You do)

Write a 900–1,200 word case study with:

- a one-line summary;
- context and your specific role;
- a precise problem statement;
- two or three decision points with rationale;
- one rejected alternative and one trade-off;
- 4–6 evidence images with captions;
- results with counts, denominators and limitations;
- lessons and next steps;
- a 150-word short version for a portfolio card.

Anonymise all participants. Label course work as course work. Do not invent metrics or client names.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** What should a case study lead with?
- A. A one-line summary stating the problem, the action taken and the result, placed before any images.
- B. A gallery of polished final screens, arranged to show the visual range of the finished product.
- C. A short list of the design tools used, with a note on how long you have used each.
- D. A short personal biography describing your education, design influences and how you became interested in the field.

**Q2.** Which is a precise problem statement?
- A. New users abandon at payment because the delivery fee appears late, so the total feels untrustworthy.
- B. The interface looks outdated next to competitors, so the visual style should be refreshed before launch.
- C. Users want a better experience overall, and the product should feel more modern and more welcoming.
- D. The app needs more colour and personality, because the current palette feels flat on most screens.

**Q3.** Why show a rejected alternative?
- A. To demonstrate the judgement behind the decision by explaining what you considered and why you set it aside.
- B. To fill space in the case study so the document reaches the required length without extra research.
- C. To criticise the teammates who preferred the other option, showing that your own judgement was the correct one.
- D. To show that you can use more design tools than the other candidates applying for the same role.

**Q4.** What is the difference between an output and an outcome?
- A. An output is what you made, such as a prototype; an outcome is what changed for users or the business.
- B. An output is longer and more detailed, while an outcome is a brief note that summarises the same work.
- C. An outcome is a screenshot of the finished screen, while an output is the written report that explains it.
- D. There is no meaningful difference, because both terms describe the same deliverables listed in the final handoff.

**Q5.** How should a small-sample result be reported?
- A. Users loved the new flow, and several said they would happily recommend it to friends and colleagues.
- B. Conversion increased by 40%, proving that the redesign worked and should now be rolled out to everyone.
- C. The sample was small but encouraging, so the detailed numbers can safely be left out of the summary.
- D. Three of five participants improved, and the result comes from a small sample with no controlled test.

**Q6.** A client project is under NDA. What is acceptable?
- A. Publish the full project, because the work is yours and the client's confidentiality agreement covers only their staff.
- B. Publish a reconstructed example with a clear label, or describe the method without any confidential client detail.
- C. Invent a different client name and change the logo, so the work can be shown without identifying anyone.
- D. Publish the internal metrics only, since figures reveal far less about the client than screenshots or names would.

**Q7.** What makes a lesson useful?
- A. It is inspirational and reminds the reader why design work matters in a difficult and fast-moving industry.
- B. It mentions a famous company, which shows that the method has already been validated at a large scale.
- C. It is short enough to fit in one word, so readers remember it easily after finishing the case study.
- D. It is specific about what you would do differently and about what you would test next time.

**Q8.** Why include a short version?
- A. Recruiters never read long text, so the short version is the only part of the case study anyone will see.
- B. It replaces the long version entirely, which becomes unnecessary once the key points have been compressed into a card.
- C. Portfolio cards and introductions need a scannable summary that leads interested readers to the full case study.
- D. It is required by Figma when a project is published, and the portfolio cannot go live without one.

**Q9.** A learner's case study opens with 'I designed a beautiful banking app' and then shows final screens. What is the most important missing element?
- A. More decorative mockup frames, so the finished screens look consistent with a polished case study.
- B. A longer list of software tools, including the exact versions used for each screen and each prototype.
- C. The user problem, evidence, decisions and outcomes that together explain why the design exists at all.
- D. A brighter colour palette, so the banking app feels more modern than the current screens do.

**Q10.** A case study reports 'users loved the new design' after five informal conversations, with no quotes or counts. What is the problem?
- A. The case study is too short, and a longer narrative would make the same point more convincingly.
- B. Five conversations are never allowed in a portfolio, so the evidence should have come from a survey.
- C. A small, undocumented sample is being turned into an unsupported claim that users loved the design.
- D. The design should have used more colours, since visual appeal is what makes users respond well.

## 10. Practical task and pass criteria

**Task.** Submit the full case study and the 150-word short version.

**Pass criteria — all must be met:**

- [ ] One-line summary includes problem, action and result.
- [ ] Context states the product, user and your specific role.
- [ ] Problem statement includes who, what, barrier and why it matters.
- [ ] At least two decision points include rationale.
- [ ] At least one rejected alternative and one trade-off are explained.
- [ ] 4–6 images carry evidence and have captions.
- [ ] Results include counts, denominators and limitations.
- [ ] Lessons are specific and include a next step.
- [ ] Participants and clients are anonymised or permission is documented.
- [ ] Course work is labelled as course work; no invented metrics.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Starting with the final screen | It looks impressive | Start with the problem and the summary. |
| A timeline of activities | It is easy to write | Replace with decision points. |
| No rejected option | Decisions feel obvious in hindsight | Show the alternative you considered. |
| Claiming causation from five users | Portfolio pressure | Say "consistent with" and state limits. |
| Real client data | Convenience | Anonymise or reconstruct with a label. |
| Every screen included | Wanting to show work | Choose evidence, not volume. |
| Generic lessons | Filler | Name a specific change you would make. |
| No short version | Overlooking scanning | Write the 150-word card. |

**Retry variant.** Rewrite the same project as a **one-page decision memo** for a product manager: problem, three options, recommendation, evidence, risk, decision needed. No images. This forces you to separate reasoning from visual presentation.

## 12. Proof artifact for your portfolio

The case study itself is the artifact. Keep the long version, the short version, the images and a permissions note. Add it to your portfolio as one of three core projects.

## 13. Low-data and low-cost path

- Write in plain text or a free document; no portfolio platform is required.
- Compress images to under 200 KB each.
- Use screenshots instead of video.
- If you cannot publish client work, write a method-focused study with a reconstructed example.
- Skip the video if data is tight; the structure above is complete.

## 14. Watch and read more

**Recommended video:** *How to create your first UX case study (2026 beginner tutorial)* by Aliena Cai (2026, 20 min 41 s) — `https://www.youtube.com/watch?v=044MI9uH1c4`. A beginner walkthrough of case-study structure. Metadata checked 2026-10-30; embedded playback was verified in Chrome on 2026-10-30. Use it for structure, not as a template to copy.

**Read:**

- Nielsen Norman Group, *Case studies* — `https://www.nngroup.com/videos/ux-design-portfolio-case-study/`. What hiring managers look for.
- Nielsen Norman Group, *Case Studies* — `https://www.nngroup.com/topic/case-studies/`. A curated hub of case-study articles and videos; choose one example with evidence, not a gallery of screens.
- W3C WAI, *WCAG 2.2 Quick Reference* — `https://www.w3.org/WAI/WCAG22/quickref/`. Accessibility claims in a case study should be checkable.

## 15. What comes next

Stop 7.2 is about the people who will build and shape the product with you: developers and product managers. The case study gives you evidence; the next stop gives you the communication skills to use it in a team.