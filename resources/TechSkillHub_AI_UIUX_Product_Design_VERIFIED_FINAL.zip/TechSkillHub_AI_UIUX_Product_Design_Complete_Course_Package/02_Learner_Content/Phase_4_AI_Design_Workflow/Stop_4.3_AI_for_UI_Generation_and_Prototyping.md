---
stop_id: 4.3
title: AI for UI Generation and Prototyping
phase: 4
prerequisites: Stop 4.2
outcome: Write a constrained prompt that generates a usable UI draft, import it into a design tool, and review it against tokens, states and accessibility before accepting any of it.
time: 80-100 minutes
artifact: A prompt pack, three generated drafts, a review sheet with at least ten checks, and one corrected screen that meets your tokens and accessibility rules.
---

# Stop 4.3 — AI for UI Generation and Prototyping

> **Phase 4 · The AI design workflow** · Prerequisite: Stop 4.2 · Suggested session: 80–100 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Write a UI prompt that specifies user, task, content, tokens, states and constraints.
2. Generate three drafts and compare them against criteria.
3. Import or recreate a draft in Figma without inheriting its defects.
4. Review generated UI for accessibility, consistency, content and flow fit.
5. Decide what to keep, what to fix and what to reject.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Prompt-to-UI tool** | A tool that generates interface screens from a text description. |
| **Generation** | The first output from an AI tool. |
| **Import** | Bringing generated output into a design file, often as an image or editable layers. |
| **Draft** | An early version, not a finished design. |
| **Constraint** | A requirement the output must satisfy. |
| **Token** | A named design value the output should use. |
| **State coverage** | Whether the generated design includes loading, empty, error and success. |
| **Fidelity** | How closely a draft resembles the final product. |
| **Hallucinated UI** | Components or content the AI invents that do not fit the product. |
| **Attribution** | Knowing which tool produced which output, and under what licence. |
| **Licence** | The legal terms for using generated assets. |
| **Vendor lock-in** | Dependence on a tool that makes leaving costly. |
| **Review sheet** | A structured checklist for judging generated output. |
| **Recreate vs import** | Rebuilding the layout in your system versus importing the AI's layers. |

## 3. Why this matters

AI can produce a screen in seconds. It cannot know your product's rules, your users' constraints, your accessibility requirements or your design tokens unless you tell it — and even then, it will approximate. The output is a **draft**, not a design decision.

The professional skill is not prompting for prettier output. It is **constraining the input and auditing the output**. A generated screen that ignores your spacing scale, uses inaccessible grey text and invents a "Scan QR" feature is worse than a blank frame, because it looks finished.

> **Everyday example.** A printer can produce a hundred posters in a minute. If the file has the wrong phone number, you have a hundred wrong posters. Speed multiplies whatever is in the input.

## 4. Before you start

- Have your design tokens, component names and one selected flow.
- Choose a tool. Options change frequently; examples include AI features inside Figma, v0, Lovable, Bolt, Uizard, or a general assistant that writes HTML/CSS. Use a free tier.
- Read the tool's terms on data use and ownership. Do not upload client-confidential material.
- Create a folder `02_Exercises/4.3_generated/` for outputs and screenshots.

> **Cost and licence warning.** Free tiers, model names and export rights change. This course does not endorse a specific tool, and no payment is required. If a tool asks for a card, stop and use the recreation path in section 13.

## 5. Teaching, step by step

### Step 1 — Write the constraint stack

A strong UI prompt has seven layers:

1. **User and context:** who, where, on what device, with what constraints.
2. **Task:** the one job the screen supports.
3. **Content:** the real labels and data, not filler Latin text.
4. **Structure:** regions and hierarchy.
5. **Tokens:** colours, type sizes, spacing, radius.
6. **States:** which states to show.
7. **Rules:** accessibility, language, what not to invent.

Example:

> Design a mobile confirmation screen for a first-time user sending ₦25,000 to a new recipient in Nigeria, on a 393 × 852 Android phone with a slow connection.
> Task: let the user verify the recipient and amount before an irreversible transfer.
> Content: title "Confirm transfer"; amount "₦25,000"; recipient "Adaeze O."; bank "Kudi Bank"; account "012 345 6789"; warning "This cannot be reversed"; primary button "Send ₦25,000"; secondary "Cancel".
> Structure: header with back; amount first; recipient block; warning directly above the button; sticky footer.
> Tokens: primary #1D4ED8, text #111827, secondary text #4B5563, background #FFFFFF, radius 12, spacing 4/8/12/16/24, body 16, amount 40 bold.
> States: default and error (name could not be verified).
> Rules: WCAG AA contrast, 44 px touch targets, visible labels, no icons without text labels, do not invent features, use sentence case, no stock photos.

The prompt is long because the constraint is the work. A short prompt produces a generic screen.

### Step 2 — Generate three drafts with different emphases

Ask for:

- **Draft A:** maximum clarity, minimal decoration.
- **Draft B:** strong hierarchy, larger type, more whitespace.
- **Draft C:** compact, information-dense for experienced users.

Then compare. The point is not to pick the prettiest; it is to see which trade-off fits the evidence. First-time users usually need clarity, not density.

### Step 3 — Review before importing

Use a ten-point review sheet:

| # | Check | Question |
|---|---|---|
| 1 | Task fit | Does the screen support the stated task, or add unrelated content? |
| 2 | Hierarchy | Is the most important fact the most prominent? |
| 3 | Tokens | Are the colours, type and spacing from your system? |
| 4 | Contrast | Does every text pair meet 4.5:1 (or 3:1 for large text)? |
| 5 | Target size | Are interactive elements at least 44 × 44 px? |
| 6 | Labels | Are fields labelled persistently, not by placeholder? |
| 7 | States | Are error/loading/success states present or specified? |
| 8 | Content | Is the copy real, plain and free of invented claims? |
| 9 | Consistency | Do components match your library? |
| 10 | Invented features | Did the tool add anything the product does not have? |

Score each draft, note the failures, and choose the one with the fewest **structural** problems. Cosmetic issues are easy to fix; a wrong structure is not.

### Step 4 — Import, then rebuild

You have three options:

1. **Screenshot as reference:** paste the draft beside your frame and rebuild it with your components. Slowest, highest quality, best for learning.
2. **Import editable layers:** if the tool exports to Figma, import and then replace its components with yours. Watch for hidden absolute positioning and unnamed layers.
3. **Use generated HTML/CSS:** useful for Stop 5.2, but review the code before shipping.

For this stop, rebuild at least one draft by hand. It teaches you what the AI approximated and where your system is stronger.

### Step 5 — Fix the five common generated defects

| Defect | What it looks like | Fix |
|---|---|---|
| **Generic style** | Centred hero, purple gradient, rounded cards everywhere | Apply your tokens and hierarchy; remove decoration that does not serve the task. |
| **Inaccessible text** | Light grey 12 px labels | Darken, enlarge, and measure contrast. |
| **Placeholder labels** | "Enter amount" inside the field only | Add persistent labels above fields. |
| **Invented features** | "Scan QR", "Split payment", "Invite friends" | Remove unless in scope; log the removal. |
| **Missing states** | Only the success screen | Add loading, error and empty states. |

### Step 6 — Check the content, not just the layout

AI-generated copy often sounds plausible and says nothing. Look for:

- vague verbs ("Manage your account");
- invented statistics ("Trusted by 10,000 users");
- promises the product cannot keep ("Instant, fee-free transfers");
- inconsistent tone;
- English that does not fit the local context.

Replace with specific, honest copy. You will go deeper in Stop 4.5.

### Step 7 — Record provenance and licences

For each draft, record:

- tool and version;
- date;
- prompt;
- output file;
- licence or terms link;
- what you changed.

If you cannot establish that you may use an asset commercially, do not put it in a portfolio. Generated images and icons may carry unclear rights; your own shapes and licensed icons are safer.

### Step 8 — Measure the speed honestly

Record:

- time to first usable draft;
- time to fix to your standard;
- defects found per draft;
- whether the AI saved time overall.

Sometimes it does; sometimes fixing the output takes longer than starting from your components. An honest measurement is more valuable than a claim that AI "10x'd" your work.

## 6. Worked example (I do)

**Prompt:** the constraint stack above.

**Draft A output:** a clean screen with the amount at 32 px, recipient name at 16 px, a grey "Confirm" button, and a "Scan QR" icon in the header. The warning is below the button.

**Review:**

1. Task fit: mostly, but the QR icon is unrelated.
2. Hierarchy: amount at 32 px is weaker than the title at 28 px — wrong order.
3. Tokens: used #2563EB instead of #1D4ED8; spacing at 20/28 instead of the scale.
4. Contrast: secondary text at #9CA3AF on white = 2.6:1 — fail.
5. Target size: the back arrow is 24 × 24 — fail.
6. Labels: no fields on this screen; pass.
7. States: no error state — fail.
8. Content: "Confirm" is vague; should repeat the amount.
9. Consistency: button radius 8 instead of 12.
10. Invented features: QR scan — remove.

**Decision:** keep the overall structure (amount, recipient, warning, footer), rebuild with tokens, move the warning above the button, rename the button, remove the QR, add an error state.

**What I learned:** the AI was good at producing a plausible arrangement and bad at hierarchy, tokens and accessibility. The arrangement saved me maybe ten minutes; the fixes took twenty. Net time saving was small, but the first draft helped me see an alternative arrangement I had not considered.

**Honest conclusion:** "AI is useful for exploring arrangements, not for producing finished screens. My system produces a better result faster once the flow is settled."

## 7. We do it together

1. Write your constraint stack for one screen.
2. Generate three drafts with different emphases.
3. Fill the ten-point review sheet for each.
4. Choose the draft with the fewest structural problems.
5. Rebuild it in Figma with your components and tokens.
6. Add the missing error and loading states.
7. Replace all generated copy with specific, honest copy.
8. Record provenance and licence for the tool.
9. Measure time to draft, time to fix, and defects found.
10. Write a 150-word verdict on whether the tool helped.

## 8. Your turn (You do)

**Independent task.** Produce a **generated-UI review pack**.

Submit:

1. The constraint-stack prompt.
2. Three generated drafts (screenshots or files).
3. A completed ten-point review sheet for each draft.
4. A list of every invented feature and every token violation.
5. One corrected screen, rebuilt with your components, including at least two states.
6. A provenance record: tool, date, licence link, what changed.
7. A time-and-defect measurement.
8. A 200-word verdict: what the tool did well, what it got wrong, and whether you would use it again for this kind of task.

**Rules:** no paid tool required; no client-confidential data in prompts; no generated asset in the final screen unless its licence is clear. If you cannot access a generation tool, recreate a draft manually from a written description and state the substitution.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** What is the main purpose of a constraint stack in a UI prompt?
- A. To make the prompt longer, because detailed prompts are assumed to produce better screens.
- B. To force the assistant to use one specific model with predictable visual output.
- C. To specify user, task, content, tokens, states and rules so output is usable.
- D. To remove the need to review the output, since constraints prevent every defect.

**Q2.** Why generate three drafts with different emphases?
- A. To avoid relying on one draft, since a single version is never valid.
- B. To increase the tool's cost per screen and justify a paid subscription later.
- C. To compare trade-offs instead of accepting the first plausible screen the tool produces.
- D. To leave the choice open until someone else reviews all three drafts.

**Q3.** A generated screen uses #9CA3AF secondary text at 12 px on white. What is the issue?
- A. The grey is too dark against white, making the text heavier than the heading.
- B. It fails contrast for normal text, measuring about 2.6:1 against the 4.5:1 minimum.
- C. It uses the wrong font family, which makes the secondary text look inconsistent.
- D. It is fine, because grey text is always accessible on a white background.

**Q4.** What should you do with an invented "Scan QR" feature in a draft?
- A. Remove it unless it is in scope, and log the removal for the decision record.
- B. Keep it, because a useful-looking feature adds value even when it was never planned.
- C. Add it to the backlog automatically so the team can consider it next sprint.
- D. Ask the AI to animate it, then judge whether the motion suits the screen.

**Q5.** Why rebuild at least one draft by hand?
- A. Because importing generated layers is forbidden by most design tool licences.
- B. Because rebuilding is faster than importing and reduces the time spent on review.
- C. Because rebuilding reveals what the AI approximated and applies your system properly.
- D. Because the rebuild teaches the model your tokens and improves its future output.

**Q6.** What does provenance record?
- A. Tool, date, prompt, output file, licence and the changes you made.
- B. Only the tool name, since the other details can be recovered from the file.
- C. The designer's mood, so reviewers understand the intent behind the screen.
- D. The file size and export format, so storage requirements stay predictable.

**Q7.** A generated headline says "Trusted by 10,000 users" with no data. What is wrong?
- A. It is too long for a headline and competes with the primary button.
- B. It is an invented claim that must be removed or properly substantiated.
- C. It uses the wrong font weight, so the number does not read as emphasis.
- D. It is fine, because the assistant sourced the figure from its training data.

**Q8.** How should you measure whether AI saved time?
- A. Time to the first usable draft only, since that is what the tool accelerates.
- B. The number of prompts sent, since more prompts indicate more exploration.
- C. Time to draft plus time to fix to standard, plus defects found.
- D. The tool's published marketing claims about average speed improvements for teams.

**Q9.** An AI-generated draft looks polished but has no empty, loading or error states. What should the learner do before presenting it?
- A. Present it as finished, because the default state is what most reviewers will see.
- B. Add more gradients and illustration so the missing states attract less attention.
- C. Add and review the missing states, then check the draft against real constraints.
- D. Delete the project and start from a blank file with the states designed first.

**Q10.** A generated screen uses 12 px grey text with a measured contrast of 2.6:1 on white. What is the specific failure?
- A. The text is too large for the screen and crowds the neighbouring content.
- B. The screen uses too many columns, so the reading order is unclear.
- C. Normal-sized text falls below the 4.5:1 WCAG AA contrast requirement.
- D. The text is not written in sentence case, which weakens the tone.

## 10. Practical task and pass criteria

**Task.** Submit the eight-part generated-UI review pack.

**Pass criteria — all must be met:**

- [ ] A constraint stack covering all seven layers.
- [ ] Three drafts with different emphases.
- [ ] Ten-point review completed for each.
- [ ] Invented features and token violations listed.
- [ ] One corrected screen with at least two states.
- [ ] Provenance and licence recorded.
- [ ] Time and defect measurement included.
- [ ] Verdict is specific and honest.
- [ ] No unlicensed asset or fabricated claim.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Short, vague prompt | It feels faster | Use the seven-layer stack. |
| Accepting the first draft | It looks good | Generate three; compare structurally. |
| Importing without review | Import feels like progress | Review before and after import. |
| Keeping invented features | They seem useful | Remove and log. |
| Generated copy left unchanged | It reads smoothly | Replace with specific, honest copy. |
| No licence record | It feels bureaucratic | Record tool, terms and assets. |
| Claiming huge time savings | It is exciting | Measure draft + fix time. |

**Retry variant.** Generate a **desktop dashboard** instead of a mobile screen, with a table, filters and a status column. Review it for density, data-table accessibility and responsive behaviour. Submit three drafts, the review, one corrected screen and a 150-word note on which defect was hardest to see.

## 12. Proof artifact for your portfolio

**Artifact:** `Generated-UI-Review` — stored in `03_Projects/<project>/ai-workflow`.

This is strong evidence of judgment: you show the raw output, the defects and the corrected result. Do not present the raw generation as your design.

## 13. Low-data and low-cost path

- Use a free AI chat to describe layouts, then rebuild manually in Figma; no generation tool needed.
- Avoid image generation, which is data-heavy and licence-ambiguous.
- Recreate one draft by hand from a written description and state the substitution.
- The video is optional and 1:27; the review sheet and constraint stack are the lesson.

## 14. Watch and read more

**Recommended video (optional, 1:27:43):** *Designing With AI: Claude, Codex, Figma | Full Guide* — UI Collective. `https://www.youtube.com/watch?v=j_ZPV10bu54`. Verified available on 2026-10-30. It is long and tool-specific; interfaces and pricing change, so treat it as a demonstration of workflow, not a current feature list.

**Read (verified 2026-10-30):**

- Microsoft, *Guidelines for Human-AI Interaction* — `https://www.microsoft.com/en-us/haxtoolkit/ai-guidelines/`. Evidence-based practices for AI features, including feedback, error handling and user control.
- W3C, *WCAG 2.2* — `https://www.w3.org/TR/WCAG22/`. The accessibility checks you apply to generated output.

## 15. What comes next

Stop 4.4 turns AI into a critic: heuristic evaluation, accessibility checks, consistency checks and a structured "red team" of your own design. The output is only useful if you can judge it.