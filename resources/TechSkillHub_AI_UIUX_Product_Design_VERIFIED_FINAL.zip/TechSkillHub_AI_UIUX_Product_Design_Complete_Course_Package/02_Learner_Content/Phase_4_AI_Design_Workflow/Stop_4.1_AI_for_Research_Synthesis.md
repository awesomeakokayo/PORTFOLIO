---
stop_id: 4.1
title: AI for Research Synthesis
phase: 4
prerequisites: Phase 3 gate passed
outcome: Use an AI assistant to cluster interview notes into themes while keeping every theme traceable to a real quote, and catch invented or distorted evidence.
time: 70-90 minutes
artifact: An AI-assisted synthesis with a prompt log, a theme table, a quote-to-theme traceability matrix and a verification note listing what the AI got wrong.
---

# Stop 4.1 — AI for Research Synthesis

> **Phase 4 · The AI design workflow** · Prerequisite: Phase 3 gate · Suggested session: 70–90 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Prepare interview notes for AI safely: anonymised, chunked and labelled by participant.
2. Write a synthesis prompt that requires evidence and refuses invention.
3. Build a traceability matrix linking every theme to a real quote and participant.
4. Spot fabricated, merged or over-generalised themes.
5. Decide what the AI may do and what a human must do.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Synthesis** | Turning raw notes into patterns, themes and insights. |
| **Theme** | A repeated idea across participants, supported by evidence. |
| **Code** | A short label attached to a piece of evidence. |
| **Affinity mapping** | Grouping similar observations into clusters. |
| **Traceability** | The ability to follow a claim back to its source. |
| **Quote** | A participant's actual words, reproduced accurately. |
| **Paraphrase** | A restatement in your own words, which must still match the source. |
| **Over-generalisation** | A claim that goes beyond what the evidence supports. |
| **Confabulation** | An AI producing plausible but invented details. |
| **Prompt log** | A record of the prompts used, the outputs and your edits. |
| **Chunking** | Splitting long notes into smaller sections the model can handle. |
| **PII** | Personally identifiable information: names, phone numbers, addresses, IDs. |
| **Synthetic data** | Data generated to imitate real data; useful for practice, never for claims about real users. |
| **Audit trail** | The record that lets someone check how a conclusion was reached. |

## 3. Why this matters

Synthesis is slow. Twenty interviews produce hours of notes, and the temptation to paste everything into an AI and accept the summary is strong. The summary will look clean, confident and organised. It may also invent a theme, merge two participants into one, or turn "two people mentioned fees" into "users are price-sensitive".

The professional use of AI here is **clustering assistance**, not **evidence creation**. The AI can suggest groups. You check every group against the raw notes. The traceability matrix is what separates a useful synthesis from a plausible fiction.

> **Everyday example.** A market trader asks an assistant to sort a basket of receipts into categories. The assistant can sort quickly, but if it invents a receipt or mixes two customers' purchases, the accounts are wrong. You still check the totals against the actual receipts.

## 4. Before you start

- Use your Stop 1.2 notes, or the notes from your Phase 1 gate research. You need at least five participants for a meaningful synthesis. If you have fewer, label the output "practice synthesis" and do not generalise.
- Anonymise first: replace names with P1, P2; remove locations, employers, phone numbers and amounts that could identify someone.
- Create a table with columns: `Participant | Raw quote | Context | My code`.
- Decide your AI tool and check its data controls. If you are unsure, use invented practice notes for the prompt and do the real synthesis manually.

## 5. Teaching, step by step

### Step 1 — Prepare the data before the prompt

Good synthesis input has:

- one participant per section;
- short quotes with context;
- no identifying data;
- a note of what the interviewer asked;
- a marker for uncertainty ("participant seemed unsure").

Bad input: a single 8,000-word blob with names, half-sentences and no attribution. The AI will fill the gaps to make it coherent — which is exactly what you do not want.

### Step 2 — Write a synthesis prompt with evidence rules

Use this structure:

1. **Role:** "You are assisting with qualitative synthesis. You do not invent evidence."
2. **Input:** the anonymised notes, clearly delimited.
3. **Task:** "Cluster the observations into 3–6 themes. For each theme, list the supporting quotes with participant IDs."
4. **Constraint:** "Use only the text provided. If a theme has fewer than two participants, label it 'single-participant observation'. Do not infer demographics, causes or frequencies."
5. **Output format:** a table with theme, definition, participant IDs, quotes, counter-evidence.
6. **Check:** "List anything you were unsure about, and any quote you could not match exactly."

Full example:

> You are assisting with qualitative research synthesis. You must not invent, merge or paraphrase quotes. Below are anonymised notes from five interviews, separated by participant ID. Cluster the observations into 3–6 themes. For each theme, give: a plain-language definition; the participant IDs that support it; exact quotes copied from the notes; and any counter-evidence. If a theme appears in only one participant, label it "single-participant observation". Do not infer age, income, gender or location. Do not state frequencies as percentages. End with a list of uncertainties and any quote you could not match exactly. Use only the notes provided.

### Step 3 — Run it in chunks, not one giant paste

If the notes are long, synthesise in two stages:

1. **Per participant:** ask for a 5-bullet summary with exact quotes. Check each summary against that participant's notes.
2. **Across participants:** feed the verified summaries and ask for themes, with participant IDs.

Why chunk? Long inputs get truncated or summarised internally, and the model may lose attribution. Chunking also gives you checkpoints where you can catch errors before they propagate.

### Step 4 — Build the traceability matrix

For every theme the AI proposes, fill a row:

| Theme | Participant | Exact quote | Context | Supports or contradicts? | Verified? |
|---|---|---|---|---|---|
| Second-channel verification | P1 | "I called her to confirm the name" | Before sending ₦15,000 | Supports | Yes |
| Second-channel verification | P2 | "I sent a screenshot to my sister" | Before paying a new seller | Supports | Yes |
| Fee confusion | P3 | "I didn't know there was a charge until after" | Cash-out at an agent | Supports | Yes |
| Trust in photos | — | — | — | No evidence | No — rejected |

The last row is important. If the AI proposes "users want recipient photos" and no quote supports it, the row stays with "No evidence" and the theme is rejected. You now have a record of the rejection, which is more professional than silently deleting it.

### Step 5 — Hunt for the four synthesis errors

| Error | What it looks like | How to catch it |
|---|---|---|
| **Fabricated quote** | A quote that sounds right but is not in the notes | Search the exact phrase in your notes; if it is not there, reject it |
| **Merged participants** | "P1 and P2 both said…" when only P1 did | Check each participant ID separately |
| **Over-generalisation** | "Users want…" from two people | Rewrite with the sample: "2 of 5 participants…" |
| **Invented cause** | "Because the font is small, users distrust the app" | Ask what evidence links cause and effect; usually none |

Add a fifth: **theme inflation**. The AI produces six themes from three observations by splitting synonyms. Merge themes that describe the same behaviour.

### Step 6 — Check contradictions, not just support

A good synthesis reports where participants disagreed. Ask the AI explicitly:

> "List any observations that contradict each theme. If none, say 'no counter-evidence found in these notes'."

Then verify. Contradictions are often the most useful finding: they show the product serves different contexts.

### Step 7 — Write insights, not just themes

A theme is a pattern ("participants check the recipient through a second channel"). An insight explains what it means for design:

> "Because the in-app name display is not trusted alone, a confirmation step that repeats the name and amount may reduce duplicate transfers — but it will not eliminate the second-channel check, which may be a healthy trust behaviour. Test whether the check decreases only when confidence increases."

The AI can help draft insights, but you must own the causal claim and label it as an interpretation.

### Step 8 — Record the human decisions

End with a "Human review" section:

- Which AI suggestions were accepted, edited or rejected.
- Which quotes were verified word for word.
- Which themes were merged or split.
- What the AI could not know (context, tone, local meaning).
- What you would do differently next time.

This is the evidence of judgment that the course assesses. An AI-generated synthesis without this section is not a professional artifact.

## 6. Worked example (I do)

**Input:** five anonymised interview notes about sending money.

**AI output (excerpt):**

> Theme 1: Users do not trust bank apps. All participants said they verify transfers outside the app.
> Theme 2: Users want biometric confirmation.
> Theme 3: Fees are confusing.

**My check:**

- **Theme 1:** P1 called her mother; P2 sent a screenshot; P3 asked an agent; P4 said she trusts the app and did not check; P5 checked only for new recipients. The claim "all participants" is false, and "do not trust bank apps" over-generalises. Rewrite: "4 of 5 participants used a second channel when sending to a new recipient; P4 did not, and described the app's confirmation as sufficient."
- **Theme 2:** No participant mentioned biometrics. The AI inferred a solution. Reject. Note: "No evidence for biometrics; do not include."
- **Theme 3:** P3 mentioned a fee only after the transaction; P5 mentioned agent charges. That is two participants, not all. Rewrite: "2 of 5 participants were surprised by a fee that appeared after they had committed."

**What I kept:** the clustering instinct — verification, fees and trust are real groupings. **What I changed:** every quantifier, one fabricated solution and one over-generalisation.

**The insight I wrote:** "Verification is a social behaviour, not only an interface step. The design opportunity is to make the in-app confirmation trustworthy enough that users need fewer external checks, without removing the check for high-risk transfers."

**What the AI could not know:** that calling a mother before sending money is also a social courtesy, not only a trust signal. That interpretation came from the interview context, not the text.

## 7. We do it together

1. Anonymise your notes and split them by participant.
2. Write the synthesis prompt with evidence rules.
3. Run stage 1 per participant and check each summary.
4. Run stage 2 across participants.
5. Build the traceability matrix for every proposed theme.
6. Search each quote in the raw notes. Mark verified or rejected.
7. Ask for counter-evidence and verify it.
8. Rewrite every quantifier to match the sample.
9. Write 2–3 insights, each labelled as interpretation.
10. Write the human review section.

## 8. Your turn (You do)

**Independent task.** Produce an **AI-assisted synthesis pack** for your research.

Submit:

1. The anonymised input (or a description if confidentiality prevents sharing).
2. The exact prompts used, in order.
3. The AI's raw output, unedited.
4. A traceability matrix with every theme, participant, exact quote and verification status.
5. A list of at least **three** AI errors or weak claims you caught, with the correction.
6. Two or three insights, each labelled as interpretation and tied to evidence.
7. A counter-evidence section.
8. A 200-word human review: what the AI did well, what it got wrong, what only you could know.

**Rules:** no fabricated quotes; no percentages from five people; no demographic inferences; no uploading identifying data. If you have fewer than five participants, label the work "practice synthesis" and do not generalise.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** What is the safest role for AI in research synthesis?
- A. Clustering the notes into candidate themes that a human then checks against every quote.
- B. Generating findings directly from the project brief, so the team saves the reading time.
- C. Conducting the interviews itself and reporting what participants said about the product.
- D. Writing participant quotes that read naturally, then filling gaps the notes left open.

**Q2.** An AI says "all participants distrusted the app". What should you do first?
- A. Accept it, because the model has read every note and summarised them consistently.
- B. Check each participant's notes separately to verify whether the quantifier is true.
- C. Delete the whole theme, since one exaggerated word makes the entire grouping unusable.
- D. Add a percentage beside the claim so the strength of the finding is clearer.

**Q3.** What does a traceability matrix contain?
- A. Theme, participant, exact quote, context, whether it supports or contradicts, and verification status.
- B. Theme names only, kept short so the synthesis document stays easy to scan.
- C. The AI model version and date, so a reviewer can reproduce the same summary later.
- D. The list of interview questions, so a reviewer can see what each participant was asked.

**Q4.** Why chunk long notes before synthesis?
- A. Because the assistant cannot process long text at all and returns an empty answer.
- B. Because a longer output makes the synthesis look more thorough to reviewers.
- C. Because shorter sections contain fewer names, so anonymising can be skipped.
- D. Because long inputs get truncated or lose attribution, and chunks give checkpoints.

**Q5.** An AI proposes "users want biometric login" but no participant mentioned it. What is this?
- A. A fabricated solution presented as a finding, which you reject and record as unsupported.
- B. A valid insight, because it follows logically from the trust problems participants described.
- C. A useful counter-example showing where participants disagreed with the proposed theme.
- D. A sample limitation, since only five participants were interviewed about the product.

**Q6.** What is the difference between a theme and an insight?
- A. A theme is simply the longer version of an insight, written up in more detail.
- B. A theme is a pattern in the evidence; an insight interprets what it means for design.
- C. An insight is always a direct quote, while a theme is the label attached to it.
- D. There is no real difference, since both describe the same pattern from interviews.

**Q7.** Why record rejected themes?
- A. To make the document longer, since a fuller appendix looks more thorough.
- B. To satisfy the design tool, which requires a rejection row before export.
- C. To show the assistant where it went wrong, so its next answer improves.
- D. To preserve the audit trail and stop the same unsupported claim returning.

**Q8.** Which is a privacy failure?
- A. Pasting a transcript with a participant's phone number into a free chat tool.
- B. Using P1 and P2 as identifiers when quoting participants in the synthesis table.
- C. Storing the anonymised notes in a password-protected folder on the team drive.
- D. Removing an employer name from a quote before sending it for synthesis.

**Q9.** An AI summary says '8 out of 10 participants distrusted the app', but the learner only has six interview notes. What should they do first?
- A. Add four invented interviews so the sample matches the number the summary reports.
- B. Publish the 8/10 figure because a larger-sounding sample makes the finding persuasive.
- C. Reject the statistic, then check every claim against the six notes that actually exist.
- D. Ask the AI to explain its confidence, then quote that explanation in the report.

**Q10.** A themes table contains labels such as 'trust' and 'speed' but no quotes or participant IDs. What is missing?
- A. A more attractive colour scheme, so reviewers can tell the themes apart at a glance.
- B. More themes on the page, so the synthesis looks comprehensive rather than thin.
- C. Traceability from each theme back to specific evidence and participant IDs in the notes.
- D. A second AI summary, so the two outputs can be compared for agreement.

## 10. Practical task and pass criteria

**Task.** Submit the eight-part synthesis pack.

**Pass criteria — all must be met:**

- [ ] Input is anonymised, or the substitution is explained.
- [ ] Prompts and raw output are included.
- [ ] Every theme has a traceability row with a verified quote.
- [ ] At least three AI errors or weak claims are caught and corrected.
- [ ] Quantifiers match the sample size.
- [ ] Insights are labelled as interpretation.
- [ ] Counter-evidence is reported.
- [ ] Human review explains what only the researcher could know.
- [ ] No fabricated quote, participant or percentage.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| Pasting raw notes with names | Convenience | Anonymise first; use P1/P2. |
| Accepting a clean summary | It reads well | Verify every quote and participant. |
| Turning two mentions into "users want" | Pattern excitement | State the sample: "2 of 5". |
| Letting AI infer demographics | It fills gaps plausibly | Ban inference in the prompt; check output. |
| No counter-evidence | The theme feels strong | Ask explicitly and verify. |
| Themes that are really solutions | AI likes actionable output | Separate evidence from recommendation. |
| No prompt log | It feels like extra work | Save prompts and outputs as you go. |

**Retry variant.** Repeat the synthesis using **invented practice notes** that you write yourself, containing two deliberate contradictions and one single-participant observation. Ask the AI to synthesise, then audit it against your known ground truth. Submit the notes, the AI output, your audit and a 150-word note on which error was hardest to catch. This variant tests detection without risking real participant data.

## 12. Proof artifact for your portfolio

**Artifact:** `Synthesis-Pack-v1` — stored in `03_Projects/<project>/research/synthesis`.

Keep the raw output and your corrections. In a case study, the corrections are evidence of judgment, not embarrassment.

## 13. Low-data and low-cost path

- Use text-only notes and a free AI tier.
- If you cannot use AI, do the synthesis manually with sticky notes and still complete the traceability matrix; label the method.
- The video is optional and seven minutes; the evidence rules above are the lesson.
- Work offline by preparing notes first, then using a short online session for the prompt.

## 14. Watch and read more

**Recommended video (optional, 6:51):** *How to Use AI (ChatGPT) for UX Research Synthesis* — AI Design Professor. `https://www.youtube.com/watch?v=2V3NoUcLV_4`. Verified available on 2026-10-30. It demonstrates one workflow; the evidence and verification rules here are the course's own and should take precedence.

**Read (verified 2026-10-30):**

- Nielsen Norman Group, *Accelerating Research with AI* — `https://www.nngroup.com/articles/research-with-ai/`. Covers where AI helps in research and where a human must check the source; read the warnings about invented evidence.
- NIST, *AI Risk Management Framework* — `https://www.nist.gov/itl/ai-risk-management-framework`. See the "valid and reliable" characteristic; it maps directly to verifying AI synthesis.

## 15. What comes next

Stop 4.2 uses AI to generate flows, information architecture and edge cases — then teaches you to attack the output before it becomes a design.