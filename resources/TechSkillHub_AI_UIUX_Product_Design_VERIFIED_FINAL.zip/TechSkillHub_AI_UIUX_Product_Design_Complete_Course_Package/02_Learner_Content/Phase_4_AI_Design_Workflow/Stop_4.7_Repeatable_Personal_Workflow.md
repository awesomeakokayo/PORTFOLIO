---
stop_id: 4.7
title: Repeatable Personal Workflow
phase: 4
prerequisites: Stop 4.6
outcome: Document a repeatable AI-assisted workflow with a prompt library, decision log, verification gates and explicit rules for when not to use AI.
time: 70-90 minutes
artifact: A personal AI workflow document: five reusable prompts, a decision log template, a verification gate checklist and a "do not use AI" rule set.
---

# Stop 4.7 — Repeatable Personal Workflow

> **Phase 4 · The AI design workflow** · Prerequisite: Stop 4.6 · Suggested session: 70–90 minutes · Pass target: 80%.

## 1. What you will be able to do

By the end of this stop you can:

1. Describe your AI workflow in five stages, with a human decision at each.
2. Build a reusable prompt library with constraints and verification steps.
3. Keep a decision log that shows what AI contributed and what you overrode.
4. Set explicit rules for when not to use AI.
5. Measure whether the workflow improves speed and quality, honestly.

## 2. New words in plain English

| Term | What it means here |
|---|---|
| **Workflow** | A repeatable sequence of steps for doing a kind of work. |
| **Prompt library** | A set of saved, tested prompts for recurring tasks. |
| **Prompt template** | A prompt with placeholders you fill for each project. |
| **Decision log** | A record of decisions, alternatives and reasons. |
| **Verification gate** | A checkpoint where output must be checked before proceeding. |
| **Human in the loop** | A person who reviews and approves AI output. |
| **Override** | A deliberate human rejection or change of AI output. |
| **Automation bias** | The tendency to trust automated output more than we should. |
| **Provenance** | The record of where an output came from. |
| **Reproducibility** | The ability to repeat a process and get a comparable result. |
| **Quality gate** | A criterion that must be met before work moves on. |
| **Data classification** | Deciding what data is safe to share with a tool. |
| **Tool churn** | The rapid change of AI tools and features. |
| **Fallback** | What you do when the tool is unavailable or unsuitable. |

## 3. Why this matters

A one-off clever prompt is not a workflow. A workflow is what you do on a Tuesday when the tool changes, the client sends a 40-page brief, and you have four hours. It is the difference between "I used AI once" and "I can reliably deliver with AI without losing judgment".

The decision log is also a career asset. In an interview, "here is what the AI produced, here is what I rejected, and here is why" is far stronger than "I use AI to speed up my work". It shows judgment, which is the thing employers cannot easily automate.

> **Everyday example.** A taxi driver with a fixed routine — check fuel, check tyres, plan the route, confirm the fare — delivers reliably. A driver who improvises every morning eventually has a bad day. Your workflow is the routine.

## 4. Before you start

- Gather your prompts, outputs and corrections from Stops 4.1–4.6.
- Choose one real project to apply the workflow to.
- Decide your data rules: what you will never paste into a tool.

## 5. Teaching, step by step

### Step 1 — Map the five stages

A defensible AI design workflow:

1. **Frame:** define the problem and the evidence without AI. AI may help you restate, not invent.
2. **Diverge:** use AI to generate options, flows, copy or critique prompts.
3. **Select:** choose with criteria and evidence; record the choice.
4. **Verify:** check facts, accessibility, consistency and flow against sources and tests.
5. **Ship and log:** deliver, record provenance, and note what you would change.

AI appears in stages 2 and 3 as an assistant, and in stage 4 as a first-pass checker. It does not own stage 1 or the final decision in stage 5.

### Step 2 — Build a prompt library with five templates

Save five prompts you will actually reuse:

1. **Tutor prompt** (Stop 0.4): explain a concept at beginner level with a check question.
2. **Synthesis prompt** (Stop 4.1): cluster evidence with quotes and no invention.
3. **Flow prompt** (Stop 4.2): three structurally different flows plus edge cases.
4. **Critique prompt** (Stop 4.4): heuristic, accessibility and red-team passes.
5. **Copy prompt** (Stop 4.5): five variants with tone, length and claim constraints.

Each template should include:

- role and context;
- task;
- constraints;
- output format;
- verification instruction ("list uncertainties", "cite sources", "say if not visible");
- a "do not" list.

Store them in one document with a version and a last-tested date.

### Step 3 — Design the decision log

Use a table:

| Date | Stage | AI output summary | Decision | Reason | Evidence | Human override? |
|---|---|---|---|---|---|---|
| 2026-11-12 | Diverge | Three flows | Selected hybrid B+C | B fits evidence; C solves unknown outcome | Interviews P1–P5 | Yes — removed QR |
| 2026-11-12 | Verify | Claimed 4.8:1 contrast | Rejected | Measured 3.1:1 | WebAIM | Yes |

The log should be short enough to maintain daily. One row per meaningful decision, not per prompt.

### Step 4 — Put verification gates in the workflow

At minimum:

- **Gate 1: Evidence.** No claim enters the design without a source or a "fictional" label.
- **Gate 2: Accessibility.** No screen proceeds without contrast, target size, labels and focus checks.
- **Gate 3: Flow.** No flow proceeds without loading, error, empty and success states.
- **Gate 4: Consistency.** No screen proceeds with off-system components or tokens.
- **Gate 5: Provenance.** No output is used without a record of the tool, date and edits.

A gate is binary: pass or rework. "Mostly fine" is not a gate.

### Step 5 — Write the "do not use AI" rules

AI is the wrong tool when:

- the task requires **real user contact** (interviews, usability tests);
- the output would be **presented as fact** without a verifiable source;
- the data is **confidential or identifying** and the tool's terms are unclear;
- the decision has **legal, safety or ethical consequences** that require accountable judgment;
- you cannot **explain or verify** the output;
- the task is **learning a fundamental** and the struggle is the point;
- the tool's **licence** for the output is unclear and the work is commercial.

Write these as rules with a fallback for each. "If I cannot verify a claim, I remove it or label it fictional" is a rule; "be careful" is not.

### Step 6 — Set data rules

Classify data:

| Class | Examples | Rule |
|---|---|---|
| Public | Published docs, public screens | May use with normal care |
| Internal | Drafts, internal notes | Use only with an approved tool and no confidential detail |
| Confidential | Client strategy, unreleased work | Do not paste into consumer AI tools |
| Personal | Names, phone numbers, addresses, IDs | Never paste; anonymise first |

If you are unsure, treat it as confidential. Record the classification in your workflow document.

### Step 7 — Measure honestly

Track:

- time per stage with and without AI;
- number of outputs accepted, edited, rejected;
- defects found in verification;
- rework caused by AI errors;
- quality against the rubric.

Do not claim a multiplier without measurement. A realistic entry: "Drafting three flows took 12 minutes with AI versus 40 minutes manually; fixing invented features took 15 minutes, so net saving was 13 minutes and one idea I would not have considered."

### Step 8 — Plan for tool churn

AI tools change monthly. Keep the workflow portable:

- store prompts in plain text, not inside one tool;
- keep outputs and decisions in your own files;
- avoid depending on a single vendor's export;
- re-test prompts when a model changes;
- keep a manual fallback for every AI step.

The principles — evidence, verification, judgment — outlive the tools.

## 6. Worked example (I do)

**My workflow, in one page:**

1. **Frame:** I write the problem brief and gather evidence. No AI in the first draft.
2. **Diverge:** I use the flow prompt to generate three structures and the critique prompt to attack the leading one.
3. **Select:** I score against evidence and constraints, and log the choice.
4. **Verify:** I run the evidence, accessibility, flow and consistency gates. I fix what fails and re-check.
5. **Ship and log:** I record provenance and a one-paragraph reflection.

**Prompt library (excerpt):**

> **Flow prompt v2** — "Generate three user flows for [task] for [user] under [constraints]. Each must use a different structure: single-screen, wizard, conversational. For each, list steps, required data, failure points and trade-offs. Do not assume features we do not have: [list]. Mark any step you are unsure about."

**Decision log (excerpt):**

| Date | Stage | Output | Decision | Reason |
|---|---|---|---|---|
| 11 Nov | Diverge | QR scan step | Rejected | Not in product scope |
| 11 Nov | Verify | "All users distrust banks" | Rewritten | 4 of 5, not all |
| 12 Nov | Verify | Contrast 4.8:1 claim | Rejected | Measured 3.1:1 |

**Do-not-use rules:** no real transcripts in free tools; no AI-generated user quotes; no unverified statistics; no AI in usability sessions; no AI for the final accessibility sign-off.

**Measurement:** 12 minutes to three flows, 15 minutes to fix, 13 minutes net saving; one useful alternative structure; two invented features removed.

**What I would change:** I would run the accessibility gate before the critique pass, because the critique spent time on visual issues that the gate would have caught faster.

## 7. We do it together

1. Write your five-stage workflow in one page.
2. Save five prompt templates with constraints and verification instructions.
3. Create the decision log table and fill three rows from your recent work.
4. Write five verification gates with pass/fail criteria.
5. Write five "do not use AI" rules with fallbacks.
6. Write your data classification table.
7. Record one measurement: time, defects, rework.
8. Test the workflow on one small task and note where it broke.
9. Revise one prompt based on the test.
10. Date and version the document.

## 8. Your turn (You do)

**Independent task.** Produce a **personal AI workflow document**.

Submit:

1. The five-stage workflow with the human decision at each stage.
2. Five prompt templates, each with role, task, constraints, output format, verification instruction and a do-not list.
3. A decision log template plus three real entries from your work.
4. Five verification gates with binary pass criteria.
5. Five "do not use AI" rules, each with a fallback.
6. A data classification table.
7. One honest measurement of time/quality with and without AI.
8. A 150-word reflection on the biggest risk in your workflow and how you mitigate it.

**Rules:** no generic prompts ("write a design"); no unmeasured claims of productivity; no rule you would not actually follow. The document must be usable by someone else on your behalf.

## 9. Comprehension check

Answer all ten questions without looking at the lesson. Each question has one best answer. The pass mark is 8/10 (80%). If you score below 8, reread the section named in the feedback and complete the retry variant in section 11.

**Q1.** Which stage should AI not own?
- A. Framing the problem and making the final decision to ship.
- B. Divergence, where the assistant generates flows and options quickly.
- C. Drafting variants of copy, flows and critique prompts for review.
- D. First-pass critique, where findings are drafted for a human to check.

**Q2.** What makes a prompt reusable?
- A. It is long, with several paragraphs of context before the task.
- B. It mentions a specific model, so the output stays consistent.
- C. It has placeholders, constraints, an output format and a verification instruction.
- D. It was written by an expert, so its structure is implicitly sound.

**Q3.** What is automation bias?
- A. Refusing to use automated tools at all because they feel untrustworthy.
- B. Automating a workflow so that fewer human steps are needed each time.
- C. Treating it as a bias in training data rather than in the user.
- D. Trusting automated output more than the available evidence actually warrants.

**Q4.** What is a verification gate?
- A. A suggestion to check the output later, once the sprint is finished.
- B. A binary checkpoint that output must pass before it proceeds.
- C. A prompt that asks the assistant to verify its own previous answer.
- D. A design review meeting where the team discusses the screen.

**Q5.** Which data should never be pasted into a consumer AI tool?
- A. Public documentation that anyone can download from the vendor site.
- B. Your own published portfolio, already visible to anyone online.
- C. A public competitor screenshot taken from their marketing page.
- D. A participant's name, phone number and home address.

**Q6.** Why keep prompts in plain text outside a tool?
- A. To survive tool churn and keep the workflow portable across vendors.
- B. To avoid relying on tools, which cannot store prompts for more than one session.
- C. To make each prompt longer and more detailed than a saved version.
- D. To share the prompts publicly as a portfolio of your AI practice.

**Q7.** How should productivity be measured?
- A. By the tool's claims about how much faster designers usually work.
- B. By the number of prompts sent during a typical working day.
- C. By total time, defects, rework and quality against the criteria.
- D. By the number of outputs produced in a single session.

**Q8.** Which is a valid "do not use AI" rule?
- A. "Never use AI for anything, because every output needs checking anyway."
- B. "Do not use AI to generate user quotes or interview findings."
- C. "Only use AI on Mondays, when the team has time to review outputs."
- D. "Do not use AI for colour, because palettes should come from the system."

**Q9.** A learner wants a reusable prompt for critiquing screens. Which addition makes the prompt most reusable?
- A. A longer list of adjectives describing what good design should feel like.
- B. A request to be as confident as possible so the critique sounds decisive.
- C. A rule to accept the first answer, saving time on repeated reviews.
- D. A fixed structure with role, criteria, evidence, output format and verification.

**Q10.** A team adopts AI output without review because the tool is usually right. Which risk is this?
- A. Automation bias, where people over-trust automated output and stop checking.
- B. Scope creep, where the project grows beyond the agreed problem statement.
- C. Design system drift, where components gradually diverge from the tokens.
- D. Low contrast, where text fails the minimum ratio against its background.

## 10. Practical task and pass criteria

**Task.** Submit the eight-part workflow document.

**Pass criteria — all must be met:**

- [ ] Five stages with human decisions identified.
- [ ] Five prompt templates with constraints and verification.
- [ ] Decision log with three real entries.
- [ ] Five binary verification gates.
- [ ] Five do-not rules with fallbacks.
- [ ] Data classification table.
- [ ] One honest measurement.
- [ ] A reflection naming a real risk and mitigation.
- [ ] No unmeasured productivity claim.

## 11. Common mistakes and how to fix them

| Mistake | Why it happens | Fix |
|---|---|---|
| A list of prompts with no process | Prompts feel like the workflow | Map the five stages and the human decisions. |
| "Be careful" rules | They are easy to write | Make rules binary with fallbacks. |
| Logging every prompt | Overhead | Log decisions, not keystrokes. |
| Claiming 10x speed | It sounds impressive | Measure total time and rework. |
| No data rules | Convenience | Classify data; never paste personal data. |
| Tool-specific workflow | It is current | Keep prompts portable and a manual fallback. |
| No verification gates | AI output looks fine | Make gates binary and enforce them. |

**Retry variant.** Apply your workflow to a **different, smaller task** (for example, drafting a single error message and its variants) and record where the workflow was too heavy. Revise it to a "lightweight" version for small tasks and a "full" version for gates. Submit both versions and a 120-word note on when each applies.

## 12. Proof artifact for your portfolio

**Artifact:** `AI-Workflow-v1` — stored in `03_Projects/00_Foundations/ai-workflow`.

This is a differentiator in hiring. Most candidates say they use AI; few can show a documented, auditable workflow with overrides.

## 13. Low-data and low-cost path

- The document is text only.
- Use free tools; no subscriptions required.
- If AI is unavailable, document the workflow with the AI steps marked "manual fallback" and show how you would do them yourself.
- The video is optional and 14 minutes; the workflow structure above is the lesson.

## 14. Watch and read more

**Recommended video (optional, 14:19):** *Use AI Like a Senior Designer (3 Workflows)* — UI Collective. `https://www.youtube.com/watch?v=Oo-5AWdQAt8`. Verified available on 2026-10-30. It shows practitioner workflows; the verification gates and data rules here are the course's own.

**Read (verified 2026-10-30):**

- NIST, *AI Risk Management Framework* — `https://www.nist.gov/itl/ai-risk-management-framework`. Governance and risk concepts that map to workflow gates.
- Microsoft, *Guidelines for Human-AI Interaction* — `https://www.microsoft.com/en-us/haxtoolkit/ai-guidelines/`. Practical guidance on feedback, errors and human control.
- OECD, *OECD AI Principles* — `https://oecd.ai/en/ai-principles`. Transparency and accountability principles.

## 15. What comes next

**Gate 4** asks you to do the same design task twice — once with AI off, once with AI on — and submit both, a prompt and decision log, and a written comparison. Read `03_Assessments/Learner/Phase_4_Gate.md`. Phase 5 then takes the design into code.