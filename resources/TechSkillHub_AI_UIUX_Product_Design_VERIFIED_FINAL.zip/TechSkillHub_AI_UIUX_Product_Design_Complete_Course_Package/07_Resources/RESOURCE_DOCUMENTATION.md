# Resource Documentation

**Package:** TechSkillHub AI-Assisted UI/UX and Product Design
**Date checked:** 2026-10-30
**Sources:** 66 non-video sources in `06_Research/SOURCE_REGISTER.csv`
**Videos:** 38 rows in `08_YouTube/YOUTUBE_VIDEO_MANIFEST.csv`

## 1. What this document covers

How the course's external resources were chosen, what "verified" means, how to use them on a low-data connection, and what to do when a link or video fails. It does not reproduce the resources or claim to own them.

## 2. Resource categories

| Category | Examples | How the course uses them |
|---|---|---|
| **Standards** | WCAG 2.2, NIST AI RMF, OECD AI Principles | Define thresholds and principles; cited when a rule matters. |
| **Official documentation** | Figma Help, MDN, GitHub Docs, Netlify | Teach tool mechanics and code behaviour. |
| **Design systems** | Material 3, GOV.UK Design System | Show patterns, components and public documentation practice. |
| **Practitioner guidance** | NN/g, WebAIM, GOV.UK Service Manual, Atlassian | Explain methods, critique and collaboration. |
| **Tools** | Squoosh, WebAIM Contrast Checker, Netlify Drop, GitHub Pages | Let learners perform a check or publish work. |
| **Research** | Google HEART paper | Explain metric selection. |
| **Professional guidance** | Freelancers Union rate and proposal guides | Frame freelance pricing and proposals without making legal claims. |

## 3. Selection rules

A resource was included only if it was:

- relevant to a specific stop outcome;
- free to access without a login;
- stable enough to cite (documentation, standard or established article);
- readable on a low-data connection;
- non-promotional;
- available in English.

Commercial tools are documented through their own help pages. The course does not require a paid tier to pass any stop.

## 4. What "verified" means

### For non-video sources

- The URL was requested on 2026-10-30 with redirects followed.
- The final response was HTTP 200, except one W3C page that returns 403 to scripted clients and was reviewed in a browser instead. That exception is recorded, not hidden.
- The final URL is recorded in the register.
- The source was read enough to confirm it supports the claim for which it is cited.
- Beginner fit, cost, login requirement, currency and lesson fit were recorded in `RESOURCE_REVIEW.csv`.
- The stops where it is used are recorded.

It does **not** mean the entire page was audited, that it will never change, or that it is the only possible source.

### For videos

- The watch page returned HTTP 200 and playability status `OK`.
- The title, channel, upload date, length, available countries and caption tracks were read from the page.
- The exact title is reproduced, including punctuation.
- The video is marked as an **optional overview**, not the primary source.
- **Embedded playback was tested for all 38 videos in the real lesson page:** the iframe loaded, the media element reached `readyState 4`, playback was not paused and `currentTime` advanced.
- Direct watch-page playback was confirmed for 13 of 38; for the rest, pre-roll advertising exceeded the test window.
- Every video lists an English caption track, but caption accuracy was not reviewed.
- Every video's metadata lists Nigeria, but playback from a Nigerian network was not tested.
- **No transcript is included.** The lesson text covers the outcome.

### What is not claimed

- That a video's content is accurate or current in every statement.
- That a timestamp is correct.
- That captions are accurate or complete.
- That the video will play in every country, network or browser.
- That a resource is the best possible source, only that it passed the review recorded here.
- That the source list is exhaustive.

## 5. Video manifest fields

| Field | Meaning |
|---|---|
| `stop_id` | The lesson the video supports. |
| `video_id` | The YouTube ID, read from the URL and watch page. |
| `title` | Exact watch-page title, entities decoded. |
| `creator` | Channel/owner name from the watch page. |
| `url` / `embed_url` | Canonical watch URL and the privacy-enhanced embed URL. |
| `duration_seconds` | Length from the watch page. |
| `published_date` | Upload date in ISO form. |
| `watch_page_status` | HTTP result for the watch page. |
| `playability` | Status reported by the watch page. |
| `region_status` | Available-country evidence, including whether Nigeria is listed. |
| `captions_status` | Caption tracks listed by YouTube. |
| `transcript_status` | Whether a transcript was retrieved or reviewed. |
| `content_fit` | Why the video fits the stop, or how it only partially fits. |
| `embedded_playback` | Result of playing the embed inside the real lesson. |
| `final_status` | The honest overall status, including what was not tested. |

## 6. How to use resources on a low-data connection

1. Read the lesson first. Every stop is complete without the video.
2. Open only the sources named in the "Watch and read more" section; they are the minimum set.
3. Use the browser's reader mode for long articles.
4. Prefer text documentation over video when data is expensive.
5. Download a page once and read it offline rather than reloading.
6. Use the HTML lesson's "Load video" button only when you choose to spend data.
7. For the contrast checker and Squoosh, the tools run locally in the browser after the page loads.
8. If a source is blocked, use the lesson's own explanation and note the gap.

## 7. Resource map by phase

| Phase | Core resources | Why |
|---|---|---|
| 0 | Figma frames, Cornell LSC study strategies, NN/g heuristics, IBM AI hallucinations, NIST AI RMF, MDN Accessibility | Set up, study, observe, use AI responsibly. |
| 1 | GOV.UK user research, NN/g interviews and problem statements, GOV.UK Design System | Research ethics and problem framing. |
| 2 | WCAG 2.2, WebAIM, Material 3, GOV.UK components, NN/g empty states | Visual and interaction fundamentals. |
| 3 | Figma Help (frames, auto layout, components, variants, variables, prototyping), NN/g prototyping case study | Tool fluency and systems. |
| 4 | Microsoft HAX, NIST, OECD, WCAG, NN/g research with AI, Figma Dev Mode | AI workflow and verification. |
| 5 | MDN, web.dev, GitHub Pages, Figma Dev Mode | Build, handoff, performance. |
| 6 | NN/g testing, metrics and A/B testing, GOV.UK measuring success, HEART, Amplitude North Star | Test, measure, iterate. |
| 7 | NN/g case studies and portfolios, Atlassian, Freelancers Union, GitHub Pages | Career and collaboration. |

## 8. Copyright and licensing

- Links are provided for study; the course does not reproduce substantial copyrighted text.
- Quotations are short and attributed.
- No competitor screenshots or proprietary assets are included.
- Learners must use their own images or clearly licensed assets and credit them.
- Figma, Material 3, GitHub, Netlify and other names are trademarks of their owners; the course is not affiliated with them.
- The course does not include affiliate links.

## 9. Accessibility of resources

- Prefer sources with semantic HTML and readable text.
- Videos are optional and have a direct link; captions are controlled by YouTube.
- If a source is inaccessible to you, use the lesson text and tell your instructor. The outcome, not the resource, is the requirement.
- Do not require a learner to watch a video to pass a gate.

## 10. Broken links and changes

If a link fails:

1. Check whether the page moved; search the title.
2. Use the lesson text in the meantime.
3. Report the URL, the stop and the date to the course maintainer.
4. The maintainer should replace the source, update the register and verification log, and recompute the file hashes.

If a video is private, removed or region-blocked:

1. Mark it unavailable in the manifest.
2. Keep the lesson as the primary source.
3. Replace it only with a video whose metadata has been checked.
4. Do not invent a replacement ID or title.

## 11. Maintenance schedule

- Before each cohort: spot-check the 10 most-used sources and all videos.
- Every six months: full link check; update the register.
- After any content change: rebuild the platform files, rerun validation, recompute hashes.
- Keep the previous audit for comparison.

## 12. Cost transparency

- No resource requires payment to complete the course.
- Figma's free tier is sufficient; Dev Mode may be paid, and the course provides a manual alternative.
- GitHub Pages and Netlify Drop are free for the exercises.
- AI free tiers are sufficient; paid tiers are optional.
- A domain name is optional and usually paid annually.
- Data costs are the learner's responsibility; the low-data path reduces them.

## 13. Contact and corrections

Report a broken link, an inaccurate claim or an inaccessible resource to the course maintainer with:

- the stop ID;
- the URL;
- what happened;
- the date;
- a suggested replacement, if you have one.

Corrections are recorded in `09_Verification/VERIFICATION_LOG.md` so learners and instructors can see what changed.
