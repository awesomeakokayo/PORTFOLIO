# Achievement Map

This map states what a learner can **do** at the end of each phase, and what evidence proves it. It is the bridge between lessons, gates and a portfolio.

| Phase | Capability | Evidence | Portfolio artifact |
|---|---|---|---|
| 0 | Set up a safe workspace, observe an interface, use AI as a tutor, publish a first screen | Workspace tree, 10 observations, AI log, live page | First screen + observation set |
| 1 | Research a problem ethically and frame it without prescribing a solution | Plan, consent, notes, synthesis, problem statement, competitor review | Research summary and problem statement |
| 2 | Design a readable, consistent, accessible screen with real states | Three screens, style sheet, component states, accessibility audit | Visual foundation case |
| 3 | Build a structured Figma file, component system and clickable flow | File map, components, variables, prototype, documentation | Design system specimen |
| 4 | Direct AI across the workflow and verify its output | Two-run comparison, prompt log, verification review | AI workflow comparison |
| 5 | Ship a responsive, accessible, low-bandwidth front end | Live URL, repo, handoff, performance and accessibility evidence | Deployed prototype |
| 6 | Test with people, measure, prioritise and ship a v2 | Test pack, findings, metrics, v2, before/after | Before/after iteration story |
| 7 | Explain the work, collaborate, publish a portfolio and price it | Case study, collaboration pack, live portfolio, pricing pack | Three case studies + portfolio |

## Capability statements

By the end of the course, a learner can:

1. **Frame** a product problem with evidence, scope and a success measure.
2. **Research** with consent, traceability and honest limits.
3. **Design** a coherent interface with components, states and accessibility.
4. **Build** a working responsive front end with human-reviewed AI assistance.
5. **Test** with real people and turn findings into prioritised changes.
6. **Explain** decisions, trade-offs and results in writing and under questioning.
7. **Work** with developers and product managers using tickets, decisions and evidence.
8. **Present** a portfolio that survives a 30-second scan and a deep review.

## What is not claimed

- Not a guarantee of employment or income.
- Not a certification of professional competence beyond the evidence submitted.
- Not a substitute for local legal, tax or financial advice.
- Not a claim that five-user tests are statistically representative.

## Evidence standard

A capability is only claimed when there is an artifact a stranger can inspect: a live URL, a testable file, a findings table with counts, a decision log, a case study with limitations. A statement of intent is not evidence.
