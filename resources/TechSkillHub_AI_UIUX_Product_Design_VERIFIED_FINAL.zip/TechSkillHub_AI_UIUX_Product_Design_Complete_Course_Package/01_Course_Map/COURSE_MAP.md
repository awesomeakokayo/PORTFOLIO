# Course Map

**Course:** AI-Assisted UI/UX and Product Design
**Provider:** TechSkillHub
**Format:** self-paced, project-based, human-reviewed at gates
**Stops:** 38
**Words of learner lesson content:** approximately 128,602
**Mastery target:** 80%, with critical-error override
**Last verified:** 2026-10-30

## How the course is organised

Eight phases, each ending in a gate. A gate is a body of evidence, not a quiz. You move on when the evidence meets the criteria, not when a calendar says so.

| Phase | Theme | Stops | Gate |
|---|---|---|---|
| 0 | Getting started | 5 | [Phase 0 gate](../03_Assessments/Learner/Phase_0_Gate.md) |
| 1 | Product thinking and research | 4 | [Phase 1 gate](../03_Assessments/Learner/Phase_1_Gate.md) |
| 2 | Visual and interaction foundations | 5 | [Phase 2 gate](../03_Assessments/Learner/Phase_2_Gate.md) |
| 3 | Figma fluency and design systems | 5 | [Phase 3 gate](../03_Assessments/Learner/Phase_3_Gate.md) |
| 4 | The AI design workflow | 7 | [Phase 4 gate](../03_Assessments/Learner/Phase_4_Gate.md) |
| 5 | Design to build | 5 | [Phase 5 gate](../03_Assessments/Learner/Phase_5_Gate.md) |
| 6 | Testing, metrics and iteration | 3 | [Phase 6 gate](../03_Assessments/Learner/Phase_6_Gate.md) |
| 7 | Capstone and career launch | 4 | [Phase 7 gate](../03_Assessments/Learner/Capstone.md) |

## What each phase delivers

### Phase 0 — Getting started

Set up your workspace, learn how the course works, practise seeing like a designer, use AI as a tutor, and publish a first screen.

**Stops:** [0.1](../02_Learner_Content/Phase_0_Getting_Started/Stop_0.1_Your_Workspace.md), [0.2](../02_Learner_Content/Phase_0_Getting_Started/Stop_0.2_How_This_Course_Works.md), [0.3](../02_Learner_Content/Phase_0_Getting_Started/Stop_0.3_Seeing_Like_a_Designer.md), [0.4](../02_Learner_Content/Phase_0_Getting_Started/Stop_0.4_Using_AI_as_a_Tutor.md), [0.5](../02_Learner_Content/Phase_0_Getting_Started/Stop_0.5_Your_First_Screen.md)
**Gate evidence:** A screenshot of your folder tree plus a one-page workspace checklist showing each account is active and one file was recovered after closing the browser; A one-page study plan and a sample set of course notes showing the four required note fields; A three-screen annotated teardown with at least 20 correctly named interface parts and a short note on what each screen wants the user to do; and more.

### Phase 1 — Product thinking and research

Understand what product design is responsible for, research real people ethically, frame a problem, and review the market without copying it.

**Stops:** [1.1](../02_Learner_Content/Phase_1_Product_Thinking_And_Research/Stop_1.1_What_Product_Design_Actually_Is.md), [1.2](../02_Learner_Content/Phase_1_Product_Thinking_And_Research/Stop_1.2_User_Research_Basics.md), [1.3](../02_Learner_Content/Phase_1_Product_Thinking_And_Research/Stop_1.3_Problem_Framing.md), [1.4](../02_Learner_Content/Phase_1_Product_Thinking_And_Research/Stop_1.4_Competitive_and_Market_Review.md)
**Gate evidence:** A ten-item classification table (research / UX / UI / business) with a one-line justification for each, plus a short definition of product design in your own words; Two anonymised interview notes, a consent record, and a findings table that separates direct quotes from your interpretation; A one-page problem brief for a real product idea, with evidence links, success metrics, scope, non-goals, assumptions and risks; and more.

### Phase 2 — Visual and interaction foundations

Build the visual and interaction foundations: layout, type, colour, components, states and accessibility.

**Stops:** [2.1](../02_Learner_Content/Phase_2_Visual_And_Interaction_Foundations/Stop_2.1_Layout_Grid_Spacing_and_Hierarchy.md), [2.2](../02_Learner_Content/Phase_2_Visual_And_Interaction_Foundations/Stop_2.2_Typography_and_Colour.md), [2.3](../02_Learner_Content/Phase_2_Visual_And_Interaction_Foundations/Stop_2.3_Components_and_Patterns.md), [2.4](../02_Learner_Content/Phase_2_Visual_And_Interaction_Foundations/Stop_2.4_Interaction_and_States.md), [2.5](../02_Learner_Content/Phase_2_Visual_And_Interaction_Foundations/Stop_2.5_Accessibility_and_Inclusive_Design.md)
**Gate evidence:** A before/after layout of one screen with a marked 8-point spacing scale, a 4-column mobile grid, and a one-paragraph explanation of the reading order; A type scale and colour token sheet with contrast ratios recorded, applied to one screen, plus a rationale; A component sheet with seven components (button, text field, select, checkbox/radio, card, list item, navigation), each with states and usage notes; and more.

### Phase 3 — Figma fluency and design systems

Become fluent in Figma: auto layout, components, variants, variables, prototyping and a small design system.

**Stops:** [3.1](../02_Learner_Content/Phase_3_Figma_And_Design_Systems/Stop_3.1_Figma_Essentials.md), [3.2](../02_Learner_Content/Phase_3_Figma_And_Design_Systems/Stop_3.2_Auto_Layout_and_Constraints.md), [3.3](../02_Learner_Content/Phase_3_Figma_And_Design_Systems/Stop_3.3_Components_Variants_and_Variables.md), [3.4](../02_Learner_Content/Phase_3_Figma_And_Design_Systems/Stop_3.4_Prototyping.md), [3.5](../02_Learner_Content/Phase_3_Figma_And_Design_Systems/Stop_3.5_Building_a_Small_Design_System.md)
**Gate evidence:** An organised Figma starter file with named pages, a frame library, text and colour styles, and a shortcut sheet; Three responsive components (a card, a list row, a form field) and one screen tested at 320, 393 and 430 px widths, with a behaviour note; A button component set (3 variants × 4 states × 2 sizes) using variables, plus a one-page explanation of properties and naming; and more.

### Phase 4 — The AI design workflow

Use AI for synthesis, ideation, UI, critique and microcopy, then verify everything and build a repeatable workflow.

**Stops:** [4.1](../02_Learner_Content/Phase_4_AI_Design_Workflow/Stop_4.1_AI_for_Research_Synthesis.md), [4.2](../02_Learner_Content/Phase_4_AI_Design_Workflow/Stop_4.2_AI_for_Ideation_and_Flows.md), [4.3](../02_Learner_Content/Phase_4_AI_Design_Workflow/Stop_4.3_AI_for_UI_Generation_and_Prototyping.md), [4.4](../02_Learner_Content/Phase_4_AI_Design_Workflow/Stop_4.4_AI_for_Critique.md), [4.5](../02_Learner_Content/Phase_4_AI_Design_Workflow/Stop_4.5_AI_for_Content_and_Microcopy.md), [4.6](../02_Learner_Content/Phase_4_AI_Design_Workflow/Stop_4.6_Verification_and_Judgment.md), [4.7](../02_Learner_Content/Phase_4_AI_Design_Workflow/Stop_4.7_Repeatable_Personal_Workflow.md)
**Gate evidence:** An AI-assisted synthesis with a prompt log, a theme table, a quote-to-theme traceability matrix and a verification note listing what the AI got wrong; Three AI-generated flows, a critique matrix, one selected flow with edge cases, and a decision log explaining what was kept, changed and rejected; A prompt pack, three generated drafts, a review sheet with at least ten checks, and one corrected screen that meets your tokens and accessibility rules; and more.

### Phase 5 — Design to build

Move from design to build: web basics, handoff, AI-assisted code, design systems in code, and responsive low-bandwidth delivery.

**Stops:** [5.0](../02_Learner_Content/Phase_5_Design_To_Build/Stop_5.0_Web_Basics.md), [5.1](../02_Learner_Content/Phase_5_Design_To_Build/Stop_5.1_Handoff_That_Developers_Love.md), [5.2](../02_Learner_Content/Phase_5_Design_To_Build/Stop_5.2_Turning_a_Design_Into_Working_UI_With_AI_Coding_Tools.md), [5.3](../02_Learner_Content/Phase_5_Design_To_Build/Stop_5.3_Design_Systems_in_Code.md), [5.4](../02_Learner_Content/Phase_5_Design_To_Build/Stop_5.4_Responsive_Mobile_First_and_Low_Bandwidth_Design.md)
**Gate evidence:** A live URL of your edited page plus a short "what I changed and why" note and a screenshot of the published page; A handoff pack for one screen: annotated spec, state matrix, asset list, edge-case list, naming conventions and an open-questions log; A working page generated with AI, plus the prompt log, a review table of at least 10 checks, and the corrected final code; and more.

### Phase 6 — Testing, metrics and iteration

Test with real people, define product metrics, and ship a v2 based on evidence.

**Stops:** [6.1](../02_Learner_Content/Phase_6_Testing_Metrics_Iteration/Stop_6.1_Usability_Testing.md), [6.2](../02_Learner_Content/Phase_6_Testing_Metrics_Iteration/Stop_6.2_Product_Metrics.md), [6.3](../02_Learner_Content/Phase_6_Testing_Metrics_Iteration/Stop_6.3_Iteration.md)
**Gate evidence:** A test pack: plan, consent script, task list, session notes for five participants, a findings table with severity and evidence, and a short summary; A metric definition sheet with formulas, a fictional funnel with drop-off, and a one-page interpretation that separates what the data shows from what it does not; A v2 plan with a prioritised backlog, rationale for each change, one written A/B hypothesis, a change log and a re-test plan.

### Phase 7 — Capstone and career launch

Write the case study, work with developers and PMs, publish a portfolio, and learn to price and negotiate.

**Stops:** [7.1](../02_Learner_Content/Phase_7_Capstone_And_Career/Stop_7.1_Case_Study_Writing.md), [7.2](../02_Learner_Content/Phase_7_Capstone_And_Career/Stop_7.2_Working_With_Developers_and_Product_Managers.md), [7.3](../02_Learner_Content/Phase_7_Capstone_And_Career/Stop_7.3_Portfolio_and_Presence.md), [7.4](../02_Learner_Content/Phase_7_Capstone_And_Career/Stop_7.4_Getting_Paid.md)
**Gate evidence:** A 900-1,200 word case study with a one-line summary, evidence images, decision rationale, results and limitations, plus a 150-word short version; A collaboration pack: a scoped ticket, a decision log, a critique note with three actionable points, and a written escalation for one disagreement; A live portfolio URL with three case studies, an about page, contact method and a mobile check; plus a one-paragraph positioning statement; and more.


## Stop index

| ID | Title | Prerequisite | Suggested time | Proof artifact | Lesson | Assessment |
|---|---|---|---|---|---|---|
| 0.1 | Your Workspace | None. This is the first stop. | 45-60 minutes | A screenshot of your folder tree plus a one-page workspace checklist showing each account is active and one file was recovered after closing the browser | [Open](../02_Learner_Content/Phase_0_Getting_Started/Stop_0.1_Your_Workspace.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_0.1_Assessment.md) |
| 0.2 | How This Course Works | Stop 0.1 | 40-55 minutes | A one-page study plan and a sample set of course notes showing the four required note fields | [Open](../02_Learner_Content/Phase_0_Getting_Started/Stop_0.2_How_This_Course_Works.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_0.2_Assessment.md) |
| 0.3 | Seeing Like a Designer | Stop 0.1, Stop 0.2 | 50-70 minutes | A three-screen annotated teardown with at least 20 correctly named interface parts and a short note on what each screen wants the user to do | [Open](../02_Learner_Content/Phase_0_Getting_Started/Stop_0.3_Seeing_Like_a_Designer.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_0.3_Assessment.md) |
| 0.4 | Using AI as a Tutor | Stop 0.3 | 45-60 minutes | A three-question AI tutor log with the prompt used, the answer summary, a verdict (right / partly right / wrong), the source used to check it, and what you would ask next | [Open](../02_Learner_Content/Phase_0_Getting_Started/Stop_0.4_Using_AI_as_a_Tutor.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_0.4_Assessment.md) |
| 0.5 | Your First Screen | Stop 0.1 (Figma account), Stop 0.3 (interface vocabulary) | 60-90 minutes | A Figma frame of the recreated screen plus a one-paragraph rationale for the change, exported as PNG and PDF | [Open](../02_Learner_Content/Phase_0_Getting_Started/Stop_0.5_Your_First_Screen.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_0.5_Assessment.md) |
| 1.1 | What Product Design Actually Is | Phase 0 gate passed | 45-60 minutes | A ten-item classification table (research / UX / UI / business) with a one-line justification for each, plus a short definition of product design in your own words | [Open](../02_Learner_Content/Phase_1_Product_Thinking_And_Research/Stop_1.1_What_Product_Design_Actually_Is.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_1.1_Assessment.md) |
| 1.2 | User Research Basics | Stop 1.1 | 90-120 minutes across two sessions | Two anonymised interview notes, a consent record, and a findings table that separates direct quotes from your interpretation | [Open](../02_Learner_Content/Phase_1_Product_Thinking_And_Research/Stop_1.2_User_Research_Basics.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_1.2_Assessment.md) |
| 1.3 | Problem Framing | Stop 1.2 | 60-80 minutes | A one-page problem brief for a real product idea, with evidence links, success metrics, scope, non-goals, assumptions and risks | [Open](../02_Learner_Content/Phase_1_Product_Thinking_And_Research/Stop_1.3_Problem_Framing.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_1.3_Assessment.md) |
| 1.4 | Competitive and Market Review | Stop 1.3 | 80-110 minutes | A competitive review with three products, a pattern matrix, a gap analysis and a dated evidence log | [Open](../02_Learner_Content/Phase_1_Product_Thinking_And_Research/Stop_1.4_Competitive_and_Market_Review.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_1.4_Assessment.md) |
| 2.1 | Layout, Grid, Spacing and Hierarchy | Phase 1 gate passed | 60-80 minutes | A before/after layout of one screen with a marked 8-point spacing scale, a 4-column mobile grid, and a one-paragraph explanation of the reading order | [Open](../02_Learner_Content/Phase_2_Visual_And_Interaction_Foundations/Stop_2.1_Layout_Grid_Spacing_and_Hierarchy.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_2.1_Assessment.md) |
| 2.2 | Typography and Colour | Stop 2.1 | 70-90 minutes | A type scale and colour token sheet with contrast ratios recorded, applied to one screen, plus a rationale | [Open](../02_Learner_Content/Phase_2_Visual_And_Interaction_Foundations/Stop_2.2_Typography_and_Colour.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_2.2_Assessment.md) |
| 2.3 | Components and Patterns | Stop 2.2 | 70-90 minutes | A component sheet with seven components (button, text field, select, checkbox/radio, card, list item, navigation), each with states and usage notes | [Open](../02_Learner_Content/Phase_2_Visual_And_Interaction_Foundations/Stop_2.3_Components_and_Patterns.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_2.3_Assessment.md) |
| 2.4 | Interaction and States | Stop 2.3 | 70-90 minutes | A state map for one flow with at least seven states, each with a screen or component variant and a recovery path | [Open](../02_Learner_Content/Phase_2_Visual_And_Interaction_Foundations/Stop_2.4_Interaction_and_States.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_2.4_Assessment.md) |
| 2.5 | Accessibility and Inclusive Design | Stop 2.4 | 80-100 minutes | An accessibility audit of one screen with at least ten checks, pass/fail results, fixes and a prioritised remediation list | [Open](../02_Learner_Content/Phase_2_Visual_And_Interaction_Foundations/Stop_2.5_Accessibility_and_Inclusive_Design.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_2.5_Assessment.md) |
| 3.1 | Figma Essentials | Phase 2 gate passed | 70-90 minutes | An organised Figma starter file with named pages, a frame library, text and colour styles, and a shortcut sheet | [Open](../02_Learner_Content/Phase_3_Figma_And_Design_Systems/Stop_3.1_Figma_Essentials.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_3.1_Assessment.md) |
| 3.2 | Auto Layout and Constraints | Stop 3.1 | 80-100 minutes | Three responsive components (a card, a list row, a form field) and one screen tested at 320, 393 and 430 px widths, with a behaviour note | [Open](../02_Learner_Content/Phase_3_Figma_And_Design_Systems/Stop_3.2_Auto_Layout_and_Constraints.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_3.2_Assessment.md) |
| 3.3 | Components, Variants and Variables | Stop 3.2 | 90-120 minutes | A button component set (3 variants × 4 states × 2 sizes) using variables, plus a one-page explanation of properties and naming | [Open](../02_Learner_Content/Phase_3_Figma_And_Design_Systems/Stop_3.3_Components_Variants_and_Variables.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_3.3_Assessment.md) |
| 3.4 | Prototyping | Stop 3.3 | 80-100 minutes | A clickable prototype of one complete flow, with at least six screens, a start point, back navigation, one overlay and one loading/error state, plus a test-readiness note | [Open](../02_Learner_Content/Phase_3_Figma_And_Design_Systems/Stop_3.4_Prototyping.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_3.4_Assessment.md) |
| 3.5 | Building a Small Design System | Stop 3.4 | 120-150 minutes across two sessions | A mini design system file: token pages, ten documented components, a documentation page and one screen built only from system components | [Open](../02_Learner_Content/Phase_3_Figma_And_Design_Systems/Stop_3.5_Building_a_Small_Design_System.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_3.5_Assessment.md) |
| 4.1 | AI for Research Synthesis | Phase 3 gate passed | 70-90 minutes | An AI-assisted synthesis with a prompt log, a theme table, a quote-to-theme traceability matrix and a verification note listing what the AI got wrong | [Open](../02_Learner_Content/Phase_4_AI_Design_Workflow/Stop_4.1_AI_for_Research_Synthesis.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_4.1_Assessment.md) |
| 4.2 | AI for Ideation and Flows | Stop 4.1 | 70-90 minutes | Three AI-generated flows, a critique matrix, one selected flow with edge cases, and a decision log explaining what was kept, changed and rejected | [Open](../02_Learner_Content/Phase_4_AI_Design_Workflow/Stop_4.2_AI_for_Ideation_and_Flows.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_4.2_Assessment.md) |
| 4.3 | AI for UI Generation and Prototyping | Stop 4.2 | 80-100 minutes | A prompt pack, three generated drafts, a review sheet with at least ten checks, and one corrected screen that meets your tokens and accessibility rules | [Open](../02_Learner_Content/Phase_4_AI_Design_Workflow/Stop_4.3_AI_for_UI_Generation_and_Prototyping.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_4.3_Assessment.md) |
| 4.4 | AI for Critique | Stop 4.3 | 70-90 minutes | An AI critique transcript, a verification table with accepted/rejected findings, a severity-rated issue list and a revised screen | [Open](../02_Learner_Content/Phase_4_AI_Design_Workflow/Stop_4.4_AI_for_Critique.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_4.4_Assessment.md) |
| 4.5 | AI for Content and Microcopy | Stop 4.4 | 70-90 minutes | A microcopy pack for one flow: before/after copy for five elements, a tone guide, a clarity check and notes from one reader test | [Open](../02_Learner_Content/Phase_4_AI_Design_Workflow/Stop_4.5_AI_for_Content_and_Microcopy.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_4.5_Assessment.md) |
| 4.6 | Verification and Judgment | Stop 4.5 | 80-100 minutes | An annotated review of three generated screens, a personal review checklist, and corrected versions of two screens with a rationale for every fix | [Open](../02_Learner_Content/Phase_4_AI_Design_Workflow/Stop_4.6_Verification_and_Judgment.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_4.6_Assessment.md) |
| 4.7 | Repeatable Personal Workflow | Stop 4.6 | 70-90 minutes | A personal AI workflow document: five reusable prompts, a decision log template, a verification gate checklist and a "do not use AI" rule set | [Open](../02_Learner_Content/Phase_4_AI_Design_Workflow/Stop_4.7_Repeatable_Personal_Workflow.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_4.7_Assessment.md) |
| 5.0 | Web Basics | Phase 4 gate passed | 60-80 minutes | A live URL of your edited page plus a short "what I changed and why" note and a screenshot of the published page | [Open](../02_Learner_Content/Phase_5_Design_To_Build/Stop_5.0_Web_Basics.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_5.0_Assessment.md) |
| 5.1 | Handoff That Developers Love | Stop 5.0 passed, or equivalent ability to publish a page | 75-95 minutes | A handoff pack for one screen: annotated spec, state matrix, asset list, edge-case list, naming conventions and an open-questions log | [Open](../02_Learner_Content/Phase_5_Design_To_Build/Stop_5.1_Handoff_That_Developers_Love.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_5.1_Assessment.md) |
| 5.2 | Turning a Design Into Working UI With AI Coding Tools | Stops 5.0 and 5.1 passed | 90-120 minutes | A working page generated with AI, plus the prompt log, a review table of at least 10 checks, and the corrected final code | [Open](../02_Learner_Content/Phase_5_Design_To_Build/Stop_5.2_Turning_a_Design_Into_Working_UI_With_AI_Coding_Tools.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_5.2_Assessment.md) |
| 5.3 | Design Systems in Code | Stop 5.2 passed; a small Figma component set from Phase 3 | 90-120 minutes | A small coded design system: token file, two or more components, a usage page and a drift checklist comparing Figma values with code values | [Open](../02_Learner_Content/Phase_5_Design_To_Build/Stop_5.3_Design_Systems_in_Code.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_5.3_Assessment.md) |
| 5.4 | Responsive, Mobile-First and Low-Bandwidth Design | Stop 5.2 passed; a working page to adapt | 90-120 minutes | A responsive, low-bandwidth version of the page with a before/after performance table, screenshots at 320px and 1280px, and a note on offline and error behaviour | [Open](../02_Learner_Content/Phase_5_Design_To_Build/Stop_5.4_Responsive_Mobile_First_and_Low_Bandwidth_Design.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_5.4_Assessment.md) |
| 6.1 | Usability Testing | Phase 5 gate passed; a deployed prototype | 90-120 minutes | A test pack: plan, consent script, task list, session notes for five participants, a findings table with severity and evidence, and a short summary | [Open](../02_Learner_Content/Phase_6_Testing_Metrics_Iteration/Stop_6.1_Usability_Testing.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_6.1_Assessment.md) |
| 6.2 | Product Metrics | Stop 6.1 passed | 75-95 minutes | A metric definition sheet with formulas, a fictional funnel with drop-off, and a one-page interpretation that separates what the data shows from what it does not | [Open](../02_Learner_Content/Phase_6_Testing_Metrics_Iteration/Stop_6.2_Product_Metrics.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_6.2_Assessment.md) |
| 6.3 | Iteration | Stops 6.1 and 6.2 passed | 80-100 minutes | A v2 plan with a prioritised backlog, rationale for each change, one written A/B hypothesis, a change log and a re-test plan | [Open](../02_Learner_Content/Phase_6_Testing_Metrics_Iteration/Stop_6.3_Iteration.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_6.3_Assessment.md) |
| 7.1 | Case Study Writing | Phase 6 gate passed | 90-120 minutes | A 900-1,200 word case study with a one-line summary, evidence images, decision rationale, results and limitations, plus a 150-word short version | [Open](../02_Learner_Content/Phase_7_Capstone_And_Career/Stop_7.1_Case_Study_Writing.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_7.1_Assessment.md) |
| 7.2 | Working With Developers and Product Managers | Stop 7.1 passed | 75-95 minutes | A collaboration pack: a scoped ticket, a decision log, a critique note with three actionable points, and a written escalation for one disagreement | [Open](../02_Learner_Content/Phase_7_Capstone_And_Career/Stop_7.2_Working_With_Developers_and_Product_Managers.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_7.2_Assessment.md) |
| 7.3 | Portfolio and Presence | Stop 7.1 passed; at least two case studies drafted | 90-120 minutes | A live portfolio URL with three case studies, an about page, contact method and a mobile check; plus a one-paragraph positioning statement | [Open](../02_Learner_Content/Phase_7_Capstone_And_Career/Stop_7.3_Portfolio_and_Presence.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_7.3_Assessment.md) |
| 7.4 | Getting Paid | Stop 7.3 passed | 90-120 minutes | A pricing calculator, a one-page proposal, a remote application pack and a negotiation plan with your walk-away number | [Open](../02_Learner_Content/Phase_7_Capstone_And_Career/Stop_7.4_Getting_Paid.md) | [Sheet](../03_Assessments/Learner/Stop_Assessments/Stop_7.4_Assessment.md) |

## Progression rules

1. Complete the stop's comprehension check at 80% or above (8/10).
2. Complete the practical task and meet every pass criterion.
3. Save the proof artifact in your portfolio folder.
4. At the end of a phase, submit the gate evidence for human review.
5. Do not start the next phase until the gate is passed, unless your instructor agrees a specific exception.

The dependency graph is in `DEPENDENCY_GRAPH.md`. The machine-readable index is `STOP_INDEX.csv`.

## Time

The suggested session time for each stop is 60–120 minutes. A realistic total, including practice, gate evidence and the capstone, is **120–180 hours**. This is an estimate, not a deadline. Learners with less time can use the low-data path and spread the work; learners with more can deepen the evidence.

## Tools and cost

- Figma free tier is sufficient for Phases 0–3 and the design parts of later phases.
- A browser, a plain-text editor and a free GitHub account are sufficient for Phase 5.
- Free AI tiers are sufficient; paid tiers are optional.
- No paid course, stock library or device is required.
- Every stop has a low-data alternative.

## What the course does not promise

The course does not guarantee a job, a promotion, a client, an income or a particular salary. It provides practice, feedback and portfolio evidence. Employment and income depend on many factors outside the course.

## Regional context

Examples use Nigerian and wider African settings where relevant, with fictional data. The course does not assume one country, one currency, constant electricity, unlimited data or a particular device. Adapt examples to your own context and say what you changed.
