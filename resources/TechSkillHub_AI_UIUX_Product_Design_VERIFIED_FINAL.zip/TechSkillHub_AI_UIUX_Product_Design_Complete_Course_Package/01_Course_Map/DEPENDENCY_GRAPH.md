# Dependency Graph

```mermaid
flowchart TD
  P0[Phase 0: Foundations] --> G0{Gate 0}
  G0 --> P1[Phase 1: Research]
  P1 --> G1{Gate 1}
  G1 --> P2[Phase 2: Visual foundations]
  P2 --> G2{Gate 2}
  G2 --> P3[Phase 3: Figma & systems]
  P3 --> G3{Gate 3}
  G3 --> P4[Phase 4: AI workflow]
  P4 --> G4{Gate 4}
  G4 --> P5[Phase 5: Design to build]
  P5 --> G5{Gate 5}
  G5 --> P6[Phase 6: Test & iterate]
  P6 --> G6{Gate 6}
  G6 --> P7[Phase 7: Career & capstone]
  P7 --> CAP[Capstone panel]
```

If Mermaid is unavailable, read the arrows as "must be passed before".

## Hard dependencies

| Stop | Needs | Why |
|---|---|---|
| 1.1 | Phase 0 gate | Research requires a safe workspace and observation habits. |
| 2.1 | Phase 1 gate | Visual decisions need a problem to serve. |
| 3.1 | 2.1–2.5 | Figma is a tool for the foundations, not a substitute. |
| 4.1 | Phase 3 gate | AI synthesis needs real notes and a design context. |
| 5.0 | 4.6 | Building without verification repeats generated errors. |
| 5.2 | 5.1 | Code generation needs a handoff to review against. |
| 6.1 | Phase 5 gate | Testing needs something deployed to test. |
| 6.3 | 6.1 and 6.2 | Iteration needs findings and measures. |
| 7.1 | Phase 6 gate | A case study needs results, not intentions. |
| Capstone | Phase 6 gate and 7.1–7.4 | The capstone integrates the whole course. |

## Soft dependencies

- 3.4 (prototyping) helps 4.2 (flows) and 5.1 (handoff).
- 2.5 (accessibility) is revisited in 5.4 (responsive) and 6.1 (testing).
- 4.6 (verification) is a prerequisite habit for 5.2 (AI code) and 7.4 (AI in applications).

## Allowed exceptions

An instructor may allow a learner to start a phase before the previous gate is fully signed off when:

- the missing evidence is administrative, not a capability gap;
- the learner has demonstrated the capability elsewhere;
- the exception is recorded with a date and a completion condition.

An exception is not a waiver of the gate. The gate must still be passed before the capstone.

## Re-entry

A learner returning after a break should:

1. Re-read the last passed gate's evidence.
2. Re-take the last stop check.
3. Re-check the live prototype and links.
4. Resume at the next stop, not at the beginning.
