# Answer Key — Stop 4.5: AI for Content and Microcopy

**Instructor use only. Do not distribute.**
**Phase:** 4 · The AI design workflow
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | B | judgment | Section 5, Step 2 |
| Q2 | B | applied | Section 5, Step 3 |
| Q3 | A | problem | Section 5, Step 3 |
| Q4 | C | applied | Section 5, Step 4 |
| Q5 | D | problem | Section 5, Step 7 |
| Q6 | A | best | Section 5, Step 6 |
| Q7 | D | applied | Section 5, Step 1 |
| Q8 | D | best | Section 5, Step 8 |
| Q9 | B | applied | Section 5 (worked steps) |
| Q10 | A | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. Which button label is strongest for an irreversible transfer?

**Type:** judgment · **Lesson reference:** Section 5, Step 2

**Correct answer: B. "Send ₦25,000" names the action and repeats the amount before an irreversible step.**

**Why this is correct:** It names the action and the consequence. Section 5, Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | "Submit" is compact, familiar from forms, and consistent with the rest of the flow. | Incorrect | It names neither the action nor the amount, so the user cannot see the consequence of an irreversible transfer. |
| B | "Send ₦25,000" names the action and repeats the amount before an irreversible step. | **Correct** | It names the action and the consequence. Section 5, Step 2. |
| C | "OK" is short and familiar from dialogs, so it keeps the footer uncluttered. | Incorrect | It is a generic acknowledgement that gives no clue what will happen or how much will leave the account. |
| D | "Continue" suggests progress to the next step rather than completion of a transfer. | Incorrect | It implies moving to another step, not completing a transfer that cannot be reversed. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. When writing recovery microcopy after a failed payment, which four pieces should the message carry?

**Type:** applied · **Lesson reference:** Section 5, Step 3

**Correct answer: B. What happened, why, what to do now and what is safe.**

**Why this is correct:** Recovery-oriented structure. Section 5, Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Apology, blame, error code and close, so the user knows the team is sorry. | Incorrect | Blame and internal codes are explicitly listed as things to avoid, and the user still gets no route forward. |
| B | What happened, why, what to do now and what is safe. | **Correct** | Recovery-oriented structure. Section 5, Step 3. |
| C | Title, body, image and link, so the message matches the page layout. | Incorrect | That is a page layout, not an error structure; it never says what happened or what is safe. |
| D | Error, retry, cancel and help, so every possible next action is offered. | Incorrect | Those are buttons; the message still needs what happened, why, what to do now and what is safe. |

**If the learner chose otherwise:** revisit Section 5, Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. Why is "Oops!" a weak error message?

**Type:** problem · **Lesson reference:** Section 5, Step 3

**Correct answer: A. It trivialises the problem and gives no information or route forward.**

**Why this is correct:** Tone and information both fail. Section 5, Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It trivialises the problem and gives no information or route forward. | **Correct** | Tone and information both fail. Section 5, Step 3. |
| B | It is too formal for a consumer payment app used on mobile. | Incorrect | The word is casual rather than formal; the real defect is that it trivialises a failure. |
| C | It is too long for an error area that has limited space. | Incorrect | It is two syllables; the defect is trivialising failure and giving the user no next step. |
| D | It is inaccessible to screen readers that read punctuation aloud. | Incorrect | Accessibility concerns contrast, labels and targets; the failure here is tone plus absent recovery guidance. |

**If the learner chose otherwise:** revisit Section 5, Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. What should an empty state do?

**Type:** applied · **Lesson reference:** Section 5, Step 4

**Correct answer: C. Explain what would be here and offer the first useful action.**

**Why this is correct:** Empty states guide the first action. Section 5, Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Show plausible fake data so the screen looks populated and complete. | Incorrect | Fake rows mislead users into thinking records exist and are explicitly discouraged alongside excessive illustration. |
| B | Use a large illustration only, since text would clutter the empty area. | Incorrect | Illustration alone does not say what would be here or what first action to take. |
| C | Explain what would be here and offer the first useful action. | **Correct** | Empty states guide the first action. Section 5, Step 4. |
| D | Hide the screen until the user has created their first record. | Incorrect | Hiding removes the first action; the empty state should explain the gap and guide the user forward. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. What is the best way to test microcopy?

**Type:** problem · **Lesson reference:** Section 5, Step 7

**Correct answer: D. Ask a reader to restate what happened and what they would do.**

**Why this is correct:** Comprehension, not preference, is the measure. Section 5, Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Ask a few people whether they like the wording and tone. | Incorrect | Preference is easy to collect but does not show whether the meaning landed with the reader. |
| B | Count the words and compare the total with the style guide limit. | Incorrect | Brevity is not comprehension; a short sentence can still leave the user unsure what happened. |
| C | Run it through a grammar checker and fix every flagged sentence. | Incorrect | Grammar checks surface correctness, not whether a reader can restate the outcome and next step. |
| D | Ask a reader to restate what happened and what they would do. | **Correct** | Comprehension, not preference, is the measure. Section 5, Step 7. |

**If the learner chose otherwise:** revisit Section 5, Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. "Trusted by 10,000 users" with no data is…

**Type:** best · **Lesson reference:** Section 5, Step 6

**Correct answer: A. An unverified claim that must be substantiated or removed.**

**Why this is correct:** Fabricated social proof is an integrity issue. Section 5, Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | An unverified claim that must be substantiated or removed. | **Correct** | Fabricated social proof is an integrity issue. Section 5, Step 6. |
| B | Good social proof, because a large number reassures new visitors. | Incorrect | Social proof must be true and verifiable; an unsourced user count is fabricated evidence. |
| C | A tone choice, since confident copy suits a competitive market. | Incorrect | The problem is factual accuracy: a claim about users is not a matter of attitude or tone. |
| D | A localisation issue, because numbers are grouped differently by region. | Incorrect | Localisation concerns currency, idioms and context; this is an unverified claim about users. |

**If the learner chose otherwise:** revisit Section 5, Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. Why does tone change while voice stays constant?

**Type:** applied · **Lesson reference:** Section 5, Step 1

**Correct answer: D. Because the emotional context changes: success, error and danger need different warmth.**

**Why this is correct:** Voice is personality; tone adapts to the moment. Section 5, Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Because users get bored by the same tone and need variety to stay engaged. | Incorrect | Boredom is not the reason; tone shifts because success, error and danger carry different emotional weight. |
| B | Because voice is only for marketing pages, while product screens use tone. | Incorrect | Voice is the product's consistent personality in every context, not a marketing-only asset. |
| C | Because the AI cannot hold a consistent voice across several screens. | Incorrect | The model can mimic a voice; the lesson's point is that tone must adapt to the moment. |
| D | Because the emotional context changes: success, error and danger need different warmth. | **Correct** | Voice is personality; tone adapts to the moment. Section 5, Step 1. |

**If the learner chose otherwise:** revisit Section 5, Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. What is localisation beyond translation?

**Type:** best · **Lesson reference:** Section 5, Step 8

**Correct answer: D. Adapting currency, formats, idioms, terminology and cultural context for local readers.**

**Why this is correct:** Localisation is fit for context, not literal substitution. Section 5, Step 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Changing the font so the text suits the scripts used in each market. | Incorrect | Typography is a visual choice; localisation adapts meaning, currency, formats and terminology. |
| B | Adding flags to the language switcher so users recognise their region quickly. | Incorrect | Flags are decoration and can misrepresent mixed-language users; they do not adapt the content. |
| C | Translating word for word while keeping the same sentence structure everywhere. | Incorrect | Literal translation can break idioms and number formats; localisation asks whether the sentence makes sense locally. |
| D | Adapting currency, formats, idioms, terminology and cultural context for local readers. | **Correct** | Localisation is fit for context, not literal substitution. Section 5, Step 8. |

**If the learner chose otherwise:** revisit Section 5, Step 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A learner is writing the primary button for an irreversible transfer of ₦12,500. Which label is strongest?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: B. "Send ₦12,500 now" names the action and the exact amount leaving the account.**

**Why this is correct:** It names the action and the consequence, supporting informed confirmation.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | "Submit" is the conventional label and tells users the form is complete. | Incorrect | It hides the amount and the action, so the user cannot confirm the consequence before an irreversible transfer. |
| B | "Send ₦12,500 now" names the action and the exact amount leaving the account. | **Correct** | It names the action and the consequence, supporting informed confirmation. |
| C | "Continue" keeps the flow moving without repeating the amount the user has already seen. | Incorrect | It suggests another step rather than the final send, which misleads on a confirmation button. |
| D | "OK" is quick to scan and fits the compact width of the footer button. | Incorrect | It conveys neither the action nor the ₦12,500 consequence the lesson requires. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A landing page says 'Trusted by 10,000 users' but the team has no source for the number. What is the main problem?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: A. It is fabricated social proof and must be removed or verifiable.**

**Why this is correct:** Unsupported claims damage trust and are an integrity failure.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It is fabricated social proof and must be removed or verifiable. | **Correct** | Unsupported claims damage trust and are an integrity failure. |
| B | The number is too small to impress visitors and should be larger. | Incorrect | Persuasiveness is irrelevant; an unsourced number is fabricated social proof regardless of its size. |
| C | The sentence is too short to explain what the product actually does. | Incorrect | Length is not the defect; the claim has no verifiable source behind it. |
| D | It should be in all capitals so the claim stands out on the page. | Incorrect | Capitals add emphasis to an unverified claim and make the integrity problem more prominent. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- Voice and tone page with rules and four contexts. — with a file, screenshot, link or log that a stranger can inspect.
- Five before/after elements. — with a file, screenshot, link or log that a stranger can inspect.
- Five AI variants with edits and rejection reasons. — with a file, screenshot, link or log that a stranger can inspect.
- Claim check table with unverified claims removed or substantiated. — with a file, screenshot, link or log that a stranger can inspect.
- A reader test with a verbatim restatement. — with a file, screenshot, link or log that a stranger can inspect.
- No blaming, false urgency or fake social proof. — with a file, screenshot, link or log that a stranger can inspect.
- Reflection is specific about AI's limits. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
