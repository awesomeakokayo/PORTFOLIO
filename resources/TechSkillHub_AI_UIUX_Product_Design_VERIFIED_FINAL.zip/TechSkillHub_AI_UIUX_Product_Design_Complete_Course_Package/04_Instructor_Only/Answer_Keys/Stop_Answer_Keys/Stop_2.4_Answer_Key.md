# Answer Key — Stop 2.4: Interaction and States

**Instructor use only. Do not distribute.**
**Phase:** 2 · Visual and interaction foundations
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | D | judgment | Section 5, Step 3 |
| Q2 | B | applied | Section 5, Step 2 |
| Q3 | D | problem | Section 5, Step 4 |
| Q4 | D | applied | Section 5, Step 5 |
| Q5 | D | problem | Section 5, Step 7 |
| Q6 | C | best | Section 5, Step 4 |
| Q7 | D | applied | Section 5, Step 2 |
| Q8 | B | best | Section 5, Step 5 |
| Q9 | C | applied | Section 5 (worked steps) |
| Q10 | A | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. Why is "Try again" dangerous after an unknown transfer outcome?

**Type:** judgment · **Lesson reference:** Section 5, Step 3

**Correct answer: D. The first attempt may have succeeded, so retrying can duplicate the transfer.**

**Why this is correct:** Unknown outcomes need a status check, not a blind retry. Section 5, Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It is too long for the primary button and wraps onto two lines. | Incorrect | Length is a copy concern and two short words are hardly wordy; the hazard is what the retry does, not how it reads. |
| B | It is inaccessible, because screen readers announce the two words poorly. | Incorrect | The wording is plain and legible, and the risk is behavioural: the action itself can move money a second time. |
| C | It requires a confirmation dialog, which slows the recovery path down. | Incorrect | Adding a confirmation would not remove the danger, because the user could still confirm a duplicate transfer. |
| D | The first attempt may have succeeded, so retrying can duplicate the transfer. | **Correct** | Unknown outcomes need a status check, not a blind retry. Section 5, Step 3. |

**If the learner chose otherwise:** revisit Section 5, Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. When is a spinner with no label acceptable?

**Type:** applied · **Lesson reference:** Section 5, Step 2

**Correct answer: B. For very short waits, or when the activity is already obvious.**

**Why this is correct:** Labels help for multi-second waits; very short waits should not flash an indicator. Section 5, Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | For waits of several minutes, when the user has nothing else to do. | Incorrect | A wait of several minutes needs an explanation, a progress signal and a way to leave, not a silent spinner. |
| B | For very short waits, or when the activity is already obvious. | **Correct** | Labels help for multi-second waits; very short waits should not flash an indicator. Section 5, Step 2. |
| C | Never, because an unlabelled spinner is always an accessibility failure. | Incorrect | The lesson allows no indicator, or a subtle inline change, for waits under a second, so an absolute never is too strong. |
| D | Only on desktop, where screens have room for a supporting caption. | Incorrect | The indicator depends on how long the wait lasts and what context makes obvious, not on the platform. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. What are the four parts of a good error message?

**Type:** problem · **Lesson reference:** Section 5, Step 4

**Correct answer: D. What happened, why it happened, what to do now, what is safe.**

**Why this is correct:** Recovery-oriented error copy. Section 5, Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Error code, timestamp, affected user name and the full stack trace. | Incorrect | Codes, timestamps and stack traces are engineering diagnostics for support staff; they tell the user nothing about what to do next. |
| B | Apology, blame for the mistake, a retry prompt and a close button. | Incorrect | Apology and blame are not parts of the four, and blaming the user is explicitly something a good message avoids. |
| C | A title, a supporting image, a primary button and a small footer. | Incorrect | A title, image, button and footer describe a screen's layout, not the content an error must carry for recovery. |
| D | What happened, why it happened, what to do now, what is safe. | **Correct** | Recovery-oriented error copy. Section 5, Step 4. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. A dashboard loads six sections and one fails. What is the best state?

**Type:** applied · **Lesson reference:** Section 5, Step 5

**Correct answer: D. Show the five loaded sections and mark the failed one with a retry.**

**Why this is correct:** Partial states preserve useful content and localise recovery. Section 5, Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Blank the whole page and show one generic error where the dashboard was. | Incorrect | Blanking discards five sections that loaded correctly, when the partial-state rule is to keep whatever arrived. |
| B | Show invented sample figures in the failed section so the layout looks complete. | Incorrect | Inventing figures for the failed section misleads the user about their own data and hides that anything failed. |
| C | Redirect the user to the home page and ask them to try the dashboard later. | Incorrect | Redirecting drops the task entirely and gives no retry for the section that failed. |
| D | Show the five loaded sections and mark the failed one with a retry. | **Correct** | Partial states preserve useful content and localise recovery. Section 5, Step 5. |

**If the learner chose otherwise:** revisit Section 5, Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. Which action needs confirmation rather than undo?

**Type:** problem · **Lesson reference:** Section 5, Step 7

**Correct answer: D. Permanently deleting an account, because all of the data is unrecoverable.**

**Why this is correct:** Irreversible, high-consequence actions need deliberate confirmation. Section 5, Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Liking a post, because the like appears instantly in other people's feeds. | Incorrect | A like is low risk and trivially reversible, so the lesson's answer there is to allow it with undo. |
| B | Adding an item to a cart, because the total updates on the next screen. | Incorrect | Adding to a cart has almost no consequence and is undone by removing the item, so undo covers it. |
| C | Changing a filter, because the results list reloads with a new ordering. | Incorrect | Changing a filter only alters what is displayed and reverses instantly, so no confirmation is warranted. |
| D | Permanently deleting an account, because all of the data is unrecoverable. | **Correct** | Irreversible, high-consequence actions need deliberate confirmation. Section 5, Step 7. |

**If the learner chose otherwise:** revisit Section 5, Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. What is wrong with "Invalid input" as an error?

**Type:** best · **Lesson reference:** Section 5, Step 4

**Correct answer: C. It does not say what is wrong, why, or how to fix it.**

**Why this is correct:** The message must support recovery. Section 5, Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It is too polite, so users do not realise that something has actually failed. | Incorrect | Politeness is not the failing; the message is blunt, and the real defect is the information it withholds. |
| B | It is too long to fit beside the field on a narrow mobile screen. | Incorrect | It is only two words, so length cannot be the problem; what matters is the missing cause and fix. |
| C | It does not say what is wrong, why, or how to fix it. | **Correct** | The message must support recovery. Section 5, Step 4. |
| D | It relies on colour alone, and the message carries no icon. | Incorrect | The message is text on screen, so colour plays no part; nothing here marks the state by hue. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. Why disable the submit button during processing?

**Type:** applied · **Lesson reference:** Section 5, Step 2

**Correct answer: D. To prevent duplicate submissions and show that the action is underway.**

**Why this is correct:** Duplicate prevention and status communication. Section 5, Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | To make the button look busy so the interface feels responsive. | Incorrect | Looking busy is a side effect; the purpose is stopping a second submission and telling the user the action is underway. |
| B | To improve the contrast between the button label and its background. | Incorrect | Disabling usually lowers a button's contrast, so accessibility is not the reason for this state. |
| C | Because WCAG 2.2 requires submit buttons to be disabled while loading. | Incorrect | WCAG does not require submit buttons to be disabled; this is a duplicate-prevention decision from the lesson's flow. |
| D | To prevent duplicate submissions and show that the action is underway. | **Correct** | Duplicate prevention and status communication. Section 5, Step 2. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. What should an empty state avoid?

**Type:** best · **Lesson reference:** Section 5, Step 5

**Correct answer: B. Fake content that pretends the user already has activity to look at.**

**Why this is correct:** Fake data misleads and undermines trust. Section 5, Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | An explanation of why the section is empty and what belongs here. | Incorrect | The empty-state checklist requires explaining why the space is empty, so an explanation is exactly what it should include. |
| B | Fake content that pretends the user already has activity to look at. | **Correct** | Fake data misleads and undermines trust. Section 5, Step 5. |
| C | A first action that lets the user create the first item. | Incorrect | Offering a first action is required, not something to avoid; without it the state becomes a dead end. |
| D | A short headline that names the state in a few words. | Incorrect | Brevity is required, and a short headline is one of the things an empty state is meant to carry. |

**If the learner chose otherwise:** revisit Section 5, Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A transfer request times out and the app does not know whether the money left the account. What should the interface show?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: C. An outcome-unknown state that checks status and tells the user not to retry yet.**

**Why this is correct:** An unknown outcome needs a status check to avoid duplicate transfers.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A Try again button as the primary action, with the amount still filled in. | Incorrect | A blind retry can duplicate a transfer that may already have left the account, which is the risk the lesson flags. |
| B | A success message, because the request left the device and reached the bank. | Incorrect | Sending is not confirming; claiming success would assert something about the user's money that the system cannot verify. |
| C | An outcome-unknown state that checks status and tells the user not to retry yet. | **Correct** | An unknown outcome needs a status check to avoid duplicate transfers. |
| D | A blank screen until the user pulls to refresh and reload the balance. | Incorrect | A blank screen is a dead end that leaves the user with no information about whether the money moved. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A dashboard spinner has run for two minutes with no message, timeout or retry. What is missing?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: A. A bounded waiting state with an explanation, a timeout and a recovery action.**

**Why this is correct:** Long waits need status communication and a way out when the request fails.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A bounded waiting state with an explanation, a timeout and a recovery action. | **Correct** | Long waits need status communication and a way out when the request fails. |
| B | A brighter spinner colour so the loading state stands out on the page. | Incorrect | A brighter colour does not tell the user how long the wait will last, what is happening, or how to escape. |
| C | More animation around the spinner so the progress feels continuous to the user. | Incorrect | Extra motion implies progress the system does not actually know about, adding noise instead of information. |
| D | A larger logo above the spinner so the brand remains visible while loading. | Incorrect | A larger logo fills space without answering the wait or giving the user a way out. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- At least eight states, including loading, empty, error, success and offline. — with a file, screenshot, link or log that a stranger can inspect.
- A visual variant for each state. — with a file, screenshot, link or log that a stranger can inspect.
- Every error has the four parts and a recovery route. — with a file, screenshot, link or log that a stranger can inspect.
- Every destructive action has a stated confirm/undo/status-check decision. — with a file, screenshot, link or log that a stranger can inspect.
- No state is a dead end without a route forward. — with a file, screenshot, link or log that a stranger can inspect.
- The worst-moment analysis identifies a real harm and a mitigation. — with a file, screenshot, link or log that a stranger can inspect.
- The usability observation records a person's actual response. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
