# Answer Key — Stop 4.4: AI for Critique

**Instructor use only. Do not distribute.**
**Phase:** 4 · The AI design workflow
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | A | judgment | Section 5, Step 3 |
| Q2 | A | applied | Section 5, Step 4 |
| Q3 | A | problem | Section 2 and Step 7 |
| Q4 | D | applied | Section 5, Step 2 |
| Q5 | B | problem | Section 5, Step 6 |
| Q6 | D | best | Section 5, Step 5 |
| Q7 | B | applied | Section 6 |
| Q8 | B | best | Section 5, Step 8 |
| Q9 | B | applied | Section 5 (worked steps) |
| Q10 | C | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. What makes a critique finding actionable?

**Type:** judgment · **Lesson reference:** Section 5, Step 3

**Correct answer: A. It names the element, principle, harm, evidence and the specific fix.**

**Why this is correct:** Actionable findings are specific and evidenced. Section 5, Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It names the element, principle, harm, evidence and the specific fix. | **Correct** | Actionable findings are specific and evidenced. Section 5, Step 3. |
| B | It is written by an AI critic, which makes it thorough and consistent. | Incorrect | Authorship does not make a finding specific; AI output still needs the element, principle, harm, evidence and fix. |
| C | It uses design jargon, which signals expertise to the reviewing team. | Incorrect | Jargon obscures rather than clarifies; a usable finding names a visible element and a concrete fix. |
| D | It is long and detailed, covering every part of the screen at once. | Incorrect | Length is not the test; a finding that cannot fill the five required fields is not actionable however long it is. |

**If the learner chose otherwise:** revisit Section 5, Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. The AI says a button fails contrast. What should you do first?

**Type:** applied · **Lesson reference:** Section 5, Step 4

**Correct answer: A. Measure the actual colour pair, because the claim may be a false positive.**

**Why this is correct:** Verify before acting. Section 5, Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Measure the actual colour pair, because the claim may be a false positive. | **Correct** | Verify before acting. Section 5, Step 4. |
| B | Delete the button and rebuild it with a darker background colour. | Incorrect | Deleting acts before verification, and the worked example shows contrast claims are sometimes false positives. |
| C | Change the colour first, then confirm the new pair meets the requirement. | Incorrect | Changing the colour assumes the finding is true; you measure the actual pair before altering the design. |
| D | Ask the AI to suggest a corrected colour and apply its recommendation. | Incorrect | The model cannot measure your screen; verification is your job, not another generated answer. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. What is a false negative in critique?

**Type:** problem · **Lesson reference:** Section 2 and Step 7

**Correct answer: A. A real problem the critique missed because its method could not detect it.**

**Why this is correct:** False negatives are missed issues, often in non-visual behaviour. Section 2 and Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A real problem the critique missed because its method could not detect it. | **Correct** | False negatives are missed issues, often in non-visual behaviour. Section 2 and Step 7. |
| B | A problem that does not exist, reported confidently by the reviewing tool. | Incorrect | A problem that does not exist is a false positive: a reported issue that is not actually a problem. |
| C | A problem rated with a low severity because it affects very few users. | Incorrect | Severity describes how much harm a problem causes and how often, not whether the critique detected it. |
| D | A finding about colour contrast rather than about interaction behaviour. | Incorrect | Subject matter is irrelevant; a false negative is specifically a real problem the critique failed to find. |

**If the learner chose otherwise:** revisit Section 2 and Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. Why run separate passes for heuristics, accessibility and content?

**Type:** applied · **Lesson reference:** Section 5, Step 2

**Correct answer: D. Because each pass produces more specific findings and makes verification easier.**

**Why this is correct:** Focused passes reduce mixing and omission. Section 5, Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Because a shorter prompt makes the assistant respond faster to each request. | Incorrect | Three passes usually add text; the benefit is specificity and easier verification, not brevity. |
| B | Because the assistant cannot run multiple checks in one prompt and stops early. | Incorrect | AI can run several checks, but one combined pass mixes visual, interaction and content issues. |
| C | Because WCAG requires separate passes, so accessibility is never mixed with heuristics. | Incorrect | WCAG sets accessibility criteria, not a critique procedure; running separate passes is a method choice. |
| D | Because each pass produces more specific findings and makes verification easier. | **Correct** | Focused passes reduce mixing and omission. Section 5, Step 2. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. What does a red-team pass add?

**Type:** problem · **Lesson reference:** Section 5, Step 6

**Correct answer: B. Adversarial perspectives from specific roles that expose exploitation and failure modes.**

**Why this is correct:** Role-based attack surfaces hidden risks. Section 5, Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A colour palette that makes the screen feel urgent to first-time users. | Incorrect | A palette is visual output; red teaming produces failure modes from adversarial roles. |
| B | Adversarial perspectives from specific roles that expose exploitation and failure modes. | **Correct** | Role-based attack surfaces hidden risks. Section 5, Step 6. |
| C | A faster prototype, because the tool generates the corrected screens itself. | Incorrect | Red teaming critiques a design that already exists; it does not build or speed up a prototype. |
| D | A guarantee that no usability problems remain before the design ships. | Incorrect | No method guarantees zero problems; Step 7 says screenshot-only critique still misses keyboard, network and context issues. |

**If the learner chose otherwise:** revisit Section 5, Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. Severity should be based on…

**Type:** best · **Lesson reference:** Section 5, Step 5

**Correct answer: D. Harm and frequency, not fix effort, because critical issues come first.**

**Why this is correct:** Critical issues come first even if easy to fix. Section 5, Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | How easy the fix is, so quick improvements can be cleared from the list. | Incorrect | The lesson states severity is not ease of fixing; a five-minute critical issue still comes first. |
| B | The AI's ranking, because it has compared many similar screens before. | Incorrect | The model's ordering is unverified output; you rate findings by harm and frequency yourself. |
| C | The designer's own preference, since they know which issues matter most. | Incorrect | Preference is taste, not the harm and frequency scale the lesson defines. |
| D | Harm and frequency, not fix effort, because critical issues come first. | **Correct** | Critical issues come first even if easy to fix. Section 5, Step 5. |

**If the learner chose otherwise:** revisit Section 5, Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. The AI suggests masking the full account number on a confirmation screen. Why might you reject it?

**Type:** applied · **Lesson reference:** Section 6

**Correct answer: B. Because the task requires verifying the full number, so masking defeats the purpose.**

**Why this is correct:** Context matters; a privacy pattern can conflict with the task. Section 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Because masking is always wrong on any screen that shows a payment amount. | Incorrect | Masking is right elsewhere; it fails here because this screen's task is verifying the full account number. |
| B | Because the task requires verifying the full number, so masking defeats the purpose. | **Correct** | Context matters; a privacy pattern can conflict with the task. Section 6. |
| C | Because masking is too easy to implement and adds no real design value. | Incorrect | Effort is irrelevant to the decision; the conflict is with the task, not the workload. |
| D | Because the AI cannot actually read numbers, so its suggestion is unreliable. | Incorrect | The AI did see the number; the rejection is about context and task purpose, not visibility. |

**If the learner chose otherwise:** revisit Section 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. What should a rejected-findings log contain?

**Type:** best · **Lesson reference:** Section 5, Step 8

**Correct answer: B. The finding and the specific evidence that justified rejecting it.**

**Why this is correct:** Rejections need reasons to be reviewable. Section 5, Step 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Only the word rejected, so the table stays short and easy to scan. | Incorrect | A bare label gives no reason, so a reviewer cannot check the judgement or learn from it. |
| B | The finding and the specific evidence that justified rejecting it. | **Correct** | Rejections need reasons to be reviewable. Section 5, Step 8. |
| C | The AI's apology and a note that it will try harder next time. | Incorrect | An apology is noise; the log needs the finding and the evidence that disproves it. |
| D | A new design that resolves the finding without discussing it. | Incorrect | A redesign is separate work; the log records why a specific finding was refused. |

**If the learner chose otherwise:** revisit Section 5, Step 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. An AI critique returns 20 findings, including 'the design feels cluttered'. Which revision makes the critique usable?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: B. Rewrite each as a specific observation with evidence, severity and next action.**

**Why this is correct:** Actionable findings are specific, evidenced and prioritised.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Keep all twenty, because a long list demonstrates thoroughness to stakeholders. | Incorrect | Quantity is not thoroughness; a vague finding like 'feels cluttered' still lacks an element, evidence and a fix. |
| B | Rewrite each as a specific observation with evidence, severity and next action. | **Correct** | Actionable findings are specific, evidenced and prioritised. |
| C | Delete every negative finding so the critique feels constructive to the team. | Incorrect | That discards real defects; the problem is vagueness and missing evidence, not negativity. |
| D | Ask the AI to make the wording friendlier without changing the findings. | Incorrect | Friendlier wording changes tone, not the missing element, severity or next action. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A review based only on screenshots misses a keyboard trap in the prototype. What kind of critique failure is this?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: C. A false negative, because the method could not observe the real issue.**

**Why this is correct:** Screenshot-only review cannot test keyboard behaviour, so the issue is missed.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A false positive, because the reviewer invented an issue that is not there. | Incorrect | A false positive is a reported problem that is not real; here nothing was reported at all. |
| B | A visual hierarchy error, because the trap disrupts the reading order. | Incorrect | Hierarchy is a property of the design; the failure lies in the review method's coverage. |
| C | A false negative, because the method could not observe the real issue. | **Correct** | Screenshot-only review cannot test keyboard behaviour, so the issue is missed. |
| D | A content tone problem, because the keyboard behaviour confuses the copy. | Incorrect | Tone concerns copy; the missed issue is keyboard behaviour a screenshot cannot show. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- A brief with role, task, standards and output format. — with a file, screenshot, link or log that a stranger can inspect.
- Four passes completed. — with a file, screenshot, link or log that a stranger can inspect.
- Verification table with labels and evidence. — with a file, screenshot, link or log that a stranger can inspect.
- At least two false positives rejected with evidence. — with a file, screenshot, link or log that a stranger can inspect.
- At least one false negative found independently. — with a file, screenshot, link or log that a stranger can inspect.
- Severity ratings tied to harm and frequency. — with a file, screenshot, link or log that a stranger can inspect.
- Action list with owner, fix and verification. — with a file, screenshot, link or log that a stranger can inspect.
- Revised screen with at least three fixes. — with a file, screenshot, link or log that a stranger can inspect.
- No accepted finding without evidence. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
