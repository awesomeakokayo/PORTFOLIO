# Answer Key — Stop 0.2: How This Course Works

**Instructor use only. Do not distribute.**
**Phase:** 0 · Getting started
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | B | judgment | Section 5, Step 2 |
| Q2 | C | applied | Section 5, Step 3 |
| Q3 | A | problem | Section 5, Step 2 |
| Q4 | C | applied | Section 5, Step 4 |
| Q5 | A | problem | Section 5, Step 5 |
| Q6 | A | best | Section 3 and Step 6 |
| Q7 | B | applied | Section 5, Step 7 |
| Q8 | D | best | Section 5, Step 8 |
| Q9 | D | applied | Section 5 (worked steps) |
| Q10 | C | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. A learner scores 8/10 on the comprehension check but their task misses two essential rubric criteria. What happens?

**Type:** judgment · **Lesson reference:** Section 5, Step 2

**Correct answer: B. They rework the task, because the stop is not passed until it is met.**

**Why this is correct:** A stop requires both the check and all essential task criteria. Section 5, Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | They pass, because the quiz score is above the required 80% threshold. | Incorrect | An 80% quiz score satisfies only half the rule; Step 2 requires the check and all essential task criteria together. |
| B | They rework the task, because the stop is not passed until it is met. | **Correct** | A stop requires both the check and all essential task criteria. Section 5, Step 2. |
| C | They pass with a warning that is recorded on their permanent course record. | Incorrect | There is no pass-with-warning at stop level; the gate reviewer's options are pass, pass with notes or rework. |
| D | They skip to the phase gate and submit the missing criteria there instead. | Incorrect | The phase gate opens only after the stop is passed, so skipping it removes a requirement Step 2 sets. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. What is the purpose of a retry variant?

**Type:** applied · **Lesson reference:** Section 5, Step 3

**Correct answer: C. To test the same ability with a fresh task after receiving targeted feedback.**

**Why this is correct:** A fresh variant tests transfer rather than memorisation. Section 5, Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | To repeat the identical task until every answer is memorised correctly. | Incorrect | Repeating the identical task measures memory of the answer, which Step 3 says is exactly what a retry must avoid. |
| B | To lower the pass mark slightly so the learner can move on sooner. | Incorrect | The pass mark stays at 80%; the retry changes the task or question set, not the standard. |
| C | To test the same ability with a fresh task after receiving targeted feedback. | **Correct** | A fresh variant tests transfer rather than memorisation. Section 5, Step 3. |
| D | To replace the phase gate with a shorter check that needs no reviewer. | Incorrect | A retry is a fresh attempt at the same stop; the phase gate is a separate, human-reviewed checkpoint. |

**If the learner chose otherwise:** revisit Section 5, Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. Which is a critical issue that cannot be averaged away by high marks elsewhere?

**Type:** problem · **Lesson reference:** Section 5, Step 2

**Correct answer: A. Fabricated interview quotes that are presented in a case study as real.**

**Why this is correct:** Research fabrication is a critical integrity issue. Section 5, Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Fabricated interview quotes that are presented in a case study as real. | **Correct** | Research fabrication is a critical integrity issue. Section 5, Step 2. |
| B | A spelling mistake in the label of one secondary button. | Incorrect | A misspelt button label is an ordinary quality error fixed in rework, not one of the critical issues Step 2 names. |
| C | A brand colour that is slightly off the palette used elsewhere. | Incorrect | A slightly off-brand colour is polish; the critical issues are fabricated research, exposed identity and inaccessible design. |
| D | A missing favicon on a prototype that is otherwise complete. | Incorrect | A missing favicon is a minor asset omission and does not invalidate the work or force rework. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. Which note field is designed to catch an illusion of understanding?

**Type:** applied · **Lesson reference:** Section 5, Step 4

**Correct answer: C. The idea I almost got wrong, written from memory after the lesson ends.**

**Why this is correct:** Naming the near-miss exposes gaps that rereading silently hides. Section 5, Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The stop title, written at the top of the page before you begin reading. | Incorrect | The stop title only labels the lesson; it records nothing about what you misunderstood while studying it. |
| B | The date, recorded when you first open the lesson and when you finish. | Incorrect | The date is bookkeeping for the tracking table, not a test of whether the idea landed. |
| C | The idea I almost got wrong, written from memory after the lesson ends. | **Correct** | Naming the near-miss exposes gaps that rereading silently hides. Section 5, Step 4. |
| D | The resource list, added at the end from the links in the lesson. | Incorrect | A resource list points to further reading and never exposes a gap in your own grasp. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. What makes a help request useful?

**Type:** problem · **Lesson reference:** Section 5, Step 5

**Correct answer: A. Describing what you were doing, expected, observed and had already tried.**

**Why this is correct:** The four-part structure lets someone diagnose instead of guess. Section 5, Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Describing what you were doing, expected, observed and had already tried. | **Correct** | The four-part structure lets someone diagnose instead of guess. Section 5, Step 5. |
| B | Saying that it does not work and attaching a screenshot of the screen. | Incorrect | A bare "it doesn't work" with a screenshot supplies none of the four parts, so the helper must guess at the fault. |
| C | Sending the whole project file with no message and letting them explore it. | Incorrect | A file with no message makes the helper hunt for the fault instead of diagnosing a symptom you described. |
| D | Asking directly for the final answer so you can compare it with your own. | Incorrect | Asking for the final answer gets a result you cannot explain or reuse, which is why the template asks for diagnosis. |

**If the learner chose otherwise:** revisit Section 5, Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. Why does the course avoid a week-by-week deadline?

**Type:** best · **Lesson reference:** Section 3 and Step 6

**Correct answer: A. Because progress is judged by mastery, and learners start with different time and constraints.**

**Why this is correct:** Mastery, not elapsed time, controls progression. Section 3 and Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Because progress is judged by mastery, and learners start with different time and constraints. | **Correct** | Mastery, not elapsed time, controls progression. Section 3 and Step 6. |
| B | Because learners cannot read calendars reliably and often miss the dates they set. | Incorrect | The course does use calendars, booking recurring sessions; the objection is dated deadlines, not calendar literacy. |
| C | Because the course has no phases, gates or fixed order of lessons at all. | Incorrect | The course has eight phases and gates; only the week-by-week deadline is removed. |
| D | Because videos are optional and most learners choose to skip them entirely. | Incorrect | Videos being optional does not explain scheduling; mastery, not elapsed time, controls progression. |

**If the learner chose otherwise:** revisit Section 3 and Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. A learner uses AI to draft a case study and submits it without checking. Which rule did they break first?

**Type:** applied · **Lesson reference:** Section 5, Step 7

**Correct answer: B. Declare it, verify it, explain it, and above all verify every claim before submitting.**

**Why this is correct:** AI facts and claims must be verified; unverified text is a risk. Section 5, Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Use only paper notes, never a chat tool, when drafting a case study. | Incorrect | Paper notes are never required; Step 4 allows notes on paper, in an app or in a markdown file. |
| B | Declare it, verify it, explain it, and above all verify every claim before submitting. | **Correct** | AI facts and claims must be verified; unverified text is a risk. Section 5, Step 7. |
| C | Never use AI for writing, even when it is only a first draft. | Incorrect | AI is allowed as tutor, drafting partner and critic, so a blanket ban misreads Step 7 entirely. |
| D | Submit only on Sundays, after the weekly review session has finished completely. | Incorrect | A Sunday-only submission day is a schedule the course never sets; it uses sessions you choose. |

**If the learner chose otherwise:** revisit Section 5, Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. What does a course certificate honestly prove?

**Type:** best · **Lesson reference:** Section 5, Step 8

**Correct answer: D. That the learner completed assessed work against the published criteria.**

**Why this is correct:** A certificate records completion against criteria, not employment or market value. Section 5, Step 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | That the learner will get a job offer soon after finishing the course. | Incorrect | Step 8 says a certificate does not guarantee a job; employment depends on market, portfolio and communication. |
| B | That the learner is better than designers who have no certificate. | Incorrect | The certificate records your own assessed work and makes no comparison with uncertified designers. |
| C | That the learner's portfolio is complete and ready for interviews. | Incorrect | The portfolio is separate work — case studies, prototype, design system — and a certificate does not prove it is complete. |
| D | That the learner completed assessed work against the published criteria. | **Correct** | A certificate records completion against criteria, not employment or market value. Section 5, Step 8. |

**If the learner chose otherwise:** revisit Section 5, Step 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A learner scores 8/10 on a stop check but their practical submission is missing the required screenshot evidence. What should happen next?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: D. The learner supplies the missing evidence and the task is re-marked against the same criteria.**

**Why this is correct:** The stop requires both the knowledge check and all essential practical criteria; a missing artifact is a rework item, not an automatic pass.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The learner passes because 8/10 meets the 80% threshold for the stop. | Incorrect | 8/10 satisfies only the quiz half; the missing screenshot is an unmet essential criterion, so the stop is not passed. |
| B | The learner skips the stop and returns to the same work at the capstone. | Incorrect | Stops gate each other and the phase gate samples stop work, so skipping one breaks the sequence. |
| C | The instructor lowers the practical criteria for this learner and records the change. | Incorrect | Criteria are published and applied to every learner; supplying evidence is the fix, not lowering the bar. |
| D | The learner supplies the missing evidence and the task is re-marked against the same criteria. | **Correct** | The stop requires both the knowledge check and all essential practical criteria; a missing artifact is a rework item, not an automatic pass. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A learner fails a retry by submitting the same file with a new date. Which problem does this reveal?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: C. The learner is repeating a memorised answer instead of transferring the skill to new work.**

**Why this is correct:** A retry must be a different variant; resubmitting the same work does not show that the skill transferred.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The learner has not watched enough of the optional videos for the stop. | Incorrect | The course never counts videos watched — it tracks stops passed — so viewing hours cannot explain the failure. |
| B | The instructor marked the first attempt more strictly than the rubric allows. | Incorrect | The marker applied the same criteria as everyone; the problem is the resubmission, not strictness. |
| C | The learner is repeating a memorised answer instead of transferring the skill to new work. | **Correct** | A retry must be a different variant; resubmitting the same work does not show that the skill transferred. |
| D | The course needs a longer deadline so learners can revise before resubmitting. | Incorrect | There are no deadlines to lengthen; the course runs on sessions you schedule yourself. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- The plan names real days/times and at least one real constraint. — with a file, screenshot, link or log that a stranger can inspect.
- A minimum commitment is stated in one sentence. — with a file, screenshot, link or log that a stranger can inspect.
- The note contains all four fields and the "almost got wrong" field is specific, not "nothing". — with a file, screenshot, link or log that a stranger can inspect.
- The pass rule is stated correctly: 80% plus all essential criteria. — with a file, screenshot, link or log that a stranger can inspect.
- The help request template contains the four parts. — with a file, screenshot, link or log that a stranger can inspect.
- The AI rule says when AI will and will not be used. — with a file, screenshot, link or log that a stranger can inspect.
- The tracking table includes a retry count column. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
