# Answer Key — Stop 4.3: AI for UI Generation and Prototyping

**Instructor use only. Do not distribute.**
**Phase:** 4 · The AI design workflow
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | C | judgment | Section 5, Step 1 |
| Q2 | C | applied | Section 5, Step 2 |
| Q3 | B | problem | Section 5, Step 3 |
| Q4 | A | applied | Section 5, Step 5 |
| Q5 | C | problem | Section 5, Step 4 |
| Q6 | A | best | Section 5, Step 7 |
| Q7 | B | applied | Section 5, Step 6 |
| Q8 | C | best | Section 5, Step 8 |
| Q9 | C | applied | Section 5 (worked steps) |
| Q10 | C | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. What is the main purpose of a constraint stack in a UI prompt?

**Type:** judgment · **Lesson reference:** Section 5, Step 1

**Correct answer: C. To specify user, task, content, tokens, states and rules so output is usable.**

**Why this is correct:** Constraints replace the AI's guesses with your requirements. Section 5, Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | To make the prompt longer, because detailed prompts are assumed to produce better screens. | Incorrect | The stack is long because the constraints are the work; length alone does not make output usable or non-generic. |
| B | To force the assistant to use one specific model with predictable visual output. | Incorrect | The seven layers describe the design requirements, not the model or vendor that should generate the screen. |
| C | To specify user, task, content, tokens, states and rules so output is usable. | **Correct** | Constraints replace the AI's guesses with your requirements. Section 5, Step 1. |
| D | To remove the need to review the output, since constraints prevent every defect. | Incorrect | Constraints reduce guessing, but every draft still goes through the ten-point review before anything is accepted. |

**If the learner chose otherwise:** revisit Section 5, Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. Why generate three drafts with different emphases?

**Type:** applied · **Lesson reference:** Section 5, Step 2

**Correct answer: C. To compare trade-offs instead of accepting the first plausible screen the tool produces.**

**Why this is correct:** Divergence supports a reasoned choice. Section 5, Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | To avoid relying on one draft, since a single version is never valid. | Incorrect | A single draft can be workable; three drafts exist to expose trade-offs, not because one draft is always invalid. |
| B | To increase the tool's cost per screen and justify a paid subscription later. | Incorrect | The stop requires a free tier, so cost is not the aim; generating variants is about comparison. |
| C | To compare trade-offs instead of accepting the first plausible screen the tool produces. | **Correct** | Divergence supports a reasoned choice. Section 5, Step 2. |
| D | To leave the choice open until someone else reviews all three drafts. | Incorrect | The three drafts feed the critique matrix and a selection; they are material for a decision, not a way to postpone it. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. A generated screen uses #9CA3AF secondary text at 12 px on white. What is the issue?

**Type:** problem · **Lesson reference:** Section 5, Step 3

**Correct answer: B. It fails contrast for normal text, measuring about 2.6:1 against the 4.5:1 minimum.**

**Why this is correct:** Around 2.6:1, below the 4.5:1 requirement. Section 5, Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The grey is too dark against white, making the text heavier than the heading. | Incorrect | #9CA3AF is a light grey, so darkness is the opposite of the problem; the measured 2.6:1 contrast is too weak. |
| B | It fails contrast for normal text, measuring about 2.6:1 against the 4.5:1 minimum. | **Correct** | Around 2.6:1, below the 4.5:1 requirement. Section 5, Step 3. |
| C | It uses the wrong font family, which makes the secondary text look inconsistent. | Incorrect | Font choice is a separate check; the measurable defect here is contrast against the 4.5:1 requirement. |
| D | It is fine, because grey text is always accessible on a white background. | Incorrect | The worked example measures 2.6:1 for this exact pair, so grey is not automatically accessible. |

**If the learner chose otherwise:** revisit Section 5, Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. What should you do with an invented "Scan QR" feature in a draft?

**Type:** applied · **Lesson reference:** Section 5, Step 5

**Correct answer: A. Remove it unless it is in scope, and log the removal for the decision record.**

**Why this is correct:** Invented capabilities must not enter the design silently. Section 5, Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Remove it unless it is in scope, and log the removal for the decision record. | **Correct** | Invented capabilities must not enter the design silently. Section 5, Step 5. |
| B | Keep it, because a useful-looking feature adds value even when it was never planned. | Incorrect | Looking useful does not establish scope; keeping it silently adds an invented capability to the design. |
| C | Add it to the backlog automatically so the team can consider it next sprint. | Incorrect | That converts an AI invention into planned work without a product decision, which the lesson says not to do. |
| D | Ask the AI to animate it, then judge whether the motion suits the screen. | Incorrect | Animating an out-of-scope feature invests effort in something the product cannot actually do. |

**If the learner chose otherwise:** revisit Section 5, Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. Why rebuild at least one draft by hand?

**Type:** problem · **Lesson reference:** Section 5, Step 4

**Correct answer: C. Because rebuilding reveals what the AI approximated and applies your system properly.**

**Why this is correct:** Reconstruction is both quality control and learning. Section 5, Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Because importing generated layers is forbidden by most design tool licences. | Incorrect | Import is allowed with review; rebuilding one draft is a required learning step, not a ban on importing. |
| B | Because rebuilding is faster than importing and reduces the time spent on review. | Incorrect | The lesson calls rebuilding the slowest, highest-quality route, so speed is not the reason. |
| C | Because rebuilding reveals what the AI approximated and applies your system properly. | **Correct** | Reconstruction is both quality control and learning. Section 5, Step 4. |
| D | Because the rebuild teaches the model your tokens and improves its future output. | Incorrect | Your rebuild does not train the tool; it shows what the AI approximated and where your system is stronger. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. What does provenance record?

**Type:** best · **Lesson reference:** Section 5, Step 7

**Correct answer: A. Tool, date, prompt, output file, licence and the changes you made.**

**Why this is correct:** Provenance supports legal and professional accountability. Section 5, Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Tool, date, prompt, output file, licence and the changes you made. | **Correct** | Provenance supports legal and professional accountability. Section 5, Step 7. |
| B | Only the tool name, since the other details can be recovered from the file. | Incorrect | The tool name is one field; provenance also needs the date, prompt, output, licence and the changes you made. |
| C | The designer's mood, so reviewers understand the intent behind the screen. | Incorrect | Mood is not a record of origin and cannot support licence checks or professional accountability. |
| D | The file size and export format, so storage requirements stay predictable. | Incorrect | Size is a storage detail and says nothing about which tool produced the output or under what terms. |

**If the learner chose otherwise:** revisit Section 5, Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. A generated headline says "Trusted by 10,000 users" with no data. What is wrong?

**Type:** applied · **Lesson reference:** Section 5, Step 6

**Correct answer: B. It is an invented claim that must be removed or properly substantiated.**

**Why this is correct:** Fabricated social proof is a critical integrity issue. Section 5, Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It is too long for a headline and competes with the primary button. | Incorrect | Length is not the issue; the sentence makes an unverifiable claim about users. |
| B | It is an invented claim that must be removed or properly substantiated. | **Correct** | Fabricated social proof is a critical integrity issue. Section 5, Step 6. |
| C | It uses the wrong font weight, so the number does not read as emphasis. | Incorrect | Typography is unrelated; the defect is invented social proof with no data behind it. |
| D | It is fine, because the assistant sourced the figure from its training data. | Incorrect | The model has no access to your user numbers; Step 6 lists invented statistics as a defect to remove. |

**If the learner chose otherwise:** revisit Section 5, Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. How should you measure whether AI saved time?

**Type:** best · **Lesson reference:** Section 5, Step 8

**Correct answer: C. Time to draft plus time to fix to standard, plus defects found.**

**Why this is correct:** Total effort determines the real benefit. Section 5, Step 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Time to the first usable draft only, since that is what the tool accelerates. | Incorrect | That ignores repair time, which the worked example shows can exceed the time the draft saved. |
| B | The number of prompts sent, since more prompts indicate more exploration. | Incorrect | Counting prompts measures activity, not whether the tool reduced total effort or repair time. |
| C | Time to draft plus time to fix to standard, plus defects found. | **Correct** | Total effort determines the real benefit. Section 5, Step 8. |
| D | The tool's published marketing claims about average speed improvements for teams. | Incorrect | Vendor claims are unmeasured; the stop asks you to record your own draft time, fix time and defect count. |

**If the learner chose otherwise:** revisit Section 5, Step 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. An AI-generated draft looks polished but has no empty, loading or error states. What should the learner do before presenting it?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: C. Add and review the missing states, then check the draft against real constraints.**

**Why this is correct:** A polished default screen is not a usable flow; state coverage is part of the design.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Present it as finished, because the default state is what most reviewers will see. | Incorrect | A polished default state is not a usable flow; missing states are a defect, not a finish line. |
| B | Add more gradients and illustration so the missing states attract less attention. | Incorrect | Decoration hides nothing and adds the generic style the lesson tells you to remove. |
| C | Add and review the missing states, then check the draft against real constraints. | **Correct** | A polished default screen is not a usable flow; state coverage is part of the design. |
| D | Delete the project and start from a blank file with the states designed first. | Incorrect | Starting over discards a draft whose structure may be sound; the fix is to add and review the missing states. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A generated screen uses 12 px grey text with a measured contrast of 2.6:1 on white. What is the specific failure?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: C. Normal-sized text falls below the 4.5:1 WCAG AA contrast requirement.**

**Why this is correct:** 12 px text is normal text and must reach 4.5:1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The text is too large for the screen and crowds the neighbouring content. | Incorrect | 12 px is small rather than large, and size is not the failure being measured here. |
| B | The screen uses too many columns, so the reading order is unclear. | Incorrect | Column count is a layout question; the measured 2.6:1 contrast is the accessibility defect. |
| C | Normal-sized text falls below the 4.5:1 WCAG AA contrast requirement. | **Correct** | 12 px text is normal text and must reach 4.5:1. |
| D | The text is not written in sentence case, which weakens the tone. | Incorrect | Sentence case is a style rule; contrast failure excludes readers regardless of capitalisation. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- A constraint stack covering all seven layers. — with a file, screenshot, link or log that a stranger can inspect.
- Three drafts with different emphases. — with a file, screenshot, link or log that a stranger can inspect.
- Ten-point review completed for each. — with a file, screenshot, link or log that a stranger can inspect.
- Invented features and token violations listed. — with a file, screenshot, link or log that a stranger can inspect.
- One corrected screen with at least two states. — with a file, screenshot, link or log that a stranger can inspect.
- Provenance and licence recorded. — with a file, screenshot, link or log that a stranger can inspect.
- Time and defect measurement included. — with a file, screenshot, link or log that a stranger can inspect.
- Verdict is specific and honest. — with a file, screenshot, link or log that a stranger can inspect.
- No unlicensed asset or fabricated claim. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
