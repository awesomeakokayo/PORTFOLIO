# Answer Key — Stop 5.2: Turning a Design Into Working UI With AI Coding Tools

**Instructor use only. Do not distribute.**
**Phase:** 5 · Design to build
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | D | judgment | Section 3 |
| Q2 | D | applied | Step 3 |
| Q3 | C | problem | Step 4 |
| Q4 | C | applied | Step 6 |
| Q5 | B | problem | Step 4 |
| Q6 | B | best | Step 8 |
| Q7 | D | applied | Step 7 |
| Q8 | B | best | Step 6 |
| Q9 | C | applied | Section 5 (worked steps) |
| Q10 | B | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. What is the most important part of using an AI coding tool well?

**Type:** judgment · **Lesson reference:** Section 3

**Correct answer: D. Specifying intent clearly and reviewing the output against explicit criteria before accepting it.**

**Why this is correct:** Direction and review are the skill. Section 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Writing the longest possible prompt, so the model has every detail it could ever need. | Incorrect | Length is not the measure; the lesson caps the brief under 300 words and rewards structure, tokens and constraints. |
| B | Accepting the first result quickly, because speed is the main advantage these tools offer. | Incorrect | Accepting the first result is the failure this stop is written against; a page can look right and still be unusable. |
| C | Using the most expensive model, since higher price usually means fewer invented details. | Incorrect | Price does not decide the quality of direction; the skill is specifying and reviewing, not buying a bigger model. |
| D | Specifying intent clearly and reviewing the output against explicit criteria before accepting it. | **Correct** | Direction and review are the skill. Section 3. |

**If the learner chose otherwise:** revisit Section 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. Why is a clickable `<div>` a problem?

**Type:** applied · **Lesson reference:** Step 3

**Correct answer: D. It is not focusable or operable by keyboard, and it gives assistive tech no button role or name.**

**Why this is correct:** Native buttons provide keyboard and semantic behaviour. Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It renders more slowly than a native button, so the interaction feels delayed on older phones. | Incorrect | Render speed is not the issue; a div paints quickly and is still unreachable for someone using only a keyboard. |
| B | It cannot be styled with CSS, so it never matches the visual design of the rest of the page. | Incorrect | A div can be styled as freely as a button; the defect is missing semantics and keyboard behaviour, not CSS. |
| C | It breaks the CSS grid it sits in, which collapses the surrounding layout on narrow screens. | Incorrect | A div is an ordinary grid item and does not break grid; the failure appears when someone tries to activate it. |
| D | It is not focusable or operable by keyboard, and it gives assistive tech no button role or name. | **Correct** | Native buttons provide keyboard and semantic behaviour. Step 3. |

**If the learner chose otherwise:** revisit Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. The generated CSS uses `#333` when your token is `#171717`. What should you do?

**Type:** problem · **Lesson reference:** Step 4

**Correct answer: C. Replace it with the token, so the theme stays consistent and later token changes still apply.**

**Why this is correct:** Hard-coded values cause drift. Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Leave it as it is, since #333 and #171717 are visually close enough for most visitors. | Incorrect | `#333` is a different value from `#171717`, so leaving it produces the drift the token system exists to prevent. |
| B | Delete all the generated CSS and start again, because one stray value proves the output is unreliable. | Incorrect | Deleting all the CSS discards correct work; the fix is to replace the stray value, not the stylesheet. |
| C | Replace it with the token, so the theme stays consistent and later token changes still apply. | **Correct** | Hard-coded values cause drift. Step 4. |
| D | Add a second token for #333, so both greys are documented and available for future screens. | Incorrect | A second token preserves the inconsistency and leaves the system with two competing text colours. |

**If the learner chose otherwise:** revisit Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. Which is a reason to reject and rebuild rather than patch?

**Type:** applied · **Lesson reference:** Step 6

**Correct answer: C. A fundamentally wrong structure, such as a table-based layout with inline styles throughout.**

**Why this is correct:** Structural problems are cheaper to rebuild than patch. Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | One wrong colour, because repainting a single element by hand is slower than rebuilding. | Incorrect | One wrong colour is small and understood, so the lesson says fix it directly rather than rebuild. |
| B | A missing semicolon, because broken syntax means the whole stylesheet cannot be trusted. | Incorrect | A missing semicolon is a one-character repair and does not make the structure wrong enough to discard. |
| C | A fundamentally wrong structure, such as a table-based layout with inline styles throughout. | **Correct** | Structural problems are cheaper to rebuild than patch. Step 6. |
| D | A typo in a comment, because comments are read by the model on every later prompt. | Incorrect | A typo in a comment changes nothing that renders, so correcting it is far cheaper than starting again. |

**If the learner chose otherwise:** revisit Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. Why test at 320px and 200% zoom?

**Type:** problem · **Lesson reference:** Step 4

**Correct answer: B. To check that content reflows readably for small screens and for users with low vision.**

**Why this is correct:** Reflow is a WCAG expectation and a real device condition. Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | To make the page load more slowly, which reveals how it behaves on a weak connection. | Incorrect | Slowing the page is not a goal; 320px and 200% simulate a small phone and a low-vision user's settings. |
| B | To check that content reflows readably for small screens and for users with low vision. | **Correct** | Reflow is a WCAG expectation and a real device condition. Step 4. |
| C | Because AI tools cannot write media queries, so the layout must be verified by hand. | Incorrect | AI tools do write media queries; the test exists because generated layouts still overflow despite them. |
| D | To increase the contrast ratio of body text, which improves as the layout gets narrower. | Incorrect | Contrast is measured with a contrast checker; zoom and narrow width test reflow, not colour ratios. |

**If the learner chose otherwise:** revisit Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. What belongs in a prompt log?

**Type:** best · **Lesson reference:** Step 8

**Correct answer: B. The prompts, output summaries, and what you accepted, changed or rejected, with reasons.**

**Why this is correct:** It records human decisions and supports review. Step 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Only the final code, so the log stays short and shows exactly what was shipped. | Incorrect | Final code alone records the output but not what you accepted, changed or rejected, which is the log's purpose. |
| B | The prompts, output summaries, and what you accepted, changed or rejected, with reasons. | **Correct** | It records human decisions and supports review. Step 8. |
| C | The model's marketing description, so readers know which product version produced the code. | Incorrect | Vendor marketing says what the product claims, not what you decided, so a reviewer learns nothing about your judgment. |
| D | Your password and account details, so the tool can resume the session on another machine. | Incorrect | A password must never be written anywhere; the log holds prompts, summaries and accept/change/reject decisions. |

**If the learner chose otherwise:** revisit Step 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. A generated page loads a 900 KB icon font for three icons. What is the best fix?

**Type:** applied · **Lesson reference:** Step 7

**Correct answer: D. Replace the font with three inline SVGs or a small sprite, which draws only what you need.**

**Why this is correct:** Page weight should match need. Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Keep the font, because polished icons matter more than a few hundred kilobytes on a portfolio page. | Incorrect | Keeping it means every visitor downloads 900 KB to draw three icons, which is the weight problem itself. |
| B | Add more icons to the page, so the 900 KB font is amortised across more visible content. | Incorrect | More icons increase dependence on the heavy font and make the page larger, moving away from the 100 KB target. |
| C | Load a second icon font as a fallback, in case the first one fails to arrive. | Incorrect | A second icon font adds another large request on top of the first, roughly doubling the cost. |
| D | Replace the font with three inline SVGs or a small sprite, which draws only what you need. | **Correct** | Page weight should match need. Step 7. |

**If the learner chose otherwise:** revisit Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. You cannot explain what a generated JavaScript function does. What should you do?

**Type:** best · **Lesson reference:** Step 6

**Correct answer: B. Ask the tool to explain it, then either understand it well enough or remove it.**

**Why this is correct:** You are responsible for shipped code. Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Ship it anyway, since the page works and users never see the code behind it. | Incorrect | Shipping code you cannot explain is what the lesson forbids; 'it works' is no defence when it breaks in production. |
| B | Ask the tool to explain it, then either understand it well enough or remove it. | **Correct** | You are responsible for shipped code. Step 6. |
| C | Rename the function so its purpose is clearer, and leave the body unchanged. | Incorrect | Renaming changes the label and nothing else, leaving you just as unable to explain the behaviour. |
| D | Add a comment saying 'AI wrote this', so future readers know the code is unverified. | Incorrect | A comment crediting the AI records origin, not behaviour, so the risk stays in the build. |

**If the learner chose otherwise:** revisit Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. An AI coding tool generates a clickable card using a `<div>` with a click handler. What is the best correction?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: C. Use a native button or link, keeping the styling, keyboard behaviour and visible focus style.**

**Why this is correct:** Native elements provide keyboard and assistive-technology behaviour that a div lacks.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Add a cursor-pointer style so the card looks clickable, and leave the markup as it is. | Incorrect | `cursor: pointer` only changes the mouse cursor; the card stays unfocusable and invisible to assistive technology. |
| B | Add a tabindex to the div so it can receive focus, and change nothing else. | Incorrect | `tabindex` makes the div focusable but supplies no role, no Enter or Space activation and no announcement. |
| C | Use a native button or link, keeping the styling, keyboard behaviour and visible focus style. | **Correct** | Native elements provide keyboard and assistive-technology behaviour that a div lacks. |
| D | Replace the card with an image of the action, which cannot be misused by a keyboard. | Incorrect | Replacing the card with an image removes the action altogether instead of making it keyboard operable. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A generated page looks correct but cannot be operated with a keyboard, and focus disappears after the first field. What review was missed?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: B. A keyboard and focus review of the rendered page, not just a visual comparison with the design.**

**Why this is correct:** Visual fidelity does not prove keyboard access or visible focus.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A colour palette review, checking that every token used on the page matches the brand. | Incorrect | Colour was presumably compared already; the missed check is keyboard operation and visible focus. |
| B | A keyboard and focus review of the rendered page, not just a visual comparison with the design. | **Correct** | Visual fidelity does not prove keyboard access or visible focus. |
| C | A content word-count check, confirming that every label and paragraph fits inside its slot. | Incorrect | Word count is a content check and cannot reveal a control that Tab never reaches. |
| D | A logo placement review, comparing its position on each breakpoint against the brand guide. | Incorrect | Logo placement is a visual comparison; focus vanishing after the first field is an interaction defect. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- The page renders and matches the handoff's core layout and tokens. — with a file, screenshot, link or log that a stranger can inspect.
- Semantic HTML is used for actions, headings, landmarks and form labels. — with a file, screenshot, link or log that a stranger can inspect.
- All interactive elements are keyboard reachable with a visible focus state. — with a file, screenshot, link or log that a stranger can inspect.
- Body text contrast is at least 4.5:1; large text and UI boundaries at least 3:1. — with a file, screenshot, link or log that a stranger can inspect.
- The page reflows at 320px without horizontal scrolling and remains usable at 200% zoom. — with a file, screenshot, link or log that a stranger can inspect.
- At least two non-default states work (for example loading and error). — with a file, screenshot, link or log that a stranger can inspect.
- No unexplained hard-coded values that contradict the tokens. — with a file, screenshot, link or log that a stranger can inspect.
- The prompt log covers at least 6 prompts with accept/change/reject decisions. — with a file, screenshot, link or log that a stranger can inspect.
- The review table covers at least 10 checks. — with a file, screenshot, link or log that a stranger can inspect.
- The reflection names one real risk the tool introduced and how you handled it. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
