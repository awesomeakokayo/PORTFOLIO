# Answer Key — Stop 5.3: Design Systems in Code

**Instructor use only. Do not distribute.**
**Phase:** 5 · Design to build
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | D | judgment | Step 1 |
| Q2 | D | applied | Step 3 |
| Q3 | B | problem | Step 5 |
| Q4 | D | applied | Step 8 |
| Q5 | B | problem | Step 9 |
| Q6 | A | best | Step 7 |
| Q7 | A | applied | Step 6 |
| Q8 | B | best | Step 4 |
| Q9 | C | applied | Section 5 (worked steps) |
| Q10 | D | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. When a token set moves from Figma into CSS, what is the difference between a primitive and a semantic token?

**Type:** judgment · **Lesson reference:** Step 1

**Correct answer: D. A primitive is a raw value like green-700; a semantic token names a job and points to it.**

**Why this is correct:** Semantics describe use and allow themes. Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Primitive tokens are only used in code, while semantic tokens exist only inside the Figma file. | Incorrect | Both kinds of token exist in Figma and in code; the distinction is raw value versus named job, not which tool uses them. |
| B | Semantic tokens always describe colours, while primitive tokens also cover spacing and radius values in the file. | Incorrect | Semantic tokens name roles such as `color-action-primary` or `space-card-padding`, so they cover spacing and radius, not colour only. |
| C | There is no real difference; the two names describe the same value at different points in the file. | Incorrect | They behave differently: the semantic token points at a primitive, which is what lets a theme swap values in one place. |
| D | A primitive is a raw value like green-700; a semantic token names a job and points to it. | **Correct** | Semantics describe use and allow themes. Step 1. |

**If the learner chose otherwise:** revisit Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. Why use `rem` for font sizes?

**Type:** applied · **Lesson reference:** Step 3

**Correct answer: D. Because it respects browser zoom and user font settings, unlike a fixed pixel size.**

**Why this is correct:** Relative units support user preferences. Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Because it is shorter to type than pixels, keeping the stylesheet compact and easier to scan. | Incorrect | `rem` is not shorter than `px` — `1rem` and `16px` take similar space — and brevity is not the reason given. |
| B | Because it makes text bold by default, so headings need fewer separate font-weight declarations. | Incorrect | Weight comes from `font-weight`, not the unit; choosing `rem` says nothing about how bold the text looks. |
| C | Because HTML requires relative units for text, and pages using pixels fail validation. | Incorrect | HTML imposes no such rule; `rem` is a CSS unit choice, and `px` is equally valid syntax. |
| D | Because it respects browser zoom and user font settings, unlike a fixed pixel size. | **Correct** | Relative units support user preferences. Step 3. |

**If the learner chose otherwise:** revisit Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. A Figma variant has no code equivalent. What is the correct response?

**Type:** problem · **Lesson reference:** Step 5

**Correct answer: B. Either implement the variant in code or remove it from the Figma file entirely.**

**Why this is correct:** Design-only variants become bugs. Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Ignore it for now, since the coded components already cover the main actions the product needs. | Incorrect | Ignoring it leaves a variant that exists only in the design file, which the lesson calls a future bug. |
| B | Either implement the variant in code or remove it from the Figma file entirely. | **Correct** | Design-only variants become bugs. Step 5. |
| C | Add a screenshot of the variant to the code folder so developers can reference it. | Incorrect | A screenshot in the code folder is not an implementation; the variant still has no behaviour or state. |
| D | Rename the variant so it matches a code class, and leave the implementation unchanged. | Incorrect | Renaming does not create a code equivalent, so Figma and the built product still disagree about what exists. |

**If the learner chose otherwise:** revisit Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. What is drift?

**Type:** applied · **Lesson reference:** Step 8

**Correct answer: D. A mismatch between the value in the design source and the value in the built product.**

**Why this is correct:** Drift is divergence between design and code. Step 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | An animation that plays when a token changes, showing the old and new values. | Incorrect | An animation is a motion effect; drift means a value in Figma no longer matches the value in the build. |
| B | A type of token that stores a value the team wants to review before release. | Incorrect | A token is a named value; drift describes divergence between two sources, not a category of token. |
| C | A Git branch where designers and developers merge their changes before a release. | Incorrect | A Git branch is version-control structure; drift occurs between the design file and the code, not between branches. |
| D | A mismatch between the value in the design source and the value in the built product. | **Correct** | Drift is divergence between design and code. Step 8. |

**If the learner chose otherwise:** revisit Step 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. Which is a good reason NOT to add a component to the system?

**Type:** problem · **Lesson reference:** Step 9

**Correct answer: B. It is used once, on a single page, and is unlikely to appear again.**

**Why this is correct:** Systematise repeated patterns, not one-offs. Step 9.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It appears on every screen, so keeping one canonical version would reduce repeated work. | Incorrect | Use on every screen is the strongest argument for systematising a component, so it cannot be the reason to leave it out. |
| B | It is used once, on a single page, and is unlikely to appear again. | **Correct** | Systematise repeated patterns, not one-offs. Step 9. |
| C | It carries accessibility requirements, such as labels, focus behaviour and announced errors. | Incorrect | Accessibility requirements are exactly what documentation should capture, and they argue for a shared component. |
| D | It has several variants, such as primary, secondary, disabled and loading states. | Incorrect | Variants are normal for system components, and Step 5 maps each one to a class or attribute. |

**If the learner chose otherwise:** revisit Step 9 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. What should component documentation include?

**Type:** best · **Lesson reference:** Step 7

**Correct answer: A. Purpose, usage rules, the exact HTML, states, accessibility behaviour, do/don't examples and known limitations.**

**Why this is correct:** Documentation must enable correct use. Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Purpose, usage rules, the exact HTML, states, accessibility behaviour, do/don't examples and known limitations. | **Correct** | Documentation must enable correct use. Step 7. |
| B | A single screenshot of the component, so readers can see what it looks like in use. | Incorrect | A screenshot shows appearance only, and the lesson says documentation that is just a picture is not a system. |
| C | The designer's name and contact details, so readers know who to ask about changes. | Incorrect | A name and contact says who made it, not when to use it, what HTML to write, or how it behaves. |
| D | A list of every colour in the company palette, with hex values and contrast ratios. | Incorrect | A palette list is a colour reference, not usage guidance, states or accessibility behaviour for this component. |

**If the learner chose otherwise:** revisit Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. Why connect help text to an input with `aria-describedby`?

**Type:** applied · **Lesson reference:** Step 6

**Correct answer: A. So assistive technology announces the help text together with the field when it receives focus.**

**Why this is correct:** It creates a programmatic relationship. Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | So assistive technology announces the help text together with the field when it receives focus. | **Correct** | It creates a programmatic relationship. Step 6. |
| B | So the input can be made wider, giving long help text more room beside the field. | Incorrect | `aria-describedby` adds no styling; width comes from CSS on the input, not from the attribute. |
| C | So the form can validate the answer before it is submitted to the server. | Incorrect | It does not validate anything; validation logic runs separately, while the attribute only links descriptive text. |
| D | So the input changes colour when the help text is present, matching the design spec. | Incorrect | Colour is set by CSS properties and tokens; the attribute changes the accessibility tree, not paint. |

**If the learner chose otherwise:** revisit Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. A button's focus outline is removed because it "looks ugly". What is the problem?

**Type:** best · **Lesson reference:** Step 4

**Correct answer: B. Keyboard users lose the only indication of which element is focused, so they cannot navigate reliably.**

**Why this is correct:** Visible focus is essential for keyboard navigation. Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Nothing is wrong, because focus outlines are optional decoration that designers may remove. | Incorrect | Focus outlines are required rather than optional; removing one without a visible replacement leaves keyboard users lost. |
| B | Keyboard users lose the only indication of which element is focused, so they cannot navigate reliably. | **Correct** | Visible focus is essential for keyboard navigation. Step 4. |
| C | The page becomes slower, because browsers recalculate the outline on every key press. | Incorrect | An outline has no measurable effect on page speed; the cost of removing it is navigational. |
| D | The grid breaks, because the outline was contributing to the column widths of the layout. | Incorrect | Focus outlines do not affect grid tracks; the damage is that the Tab position becomes invisible. |

**If the learner chose otherwise:** revisit Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A design token changes in Figma but the coded component still uses the old hex value. What should the team add?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: C. A drift check that compares the token source with the coded values and flags mismatches.**

**Why this is correct:** Drift is detected by comparing design and code values, not by assuming they match.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A larger component library, so the team has more ready-made parts to choose from. | Incorrect | A bigger library increases the surface area for drift instead of checking the value that already changed. |
| B | A rule that developers memorise every hex code, so they notice when a value changes. | Incorrect | Memorising hex codes relies on human memory and fails silently the moment a token changes. |
| C | A drift check that compares the token source with the coded values and flags mismatches. | **Correct** | Drift is detected by comparing design and code values, not by assuming they match. |
| D | A new logo, so users associate the refreshed visual identity with the updated colours. | Incorrect | A new logo is branding work and has no connection to the token values a stylesheet consumes. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A coded design system uses pixels for all font sizes, and users who increase their browser text size see no change. What is the problem?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: D. Absolute pixel sizes ignore the user's text-size preference, so relative units such as rem are needed.**

**Why this is correct:** `rem` and similar units scale with user settings, unlike fixed pixels.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The page has too many semantic tokens, which override the browser's text-size preference. | Incorrect | Semantic token count is unrelated; a page can carry many tokens and still scale if type uses `rem`. |
| B | The CSS file is too small to hold the media queries that respond to larger text. | Incorrect | File size is irrelevant here, and a short CSS file can still specify every font size in pixels. |
| C | The buttons use the wrong border radius, which stops the layout from scaling proportionally. | Incorrect | Border radius affects corners, not text size, so it cannot explain why a browser text setting does nothing. |
| D | Absolute pixel sizes ignore the user's text-size preference, so relative units such as rem are needed. | **Correct** | `rem` and similar units scale with user settings, unlike fixed pixels. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- At least 8 primitive and 6 semantic tokens are defined and used. — with a file, screenshot, link or log that a stranger can inspect.
- Type and spacing scales are documented, with units explained. — with a file, screenshot, link or log that a stranger can inspect.
- Two components each support at least three states. — with a file, screenshot, link or log that a stranger can inspect.
- One composed example uses both components together. — with a file, screenshot, link or log that a stranger can inspect.
- A usage page shows HTML, variants, accessibility behaviour and do/don't rules. — with a file, screenshot, link or log that a stranger can inspect.
- A drift table has at least 6 rows and one real mismatch corrected. — with a file, screenshot, link or log that a stranger can inspect.
- Focus is visible, labels are connected, and contrast meets 4.5:1 for text and 3:1 for UI boundaries. — with a file, screenshot, link or log that a stranger can inspect.
- A governance note states who changes tokens and what is checked before merging. — with a file, screenshot, link or log that a stranger can inspect.
- No real client or personal data is present. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
