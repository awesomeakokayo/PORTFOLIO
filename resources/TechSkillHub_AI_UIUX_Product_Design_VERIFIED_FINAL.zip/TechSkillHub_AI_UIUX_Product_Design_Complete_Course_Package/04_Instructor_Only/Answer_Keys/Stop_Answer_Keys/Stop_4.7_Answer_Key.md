# Answer Key — Stop 4.7: Repeatable Personal Workflow

**Instructor use only. Do not distribute.**
**Phase:** 4 · The AI design workflow
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | A | judgment | Section 5, Step 1 |
| Q2 | C | applied | Section 5, Step 2 |
| Q3 | D | problem | Section 2 |
| Q4 | B | applied | Section 5, Step 4 |
| Q5 | D | problem | Section 5, Step 6 |
| Q6 | A | best | Section 5, Step 8 |
| Q7 | C | applied | Section 5, Step 7 |
| Q8 | B | best | Section 5, Step 5 |
| Q9 | D | applied | Section 5 (worked steps) |
| Q10 | A | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. Which stage should AI not own?

**Type:** judgment · **Lesson reference:** Section 5, Step 1

**Correct answer: A. Framing the problem and making the final decision to ship.**

**Why this is correct:** Problem definition and final judgment require human accountability. Section 5, Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Framing the problem and making the final decision to ship. | **Correct** | Problem definition and final judgment require human accountability. Section 5, Step 1. |
| B | Divergence, where the assistant generates flows and options quickly. | Incorrect | Generating options is stage 2, where AI is explicitly allowed to act as an assistant. |
| C | Drafting variants of copy, flows and critique prompts for review. | Incorrect | Drafting flow, copy or critique variants is AI's intended role in stage 2, before selection. |
| D | First-pass critique, where findings are drafted for a human to check. | Incorrect | AI acts as a first-pass checker in stage 4; a human still verifies findings and makes the decision. |

**If the learner chose otherwise:** revisit Section 5, Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. What makes a prompt reusable?

**Type:** applied · **Lesson reference:** Section 5, Step 2

**Correct answer: C. It has placeholders, constraints, an output format and a verification instruction.**

**Why this is correct:** Templates need structure and checks to transfer across tasks. Section 5, Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It is long, with several paragraphs of context before the task. | Incorrect | A long prompt can still be vague; reusability comes from placeholders, constraints, output format and a verification instruction. |
| B | It mentions a specific model, so the output stays consistent. | Incorrect | Naming a model ties the prompt to one tool and breaks it when models change. |
| C | It has placeholders, constraints, an output format and a verification instruction. | **Correct** | Templates need structure and checks to transfer across tasks. Section 5, Step 2. |
| D | It was written by an expert, so its structure is implicitly sound. | Incorrect | Authorship is not reusability; the template still needs placeholders and verification instructions to transfer across tasks. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. What is automation bias?

**Type:** problem · **Lesson reference:** Section 2

**Correct answer: D. Trusting automated output more than the available evidence actually warrants.**

**Why this is correct:** It is a human tendency that verification gates counter. Section 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Refusing to use automated tools at all because they feel untrustworthy. | Incorrect | Refusing tools is avoidance, not bias; automation bias leans toward trusting output too readily. |
| B | Automating a workflow so that fewer human steps are needed each time. | Incorrect | Automation is a process choice, not the human tendency to over-trust results. |
| C | Treating it as a bias in training data rather than in the user. | Incorrect | The lesson defines it as a human tendency, not a training-data defect, which is why verification gates are needed. |
| D | Trusting automated output more than the available evidence actually warrants. | **Correct** | It is a human tendency that verification gates counter. Section 2. |

**If the learner chose otherwise:** revisit Section 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. What is a verification gate?

**Type:** applied · **Lesson reference:** Section 5, Step 4

**Correct answer: B. A binary checkpoint that output must pass before it proceeds.**

**Why this is correct:** Gates are pass/fail, not advisory. Section 5, Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A suggestion to check the output later, once the sprint is finished. | Incorrect | Advisory checks are what a gate replaces; a gate is binary, pass or rework. |
| B | A binary checkpoint that output must pass before it proceeds. | **Correct** | Gates are pass/fail, not advisory. Section 5, Step 4. |
| C | A prompt that asks the assistant to verify its own previous answer. | Incorrect | A prompt requests output; a gate judges whether that output may proceed. |
| D | A design review meeting where the team discusses the screen. | Incorrect | A meeting is a forum; the gate is a specific pass/fail checkpoint with stated criteria. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. Which data should never be pasted into a consumer AI tool?

**Type:** problem · **Lesson reference:** Section 5, Step 6

**Correct answer: D. A participant's name, phone number and home address.**

**Why this is correct:** Personal data is never safe to paste without explicit approval and anonymisation. Section 5, Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Public documentation that anyone can download from the vendor site. | Incorrect | Public documentation is the public class, usable with normal care under the lesson's data table. |
| B | Your own published portfolio, already visible to anyone online. | Incorrect | Your own published portfolio is already public, so it carries no personal or confidential exposure. |
| C | A public competitor screenshot taken from their marketing page. | Incorrect | A public competitor screenshot is published material, allowed under the public class rule. |
| D | A participant's name, phone number and home address. | **Correct** | Personal data is never safe to paste without explicit approval and anonymisation. Section 5, Step 6. |

**If the learner chose otherwise:** revisit Section 5, Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. Why keep prompts in plain text outside a tool?

**Type:** best · **Lesson reference:** Section 5, Step 8

**Correct answer: A. To survive tool churn and keep the workflow portable across vendors.**

**Why this is correct:** Portability protects against vendor changes. Section 5, Step 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | To survive tool churn and keep the workflow portable across vendors. | **Correct** | Portability protects against vendor changes. Section 5, Step 8. |
| B | To avoid relying on tools, which cannot store prompts for more than one session. | Incorrect | Tools do store prompts; keeping copies outside is about portability, not a missing capability. |
| C | To make each prompt longer and more detailed than a saved version. | Incorrect | Plain text does not lengthen prompts; it protects them when the vendor or model changes. |
| D | To share the prompts publicly as a portfolio of your AI practice. | Incorrect | Sharing is optional; the reason is surviving tool churn and re-testing prompts when models change. |

**If the learner chose otherwise:** revisit Section 5, Step 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. How should productivity be measured?

**Type:** applied · **Lesson reference:** Section 5, Step 7

**Correct answer: C. By total time, defects, rework and quality against the criteria.**

**Why this is correct:** Honest measurement includes the cost of fixing output. Section 5, Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | By the tool's claims about how much faster designers usually work. | Incorrect | Vendor marketing is unmeasured; the lesson asks for your own time, defect and rework data. |
| B | By the number of prompts sent during a typical working day. | Incorrect | Prompt count measures activity, not saved effort or quality against the rubric. |
| C | By total time, defects, rework and quality against the criteria. | **Correct** | Honest measurement includes the cost of fixing output. Section 5, Step 7. |
| D | By the number of outputs produced in a single session. | Incorrect | Output volume says nothing about defects, rework or quality against the rubric. |

**If the learner chose otherwise:** revisit Section 5, Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. Which is a valid "do not use AI" rule?

**Type:** best · **Lesson reference:** Section 5, Step 5

**Correct answer: B. "Do not use AI to generate user quotes or interview findings."**

**Why this is correct:** Fabricated evidence is a categorical no. Section 5, Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | "Never use AI for anything, because every output needs checking anyway." | Incorrect | A blanket ban gives no fallback and ignores the stages where AI is legitimately an assistant. |
| B | "Do not use AI to generate user quotes or interview findings." | **Correct** | Fabricated evidence is a categorical no. Section 5, Step 5. |
| C | "Only use AI on Mondays, when the team has time to review outputs." | Incorrect | A calendar rule is arbitrary and names no risk, data class or fallback. |
| D | "Do not use AI for colour, because palettes should come from the system." | Incorrect | Colour is not one of the listed risk categories; the rule would block harmless work without protecting anything. |

**If the learner chose otherwise:** revisit Section 5, Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A learner wants a reusable prompt for critiquing screens. Which addition makes the prompt most reusable?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: D. A fixed structure with role, criteria, evidence, output format and verification.**

**Why this is correct:** Structure and checks let the prompt transfer across screens without losing accountability.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A longer list of adjectives describing what good design should feel like. | Incorrect | Adjectives like clean and modern give the critic no measurable criterion or evidence to check. |
| B | A request to be as confident as possible so the critique sounds decisive. | Incorrect | Confidence increases assertion, not verification; the lesson warns against deferring to it. |
| C | A rule to accept the first answer, saving time on repeated reviews. | Incorrect | Accepting the first answer removes the verification step and invites the automation bias the course warns about. |
| D | A fixed structure with role, criteria, evidence, output format and verification. | **Correct** | Structure and checks let the prompt transfer across screens without losing accountability. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A team adopts AI output without review because the tool is usually right. Which risk is this?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: A. Automation bias, where people over-trust automated output and stop checking.**

**Why this is correct:** Verification gates exist to counter the human tendency to defer to automation.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Automation bias, where people over-trust automated output and stop checking. | **Correct** | Verification gates exist to counter the human tendency to defer to automation. |
| B | Scope creep, where the project grows beyond the agreed problem statement. | Incorrect | Scope creep is work expanding beyond the agreed problem, not a team over-trusting tool output. |
| C | Design system drift, where components gradually diverge from the tokens. | Incorrect | Design system drift is components diverging from tokens and spacing rules, not a team skipping review. |
| D | Low contrast, where text fails the minimum ratio against its background. | Incorrect | Low contrast is a specific accessibility defect, not the habit of accepting output unreviewed. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- Five stages with human decisions identified. — with a file, screenshot, link or log that a stranger can inspect.
- Five prompt templates with constraints and verification. — with a file, screenshot, link or log that a stranger can inspect.
- Decision log with three real entries. — with a file, screenshot, link or log that a stranger can inspect.
- Five binary verification gates. — with a file, screenshot, link or log that a stranger can inspect.
- Five do-not rules with fallbacks. — with a file, screenshot, link or log that a stranger can inspect.
- Data classification table. — with a file, screenshot, link or log that a stranger can inspect.
- One honest measurement. — with a file, screenshot, link or log that a stranger can inspect.
- A reflection naming a real risk and mitigation. — with a file, screenshot, link or log that a stranger can inspect.
- No unmeasured productivity claim. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
