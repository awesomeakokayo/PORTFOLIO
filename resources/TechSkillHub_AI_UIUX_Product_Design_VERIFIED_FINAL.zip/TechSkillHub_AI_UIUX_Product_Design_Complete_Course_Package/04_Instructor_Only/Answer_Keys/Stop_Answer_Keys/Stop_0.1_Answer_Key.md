# Answer Key — Stop 0.1: Your Workspace

**Instructor use only. Do not distribute.**
**Phase:** 0 · Getting started
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | D | judgment | Section 5, Step 1 |
| Q2 | B | applied | Section 5, Step 3 |
| Q3 | B | problem | Section 5, Step 4 and section 7, step 6 |
| Q4 | C | applied | Section 5, Step 4 |
| Q5 | B | problem | Section 5, Step 6 |
| Q6 | C | best | Section 5, Step 7 |
| Q7 | C | applied | Section 5, Step 2 |
| Q8 | C | best | Section 6 |
| Q9 | D | applied | Section 5 (worked steps) |
| Q10 | C | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. What is the main reason for choosing a single "source of truth" folder?

**Type:** judgment · **Lesson reference:** Section 5, Step 1

**Correct answer: D. It prevents two copies of the same work from competing as the official version of the file.**

**Why this is correct:** A source of truth prevents version confusion. It does not by itself guarantee backup, and names are still needed. Section 5, Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It makes the folder structure look tidy and consistent in the screenshots you submit for review. | Incorrect | Tidiness in a screenshot is cosmetic; Step 1 picks one official copy so you and any reviewer know which version is real, not so the folder looks neat. |
| B | It removes the need for descriptive file names because the folder itself records what each item is. | Incorrect | Names still carry what changed and when; the date-first naming rule in Step 3 applies inside whichever folder you choose as the source of truth. |
| C | It guarantees that every file is backed up automatically even if the computer is lost or replaced. | Incorrect | A computer-first source of truth lives only on that machine, so it still needs the weekly zip backup or cloud copy described in section 13. |
| D | It prevents two copies of the same work from competing as the official version of the file. | **Correct** | A source of truth prevents version confusion. It does not by itself guarantee backup, and names are still needed. Section 5, Step 1. |

**If the learner chose otherwise:** revisit Section 5, Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. Which file name follows the course naming rule?

**Type:** applied · **Lesson reference:** Section 5, Step 3

**Correct answer: B. `2026-11-02_sendmoney_home-screen_v1.fig`, saved directly inside the project's design folder.**

**Why this is correct:** Date first, hyphens instead of spaces, version at the end. Section 5, Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | `final design new.fig`, saved on the desktop after the latest changes. | Incorrect | It uses spaces, the banned word "final" and the vague word "new", with no date first and no version at the end. |
| B | `2026-11-02_sendmoney_home-screen_v1.fig`, saved directly inside the project's design folder. | **Correct** | Date first, hyphens instead of spaces, version at the end. Section 5, Step 3. |
| C | `SendMoney-final-v2.fig`, saved in the shared team folder for review. | Incorrect | It has no date to sort by and uses "final" instead of a version like v1 or v2, which Step 3 forbids. |
| D | `home screen.fig`, saved in Downloads immediately after the export finished. | Incorrect | It is only an item name containing a space: no date, project or version, so it cannot sort chronologically. |

**If the learner chose otherwise:** revisit Section 5, Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. You close the browser tab of a cloud design tool and reopen the site. The work is missing. Which cause is least likely?

**Type:** problem · **Lesson reference:** Section 5, Step 4 and section 7, step 6

**Correct answer: B. The file name put a date first, ahead of the project name and the version number.**

**Why this is correct:** A date prefix cannot cause a file to disappear. The other three are common causes. Section 5, Step 4 and section 7, step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | You are signed into a different account from the one that created the file. | Incorrect | Being signed into a different account is the first cause section 7 lists for a file that cannot be found after reopening the browser. |
| B | The file name put a date first, ahead of the project name and the version number. | **Correct** | A date prefix cannot cause a file to disappear. The other three are common causes. Section 5, Step 4 and section 7, step 6. |
| C | The file sits in a team or project space that is not currently open in the view. | Incorrect | A file created in a team or project space you are not viewing is the third cause named in section 7, so it is plausible. |
| D | The autosave never completed because the connection dropped while you were still editing the file. | Incorrect | An interrupted autosave because the connection dropped is the second cause section 7 names, so it is a plausible explanation. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and section 7, step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. What is the difference between "Download" and "Export"?

**Type:** applied · **Lesson reference:** Section 5, Step 4

**Correct answer: C. Download copies a file to your device; export creates a file in a different format.**

**Why this is correct:** Download brings a copy to your device; export converts to another format such as PNG. Section 5, Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Export only works for text files, while download handles images and every other kind of media. | Incorrect | Export is not limited to text; the lesson's own example is producing a PNG from a Figma frame. |
| B | They are the same action with different buttons, so either one produces an identical copy. | Incorrect | Download copies bytes to your device while export renders a different format, such as a PNG from a Figma frame; Step 4 treats them as separate actions. |
| C | Download copies a file to your device; export creates a file in a different format. | **Correct** | Download brings a copy to your device; export converts to another format such as PNG. Section 5, Step 4. |
| D | Download only works for images, while export converts text into a printable document. | Incorrect | Download works for any file, including notes and the practice image pack, so it is not limited to images. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. Why should you avoid writing real passwords in a plain text file?

**Type:** problem · **Lesson reference:** Section 5, Step 6

**Correct answer: B. Anyone who gets access to the device or the cloud account can read them.**

**Why this is correct:** Plain text is readable by anyone who gets the device or account. Use hints or a password manager. Section 5, Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Text files cannot be opened again later, so the passwords would be lost permanently. | Incorrect | Plain text files open in any editor; the danger is that other people can open them too, not that they become unreadable. |
| B | Anyone who gets access to the device or the cloud account can read them. | **Correct** | Plain text is readable by anyone who gets the device or account. Use hints or a password manager. Section 5, Step 6. |
| C | Passwords stored in text files stop autosave from working in the browser. | Incorrect | Autosave depends on being signed in and online, which has nothing to do with what words are stored in the file. |
| D | The file becomes too large to open on an older computer or phone. | Incorrect | A password adds a few characters, so the file stays small; Step 6's risk is exposure to anyone with the device or account. |

**If the learner chose otherwise:** revisit Section 5, Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. Which behaviour best reduces data use while studying?

**Type:** best · **Lesson reference:** Section 5, Step 7

**Correct answer: C. Setting video quality manually and downloading the notes once on Wi-Fi.**

**Why this is correct:** Manual quality and one-time downloads reduce repeated data. Section 5, Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Leaving autoplay switched on so you never have to press play yourself. | Incorrect | Autoplay keeps video streaming without you choosing it, so it spends data; Step 7 says turn autoplay off. |
| B | Watching every video at the highest quality so nothing looks blurred. | Incorrect | Highest quality uses the most data per minute; Step 7 says set 360p or 480p manually rather than relying on Auto. |
| C | Setting video quality manually and downloading the notes once on Wi-Fi. | **Correct** | Manual quality and one-time downloads reduce repeated data. Section 5, Step 7. |
| D | Keeping twenty tabs open so you can return to them later in the week. | Incorrect | Open tabs keep downloading in the background, which Step 7 lists as a reason to close tabs you are not using. |

**If the learner chose otherwise:** revisit Section 5, Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. A folder tree separates lessons, exercises, projects, research and exports. Which is the strongest reason?

**Type:** applied · **Lesson reference:** Section 5, Step 2

**Correct answer: C. Different kinds of work need different handling, and evidence must stay findable later.**

**Why this is correct:** Separation supports retrieval and evidence, not file-count reduction. Section 5, Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It keeps the total number of files on the computer much smaller over time. | Incorrect | The tree does not reduce how many files exist; it separates input, practice, evidence and output so the right file can be found. |
| B | Reviewers require exactly six top-level folders before they will pass a project. | Incorrect | Six folders is a suggested structure; the pass criteria accept a documented equivalent that serves the same purposes. |
| C | Different kinds of work need different handling, and evidence must stay findable later. | **Correct** | Separation supports retrieval and evidence, not file-count reduction. Section 5, Step 2. |
| D | Cloud storage only allows six folders, so the tree has to match that limit. | Incorrect | Cloud storage has no six-folder limit; the six come from the lesson's split of input, practice, evidence and output. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. You are on a shared computer and cannot rely on local files surviving. What is the most sensible workspace decision?

**Type:** best · **Lesson reference:** Section 6

**Correct answer: C. Use a cloud folder as the source of truth and sign out when you finish.**

**Why this is correct:** Cloud storage plus signing out protects access and persistence on a shared machine. Section 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Keep everything in the Downloads folder because it opens fastest on that machine. | Incorrect | Downloads is the browser's default dumping ground and mixes with everything else on a shared machine, the first mistake in section 11. |
| B | Email the files to yourself and delete the originals so nothing is left behind. | Incorrect | Emailing copies and deleting the originals leaves no working file and no folder structure, so the design and evidence are gone. |
| C | Use a cloud folder as the source of truth and sign out when you finish. | **Correct** | Cloud storage plus signing out protects access and persistence on a shared machine. Section 6. |
| D | Save only screenshots of your work so the other user cannot open the files. | Incorrect | Screenshots are images, not editable design files, so the actual work and its research trail would be lost. |

**If the learner chose otherwise:** revisit Section 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A learner keeps the official course folder in the cloud but edits a downloaded copy on the Desktop for a week. What should they do to restore one source of truth?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: D. Upload the edited copy, replace the cloud version, and delete the Desktop copy once checked.**

**Why this is correct:** The cloud folder was declared the source of truth, so the edited work must return there and the competing copy must be removed.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Keep both copies and add the word final to the Desktop file name before submitting. | Incorrect | Adding "final" creates a second competing official version, and Step 3 bans that word precisely because it settles nothing. |
| B | Delete the cloud folder and work only on the Desktop copy from now on, permanently. | Incorrect | Deleting the cloud folder destroys the declared source of truth and leaves only a machine-local copy, exactly what the shared-laptop example warns against. |
| C | Email the Desktop copy to yourself and leave both folders unchanged for another week. | Incorrect | Emailing a copy changes nothing on disk: both folders still hold versions and neither is declared official. |
| D | Upload the edited copy, replace the cloud version, and delete the Desktop copy once checked. | **Correct** | The cloud folder was declared the source of truth, so the edited work must return there and the competing copy must be removed. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A learner saved a Figma file yesterday but cannot see it in Recents today. They are signed into the same account. Which check is most likely to explain the disappearance?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: C. Check whether the file sits in a team or project space that is not currently open.**

**Why this is correct:** Files in team/project spaces may not appear in the current Recents view; checking the workspace breadcrumb or search is the first diagnostic.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Assume Figma deleted the file because the name contained a date at the start. | Incorrect | Figma does not delete files for having a date in the name; the naming rule requires a date at the front. |
| B | Create a new account and start the same file again from the beginning of the process. | Incorrect | A new account means a new empty workspace, and the existing file stays with the old account; check the avatar first. |
| C | Check whether the file sits in a team or project space that is not currently open. | **Correct** | Files in team/project spaces may not appear in the current Recents view; checking the workspace breadcrumb or search is the first diagnostic. |
| D | Clear the browser cache completely before searching for the file in Recents again. | Incorrect | Clearing the cache does not move a file into view and may sign you out; the lesson checks the account, then the team breadcrumb. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- A single source of truth is named in the checklist. — with a file, screenshot, link or log that a stranger can inspect.
- The folder tree contains the six top-level folders and Phase 0–7 subfolders, or a documented equivalent that serves the same purposes. — with a file, screenshot, link or log that a stranger can inspect.
- At least four files use the naming rule with date, project, item and version. — with a file, screenshot, link or log that a stranger can inspect.
- The checklist records the selected tools and confirms each chosen account is ready; if the no-AI route is used, it is recorded as a valid choice. No email addresses, passwords or tokens appear. — with a file, screenshot, link or log that a stranger can inspect.
- The screenshot shows the folders expanded, not just a closed parent folder. — with a file, screenshot, link or log that a stranger can inspect.
- The recovered file is named and the recovery method is described in one sentence. — with a file, screenshot, link or log that a stranger can inspect.
- The exported PNG opens and is not blank. — with a file, screenshot, link or log that a stranger can inspect.
- No personal or client data appears in the AI chat screenshot (if the AI route is used) or the checklist. If the no-AI route is used, the equivalent written explanation and any source notes contain no personal data. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
