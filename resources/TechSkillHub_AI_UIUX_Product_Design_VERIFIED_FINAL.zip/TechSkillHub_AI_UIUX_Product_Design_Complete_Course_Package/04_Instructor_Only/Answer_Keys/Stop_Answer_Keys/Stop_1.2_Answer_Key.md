# Answer Key — Stop 1.2: User Research Basics

**Instructor use only. Do not distribute.**
**Phase:** 1 · Product thinking and research
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | D | judgment | Section 5, Step 2 |
| Q2 | C | applied | Section 2 |
| Q3 | D | problem | Section 5, Step 1 |
| Q4 | D | applied | Section 5, Step 4 |
| Q5 | D | problem | Section 5, Step 6 |
| Q6 | D | best | Section 5, Step 7 |
| Q7 | B | applied | Section 3 |
| Q8 | A | best | Section 5, Step 4 |
| Q9 | A | applied | Section 5 (worked steps) |
| Q10 | D | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. Which question is most likely to produce a useful story?

**Type:** judgment · **Lesson reference:** Section 5, Step 2

**Correct answer: D. Tell me about the last time you tried to save money and what made it hard or easy.**

**Why this is correct:** It asks about a specific past behaviour, not an imagined future or a leading opinion. Section 5, Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Would you use a savings app if it reminded you to put money aside every Friday evening? | Incorrect | Asking whether someone would use an app tests imagined future behaviour, and Section 3 notes people answer such questions politely. |
| B | Don't you find saving difficult, given how prices have risen in the market this year? | Incorrect | The wording plants the difficulty the researcher wants confirmed, which is exactly how Section 2 defines a leading question. |
| C | Do you like saving money, or do you prefer to spend it on things you need immediately? | Incorrect | This is a closed opinion question with no specific occasion, so it yields a verdict rather than a story about what happened. |
| D | Tell me about the last time you tried to save money and what made it hard or easy. | **Correct** | It asks about a specific past behaviour, not an imagined future or a leading opinion. Section 5, Step 2. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. What makes a question leading?

**Type:** applied · **Lesson reference:** Section 2

**Correct answer: C. It suggests the answer the researcher wants, so the participant agrees to be helpful and quick.**

**Why this is correct:** Leading questions push the participant toward a preferred answer. Section 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It has more than five words, so the participant must hold too much in mind before answering. | Incorrect | Length is irrelevant, since a brief neutral question can collect a story while a long one can still steer the answer. |
| B | It asks about the past, so the participant reports a memory rather than a current opinion. | Incorrect | Asking about the past is what Step 2 recommends, because memory of a specific event is more reliable than general opinion. |
| C | It suggests the answer the researcher wants, so the participant agrees to be helpful and quick. | **Correct** | Leading questions push the participant toward a preferred answer. Section 2. |
| D | It is asked in an interview rather than a survey, so the researcher is present when answering. | Incorrect | Being in an interview does not steer anyone; the push comes from wording that implies the answer the researcher prefers. |

**If the learner chose otherwise:** revisit Section 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. Which method best answers "how many users abandon at step 2?"

**Type:** problem · **Lesson reference:** Section 5, Step 1

**Correct answer: D. Analytics or a survey, because prevalence needs numbers from a larger sample of users.**

**Why this is correct:** Prevalence needs numbers from a larger sample. Section 5, Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A heuristic evaluation, because an expert reviewer can count the steps where users get stuck. | Incorrect | A heuristic evaluation is an expert review against usability rules, involving no user behaviour and no numbers. |
| B | Two interviews, because two people can explain why they personally abandoned the form. | Incorrect | Two interviews are qualitative: they explain why those people abandoned and produce counts of one or two, not a rate. |
| C | A focus group, because discussion reveals how common the abandonment problem really is. | Incorrect | A focus group discusses opinions in a small group, so it cannot measure how many users abandon at step 2. |
| D | Analytics or a survey, because prevalence needs numbers from a larger sample of users. | **Correct** | Prevalence needs numbers from a larger sample. Section 5, Step 1. |

**If the learner chose otherwise:** revisit Section 5, Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. What must be recorded before an interview begins?

**Type:** applied · **Lesson reference:** Section 5, Step 4

**Correct answer: D. Informed consent, including written permission to take notes and to record the audio if needed.**

**Why this is correct:** Consent is required before collecting data. Section 5, Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The participant's full name and address, so the notes can be matched to the right person later. | Incorrect | Step 4 requires the opposite: record a pseudonym and keep real names, addresses and other identifying details out. |
| B | The final design of the feature, so the participant can react to the screen during the conversation. | Incorrect | A finished design is not needed before interviewing, since the conversation covers a past experience rather than a screen. |
| C | The competitor analysis for the product, so the interview can focus on where rivals do better. | Incorrect | Competitor analysis belongs to Stop 1.4 and plays no part in the consent step before an interview. |
| D | Informed consent, including written permission to take notes and to record the audio if needed. | **Correct** | Consent is required before collecting data. Section 5, Step 4. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. In two-column notes, which belongs in the left column?

**Type:** problem · **Lesson reference:** Section 5, Step 6

**Correct answer: D. I closed it and tried again because it said 'processing' for a long time.**

**Why this is correct:** The left column holds what was said or done; interpretation goes right. Section 5, Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Users want a simpler app, because several participants mentioned that the flow felt long. | Incorrect | This generalises from the interviews, which Step 6 places on the right-hand interpretation side of the page. |
| B | This proves the flow is broken, because nobody completed the transfer without asking for help. | Incorrect | This is the researcher's conclusion rather than a record of what happened, so it belongs with interpretation. |
| C | The design should use a spinner, because waiting without feedback caused most of the doubt. | Incorrect | This is a recommendation about future design, not something the participant said or did during the interview. |
| D | I closed it and tried again because it said 'processing' for a long time. | **Correct** | The left column holds what was said or done; interpretation goes right. Section 5, Step 6. |

**If the learner chose otherwise:** revisit Section 5, Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. Two interviews both mention calling the recipient before sending money. What is the most honest finding?

**Type:** best · **Lesson reference:** Section 5, Step 7

**Correct answer: D. 2 of 2 participants in this practice sample used a second channel to confirm the recipient.**

**Why this is correct:** It reports the sample and behaviour without overgeneralising. Section 5, Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | All Nigerian users distrust banks, as shown by both participants calling before they send. | Incorrect | It generalises two interviewees to a whole nationality, which Step 7 forbids when writing findings from two interviews. |
| B | Users want a photo of the recipient, since both participants checked the name before paying. | Incorrect | A photo is an untested hypothesis here: no participant was shown one, so the claim cannot be a finding. |
| C | The app is unusable, because both participants needed another channel to feel confident. | Incorrect | "Unusable" goes too far, since both participants completed transfers and only added a confirmation call as a workaround. |
| D | 2 of 2 participants in this practice sample used a second channel to confirm the recipient. | **Correct** | It reports the sample and behaviour without overgeneralising. Section 5, Step 7. |

**If the learner chose otherwise:** revisit Section 5, Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. What is the main risk of asking "Would you use this feature?"

**Type:** applied · **Lesson reference:** Section 3

**Correct answer: B. People tend to say yes to imagined future use, which is weak evidence of real behaviour.**

**Why this is correct:** Hypothetical enthusiasm is a poor predictor of behaviour. Section 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It takes too long to answer, so the interview runs over and later questions get rushed. | Incorrect | The question takes seconds to ask, so duration is not the risk; the weakness is the answer it produces. |
| B | People tend to say yes to imagined future use, which is weak evidence of real behaviour. | **Correct** | Hypothetical enthusiasm is a poor predictor of behaviour. Section 3. |
| C | It requires a survey tool, so the interview cannot be run in person with written notes. | Incorrect | No survey tool is involved; it is one spoken question inside an interview conducted in person. |
| D | It is illegal without written consent, so the researcher must get approval before asking it. | Incorrect | Asking it is legal and common; Section 3 objects that the yes is weak evidence, not that the question breaks a rule. |

**If the learner chose otherwise:** revisit Section 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. Why keep the consent record separate from the notes?

**Type:** best · **Lesson reference:** Section 5, Step 4

**Correct answer: A. Because the consent record may contain identifying details that must not travel with anonymised notes.**

**Why this is correct:** Separation protects privacy if notes are shared. Section 5, Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Because the consent record may contain identifying details that must not travel with anonymised notes. | **Correct** | Separation protects privacy if notes are shared. Section 5, Step 4. |
| B | To save space, because the notes file should stay short enough to read during the analysis. | Incorrect | Storage is not the reason; separating them keeps identifying details away from notes that get shared or published. |
| C | Because Figma requires it, since shared design files are not allowed to hold participant information. | Incorrect | Figma plays no part in consent records, which are written text kept privately by the researcher. |
| D | Because consent expires in 24 hours, so the record is useless once the interview is over. | Incorrect | Consent does not expire after a day; the lesson records date, method and permissions without setting any expiry. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A learner wants to understand why people abandon a money-transfer form. Which interview question is most useful?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: A. Tell me about the last time you started a transfer and did not finish it. What happened?**

**Why this is correct:** It asks for a specific past behaviour and invites a story without leading.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Tell me about the last time you started a transfer and did not finish it. What happened? | **Correct** | It asks for a specific past behaviour and invites a story without leading. |
| B | Would you finish the form if it had fewer steps and a clearer summary before you confirm? | Incorrect | It asks about imagined future behaviour in a redesigned flow, not about the abandonment that actually happened. |
| C | Do you agree the form is too long, and that the summary arrives far too late in the flow? | Incorrect | It is leading, handing the participant the conclusion that the form is long before they describe anything. |
| D | Why do users always abandon forms, and what should the team change to stop that happening? | Incorrect | It asks about users in the abstract and opens with a why that can feel like an accusation. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A learner interviews two friends who say they would use a new feature, then reports 'users want this feature'. What is the main research error?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: D. Hypothetical enthusiasm from two people is being presented as evidence of a broader need.**

**Why this is correct:** The sample is tiny and the statement is about imagined future behaviour, not observed behaviour.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The learner should have used a survey instead of interviews, so the sample could be larger. | Incorrect | A survey would not fix it: the friends were asked about future use, and surveying the same hypothetical repeats the error. |
| B | Two interviews are never useful, so the learner should have run at least ten before reporting. | Incorrect | Two interviews are useful for themes, and the course pack itself uses two, so the sample size alone is not the mistake. |
| C | The learner did not record the friends' names, so the findings cannot be traced back later. | Incorrect | Real names must not be collected at all, since anonymisation is required, so missing names cannot be the error. |
| D | Hypothetical enthusiasm from two people is being presented as evidence of a broader need. | **Correct** | The sample is tiny and the statement is about imagined future behaviour, not observed behaviour. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- Two real practice interviews, or an honest statement that one did not happen. — with a file, screenshot, link or log that a stranger can inspect.
- A discussion guide with at least seven open, non-leading questions. — with a file, screenshot, link or log that a stranger can inspect.
- Two-column notes for each interview. — with a file, screenshot, link or log that a stranger can inspect.
- Consent recorded for each participant, with no real names in the notes. — with a file, screenshot, link or log that a stranger can inspect.
- 3–5 themes, each with a count, a direct quote and a separate interpretation. — with a file, screenshot, link or log that a stranger can inspect.
- A Limits section that names who was not included and what cannot be concluded. — with a file, screenshot, link or log that a stranger can inspect.
- No fabricated participant, quote, number or finding. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
