# Answer Key — Stop 4.6: Verification and Judgment

**Instructor use only. Do not distribute.**
**Phase:** 4 · The AI design workflow
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | D | judgment | Section 2 |
| Q2 | C | applied | Section 5, Step 1 |
| Q3 | D | problem | Section 5, Step 3 |
| Q4 | A | applied | Section 5, Step 5 |
| Q5 | A | problem | Section 5, Step 7 |
| Q6 | C | best | Section 5, Step 9 |
| Q7 | A | applied | Section 5, Step 6 |
| Q8 | A | best | Section 5, Step 8 |
| Q9 | D | applied | Section 5 (worked steps) |
| Q10 | D | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. Which is the best definition of plausibility?

**Type:** judgment · **Lesson reference:** Section 2

**Correct answer: D. How believable something looks, which is not proof that it is correct.**

**Why this is correct:** Plausibility is appearance, not truth. Section 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | How accessible a design is for users with low vision or motor limits. | Incorrect | Accessibility is a measurable design property about who can use the screen, not how believable the output looks. |
| B | How fast a screen loads on a slow connection with limited data. | Incorrect | Load speed is performance, while plausibility is about how convincing something appears, which can be false. |
| C | How consistent a component is with the rest of the design system. | Incorrect | Consistency is about similar elements matching, while plausibility concerns whether the output seems true or merely convincing. |
| D | How believable something looks, which is not proof that it is correct. | **Correct** | Plausibility is appearance, not truth. Section 2. |

**If the learner chose otherwise:** revisit Section 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. A generated screen says "87% of users prefer this". What is the first check?

**Type:** applied · **Lesson reference:** Section 5, Step 1

**Correct answer: C. Whether the claim has a traceable source in real data.**

**Why this is correct:** Unsourced statistics are a critical integrity failure. Section 5, Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Whether the number looks realistic for a product of this size. | Incorrect | Precise-looking numbers are exactly what makes invented statistics convincing, so realism is not evidence of a source. |
| B | Whether the font is large enough for the figure to be read. | Incorrect | Typography is a separate check; the claim's source is the integrity question here. |
| C | Whether the claim has a traceable source in real data. | **Correct** | Unsourced statistics are a critical integrity failure. Section 5, Step 1. |
| D | Whether the colour of the figure is on-brand and consistent. | Incorrect | Brand colour is a visual check; it says nothing about whether the 87% figure traces to real data. |

**If the learner chose otherwise:** revisit Section 5, Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. Which is an accessibility failure commonly found in generated UI?

**Type:** problem · **Lesson reference:** Section 5, Step 3

**Correct answer: D. Light grey 12 px text that measures only 2.6:1 against white.**

**Why this is correct:** Low contrast and tiny text are common generated defects. Section 5, Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A 48 px button that exceeds the minimum target size for touch. | Incorrect | 48 px exceeds the 44 px minimum, so it is accessible rather than a failure. |
| B | A visible focus ring that appears when the user tabs to a control. | Incorrect | A visible focus ring is required for keyboard users and is correct practice, not a defect. |
| C | A persistent label that stays above the field while the user types. | Incorrect | Persistent labels are the lesson's fix for placeholder-only fields, so this is good practice. |
| D | Light grey 12 px text that measures only 2.6:1 against white. | **Correct** | Low contrast and tiny text are common generated defects. Section 5, Step 3. |

**If the learner chose otherwise:** revisit Section 5, Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. Why is a "Try again" button dangerous on an unknown payment outcome?

**Type:** applied · **Lesson reference:** Section 5, Step 5

**Correct answer: A. It may duplicate a transfer that has already succeeded at the bank.**

**Why this is correct:** Unknown outcomes need a status check. Section 5, Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It may duplicate a transfer that has already succeeded at the bank. | **Correct** | Unknown outcomes need a status check. Section 5, Step 5. |
| B | It is too small for a primary action and hard to tap accurately. | Incorrect | Target size is a different check; the danger is behavioural, not dimensional. |
| C | It is not accessible to screen reader users in its current state. | Incorrect | Accessibility concerns who can perceive and operate the control, not what retry does to the payment. |
| D | It is not part of the design system, so it will look inconsistent. | Incorrect | Component status is irrelevant; a system-compliant retry can still duplicate a transfer. |

**If the learner chose otherwise:** revisit Section 5, Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. What makes a review finding defensible?

**Type:** problem · **Lesson reference:** Section 5, Step 7

**Correct answer: A. It names the element, the evidence and the standard or user effect.**

**Why this is correct:** Evidence and specificity make a finding reviewable. Section 5, Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It names the element, the evidence and the standard or user effect. | **Correct** | Evidence and specificity make a finding reviewable. Section 5, Step 7. |
| B | It is written confidently, in language that sounds expert to stakeholders. | Incorrect | Confidence is not evidence; the lesson warns against letting assurance replace proof. |
| C | It uses technical terms that show familiarity with accessibility standards. | Incorrect | Technical terms can obscure a finding; they add no element, evidence or standard that a reviewer could check. |
| D | It comes from an AI critic that has reviewed many similar screens. | Incorrect | AI output still needs an element, evidence and a standard before anyone should act on it. |

**If the learner chose otherwise:** revisit Section 5, Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. What is a regression check?

**Type:** best · **Lesson reference:** Section 5, Step 9

**Correct answer: C. Confirming that a fix did not introduce a new problem elsewhere.**

**Why this is correct:** Fixes can break other states or elements. Section 5, Step 9.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Re-running the original AI prompt to see whether the output stays stable. | Incorrect | Re-running the prompt reproduces output; it does not test whether a fix broke a state. |
| B | Checking the file size and export settings before the handover meeting. | Incorrect | File size is storage, unrelated to whether the change created a new problem. |
| C | Confirming that a fix did not introduce a new problem elsewhere. | **Correct** | Fixes can break other states or elements. Section 5, Step 9. |
| D | Comparing two AI models to see which one produces fewer defects. | Incorrect | Comparing two models evaluates tools; it does not test whether your fix broke a state or an element. |

**If the learner chose otherwise:** revisit Section 5, Step 9 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. A screen is visually impressive but has invented social proof and no error state. What should you do?

**Type:** applied · **Lesson reference:** Section 5, Step 6

**Correct answer: A. Reject it until the integrity and flow failures are fixed, whatever it looks like.**

**Why this is correct:** Critical integrity and flow failures cannot be averaged away. Section 5, Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Reject it until the integrity and flow failures are fixed, whatever it looks like. | **Correct** | Critical integrity and flow failures cannot be averaged away. Section 5, Step 6. |
| B | Add more decoration so the screen feels more finished before release. | Incorrect | Decoration cannot fix invented evidence or a missing error state, and it adds to the generic style problem. |
| C | Ask the AI to make the layout prettier and keep the current content. | Incorrect | Polish does not remove fabricated proof or supply the absent failure path. |
| D | Ship it, because visual quality is what users judge in the first seconds. | Incorrect | Visual impressiveness is the trap; invented social proof and no error state are critical failures. |

**If the learner chose otherwise:** revisit Section 5, Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. What should a fix rationale contain?

**Type:** best · **Lesson reference:** Section 5, Step 8

**Correct answer: A. The change, the user effect and the reason for making it.**

**Why this is correct:** Rationale connects craft to judgment. Section 5, Step 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The change, the user effect and the reason for making it. | **Correct** | Rationale connects craft to judgment. Section 5, Step 8. |
| B | The tool used and its version, so the output can be reproduced. | Incorrect | Tool and date belong in the provenance record, not in the rationale for a specific fix. |
| C | The file name and folder, so reviewers can find the corrected screen. | Incorrect | A filename identifies the artefact; it does not explain the user effect or the reason. |
| D | The colour code only, since the change is visible in the file. | Incorrect | A value names the change but omits the user effect and reason, which the rationale requires. |

**If the learner chose otherwise:** revisit Section 5, Step 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A generated screen has an invented testimonial, no error state and a low-contrast button. Which issue must be fixed before any aesthetic discussion?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: D. The invented testimonial, because fabricated evidence is a critical integrity failure.**

**Why this is correct:** Integrity failures override aesthetic preferences and cannot be averaged away.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The button colour, because visual polish shapes the first impression. | Incorrect | Contrast is a real accessibility issue, but polish cannot outrank fabricated evidence in the severity order. |
| B | The spacing between sections, which makes the page feel unfinished. | Incorrect | Spacing is cosmetic polish, while the invented testimonial is a critical integrity failure that blocks acceptance. |
| C | The choice of font, which affects how trustworthy the content appears. | Incorrect | Font selection is aesthetic; unsourced testimonial evidence has to be fixed first. |
| D | The invented testimonial, because fabricated evidence is a critical integrity failure. | **Correct** | Integrity failures override aesthetic preferences and cannot be averaged away. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A learner fixes a button label but does not re-check the loading state, which now overlaps the new text. What check was missed?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: D. A regression check across the states and sizes the change affected.**

**Why this is correct:** A fix can break other states; the change must be re-tested in context.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A competitor review, comparing the screen with two rival products. | Incorrect | Comparing rivals does not detect an overlap caused by your own label change. |
| B | A brand colour audit, checking the palette against the guidelines. | Incorrect | A colour audit is unrelated to a loading state colliding with the new text. |
| C | A user interview, asking people what they think of the new label. | Incorrect | Interviews gather user views; they do not test a layout regression after a fix. |
| D | A regression check across the states and sizes the change affected. | **Correct** | A fix can break other states; the change must be re-tested in context. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- Three screens reviewed with annotations. — with a file, screenshot, link or log that a stranger can inspect.
- Findings table with type, element, evidence, severity and fix. — with a file, screenshot, link or log that a stranger can inspect.
- All five failure types addressed or explicitly checked. — with a file, screenshot, link or log that a stranger can inspect.
- Two corrected screens. — with a file, screenshot, link or log that a stranger can inspect.
- A rationale for every fix. — with a file, screenshot, link or log that a stranger can inspect.
- A regression check. — with a file, screenshot, link or log that a stranger can inspect.
- A personal checklist with a stop rule. — with a file, screenshot, link or log that a stranger can inspect.
- No invented finding, and no unsourced claim left in a corrected screen. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
