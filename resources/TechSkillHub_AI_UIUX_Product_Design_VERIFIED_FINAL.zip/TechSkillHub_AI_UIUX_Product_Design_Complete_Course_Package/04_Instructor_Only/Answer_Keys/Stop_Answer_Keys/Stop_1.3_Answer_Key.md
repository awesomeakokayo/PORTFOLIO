# Answer Key — Stop 1.3: Problem Framing

**Instructor use only. Do not distribute.**
**Phase:** 1 · Product thinking and research
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | D | judgment | Section 5, Step 1 |
| Q2 | A | applied | Section 5, Step 2 |
| Q3 | A | problem | Section 5, Step 4 |
| Q4 | A | applied | Section 2 |
| Q5 | A | problem | Section 5, Step 5 |
| Q6 | C | best | Section 5, Step 2 |
| Q7 | C | applied | Section 5, Step 3 |
| Q8 | C | best | Section 5, Step 3 and Step 7 |
| Q9 | B | applied | Section 5 (worked steps) |
| Q10 | C | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. Which is a job story?

**Type:** judgment · **Lesson reference:** Section 5, Step 1

**Correct answer: D. When I pay a new seller, I want to check who I am paying, so I can avoid losing money.**

**Why this is correct:** It has situation, motivation and expected outcome. Section 5, Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | As a user, I want a dashboard, so that I can see my money and check every payment that leaves. | Incorrect | This is a user story, role plus capability, which the glossary calls more solution-shaped than a job story. |
| B | Build a confirmation modal that repeats the amount and the recipient name before the sender finally taps send. | Incorrect | This is a bare instruction naming a component, with no situation, motivation or expected outcome. |
| C | Users need trust, because sending money to a new account feels risky without a visible confirmation before paying. | Incorrect | This states a vague need with no when, no motivation and no outcome to judge a design against. |
| D | When I pay a new seller, I want to check who I am paying, so I can avoid losing money. | **Correct** | It has situation, motivation and expected outcome. Section 5, Step 1. |

**If the learner chose otherwise:** revisit Section 5, Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. What is wrong with "Users need a notification feature" as a problem statement?

**Type:** applied · **Lesson reference:** Section 5, Step 2

**Correct answer: A. It names a solution, not the problem, so no alternative response can be judged against it.**

**Why this is correct:** "Notification feature" is a solution; the underlying problem is missing. Section 5, Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It names a solution, not the problem, so no alternative response can be judged against it. | **Correct** | "Notification feature" is a solution; the underlying problem is missing. Section 5, Step 2. |
| B | It is too short, so it cannot explain who is affected by the missing notification and why. | Incorrect | Brevity is not the test, since a short sentence can be a good problem statement; the named capability is the flaw. |
| C | It has no metric, so nobody can tell whether the notification reduced the confusion it targets. | Incorrect | Metrics belong in Step 4 rather than the problem statement, so a missing metric is not this sentence's defect. |
| D | It is not in English, so the brief cannot be reviewed by the stakeholders who approve scope. | Incorrect | The sentence is entirely in English; the defect is conceptual, because a notification feature is a solution noun. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. A metric has a target but no baseline. What should the brief do?

**Type:** problem · **Lesson reference:** Section 5, Step 4

**Correct answer: A. State that the baseline is unknown and describe how it will be measured before launch.**

**Why this is correct:** An honest unknown plus a measurement plan is acceptable; invention is not. Section 5, Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | State that the baseline is unknown and describe how it will be measured before launch. | **Correct** | An honest unknown plus a measurement plan is acceptable; invention is not. Section 5, Step 4. |
| B | Invent a plausible baseline, because a target only becomes meaningful once it has a number. | Incorrect | Fabricating a baseline is banned in Step 4, which says never to invent one, however plausible the number looks. |
| C | Remove the metric, because a measure without a baseline cannot be tracked or reported. | Incorrect | Deleting the metric abandons the target, while Step 4 keeps it and adds a plan to measure the baseline. |
| D | Use a competitor's number as your baseline, because their data reflects the same market. | Incorrect | A competitor's figure is not your baseline, since product, users and measurement conditions all differ. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. What is a guardrail metric?

**Type:** applied · **Lesson reference:** Section 2

**Correct answer: A. A measure you must not make worse while improving the main metric, such as fraud reports.**

**Why this is correct:** Guardrails protect against harmful side effects, such as fraud rising while support calls fall. Section 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A measure you must not make worse while improving the main metric, such as fraud reports. | **Correct** | Guardrails protect against harmful side effects, such as fraud rising while support calls fall. Section 2. |
| B | The main measure of success, the one number the team watches to judge whether the change worked. | Incorrect | The main success measure is the primary metric; the guardrail is specifically the measure that must not worsen. |
| C | A metric that only applies to accessibility, such as whether labels remain visible at 200% text size. | Incorrect | Guardrails are not accessibility-only, since the lesson's example is fraud reports per 1,000 transfers. |
| D | A target set by the finance team, because money and risk are their responsibility rather than design's. | Incorrect | Finance does not set guardrails; the design team names them to catch harmful side effects of its own change. |

**If the learner chose otherwise:** revisit Section 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. Which is a well-written non-goal?

**Type:** problem · **Lesson reference:** Section 5, Step 5

**Correct answer: A. We will not do social features, because they are not needed for the confirmation job and add moderation cost.**

**Why this is correct:** A non-goal needs a reason tied to scope. Section 5, Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | We will not do social features, because they are not needed for the confirmation job and add moderation cost. | **Correct** | A non-goal needs a reason tied to scope. Section 5, Step 5. |
| B | We will not do social features, because the team has not decided whether they belong in this release. | Incorrect | This pairs an exclusion with indecision rather than a scope reason, and Step 5 says a non-goal without a reason is just a wish. |
| C | Maybe social later, once the confirmation work ships and the team has spare capacity to revisit it. | Incorrect | This leaves the door open, so it protects no scope and commits to no decision about the current release. |
| D | No bad ideas, because the brief should stay open to whatever the team discovers during the research. | Incorrect | This is a slogan about quality, not a named exclusion connected to the confirmation job. |

**If the learner chose otherwise:** revisit Section 5, Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. Why should a problem brief avoid solution nouns?

**Type:** best · **Lesson reference:** Section 5, Step 2

**Correct answer: C. They close off better alternatives and make the problem impossible to judge independently of a fix.**

**Why this is correct:** Keeping the problem solution-agnostic allows cheaper or better responses. Section 5, Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | They make the page longer, because each named component needs a sentence explaining how it works. | Incorrect | Page length is unrelated, since a brief can stay short and still be built from solution nouns. |
| B | They are grammatically incorrect, because a noun cannot follow the verb that introduces the problem. | Incorrect | Solution nouns are grammatically correct, so the objection concerns judgement about the problem rather than grammar. |
| C | They close off better alternatives and make the problem impossible to judge independently of a fix. | **Correct** | Keeping the problem solution-agnostic allows cheaper or better responses. Section 5, Step 2. |
| D | They confuse developers only, because stakeholders read the brief for budget rather than for detail. | Incorrect | The confusion spreads further than developers: stakeholders and the designer also stop asking whether the feature is the right response. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. Which is the strongest evidence label for "users want a recipient photo"?

**Type:** applied · **Lesson reference:** Section 5, Step 3

**Correct answer: C. Hypothesis, because no participant was shown or asked about a photo in a way that tests the claim.**

**Why this is correct:** One suggestion does not establish a want; label it a hypothesis to test. Section 5, Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Evidence, because a participant suggested it during the interview and asked why it was missing. | Incorrect | One participant suggesting a photo is a single untested remark, and Step 3 labels exactly that case as hypothesis. |
| B | Fact, because it is a common pattern in banking apps and other products people already trust. | Incorrect | A common pattern in other apps is popularity, not a fact about whether your own users want it. |
| C | Hypothesis, because no participant was shown or asked about a photo in a way that tests the claim. | **Correct** | One suggestion does not establish a want; label it a hypothesis to test. Section 5, Step 3. |
| D | Metric, because it can be counted whenever a user taps the recipient photo in the app. | Incorrect | Nothing here is defined, baselined or counted, so it cannot function as a metric of any kind. |

**If the learner chose otherwise:** revisit Section 5, Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. What does a good brief do when the research is thin?

**Type:** best · **Lesson reference:** Section 5, Step 3 and Step 7

**Correct answer: C. States the limits, labels assumptions and names the next research question to close the gap.**

**Why this is correct:** Honest limits and explicit assumptions preserve integrity. Section 5, Step 3 and Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Fills gaps with confident language, because a brief that hedges will not convince anyone to fund it. | Incorrect | Confident language hides the gaps, which is what the lesson warns against; assumptions should be named as assumptions. |
| B | Removes the problem statement, because a problem without evidence cannot be framed precisely enough to test. | Incorrect | Removing the problem statement deletes the brief's core, when the honest move is to label what is unproven. |
| C | States the limits, labels assumptions and names the next research question to close the gap. | **Correct** | Honest limits and explicit assumptions preserve integrity. Section 5, Step 3 and Step 7. |
| D | Copies a competitor's brief, because their research already covers the same market conditions and users. | Incorrect | Copying a competitor's brief imports their problem and their evidence, which says nothing about your users. |

**If the learner chose otherwise:** revisit Section 5, Step 3 and Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A brief has a target of 'reduce failed transfers by 20%' but no baseline. What is the most honest next step?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: B. State that the baseline is unknown, define how it will be measured, and call the target provisional.**

**Why this is correct:** An honest unknown plus a measurement plan is acceptable; inventing a baseline is not.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Invent a baseline of 30% so the target looks achievable and the team can start planning work. | Incorrect | Inventing 30% is fabrication, and Step 4 states plainly that a baseline must never be invented. |
| B | State that the baseline is unknown, define how it will be measured, and call the target provisional. | **Correct** | An honest unknown plus a measurement plan is acceptable; inventing a baseline is not. |
| C | Remove the metric and rely on opinion, because a number nobody can verify invites false confidence. | Incorrect | Dropping the metric and relying on opinion discards the measurable target the brief is supposed to carry. |
| D | Change the target to 100% to motivate the team, since ambitious goals usually raise performance. | Incorrect | A 100% target is motivational rather than honest, and it still leaves the baseline undefined. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A problem brief lists 'users need a notification feature' as the problem. What is the specific framing defect?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: C. It names a solution before establishing the user situation and the barrier that design should address.**

**Why this is correct:** A solution noun closes the space before the underlying problem is evidenced.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It is too short to be a problem statement, because a frame needs several sentences to explain context. | Incorrect | Length is not the defect; the sentence is short, but its problem is the solution noun it names. |
| B | It does not mention the colour of the notification, so the team cannot build the screen consistently. | Incorrect | Colour is a UI detail the brief should omit entirely, so adding it would worsen the framing rather than repair it. |
| C | It names a solution before establishing the user situation and the barrier that design should address. | **Correct** | A solution noun closes the space before the underlying problem is evidenced. |
| D | It uses the word users, which is too broad for a brief that must name who is affected. | Incorrect | The word users is appropriate, because a problem statement names who is affected, so the term is not the flaw. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- All ten sections present, in order, on one page. — with a file, screenshot, link or log that a stranger can inspect.
- At least one job story and one problem statement with no solution nouns. — with a file, screenshot, link or log that a stranger can inspect.
- Every factual claim traceable to evidence or labelled assumption/hypothesis. — with a file, screenshot, link or log that a stranger can inspect.
- One primary metric with definition, baseline (or measurement plan) and target. — with a file, screenshot, link or log that a stranger can inspect.
- One guardrail and one counter-metric. — with a file, screenshot, link or log that a stranger can inspect.
- At least two non-goals with reasons. — with a file, screenshot, link or log that a stranger can inspect.
- At least one accessibility risk and one privacy/ethical risk with mitigations. — with a file, screenshot, link or log that a stranger can inspect.
- Three open questions. — with a file, screenshot, link or log that a stranger can inspect.
- No invented statistics, quotes or baselines. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
