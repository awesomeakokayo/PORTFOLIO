# Answer Key — Stop 5.4: Responsive, Mobile-First and Low-Bandwidth Design

**Instructor use only. Do not distribute.**
**Phase:** 5 · Design to build
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | C | judgment | Step 2 |
| Q2 | A | applied | Step 2 |
| Q3 | D | problem | Step 4 |
| Q4 | A | applied | Step 4 |
| Q5 | B | problem | Step 6 |
| Q6 | D | best | Step 7 |
| Q7 | C | applied | Step 3 |
| Q8 | B | best | Step 7 |
| Q9 | A | applied | Section 5 (worked steps) |
| Q10 | C | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. What does mobile-first mean?

**Type:** judgment · **Lesson reference:** Step 2

**Correct answer: C. Starting with the smallest layout and adding complexity only as the screen allows.**

**Why this is correct:** Mobile-first is a progressive enhancement strategy. Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Designing only for phones, since that is where most visitors to a site will arrive. | Incorrect | Mobile-first starts with the phone layout but still enhances upward; it does not mean designing for phones alone. |
| B | Shipping a mobile app instead of a website, because apps handle small screens better. | Incorrect | The term describes a CSS workflow for websites, not shipping a native mobile application. |
| C | Starting with the smallest layout and adding complexity only as the screen allows. | **Correct** | Mobile-first is a progressive enhancement strategy. Step 2. |
| D | Hiding the least important content on desktop, so the phone version stays the reference. | Incorrect | Nothing is hidden on desktop: the small layout is the base, and wider screens add columns and space. |

**If the learner chose otherwise:** revisit Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. When should you add a breakpoint?

**Type:** applied · **Lesson reference:** Step 2

**Correct answer: A. When the content needs more room or becomes hard to read at the current width.**

**Why this is correct:** Breakpoints follow content, not device names. Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | When the content needs more room or becomes hard to read at the current width. | **Correct** | Breakpoints follow content, not device names. Step 2. |
| B | At every popular device width, so the layout matches the phones and tablets people own. | Incorrect | The lesson says breakpoints are not device names, so popular widths are the wrong trigger for adding one. |
| C | Every 100 pixels, so the layout changes smoothly as the window is resized. | Incorrect | A fixed 100px interval creates many queries whether or not the content actually breaks there. |
| D | Only at 1024 pixels, because that is where desktop browsers usually start. | Incorrect | One 1024px query cannot serve content that already cramps at 40rem or overflows at 320px. |

**If the learner chose otherwise:** revisit Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. Why provide `width` and `height` on images?

**Type:** problem · **Lesson reference:** Step 4

**Correct answer: D. To reserve the right space before the file arrives, so the page does not shift while loading.**

**Why this is correct:** Intrinsic dimensions prevent CLS. Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | To make them load faster, because the browser can request a smaller file for the slot. | Incorrect | Dimensions do not speed the download; they let the browser reserve space before the file arrives. |
| B | To improve the alt text, since the description is generated from the image's proportions. | Incorrect | `alt` is a separate attribute, and width and height never change the description read aloud. |
| C | To enable lazy loading, which only works when dimensions are declared in the markup. | Incorrect | Lazy loading comes from the `loading="lazy"` attribute, not from declaring an image's intrinsic size. |
| D | To reserve the right space before the file arrives, so the page does not shift while loading. | **Correct** | Intrinsic dimensions prevent CLS. Step 4. |

**If the learner chose otherwise:** revisit Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. Which image should generally NOT be lazy-loaded?

**Type:** applied · **Lesson reference:** Step 4

**Correct answer: A. The hero image that is the largest contentful paint element on first load.**

**Why this is correct:** Lazy-loading the LCP image delays it. Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The hero image that is the largest contentful paint element on first load. | **Correct** | Lazy-loading the LCP image delays it. Step 4. |
| B | A gallery image far below the fold, which nobody sees until they scroll. | Incorrect | A gallery image far below the fold is exactly the case lazy loading serves, since it is not needed yet. |
| C | A footer logo that sits at the very bottom of every page on the site. | Incorrect | A footer logo sits at the bottom of the page, so deferring it costs nothing the user can see. |
| D | A decorative image at the bottom of the page, hidden from assistive technology. | Incorrect | A decorative image at the bottom is off-screen on load, which makes it a suitable lazy-loading candidate. |

**If the learner chose otherwise:** revisit Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. What is a performance budget?

**Type:** problem · **Lesson reference:** Step 6

**Correct answer: B. An agreed limit on page weight, requests or timing metrics that the team measures against.**

**Why this is correct:** A budget makes performance a testable constraint. Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The money spent on hosting and bandwidth each month, tracked against the project's running costs. | Incorrect | Hosting spend is money, not a ceiling on kilobytes, requests or LCP; the budget fixes limits the page must meet. |
| B | An agreed limit on page weight, requests or timing metrics that the team measures against. | **Correct** | A budget makes performance a testable constraint. Step 6. |
| C | The number of designers assigned to a team, which determines how much polish a page receives. | Incorrect | Team headcount is a staffing figure and attaches no measurable threshold to the page. |
| D | A CSS framework that ships with performance defaults, so teams do not configure them. | Incorrect | A CSS framework is a tool you might load; a budget is the weight or timing limit the team agrees on. |

**If the learner chose otherwise:** revisit Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. A page shows a blank screen for six seconds on a slow network. What is the design failure?

**Type:** best · **Lesson reference:** Step 7

**Correct answer: D. There is no honest loading state and no prioritised content, so the screen stays blank.**

**Why this is correct:** Users need feedback and readable content early. Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The brand colour is wrong for the audience, so the page feels unfamiliar when it appears. | Incorrect | Brand colour is a palette decision and cannot explain six seconds in which no content appears. |
| B | The font is too large, so fewer words fit and the text takes longer to wrap. | Incorrect | Font size affects readability once text arrives, not whether anything arrives on a slow connection. |
| C | The page has too many headings, so the browser waits for all of them to render. | Incorrect | Heading count is document structure; the failure is that no content or status reached the user. |
| D | There is no honest loading state and no prioritised content, so the screen stays blank. | **Correct** | Users need feedback and readable content early. Step 7. |

**If the learner chose otherwise:** revisit Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. Why is `clamp()` useful for headings?

**Type:** applied · **Lesson reference:** Step 3

**Correct answer: C. It creates a fluid size range with minimum and maximum bounds, so headings stay legible.**

**Why this is correct:** `clamp()` balances fluidity with safe limits. Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It makes text bold automatically, so headings stand out without a separate font-weight rule. | Incorrect | Boldness is `font-weight`; `clamp()` only returns a size between a minimum and a maximum. |
| B | It replaces media queries entirely, so a page needs no breakpoints for any layout change. | Incorrect | It reduces the need for some queries but does not replace media queries where the layout must change. |
| C | It creates a fluid size range with minimum and maximum bounds, so headings stay legible. | **Correct** | `clamp()` balances fluidity with safe limits. Step 3. |
| D | It compresses images automatically, so large photos no longer slow the heading down. | Incorrect | `clamp()` operates on CSS values such as font size; image compression happens in a separate image tool. |

**If the learner chose otherwise:** revisit Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. Which is the most honest offline behaviour?

**Type:** best · **Lesson reference:** Step 7

**Correct answer: B. Showing that the user is offline and that saving will resume when the connection returns.**

**Why this is correct:** Honest state preserves trust and prevents data loss. Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Pretending the save worked, so the interface stays optimistic and the user is not distracted. | Incorrect | Reporting a save as done while offline is the fake-success mistake the lesson lists; nothing was saved. |
| B | Showing that the user is offline and that saving will resume when the connection returns. | **Correct** | Honest state preserves trust and prevents data loss. Step 7. |
| C | Hiding the page until the network returns, so the user never sees a stale or partial state. | Incorrect | Hiding the page leaves the user with nothing to read, whereas the lesson's banner keeps readable content visible. |
| D | Reloading the page continuously until it succeeds, so the user sees the freshest data. | Incorrect | Reloading forever gives no explanation and loses input; the lesson asks for a status message plus a retry. |

**If the learner chose otherwise:** revisit Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A page's large hero image is lazy-loaded below the fold, but it is actually the first visible element. What is the likely effect?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: A. The largest contentful paint is delayed, because the browser waits before requesting the image.**

**Why this is correct:** The LCP image should load eagerly; lazy-loading it harms perceived performance.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The largest contentful paint is delayed, because the browser waits before requesting the image. | **Correct** | The LCP image should load eagerly; lazy-loading it harms perceived performance. |
| B | The image will be sharper, because the browser can pick a higher-resolution file. | Incorrect | Lazy loading changes when the file loads, not its resolution, so sharpness is unaffected either way. |
| C | The page will use less data and look identical immediately, since the image is deferred. | Incorrect | Deferring the first visible element leaves the user looking at an empty area, so the result is not identical immediately. |
| D | The HTML will become invalid, because loading is not allowed on the first visible element. | Incorrect | `loading="lazy"` is valid HTML; the cost is a delayed LCP, not invalid markup. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A page shows a blank white screen for six seconds on a slow connection before any text appears. What is the design failure?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: C. No early readable content or loading state, so the user cannot tell whether it is working.**

**Why this is correct:** Slow connections need fast text, a skeleton or a clear status rather than a blank screen.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The text is too large, so the browser needs longer to lay out each paragraph. | Incorrect | Large text would still appear once loaded; the failure is that nothing appears and no status is shown. |
| B | The page uses too many headings, which delays the first paint of the content. | Incorrect | Heading count is document structure and cannot produce a six-second blank screen. |
| C | No early readable content or loading state, so the user cannot tell whether it is working. | **Correct** | Slow connections need fast text, a skeleton or a clear status rather than a blank screen. |
| D | The logo is the wrong colour, so the page looks broken before the text arrives. | Incorrect | Logo colour is a brand detail; the user's actual problem is not knowing whether the page is loading. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- No horizontal scrolling at 320px; primary action is reachable. — with a file, screenshot, link or log that a stranger can inspect.
- Layout remains usable at 200% zoom. — with a file, screenshot, link or log that a stranger can inspect.
- At least one image uses `srcset`/`sizes` or is correctly compressed for display size. — with a file, screenshot, link or log that a stranger can inspect.
- All images have dimensions and appropriate `alt`. — with a file, screenshot, link or log that a stranger can inspect.
- Total page weight is at or below 500 KB, or the overage is explained with a plan. — with a file, screenshot, link or log that a stranger can inspect.
- LCP on Slow 4G is 2.5 s or less, or the miss is measured and explained. — with a file, screenshot, link or log that a stranger can inspect.
- CLS is 0.1 or less. — with a file, screenshot, link or log that a stranger can inspect.
- Loading, offline and error behaviour are described and at least one is implemented. — with a file, screenshot, link or log that a stranger can inspect.
- Before/after table includes weight, requests, LCP, CLS and INP. — with a file, screenshot, link or log that a stranger can inspect.
- The note states what was removed, what was kept and what could not be tested. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
