# Answer Key — Stop 7.4: Getting Paid

**Instructor use only. Do not distribute.**
**Phase:** 7 · Capstone and career launch
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | B | judgment | Step 1 |
| Q2 | A | applied | Step 5 |
| Q3 | C | problem | Step 3 |
| Q4 | C | applied | Step 7 |
| Q5 | D | problem | Step 9 |
| Q6 | B | best | Step 6 |
| Q7 | C | applied | Step 9 |
| Q8 | B | best | Step 10 |
| Q9 | C | applied | Section 5 (worked steps) |
| Q10 | D | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. Why calculate a minimum rate from costs rather than copying competitors?

**Type:** judgment · **Lesson reference:** Step 1

**Correct answer: B. Your costs and required income are specific to you, so copying may leave the work unsustainable.**

**Why this is correct:** A floor prevents unsustainable pricing. Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Competitors are always wrong, because they price by guesswork and rarely track their own expenses. | Incorrect | Competitors may price correctly for their own costs; the point is that their costs and income needs are not yours. |
| B | Your costs and required income are specific to you, so copying may leave the work unsustainable. | **Correct** | A floor prevents unsustainable pricing. Step 1. |
| C | It is required by law, and freelancers who cannot show a cost-based rate may face penalties. | Incorrect | No law mandates this formula; it is financial discipline, while tax and contract rules vary by country. |
| D | It makes you the cheapest, so you win more work and can raise prices once demand grows. | Incorrect | The floor is a minimum for sustainability, not a bid to be cheapest, and the lesson says it may sit above the market. |

**If the learner chose otherwise:** revisit Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. What is a deposit?

**Type:** applied · **Lesson reference:** Step 5

**Correct answer: A. An upfront payment that secures the work and covers the initial effort before any delivery is made.**

**Why this is correct:** Deposits reduce risk and commit both sides. Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | An upfront payment that secures the work and covers the initial effort before any delivery is made. | **Correct** | Deposits reduce risk and commit both sides. Step 5. |
| B | A discount offered at the start, so the client commits early and the total price falls. | Incorrect | A deposit is an upfront payment later credited to the fee; it does not reduce the agreed price. |
| C | A tax collected on the project fee and passed to the government at the end of the year. | Incorrect | Tax is money owed to a government authority; a deposit is payment for your work. |
| D | A revision round included in the agreed scope, so changes are settled before the work begins. | Incorrect | A revision round is a set of changes within scope; a deposit is money that secures commitment. |

**If the learner chose otherwise:** revisit Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. Which belongs in a proposal's exclusions?

**Type:** problem · **Lesson reference:** Step 3

**Correct answer: C. Work that is not included, such as copywriting, development and recruiting users for the tests.**

**Why this is correct:** Exclusions prevent scope creep. Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The client's name and project title, so the document is clearly identified as belonging to them. | Incorrect | The client's name identifies the proposal in its header; it is not work you are excluding. |
| B | Your portfolio link and two client references, so the client can check your previous work before approving. | Incorrect | A portfolio link supports your credibility; it does not define the boundary of included work. |
| C | Work that is not included, such as copywriting, development and recruiting users for the tests. | **Correct** | Exclusions prevent scope creep. Step 3. |
| D | The weather and travel time, so the client understands the daily conditions the work depends on. | Incorrect | Weather is irrelevant to scope, so listing it as an exclusion protects against nothing. |

**If the learner chose otherwise:** revisit Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. What is a reasonable response to unpaid spec work with commercial value?

**Type:** applied · **Lesson reference:** Step 7

**Correct answer: C. Ask about time, use and fee, then offer a short walkthrough or a paid trial instead.**

**Why this is correct:** Protect your labour while staying professional. Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Do it for free to prove yourself, because a strong sample often turns into a paid contract later. | Incorrect | A real unpaid brief that produces usable work is called concerning, and the lesson says declining is reasonable. |
| B | Send the final files immediately, so the employer can assess the quality and make a decision quickly. | Incorrect | Sending finals before any interview is a warning sign, and final files should be held until payment. |
| C | Ask about time, use and fee, then offer a short walkthrough or a paid trial instead. | **Correct** | Protect your labour while staying professional. Step 7. |
| D | Ignore every employer who asks, because any request for sample work is simply exploitative by nature. | Incorrect | Ignoring every employer overcorrects; the lesson says ask about time, use and fee, then offer an alternative. |

**If the learner chose otherwise:** revisit Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. What is a walk-away number?

**Type:** problem · **Lesson reference:** Step 9

**Correct answer: D. The lowest offer you are willing to accept, written down before the negotiation begins in earnest.**

**Why this is correct:** It protects you from bad deals under pressure. Step 9.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The first number you say in the call, which sets the anchor for the whole negotiation. | Incorrect | That is your target or asking price; the walk-away is the lowest figure you will accept. |
| B | The client's stated budget, which tells you the most they are willing to spend on the project. | Incorrect | The client's budget may sit below your floor; the walk-away is yours to set before the call. |
| C | Your hourly rate, multiplied by the hours you expect the project to take from start to finish. | Incorrect | The hourly rate is a unit price; the walk-away is the floor for a specific offer and scope. |
| D | The lowest offer you are willing to accept, written down before the negotiation begins in earnest. | **Correct** | It protects you from bad deals under pressure. Step 9. |

**If the learner chose otherwise:** revisit Step 9 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. Why tailor a remote application?

**Type:** best · **Lesson reference:** Step 6

**Correct answer: B. To show specific relevance to the role and increase the chance of a reply from the team.**

**Why this is correct:** Specificity signals genuine interest and fit. Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | To send more applications in less time, so you reach more companies before the roles close. | Incorrect | Mass-applying is the listed mistake, because generic applications are easy to ignore. |
| B | To show specific relevance to the role and increase the chance of a reply from the team. | **Correct** | Specificity signals genuine interest and fit. Step 6. |
| C | To hide your portfolio, because a targeted cover note matters far more than the work itself does. | Incorrect | The pack includes a portfolio link with three relevant case studies, so hiding it removes your evidence. |
| D | Because templates are now banned by most employers, and a generic application is rejected automatically. | Incorrect | Templates are not banned; tailoring means naming the company, the role and one specific problem. |

**If the learner chose otherwise:** revisit Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. A client offers 40% below your floor for the full scope. What is the best response?

**Type:** applied · **Lesson reference:** Step 9

**Correct answer: C. Offer a reduced scope within that budget, or deliver the full scope at your stated rate.**

**Why this is correct:** Options preserve the relationship and your floor. Step 9.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Accept and hope, because the relationship may lead to better-paid work once the client trusts you. | Incorrect | Accepting below the floor breaks your walk-away; Tobi declines and offers a reduced scope instead. |
| B | Ignore the client entirely, because an offer that low shows they will never respect your rate. | Incorrect | Going silent ends the conversation; the lesson trades scope rather than cutting contact. |
| C | Offer a reduced scope within that budget, or deliver the full scope at your stated rate. | **Correct** | Options preserve the relationship and your floor. Step 9. |
| D | Double the price, so the client learns that the original quote was already a fair deal. | Incorrect | An unexplained doubling gives the client no options or scope change to choose from. |

**If the learner chose otherwise:** revisit Step 9 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. Why separate business and personal money?

**Type:** best · **Lesson reference:** Step 10

**Correct answer: B. To track costs, tax and buffer accurately, so you can make sustainable decisions about the work.**

**Why this is correct:** Separation supports sustainable decisions. Step 10.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | To look professional, because separate accounts signal to clients that you run a serious design practice. | Incorrect | Appearance is not the reason; separation lets you track costs, tax and a three-to-six-month buffer. |
| B | To track costs, tax and buffer accurately, so you can make sustainable decisions about the work. | **Correct** | Separation supports sustainable decisions. Step 10. |
| C | Because clients require it, and invoices sent from a personal account may not be accepted. | Incorrect | Clients do not require it; the discipline is yours for sustainable decisions and a tax reserve. |
| D | To avoid invoices, because keeping one account makes it hard to prove what was actually earned. | Incorrect | Separation makes invoicing and receipts easier to keep, so it does the opposite of avoiding invoices. |

**If the learner chose otherwise:** revisit Step 10 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A client asks for a full brand and app design as an unpaid 'test' before any contract. What is the most professional response?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: C. Offer a small paid discovery task or a time-boxed sample, and keep the full work behind a contract.**

**Why this is correct:** This protects labour, demonstrates value and avoids giving away commercial work for free.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Do the full project for free to win the client, because the contract will follow if the work is good. | Incorrect | A full brand and app is the unpaid brief with commercial value that the lesson says you can decline. |
| B | Refuse to speak to the client again, because the request shows they do not value design work. | Incorrect | Refusing all contact is unprofessional; ask about time, use and fee, then offer an alternative. |
| C | Offer a small paid discovery task or a time-boxed sample, and keep the full work behind a contract. | **Correct** | This protects labour, demonstrates value and avoids giving away commercial work for free. |
| D | Send a generic price list with no scope, so the client can choose what fits their budget. | Incorrect | A price list is not a plan and includes no deliverables, exclusions or revision rounds. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A freelancer starts work with no deposit and no milestones, then the client stops responding after the first draft. What was missing?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: D. A payment schedule tied to milestones and a deposit that commits both sides before work starts.**

**Why this is correct:** Deposits and milestone payments reduce non-payment risk and make the agreement explicit.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A larger portfolio, because more visible work would have made the client value the project more. | Incorrect | Portfolio size does not secure payment; the missing protection is the payment structure. |
| B | A brighter proposal template, because a clearer layout would have kept the client more engaged. | Incorrect | A brighter template cannot commit a client financially; only a deposit and milestone schedule do that. |
| C | More free revisions, because generous changes would have persuaded the client to stay more involved. | Incorrect | Unlimited revisions are listed as a mistake; they add unpaid work and still create no commitment. |
| D | A payment schedule tied to milestones and a deposit that commits both sides before work starts. | **Correct** | Deposits and milestone payments reduce non-payment risk and make the agreement explicit. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- Rate calculation includes costs, tax reserve, savings, billable hours and assumptions. — with a file, screenshot, link or log that a stranger can inspect.
- Proposal has scope, exclusions, deliverables, timeline, revisions and payment schedule. — with a file, screenshot, link or log that a stranger can inspect.
- At least one deposit or milestone structure is defined. — with a file, screenshot, link or log that a stranger can inspect.
- Application pack is tailored to a named role and company. — with a file, screenshot, link or log that a stranger can inspect.
- Design-challenge policy states what you accept, decline and ask. — with a file, screenshot, link or log that a stranger can inspect.
- Negotiation plan includes target, walk-away, priorities and three tradeables. — with a file, screenshot, link or log that a stranger can inspect.
- Payment and tax responsibilities are acknowledged as country-specific. — with a file, screenshot, link or log that a stranger can inspect.
- No real bank details, ID numbers or signed contracts are included. — with a file, screenshot, link or log that a stranger can inspect.
- No promise of employment or income is made. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
