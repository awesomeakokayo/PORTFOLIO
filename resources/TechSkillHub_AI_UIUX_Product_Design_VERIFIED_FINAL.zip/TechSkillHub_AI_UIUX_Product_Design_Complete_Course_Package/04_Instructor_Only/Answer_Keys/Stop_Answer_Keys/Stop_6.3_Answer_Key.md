# Answer Key — Stop 6.3: Iteration

**Instructor use only. Do not distribute.**
**Phase:** 6 · Testing, metrics and iteration
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | B | judgment | Step 1 |
| Q2 | A | applied | Step 2 |
| Q3 | D | problem | Step 3 |
| Q4 | C | applied | Step 5 |
| Q5 | D | problem | Step 6 |
| Q6 | C | best | Step 7 |
| Q7 | B | applied | Step 6 |
| Q8 | B | best | Step 9 |
| Q9 | D | applied | Section 5 (worked steps) |
| Q10 | D | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. What is the first thing to do with a list of findings?

**Type:** judgment · **Lesson reference:** Step 1

**Correct answer: B. Normalise them first into problem statements with evidence and frequency, so they can be compared fairly.**

**Why this is correct:** Normalising makes findings testable and comparable. Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Fix the easiest one immediately, so the team can show progress while the harder items wait. | Incorrect | Fixing the easiest item is the listed mistake, and without normalised statements you cannot compare impact, confidence and effort. |
| B | Normalise them first into problem statements with evidence and frequency, so they can be compared fairly. | **Correct** | Normalising makes findings testable and comparable. Step 1. |
| C | Add them to a slide deck, so stakeholders can see the full list at the next review meeting. | Incorrect | A slide shows the findings without making them testable or giving their frequency, so the list is no easier to compare. |
| D | Ask the client which ones they prefer, so the final choice matches their expectations and priorities. | Incorrect | Client preference is opinion, and the lesson orders work by evidence and frequency, so this returns the team to taste. |

**If the learner chose otherwise:** revisit Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. Which finding is a must-fix?

**Type:** applied · **Lesson reference:** Step 2

**Correct answer: A. A keyboard trap in the date picker that stops keyboard users from booking any appointment.**

**Why this is correct:** It excludes keyboard users from a core task. Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A keyboard trap in the date picker that stops keyboard users from booking any appointment. | **Correct** | It excludes keyboard users from a core task. Step 2. |
| B | A dated illustration on the confirmation page that no longer matches the current brand. | Incorrect | A dated illustration is cosmetic and affects few people, which places it in could-fix rather than the release-blocking category. |
| C | A slightly long paragraph in the FAQ that takes a few extra seconds to read through. | Incorrect | A long paragraph is comprehension polish with a workaround, so it is should-fix at most and does not block a core flow. |
| D | A colour on the secondary button that is not listed in the current brand guide. | Incorrect | Brand-guide mismatch is a consistency issue with no exclusion or task failure, so it belongs in the backlog. |

**If the learner chose otherwise:** revisit Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. In an ICE score, what does confidence mean?

**Type:** problem · **Lesson reference:** Step 3

**Correct answer: D. How sure you are that the change will have the expected effect, based on evidence.**

**Why this is correct:** Confidence reflects evidence strength. Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | How much you personally like the idea, and whether it fits the direction you prefer. | Incorrect | Liking an idea is opinion, which the confidence scale anchors at 1; the score asks how strongly evidence supports the expected effect. |
| B | How easy the change is to build with the team and time you have available now. | Incorrect | Ease of building is effort, where 5 means large and risky, so treating it as confidence double-counts the same constraint. |
| C | How many users the change could reach once it ships to the whole audience. | Incorrect | How many users could be reached is reach or audience size, a RICE input, not the strength of evidence for the effect. |
| D | How sure you are that the change will have the expected effect, based on evidence. | **Correct** | Confidence reflects evidence strength. Step 3. |

**If the learner chose otherwise:** revisit Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. When is an A/B test least appropriate?

**Type:** applied · **Lesson reference:** Step 5

**Correct answer: C. With tiny traffic and a must-fix accessibility problem that already blocks keyboard users from booking.**

**Why this is correct:** Low power and ethical blockers make testing the wrong tool. Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | With high traffic and a clear primary metric that is already instrumented on every page. | Incorrect | High traffic and an instrumented metric are what make a test viable, since you need volume to detect a meaningful difference. |
| B | With a stable product and a change that is easy to reverse if the result looks bad. | Incorrect | A stable product and a reversible change are easy to isolate and safe to undo, both listed as reasons a test works. |
| C | With tiny traffic and a must-fix accessibility problem that already blocks keyboard users from booking. | **Correct** | Low power and ethical blockers make testing the wrong tool. Step 5. |
| D | With guardrails already in place, covering cancellations and support contacts over the same four-week period. | Incorrect | Guardrails are a precondition for an appropriate test, protecting users from harm, so their presence supports testing. |

**If the learner chose otherwise:** revisit Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. What must a hypothesis include?

**Type:** problem · **Lesson reference:** Step 6

**Correct answer: D. A testable expected effect, with a reason why the change should produce that effect.**

**Why this is correct:** A hypothesis predicts an effect and explains why. Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Only the change itself, described clearly enough for a developer to build it this week. | Incorrect | A change alone predicts nothing, so without an expected effect and reason the result can neither confirm nor falsify it. |
| B | A design screenshot of the new version, attached so reviewers can see what changed. | Incorrect | A screenshot shows the variant but states no predicted metric, duration or cause, so nothing in it can be tested. |
| C | A link to a competitor that made a similar change, as evidence that it works. | Incorrect | A competitor's example comes from another context and says nothing about your users, your metric or why the change works. |
| D | A testable expected effect, with a reason why the change should produce that effect. | **Correct** | A hypothesis predicts an effect and explains why. Step 6. |

**If the learner chose otherwise:** revisit Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. Why change one thing at a time?

**Type:** best · **Lesson reference:** Step 7

**Correct answer: C. So you can attribute the result to a specific change rather than a bundle of them.**

**Why this is correct:** Bundling changes destroys attribution. Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It makes the work slower, which is a fair price for a tidier release and a calmer team. | Incorrect | Slowness is the price of sequencing, not the reason for it; the lesson accepts that cost because attribution is worth more. |
| B | Because users dislike variety and respond better to a product that stays visually stable over time. | Incorrect | Liking visual stability is not the rationale; the reason to change one thing is so the outcome can be traced to it. |
| C | So you can attribute the result to a specific change rather than a bundle of them. | **Correct** | Bundling changes destroys attribution. Step 7. |
| D | Because analytics tools cannot record more than one change in the same release window at a time. | Incorrect | Analytics can record several changes at once; the limit is human attribution, since a bundled result fits no single change. |

**If the learner chose otherwise:** revisit Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. A change increases completion but doubles cancellations. What should you do?

**Type:** applied · **Lesson reference:** Step 6

**Correct answer: B. Investigate the guardrail and likely revert or revise, because doubled cancellations signal real harm to users.**

**Why this is correct:** Guardrails reveal harm. Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Ship it, because completion is the primary metric and the team agreed to optimise it. | Incorrect | Shipping on the primary metric alone ignores the doubled cancellations, and the lesson says a rise bought with harm is not a win. |
| B | Investigate the guardrail and likely revert or revise, because doubled cancellations signal real harm to users. | **Correct** | Guardrails reveal harm. Step 6. |
| C | Ignore the cancellations, since they are a separate team's metric and outside this scope. | Incorrect | Cancellations are this scenario's guardrail, so treating them as another team's concern repeats the mistake of dropping harm metrics. |
| D | Run more ads to offset the cancellations with new orders from a fresh audience. | Incorrect | New orders do not repair harm to existing users and add a confound, making the cancellation rise harder to interpret. |

**If the learner chose otherwise:** revisit Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. Why keep a record of failed changes?

**Type:** best · **Lesson reference:** Step 9

**Correct answer: B. To avoid repeating past mistakes and to show an honest, evidence-based process that includes reversals.**

**Why this is correct:** Failed changes are learning and accountability. Step 9.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | To punish the team members responsible, so the same people do not repeat the mistake. | Incorrect | Punishment is not the purpose, since the lesson calls a documented failed change a sign of maturity that protects the next iteration. |
| B | To avoid repeating past mistakes and to show an honest, evidence-based process that includes reversals. | **Correct** | Failed changes are learning and accountability. Step 9. |
| C | To fill the portfolio with more entries, so the case study looks longer and more complete. | Incorrect | Portfolio value comes from the chain of problem, evidence, change and result, not from displaying failure as extra content. |
| D | Because clients require a written log before they will approve any further design work. | Incorrect | No client approval process is mentioned; the log exists for internal learning, so the next iteration starts from what was tried. |

**If the learner chose otherwise:** revisit Step 9 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A team changes the button label, the page layout and the price at the same time, then sees conversion rise. What is the main problem?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: D. The changes are bundled, so the team cannot attribute the result to any one of them.**

**Why this is correct:** Changing several variables at once destroys causal attribution.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The test used too many users, so the result is harder to explain to the wider team. | Incorrect | No user count is given, and more users would not separate three simultaneous changes; the attribution gap stays the same. |
| B | The conversion metric is always invalid when more than one element on a page changes. | Incorrect | Conversion is valid once its formula, window and population are defined, and nothing here suggests the metric itself is broken. |
| C | The team forgot to add animation, which would have made the new layout feel finished. | Incorrect | Animation is presentation and has no bearing on whether the result can be traced to the label, layout or price. |
| D | The changes are bundled, so the team cannot attribute the result to any one of them. | **Correct** | Changing several variables at once destroys causal attribution. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A team has 30 findings from a test and starts fixing the easiest ones first. What is the main prioritisation error?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: D. They are prioritising ease over severity and user impact, so the important blockers may still wait.**

**Why this is correct:** Prioritisation should weigh impact and severity, not only effort.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | They are fixing too few issues, so the backlog will still be large after this sprint. | Incorrect | The number of fixes is not the error; working through easy items can produce many low-impact changes while blockers wait. |
| B | They did not run an A/B test first, so they cannot know which fix will move the metric. | Incorrect | Prioritisation comes before testing a change, and low volume may make an A/B test inappropriate in the first place. |
| C | They should fix all 30 at once, so the release is complete before anyone tests it again. | Incorrect | Fixing all thirty bundles changes so the results cannot be attributed, and it ignores must-fix, should-fix and could-fix. |
| D | They are prioritising ease over severity and user impact, so the important blockers may still wait. | **Correct** | Prioritisation should weigh impact and severity, not only effort. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- Findings are normalised with evidence and frequency. — with a file, screenshot, link or log that a stranger can inspect.
- Must-fix items are identified separately from scored items. — with a file, screenshot, link or log that a stranger can inspect.
- At least five items are scored with defined scales. — with a file, screenshot, link or log that a stranger can inspect.
- Three change entries include problem, change, reason, expected effect, risk and check. — with a file, screenshot, link or log that a stranger can inspect.
- An A/B hypothesis is complete, or its absence is justified. — with a file, screenshot, link or log that a stranger can inspect.
- v2 changes are implemented or prototyped in enough detail to test. — with a file, screenshot, link or log that a stranger can inspect.
- Before/after re-test results are reported with the same tasks. — with a file, screenshot, link or log that a stranger can inspect.
- Change log has at least three entries, including a revert or revision. — with a file, screenshot, link or log that a stranger can inspect.
- No unsupported claim of causation from a small sample. — with a file, screenshot, link or log that a stranger can inspect.
- No live experiment on real users without approval. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
