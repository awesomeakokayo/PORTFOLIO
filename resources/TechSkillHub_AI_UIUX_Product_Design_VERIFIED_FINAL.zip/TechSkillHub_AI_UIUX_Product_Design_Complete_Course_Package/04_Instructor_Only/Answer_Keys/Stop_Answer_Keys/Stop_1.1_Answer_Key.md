# Answer Key — Stop 1.1: What Product Design Actually Is

**Instructor use only. Do not distribute.**
**Phase:** 1 · Product thinking and research
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | B | judgment | Section 5, Step 2 |
| Q2 | D | applied | Section 5, Step 3 |
| Q3 | C | problem | Section 5, Step 4 |
| Q4 | D | applied | Section 5, Step 6 |
| Q5 | C | problem | Section 5, Step 5 |
| Q6 | C | best | Section 2 and Step 6 |
| Q7 | C | applied | Section 8 |
| Q8 | B | best | Section 5, Step 7 |
| Q9 | A | applied | Section 5 (worked steps) |
| Q10 | D | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. Which sentence is a problem statement rather than a solution?

**Type:** judgment · **Lesson reference:** Section 5, Step 2

**Correct answer: B. Customers cannot tell whether their payment succeeded, so they either pay twice or abandon the order.**

**Why this is correct:** It describes a situation and consequence without prescribing a product. Section 5, Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Users need a chatbot on the home screen so they can get answers without waiting for an email reply. | Incorrect | It asks for a chatbot on the home screen, a product noun, and never describes the customer's actual difficulty or its consequence. |
| B | Customers cannot tell whether their payment succeeded, so they either pay twice or abandon the order. | **Correct** | It describes a situation and consequence without prescribing a product. Section 5, Step 2. |
| C | Add a progress bar to checkout so customers can see how many steps remain before they pay. | Incorrect | It opens with an instruction to add a progress bar, naming a UI component instead of a situation and its consequence. |
| D | Build a dashboard for managers so they can compare branch performance before the monthly finance report. | Incorrect | It specifies an artefact and an audience but never says what managers cannot see today or why that omission costs them. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. What is the main difference between UX and UI?

**Type:** applied · **Lesson reference:** Section 5, Step 3

**Correct answer: D. UX is the whole experience of completing the job, while UI is the visible and interactive layer.**

**Why this is correct:** UX covers the experience and flow; UI is the interface layer. Section 5, Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | UI is only for mobile apps, while UX is only for websites that people use on a laptop. | Incorrect | The lesson never splits the terms by device; a phone app has both an experience layer and a visible interface layer. |
| B | UX is done by researchers, while UI is done by developers who turn the files into code. | Incorrect | This assigns each term to a role, while Step 3 defines them by the work covered and Section 14 says boundaries vary by company. |
| C | There is no practical difference between the two terms, because both describe how a screen looks. | Incorrect | Claiming there is no difference erases the split: UX is completing the job with minimum friction, UI is layout, type, colour and states. |
| D | UX is the whole experience of completing the job, while UI is the visible and interactive layer. | **Correct** | UX covers the experience and flow; UI is the interface layer. Section 5, Step 3. |

**If the learner chose otherwise:** revisit Section 5, Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. "Reduce support calls about failed transfers by 20%." What kind of goal is this?

**Type:** problem · **Lesson reference:** Section 5, Step 4

**Correct answer: C. A business goal with a measurable target, because it names an organisational outcome and a number.**

**Why this is correct:** It is an organisational outcome, measured. Section 5, Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A user goal, because it describes what a customer wants to achieve when sending money. | Incorrect | A user goal is what the person wants to achieve, such as paying once; fewer support calls is the organisation's own cost outcome. |
| B | A UI pattern, because support calls usually drop when the confirmation screen is redesigned. | Incorrect | A UI pattern is a reusable interface solution like a stepper, not a percentage target attached to an organisational result. |
| C | A business goal with a measurable target, because it names an organisational outcome and a number. | **Correct** | It is an organisational outcome, measured. Section 5, Step 4. |
| D | A research method, because it requires interviews with customers before the number can be set. | Incorrect | A research method is how you learn, such as an interview or observation, while this sentence names an outcome to reach. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. A team decides to hide advanced settings to simplify the first-run experience. What is the trade-off?

**Type:** applied · **Lesson reference:** Section 5, Step 6

**Correct answer: D. Simpler for beginners, but potentially frustrating for experts who rely on those settings daily.**

**Why this is correct:** Simplification shifts effort to expert users. Section 5, Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Faster to build for the team, but more expensive to host once the simplified screens finally ship. | Incorrect | Build effort and hosting cost are engineering concerns; hiding settings changes what beginners see, not server capacity or bills. |
| B | Better accessibility for screen readers, but worse performance on older phones with slow connections. | Incorrect | Nothing here concerns accessibility or loading speed; the change mainly affects whether experts can still find the settings. |
| C | No real trade-off, because simplification only removes clutter and never costs any user anything. | Incorrect | Step 6 insists every decision gives something up, and that a decision with no namable trade-off has not been understood. |
| D | Simpler for beginners, but potentially frustrating for experts who rely on those settings daily. | **Correct** | Simplification shifts effort to expert users. Section 5, Step 6. |

**If the learner chose otherwise:** revisit Section 5, Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. Which decision is primarily **research**?

**Type:** problem · **Lesson reference:** Section 5, Step 5

**Correct answer: C. Interviewing five drivers about how they decide when to accept a trip on a busy evening.**

**Why this is correct:** It is about learning user behaviour. Section 5, Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Choosing the primary button colour so the call to action stands out against the booking form. | Incorrect | Button colour is the visual and interactive layer, so the Step 5 table classes it as UI rather than research. |
| B | Setting the commission rate so drivers earn enough to stay on the platform through the year. | Incorrect | A commission rate is money and pricing, which the Step 5 table files under business rather than learning about users. |
| C | Interviewing five drivers about how they decide when to accept a trip on a busy evening. | **Correct** | It is about learning user behaviour. Section 5, Step 5. |
| D | Writing the error message for a failed card payment so customers know what to try next. | Incorrect | Writing an error message is interface copy, a wording decision, not a study of what drivers do or believe. |

**If the learner chose otherwise:** revisit Section 5, Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. Which is a **constraint**, not a goal?

**Type:** best · **Lesson reference:** Section 2 and Step 6

**Correct answer: C. The product must work on 2G connections and low-end Android phones sold in the local market.**

**Why this is correct:** A constraint limits the solution space. Section 2 and Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The team aims to increase retention by 15%, so more customers return and order again next quarter. | Incorrect | Retention is a business goal about people coming back, a desired outcome rather than a limit on what can be built. |
| B | The team wants to become the market leader in the city before any competitor establishes itself. | Incorrect | Market leadership is an ambition about position and reputation, so it names a destination rather than a boundary. |
| C | The product must work on 2G connections and low-end Android phones sold in the local market. | **Correct** | A constraint limits the solution space. Section 2 and Step 6. |
| D | The team wants to improve trust so first-time users feel safe entering their card details. | Incorrect | Improving trust is a reputation goal: an outcome to pursue, not a restriction on devices, budget or regulation. |

**If the learner chose otherwise:** revisit Section 2 and Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. Why is "the product chose not to offer guest checkout" a design decision?

**Type:** applied · **Lesson reference:** Section 8

**Correct answer: C. Because what a product refuses to do shapes effort, privacy and conversion as much as what it adds.**

**Why this is correct:** Omissions are deliberate scope and experience decisions. Section 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Because omissions never matter, since users only judge what they can see on the checkout screen. | Incorrect | Section 8 says omissions are decisions and requires two of them, so claiming they never matter reverses the lesson. |
| B | Because it is a UI colour choice that changes how the checkout button looks to returning users. | Incorrect | Guest checkout is a flow and policy choice about account creation, not a colour or styling decision on the interface. |
| C | Because what a product refuses to do shapes effort, privacy and conversion as much as what it adds. | **Correct** | Omissions are deliberate scope and experience decisions. Section 8. |
| D | Because competitors already do it, so matching them proves the decision was made deliberately and safely. | Incorrect | Competitor behaviour is not a justification; the lesson judges these choices by their effect on effort, privacy and conversion. |

**If the learner chose otherwise:** revisit Section 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. A designer says "users will love this". What is missing?

**Type:** best · **Lesson reference:** Section 5, Step 7

**Correct answer: B. Evidence or an explicit hypothesis with a plan to test whether users actually respond that way.**

**Why this is correct:** Claims about users need evidence or honest labelling as hypotheses. Section 5, Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A colour palette that matches the brand and makes the new feature feel familiar to returning users. | Incorrect | A colour palette is a UI artefact and says nothing about whether the prediction that users will love it holds. |
| B | Evidence or an explicit hypothesis with a plan to test whether users actually respond that way. | **Correct** | Claims about users need evidence or honest labelling as hypotheses. Section 5, Step 7. |
| C | A Figma file that shows the feature in each state so the team can review the interaction. | Incorrect | A Figma file shows what was designed, not evidence that users respond to it the way the designer assumes. |
| D | A business model that explains who pays for the feature and what it costs to run each month. | Incorrect | A business model explains who pays and what it costs them; it does not support a claim about user reaction. |

**If the learner chose otherwise:** revisit Section 5, Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A team is deciding to add a saved-recipient list, measure transfer completion, and change the confirmation button colour. How should these be classified?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: A. Product/UX decision, business or product metric, and UI decision respectively, in that same order.**

**Why this is correct:** The list changes the experience, completion is a measured outcome, and colour is an interface choice.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Product/UX decision, business or product metric, and UI decision respectively, in that same order. | **Correct** | The list changes the experience, completion is a measured outcome, and colour is an interface choice. |
| B | All three are UI decisions because each one appears on a screen that users interact with. | Incorrect | Step 5 warns against classifying by screen presence: colour is UI, but the saved list changes flow and completion is measured. |
| C | All three are research decisions, because each one involves learning something from real users. | Incorrect | Research means learning what users do, need or believe; these three choices implement and measure rather than discover. |
| D | The list is a metric, completion is UI, and colour is research into what users prefer. | Incorrect | Every pairing is scrambled: a saved list is not a metric, completion is not interface, colour is not research. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A brief says the team must 'increase revenue by 15%' and calls that the user problem. What is wrong with the framing?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: D. A business outcome is being substituted for the user problem the design can actually address.**

**Why this is correct:** Revenue is an organisational outcome; the brief still needs the user situation and barrier that design can influence.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Revenue targets are always forbidden in a brief, because designers cannot influence how money is earned. | Incorrect | Revenue targets are allowed; Step 4 asks for an honest business goal, so the defect is substitution rather than the number. |
| B | The percentage is too precise, so the brief should round it to a range the team can remember. | Incorrect | Precision is not the problem, since Section 3 criticises vague goals like improving the ordering experience, not exact percentages. |
| C | The brief lacks a colour palette, so the team cannot tell which direction the design should take. | Incorrect | A colour palette is a UI artefact, and a problem brief at this stage has no reason to contain one. |
| D | A business outcome is being substituted for the user problem the design can actually address. | **Correct** | Revenue is an organisational outcome; the brief still needs the user situation and barrier that design can influence. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- Ten decisions from at least three real products. — with a file, screenshot, link or log that a stranger can inspect.
- At least two of each type: research, UX, UI, business. — with a file, screenshot, link or log that a stranger can inspect.
- At least three mixed decisions with dominant and secondary type. — with a file, screenshot, link or log that a stranger can inspect.
- At least two omissions treated as decisions. — with a file, screenshot, link or log that a stranger can inspect.
- Evidence or "assumption" recorded for every row, with no invented statistics. — with a file, screenshot, link or log that a stranger can inspect.
- One trade-off sentence per product. — with a file, screenshot, link or log that a stranger can inspect.
- The 150-word answer uses at least five glossary terms correctly. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
