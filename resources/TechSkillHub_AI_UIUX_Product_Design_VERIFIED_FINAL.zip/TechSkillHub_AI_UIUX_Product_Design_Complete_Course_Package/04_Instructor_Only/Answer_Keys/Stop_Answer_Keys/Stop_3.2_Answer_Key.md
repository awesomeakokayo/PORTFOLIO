# Answer Key — Stop 3.2: Auto Layout and Constraints

**Instructor use only. Do not distribute.**
**Phase:** 3 · Figma fluency and design systems
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | B | judgment | Section 5, Step 2 |
| Q2 | A | applied | Section 5, Step 8 |
| Q3 | C | problem | Section 5, Step 6 |
| Q4 | C | applied | Section 5, Step 5 |
| Q5 | D | problem | Section 5, Step 3 |
| Q6 | B | best | Section 5, Step 8 |
| Q7 | B | applied | Section 5, Step 4 |
| Q8 | A | best | Section 5, Step 7 |
| Q9 | C | applied | Section 5 (worked steps) |
| Q10 | B | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. What does "Hug contents" do?

**Type:** judgment · **Lesson reference:** Section 5, Step 2

**Correct answer: B. The frame resizes itself to fit the children it contains, growing or shrinking.**

**Why this is correct:** Hug wraps the frame around content. Section 5, Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The child expands to fill all the space available inside its parent frame. | Incorrect | This describes Fill container: Fill expands the child to fill its parent, while Hug shrinks the frame around its children. |
| B | The frame resizes itself to fit the children it contains, growing or shrinking. | **Correct** | Hug wraps the frame around content. Section 5, Step 2. |
| C | The text inside the frame becomes bold whenever the frame is resized. | Incorrect | Font weight is set in the typography controls, while Hug is a sizing rule about frame dimensions, not text appearance. |
| D | The frame locks in place so it cannot be moved or resized by accident. | Incorrect | Locking is a layer state that blocks selection and editing, whereas Hug only changes how the frame's size follows its contents. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. A button stretches across the whole screen unexpectedly. What is the likely cause?

**Type:** applied · **Lesson reference:** Section 5, Step 8

**Correct answer: A. It is set to Fill width inside a parent that is also Fill.**

**Why this is correct:** Fill makes the child expand; use Hug or max width. Section 5, Step 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It is set to Fill width inside a parent that is also Fill. | **Correct** | Fill makes the child expand; use Hug or max width. Section 5, Step 8. |
| B | It has a stroke applied, which adds width around the button's edges. | Incorrect | A stroke only draws an outline and adds no width; the stretch comes from Fill sizing, which the lesson names as the cause. |
| C | The label text is too short, so the button expands to fill the gap. | Incorrect | A short label is exactly when a Hug button stays narrow, so the width comes from the Fill setting rather than label length. |
| D | It is a component instance, and instances always stretch to the parent. | Incorrect | Components can be Hug or Fill like any frame, so being an instance does not make a button stretch. |

**If the learner chose otherwise:** revisit Section 5, Step 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. Which is the best sizing for body text in a card?

**Type:** problem · **Lesson reference:** Section 5, Step 6

**Correct answer: C. Fill width and auto height, so the block fills the card and grows downward.**

**Why this is correct:** Text should fill available width and grow vertically. Section 5, Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Fixed width and fixed height, so the text block stays the same size. | Incorrect | Fixed size on both axes leaves no room for growth, so longer copy overflows or is clipped, the failure the lesson warns about. |
| B | Hug width and fixed height, so the block grows sideways with the copy. | Incorrect | Hug width grows the box sideways with the copy instead of wrapping inside the card, and a fixed height still clips a second line. |
| C | Fill width and auto height, so the block fills the card and grows downward. | **Correct** | Text should fill available width and grow vertically. Section 5, Step 6. |
| D | Fixed width and Hug height, but only when the body text is short. | Incorrect | This makes the rule conditional on short text, but body copy in a card must wrap at any length, so the condition dodges the requirement. |

**If the learner chose otherwise:** revisit Section 5, Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. When are constraints more appropriate than auto layout?

**Type:** applied · **Lesson reference:** Section 5, Step 5

**Correct answer: C. For backgrounds, overlays and elements pinned to the frame's edges.**

**Why this is correct:** Constraints position children in a normal frame; auto layout reflows content. Section 5, Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | For every text block, because constraints keep copy inside its column. | Incorrect | Text is reflowing content, so Fill width plus auto height handles it; the lesson states that constraints do not reflow content. |
| B | For lists, because constraints keep each row aligned as items change. | Incorrect | Lists reflow as items are added or names lengthen, and the common mistakes table names constraints on lists as a mistake fixed by auto layout. |
| C | For backgrounds, overlays and elements pinned to the frame's edges. | **Correct** | Constraints position children in a normal frame; auto layout reflows content. Section 5, Step 5. |
| D | Never, because auto layout has replaced constraints in current Figma. | Incorrect | Constraints remain right for header backgrounds, bottom bars, background images and floating action buttons pinned to frame edges. |

**If the learner chose otherwise:** revisit Section 5, Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. Why nest auto layout frames?

**Type:** problem · **Lesson reference:** Section 5, Step 3

**Correct answer: D. To give different groups their own spacing rhythms, alignment rules and padding.**

**Why this is correct:** Each level can have its own gap, padding and direction. Section 5, Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | To increase the file size deliberately, so Figma reserves more space for layers. | Incorrect | Nesting adds frames, but its purpose is layout rules; file weight is never the goal and no one trades spacing logic for it. |
| B | Because Figma requires nesting before auto layout can be applied to a frame. | Incorrect | A single flat auto layout frame is valid, and nesting is a choice you make when groups need different gaps and alignment. |
| C | To avoid using components, since nested frames already behave like instances. | Incorrect | Nesting and components are independent, and the worked card is nested while still built as a component with instances. |
| D | To give different groups their own spacing rhythms, alignment rules and padding. | **Correct** | Each level can have its own gap, padding and direction. Section 5, Step 3. |

**If the learner chose otherwise:** revisit Section 5, Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. A fixed-height card clips a long title. What is the fix?

**Type:** best · **Lesson reference:** Section 5, Step 8

**Correct answer: B. Set the card height to Hug and let the title wrap onto two lines.**

**Why this is correct:** The container should grow with content. Section 5, Step 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Shrink the font until the title fits inside the existing fixed height. | Incorrect | Shrinking the type treats the symptom, hurts readability, and still clips once the next title is longer; the container is at fault. |
| B | Set the card height to Hug and let the title wrap onto two lines. | **Correct** | The container should grow with content. Section 5, Step 8. |
| C | Remove the title from the card and rely on the description instead. | Incorrect | Removing the title deletes content the screen needs; the fix keeps the title and lets the card grow so it wraps to two lines. |
| D | Add a vertical scrollbar inside the card so the title can be scrolled. | Incorrect | A card should not scroll for its own title; scrolling hides text, while the fix is setting the card height to Hug. |

**If the learner chose otherwise:** revisit Section 5, Step 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. What does min/max width protect against?

**Type:** applied · **Lesson reference:** Section 5, Step 4

**Correct answer: B. Very long or very short content producing extreme, unusable layouts.**

**Why this is correct:** Bounds keep components usable at content extremes. Section 5, Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Colour contrast failures, by widening the area behind low-contrast labels. | Incorrect | Contrast is a colour and luminance check against a ratio, so a width boundary cannot prevent a failing pair. |
| B | Very long or very short content producing extreme, unusable layouts. | **Correct** | Bounds keep components usable at content extremes. Section 5, Step 4. |
| C | Missing fonts, by reserving space for fallback typefaces in every label. | Incorrect | Missing fonts come from uninstalled families or unshared libraries, and min/max width has no effect on font availability. |
| D | Slow prototypes, by limiting how many elements load at each breakpoint. | Incorrect | Prototype speed depends on heavy assets and long delays, while min/max width only bounds how small or large an element gets. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. What is the real test of an auto layout component?

**Type:** best · **Lesson reference:** Section 5, Step 7

**Correct answer: A. How it behaves when the content and the container size change.**

**Why this is correct:** Responsive rules only show under change. Section 5, Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | How it behaves when the content and the container size change. | **Correct** | Responsive rules only show under change. Section 5, Step 7. |
| B | How clean and balanced it looks with the sample content in place. | Incorrect | Sample content is short and tidy, so it hides the breakage; the lesson says the only real test is changing the content. |
| C | How many layers it contains when the component is fully expanded. | Incorrect | Layer count measures file tidiness, not responsiveness, and a clean tree can still overflow or clip at 320 px. |
| D | Whether it is built as a component rather than a loose group. | Incorrect | A component can carry a fixed height and clip its title, so component status says nothing about behaviour under change. |

**If the learner chose otherwise:** revisit Section 5, Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A toolbar must keep 16 px padding and an 8 px gap while its buttons change. Which Figma structure best supports this?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: C. An auto layout frame with 16 px padding and an 8 px gap between buttons.**

**Why this is correct:** Auto layout maintains padding and gap as children change.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A group whose buttons are each positioned by eye at the correct spacing. | Incorrect | A group has no gap or padding engine, so every button change needs manual nudging, which is the manual-spacing problem being avoided. |
| B | A single exported image of the toolbar, placed once and reused on each screen. | Incorrect | An image cannot hold buttons that change; nothing reflows and the toolbar becomes uneditable, so it cannot absorb a new label. |
| C | An auto layout frame with 16 px padding and an 8 px gap between buttons. | **Correct** | Auto layout maintains padding and gap as children change. |
| D | A frame with absolutely positioned buttons and a height that never changes. | Incorrect | Absolute children leave the flow, so 16 px padding and 8 px gap break as soon as a button resizes, and the fixed height clips. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A card's title is clipped when translated into a longer language. The card has a fixed height. What is the most likely fix?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: B. Let the card height hug its content and allow the title to wrap.**

**Why this is correct:** The container must grow with content rather than clipping it.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Reduce the font size until the translated title fits the fixed height. | Incorrect | Shrinking type drops below the system scale and still clips when the next translation is longer; the container, not the font, is at fault. |
| B | Let the card height hug its content and allow the title to wrap. | **Correct** | The container must grow with content rather than clipping it. |
| C | Shorten the translation without consulting the owner of the content. | Incorrect | Rewriting the copy without the content owner's approval changes meaning, and the fixed height will clip the next long string anyway. |
| D | Add a horizontal scrollbar to the card so the title can be read. | Incorrect | Horizontal scrolling hides the title instead of showing it; the fix is Hug height so the text wraps and the card grows. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- Three components with auto layout and documented sizing rules. — with a file, screenshot, link or log that a stranger can inspect.
- Card grows with long titles and description. — with a file, screenshot, link or log that a stranger can inspect.
- List row keeps the trailing action visible at 320 px. — with a file, screenshot, link or log that a stranger can inspect.
- Form field includes label, helper and error states. — with a file, screenshot, link or log that a stranger can inspect.
- Screen tested at 320, 393 and 430 px. — with a file, screenshot, link or log that a stranger can inspect.
- Behaviour table covers all three components. — with a file, screenshot, link or log that a stranger can inspect.
- No fixed heights on text containers. — with a file, screenshot, link or log that a stranger can inspect.
- The note names one rule that was hard to get right and how it was resolved. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
