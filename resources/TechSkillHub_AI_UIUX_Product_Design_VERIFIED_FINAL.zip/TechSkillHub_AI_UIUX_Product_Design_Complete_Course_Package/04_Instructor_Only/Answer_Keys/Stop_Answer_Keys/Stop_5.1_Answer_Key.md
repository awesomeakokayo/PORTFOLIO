# Answer Key — Stop 5.1: Handoff That Developers Love

**Instructor use only. Do not distribute.**
**Phase:** 5 · Design to build
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | D | judgment | Section 3 |
| Q2 | A | applied | Step 8 |
| Q3 | C | problem | Step 3 |
| Q4 | B | applied | Step 3 |
| Q5 | D | problem | Section 5 (worked steps) and Section 11 (common mistakes) |
| Q6 | A | best | Step 5 |
| Q7 | D | applied | Step 8 |
| Q8 | D | best | Step 6 |
| Q9 | B | applied | Section 5 (worked steps) |
| Q10 | D | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. What is the main purpose of a handoff pack?

**Type:** judgment · **Lesson reference:** Section 3

**Correct answer: D. To give builders the specs, states and rules they need to build the screen correctly without guessing.**

**Why this is correct:** Handoff transfers decisions, not just pictures. Section 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | To make the design file look tidy, with neat layers and frames that are easy to browse later. | Incorrect | Tidy layers are housekeeping; a well-organised frame with no values or states still leaves the developer guessing. |
| B | To replace usability testing by settling every question before the design reaches a real user. | Incorrect | Handoff and usability testing do different jobs: handoff transfers build decisions, while testing checks the design with real users. |
| C | To prove the designer worked long hours by showing a detailed record of every revision made. | Incorrect | Hours worked is not information a builder can act on; the pack answers build questions rather than documenting effort. |
| D | To give builders the specs, states and rules they need to build the screen correctly without guessing. | **Correct** | Handoff transfers decisions, not just pictures. Section 3. |

**If the learner chose otherwise:** revisit Section 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. Which is a testable acceptance criterion?

**Type:** applied · **Lesson reference:** Step 8

**Correct answer: A. "At 320px wide, the primary button stays visible without horizontal scrolling."**

**Why this is correct:** It names a condition and an observable result. Step 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | "At 320px wide, the primary button stays visible without horizontal scrolling." | **Correct** | It names a condition and an observable result. Step 8. |
| B | "The page feels premium and modern, with generous spacing and a calm, confident tone." | Incorrect | 'Feels premium' names no condition and no observable result, so two testers would judge it differently. |
| C | "Use nice spacing and a clean type scale throughout the checkout flow." | Incorrect | 'Nice spacing' gives no value or measurement, so a tester cannot pass or fail the checkout layout. |
| D | "Make the primary button pop so the main action is obvious at a glance." | Incorrect | 'Make it pop' describes a visual impression with nothing measurable, so it cannot be tested at all. |

**If the learner chose otherwise:** revisit Step 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. Why must disabled buttons still be readable?

**Type:** problem · **Lesson reference:** Step 3

**Correct answer: C. Because users need to understand what is unavailable and why, and low contrast hides that information.**

**Why this is correct:** Disabled state is information, not decoration. Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Because they are decorative placeholders that show the layout, so their contrast does not matter much. | Incorrect | A disabled control is still information — that an action exists but is unavailable — so it is not decorative. |
| B | Because disabled buttons are always clickable, so users need to read the label before pressing them. | Incorrect | Disabled means not clickable; the lesson's matrix says 'not clickable, still readable', so these two claims contradict. |
| C | Because users need to understand what is unavailable and why, and low contrast hides that information. | **Correct** | Disabled state is information, not decoration. Step 3. |
| D | Because screen readers skip disabled controls entirely, so the label must carry the meaning visually. | Incorrect | Screen readers do not skip disabled buttons; the lesson requires this state to stay readable and understandable. |

**If the learner chose otherwise:** revisit Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. What belongs in a state matrix?

**Type:** applied · **Lesson reference:** Step 3

**Correct answer: B. Every relevant state, with its trigger, visual change and behaviour, including loading, error and empty.**

**Why this is correct:** The matrix makes states explicit. Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Only the default state, drawn once, because the other states are left to the developer's judgment. | Incorrect | Default only is the happy path the lesson calls the most common handoff failure; loading, error and disabled rows would be missing. |
| B | Every relevant state, with its trigger, visual change and behaviour, including loading, error and empty. | **Correct** | The matrix makes states explicit. Step 3. |
| C | A list of the colour names used on the screen, so the palette stays consistent across builds. | Incorrect | Colour names belong to the visual spec and say nothing about triggers or behaviour, which the matrix records. |
| D | The project timeline, so the team knows which screens are finished and which are still in review. | Incorrect | A timeline is project logistics rather than a component state, so it belongs in a plan, not the matrix. |

**If the learner chose otherwise:** revisit Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. A developer asks "what happens if the API fails?" What kind of gap is this?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: D. A behaviour and content gap: what the screen does and says after a failed request.**

**Why this is correct:** Failure handling is behaviour plus error copy. Steps 3, 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A visual gap about the size, spacing and colour of the elements on the screen. | Incorrect | Size, spacing and colour are visual spec; 'what happens if the API fails' asks what the screen does and says. |
| B | A naming gap about how the layers, components and files in the design are labelled. | Incorrect | Naming gaps concern layer, component and file labels, not the behaviour and error copy after a failed request. |
| C | A pricing gap about what the feature costs to run and who pays for the extra requests. | Incorrect | Pricing is a business decision about money, unrelated to how the interface behaves when a request fails. |
| D | A behaviour and content gap: what the screen does and says after a failed request. | **Correct** | Failure handling is behaviour plus error copy. Steps 3, 7. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. Why is `Frame 427` a bad layer name?

**Type:** best · **Lesson reference:** Step 5

**Correct answer: A. It carries no meaning, so nobody can tell what it holds, find it later or reuse it.**

**Why this is correct:** Names must communicate purpose and state. Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It carries no meaning, so nobody can tell what it holds, find it later or reuse it. | **Correct** | Names must communicate purpose and state. Step 5. |
| B | It is too long for Figma's layer field, so the name gets truncated before the useful part. | Incorrect | `Frame 427` is short, not long; the problem is that those characters name no purpose, variant or state. |
| C | Figma forbids names that contain numbers, so the layer stays unnamed and cannot be exported. | Incorrect | Figma allows numbers in layer names, and files with such names still export; the defect is the naming convention. |
| D | It slows the file down, because the editor re-reads every numeric label on each save. | Incorrect | Layer names have no measurable effect on file performance; the cost is human, because nobody can find the layer. |

**If the learner chose otherwise:** revisit Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. What should an open-questions table include?

**Type:** applied · **Lesson reference:** Step 8

**Correct answer: D. The question, its owner, the date it is needed by, and a default if it stays unanswered.**

**Why this is correct:** Ownership and defaults prevent stalls. Step 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Only questions that are already answered, so the table reads as a settled record of decisions. | Incorrect | An open question is by definition undecided; listing only answered ones hides the real blockers. |
| B | A list of every layer in the file, so reviewers can trace each one back to a component. | Incorrect | Layers are an inventory of the design file, not decisions awaiting an owner, deadline and fallback. |
| C | The designer's opinions about the product, recorded so the team knows what to prioritise next. | Incorrect | Opinions without an owner, date or default stall the build; the table records decisions and their defaults. |
| D | The question, its owner, the date it is needed by, and a default if it stays unanswered. | **Correct** | Ownership and defaults prevent stalls. Step 8. |

**If the learner chose otherwise:** revisit Step 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. Which asset handover is most useful?

**Type:** best · **Lesson reference:** Step 6

**Correct answer: D. A named SVG with a 24×24 viewBox and `currentColor`, so it scales and inherits text colour.**

**Why this is correct:** Developers need editable, correctly sized, recolourable assets. Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A screenshot of the icon, taken at the size it appears on the finished screen. | Incorrect | A raster screenshot cannot be recoloured or scaled cleanly, and the lesson says not to pass off a picture of an icon as an asset. |
| B | A JPG of the whole screen, so the developer can crop the icons out of it later. | Incorrect | A JPG of the whole screen is a reference image, not an asset; it cannot be edited and carries no size or licence detail. |
| C | A link to a competitor's site, where the same icon can be inspected and copied. | Incorrect | A competitor's site is not licensed material and provides no file to build with, so the licence stays unclear. |
| D | A named SVG with a 24×24 viewBox and `currentColor`, so it scales and inherits text colour. | **Correct** | Developers need editable, correctly sized, recolourable assets. Step 6. |

**If the learner chose otherwise:** revisit Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A developer asks what should happen when the payment API returns a timeout. What should the handoff provide?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: B. The relevant states, the exact message, the recovery action, and the rule preventing a duplicate payment.**

**Why this is correct:** Failure handling is behaviour plus copy plus a safe recovery path.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A higher-resolution screenshot of the happy path, so the developer can match the finished layout exactly. | Incorrect | A sharper happy-path screenshot shows success, not what the user sees or does after a payment timeout. |
| B | The relevant states, the exact message, the recovery action, and the rule preventing a duplicate payment. | **Correct** | Failure handling is behaviour plus copy plus a safe recovery path. |
| C | A note saying 'handle errors gracefully', leaving the wording and the retry logic to the developer. | Incorrect | 'Handle errors gracefully' is adjective-level instruction; the developer must still invent the message, retry and duplicate-payment rule. |
| D | A link to the brand guidelines, so the error message uses the approved tone and colour palette. | Incorrect | Brand guidelines cover colour and tone, not the timeout message, the retry behaviour or the safeguard against charging twice. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A handoff contains final screens but no loading, empty or error states. What will the developer most likely have to do?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: D. Invent behaviour and copy for those states, which creates rework and drifts from the design intent.**

**Why this is correct:** Missing states force implementation guesses.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Ship the happy path only and ignore failures, because nothing in the pack says they matter. | Incorrect | Nothing tells the developer to ignore failures; silence about states pushes them to invent behaviour, not to skip it. |
| B | Ask the designer for a colour palette, since the screens do not show which colours to use. | Incorrect | A palette is normally already in the file; the missing material is state behaviour and its copy. |
| C | Reduce the page weight automatically, because incomplete screens usually mean the build is unfinished. | Incorrect | Page weight is a performance concern, not something a developer infers from absent loading and error screens. |
| D | Invent behaviour and copy for those states, which creates rework and drifts from the design intent. | **Correct** | Missing states force implementation guesses. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- One screen is fully specified, with values and units. — with a file, screenshot, link or log that a stranger can inspect.
- At least 6 states are defined with triggers and behaviour. — with a file, screenshot, link or log that a stranger can inspect.
- Content rules cover at least 4 text slots, including overflow. — with a file, screenshot, link or log that a stranger can inspect.
- Assets are listed with names, formats, sizes and licence status. — with a file, screenshot, link or log that a stranger can inspect.
- A naming convention is defined and applied. — with a file, screenshot, link or log that a stranger can inspect.
- Edge cases cover content, data, network, permission and device. — with a file, screenshot, link or log that a stranger can inspect.
- 5–10 acceptance criteria are testable. — with a file, screenshot, link or log that a stranger can inspect.
- Open questions have owners and defaults. — with a file, screenshot, link or log that a stranger can inspect.
- The review record shows at least three questions asked and how the pack was improved. — with a file, screenshot, link or log that a stranger can inspect.
- No real personal or confidential data is included. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
