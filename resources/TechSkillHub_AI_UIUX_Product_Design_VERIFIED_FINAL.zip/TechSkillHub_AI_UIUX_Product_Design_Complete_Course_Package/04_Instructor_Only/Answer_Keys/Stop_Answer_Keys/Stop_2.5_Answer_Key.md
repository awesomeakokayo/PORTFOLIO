# Answer Key — Stop 2.5: Accessibility and Inclusive Design

**Instructor use only. Do not distribute.**
**Phase:** 2 · Visual and interaction foundations
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | D | judgment | Section 5, Step 1 |
| Q2 | B | applied | Section 5, Step 2 |
| Q3 | C | problem | Section 5, Step 3 |
| Q4 | D | applied | Section 5, Step 3 |
| Q5 | B | problem | Section 5, Step 7 |
| Q6 | D | best | Section 6 |
| Q7 | D | applied | Section 2 and Step 5 |
| Q8 | D | best | Section 5, Step 8 |
| Q9 | A | applied | Section 5 (worked steps) |
| Q10 | D | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. What does POUR stand for?

**Type:** judgment · **Lesson reference:** Section 5, Step 1

**Correct answer: D. Perceivable, Operable, Understandable, Robust, the four principles behind every success criterion.**

**Why this is correct:** The four WCAG principles. Section 5, Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Practical, Open, Usable, Responsive, the four headings used in the audit template. | Incorrect | Open and Responsive are not WCAG principles and Practical is not one either; they only sound like audit headings. |
| B | Private, Optimal, Universal, Reliable, the four qualities of an accessible page. | Incorrect | These read like brand values; none is a WCAG principle and the acronym contains none of them. |
| C | Perceivable, Original, Useful, Responsive, the four stages of an audit. | Incorrect | Only Perceivable is correct here; Original and Useful replace Operable and Understandable, which are the real terms. |
| D | Perceivable, Operable, Understandable, Robust, the four principles behind every success criterion. | **Correct** | The four WCAG principles. Section 5, Step 1. |

**If the learner chose otherwise:** revisit Section 5, Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. What is the WCAG 2.2 AA minimum contrast for normal text?

**Type:** applied · **Lesson reference:** Section 5, Step 2

**Correct answer: B. 4.5:1, the AA minimum SC 1.4.3 sets for normal-sized text.**

**Why this is correct:** SC 1.4.3. Section 5, Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | 3:1, the threshold that applies to large text and essential icons. | Incorrect | 3:1 covers large text and essential non-text elements; normal-sized body copy is held to the higher 4.5:1. |
| B | 4.5:1, the AA minimum SC 1.4.3 sets for normal-sized text. | **Correct** | SC 1.4.3. Section 5, Step 2. |
| C | 7:1, the AAA target, which is stricter than the AA minimum asked for. | Incorrect | 7:1 is AAA and sits above the AA baseline, so it answers a stricter question than the one asked. |
| D | 2:1, a decorative-only ratio that no text of any size may use. | Incorrect | 2:1 falls below every text threshold in the standard and would leave body copy unreadable for many users. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. What is the WCAG 2.2 AA minimum target size?

**Type:** problem · **Lesson reference:** Section 5, Step 3

**Correct answer: C. 24 × 24 CSS px, the minimum SC 2.5.8 sets for AA conformance.**

**Why this is correct:** SC 2.5.8 sets 24 × 24 as the AA minimum; 44/48 is recommended practice. Section 5, Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | 16 × 16 CSS px, the size at which icon-only buttons stop being usable. | Incorrect | 16 × 16 is under SC 2.5.8 and is the very case the lesson calls a failure even when the icon looks fine. |
| B | 44 × 44 CSS px, Apple's recommended size for comfortable finger targets. | Incorrect | 44 × 44 is Apple's recommended practice, which is larger than the AA minimum the question asks about. |
| C | 24 × 24 CSS px, the minimum SC 2.5.8 sets for AA conformance. | **Correct** | SC 2.5.8 sets 24 × 24 as the AA minimum; 44/48 is recommended practice. Section 5, Step 3. |
| D | 48 × 48 CSS px, Material's recommended size for primary mobile controls. | Incorrect | 48 × 48 is Material's recommendation, again professional practice rather than the AA criterion. |

**If the learner chose otherwise:** revisit Section 5, Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. Why is a 16 px icon with a 16 px hit area a problem?

**Type:** applied · **Lesson reference:** Section 5, Step 3

**Correct answer: D. The tappable area is too small for reliable touch, even if it looks fine.**

**Why this is correct:** Target size is about the hit area, not the visual size. Section 5, Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The icon is too large for the toolbar and crowds the controls beside it. | Incorrect | 16 px is small, not large; the fault is that the tappable area stops at the icon instead of extending past it. |
| B | Icons should never be used, because text labels are always clearer. | Incorrect | Icons are legitimate controls, and the lesson asks for labels alongside them; the target area is the defect here. |
| C | It fails contrast, because the icon colour is too close to the background. | Incorrect | Contrast concerns luminance against adjacent colours, and nothing in the stem describes the icon's colour. |
| D | The tappable area is too small for reliable touch, even if it looks fine. | **Correct** | Target size is about the hit area, not the visual size. Section 5, Step 3. |

**If the learner chose otherwise:** revisit Section 5, Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. A form shows errors only with a red border. Which criterion is at risk?

**Type:** problem · **Lesson reference:** Section 5, Step 7

**Correct answer: B. 1.4.1 Use of Color, because the error is conveyed by hue alone.**

**Why this is correct:** Meaning must not rely on colour alone. Section 5, Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | 2.4.7 Focus Visible, because the field shows no outline when tabbed to. | Incorrect | 2.4.7 concerns whether a keyboard user can see the focus indicator, not how an error is communicated. |
| B | 1.4.1 Use of Color, because the error is conveyed by hue alone. | **Correct** | Meaning must not rely on colour alone. Section 5, Step 7. |
| C | 1.4.10 Reflow, because the field overflows at 320 px screen width. | Incorrect | 1.4.10 concerns reflow at 320 px and 400% zoom, not whether meaning depends on hue. |
| D | 3.1.1 Language of Page, because the error text is not language-tagged. | Incorrect | 3.1.1 concerns declaring the page's language so a screen reader pronounces it correctly. |

**If the learner chose otherwise:** revisit Section 5, Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. What does "not testable in this format" mean in an audit?

**Type:** best · **Lesson reference:** Section 6

**Correct answer: D. The current artifact cannot verify it, so it must be tested in the build.**

**Why this is correct:** Honest scoping of evidence. Section 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The check is optional, so the auditor may skip it without recording anything. | Incorrect | The check is still required; it simply cannot be verified in a static file, so it is deferred rather than dropped. |
| B | The criterion does not apply to this screen, so it can be removed. | Incorrect | The criterion still applies to the product; only the evidence is unavailable at this stage of the work. |
| C | The designer forgot to run the check before submitting the audit. | Incorrect | The label records a limit of the artifact being audited, not an oversight by the designer. |
| D | The current artifact cannot verify it, so it must be tested in the build. | **Correct** | Honest scoping of evidence. Section 6. |

**If the learner chose otherwise:** revisit Section 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. Why is semantic HTML an accessibility issue?

**Type:** applied · **Lesson reference:** Section 2 and Step 5

**Correct answer: D. Assistive technology relies on element roles and structure to announce the interface.**

**Why this is correct:** Screen readers use semantics, not visual appearance. Section 2 and Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It makes pages smaller, because semantic tags compress better when served. | Incorrect | Semantic markup has no meaningful effect on page weight; the benefit is the roles and structure a screen reader announces. |
| B | It changes the default colours, which can lower the page's contrast ratio. | Incorrect | Semantics carry no styling at all; colour and layout come from CSS, not from choosing a button element. |
| C | It is required for search engine ranking, and accessibility is a side effect. | Incorrect | Search engines do benefit, but the accessibility reason is that screen readers depend on roles to operate the interface. |
| D | Assistive technology relies on element roles and structure to announce the interface. | **Correct** | Screen readers use semantics, not visual appearance. Section 2 and Step 5. |

**If the learner chose otherwise:** revisit Section 2 and Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. Which is an example of inclusive design beyond compliance?

**Type:** best · **Lesson reference:** Section 5, Step 8

**Correct answer: D. Allowing phone formats and informal addresses that match local naming reality.**

**Why this is correct:** Inclusion considers real-world variety that standards may not fully capture. Section 5, Step 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Passing a contrast checker on every text and background pair used. | Incorrect | Passing a contrast checker is the compliance floor; inclusion asks what the standard does not capture about real people. |
| B | Adding alt text to every meaningful image and empty alt to decorative ones. | Incorrect | Alt text is a baseline requirement of the standard, so adding it is compliance rather than a step beyond it. |
| C | Using a 24 px target for every control, which is the AA minimum. | Incorrect | 24 px is precisely the AA minimum in SC 2.5.8, which makes it compliance, not inclusion. |
| D | Allowing phone formats and informal addresses that match local naming reality. | **Correct** | Inclusion considers real-world variety that standards may not fully capture. Section 5, Step 8. |

**If the learner chose otherwise:** revisit Section 5, Step 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A learner writes alt text for a chart showing monthly sales. Which alt text is most useful?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: A. A short description of the chart's purpose and the main trend.**

**Why this is correct:** Alt text should convey the information the image provides, not just its type.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A short description of the chart's purpose and the main trend. | **Correct** | Alt text should convey the information the image provides, not just its type. |
| B | The single word chart, repeated once for each axis label. | Incorrect | Naming the object tells the user nothing about the sales figures, which is the information the chart exists to convey. |
| C | A full transcription of every monthly data point inside the attribute. | Incorrect | Every data point crammed into alt text becomes unusable as speech; the trend belongs in the description and figures in a table. |
| D | An empty alt attribute, because the chart is decorative rather than informative. | Incorrect | The chart carries the sales numbers, so it is meaningful content and cannot be treated as decoration. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A learner removes the default focus outline because it looks ugly, and keyboard users can no longer see where they are. Which requirement has failed?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: D. Visible keyboard focus, so the current interactive element can be located.**

**Why this is correct:** Removing focus visibility without a replacement blocks keyboard navigation.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Colour contrast for body text, which must reach 4.5:1 on white. | Incorrect | No text colour changed, so body-text contrast ratios are untouched by removing a focus outline. |
| B | Image alt text, which must describe every meaningful picture. | Incorrect | Alt text describes pictures, whereas this failure is about a keyboard user losing their place. |
| C | Page language declaration, which tells screen readers how to pronounce. | Incorrect | The lang attribute affects pronunciation by a screen reader, not whether the focused element can be seen. |
| D | Visible keyboard focus, so the current interactive element can be located. | **Correct** | Removing focus visibility without a replacement blocks keyboard navigation. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- At least twelve checks across POUR. — with a file, screenshot, link or log that a stranger can inspect.
- Evidence for every result, with ratios or measurements where relevant. — with a file, screenshot, link or log that a stranger can inspect.
- Failures honestly marked, including "not testable". — with a file, screenshot, link or log that a stranger can inspect.
- A corrected screen with at least five fixes applied. — with a file, screenshot, link or log that a stranger can inspect.
- Developer notes that name element, value, behaviour and reason. — with a file, screenshot, link or log that a stranger can inspect.
- A prioritisation with a stated rationale. — with a file, screenshot, link or log that a stranger can inspect.
- The reflection distinguishes compliance from inclusion with a concrete example. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
