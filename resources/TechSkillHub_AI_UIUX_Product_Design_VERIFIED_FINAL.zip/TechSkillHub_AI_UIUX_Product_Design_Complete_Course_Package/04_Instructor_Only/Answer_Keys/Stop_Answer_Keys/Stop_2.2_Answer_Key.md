# Answer Key — Stop 2.2: Typography and Colour

**Instructor use only. Do not distribute.**
**Phase:** 2 · Visual and interaction foundations
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | C | judgment | Section 5, Step 1 |
| Q2 | C | applied | Section 5, Step 6 |
| Q3 | C | problem | Section 5, Step 6 |
| Q4 | A | applied | Section 2 and Stop 0 |
| Q5 | B | problem | Section 5, Step 7 |
| Q6 | A | best | Section 5, Step 5 |
| Q7 | B | applied | Section 5, Step 2 |
| Q8 | B | best | Section 5, Step 6 |
| Q9 | A | applied | Section 5 (worked steps) |
| Q10 | A | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. What does a type scale ratio of 1.25 mean?

**Type:** judgment · **Lesson reference:** Section 5, Step 1

**Correct answer: C. Each step in the scale is 1.25 times the size of the step below.**

**Why this is correct:** A ratio multiplies between steps. Section 5, Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Every size in the scale is 1.25 px larger than the one before it. | Incorrect | The ratio multiplies, so each step grows by a quarter of the previous size rather than every size gaining a flat 1.25 px. |
| B | The line height for all text styles is fixed at a 1.25 multiplier. | Incorrect | Line height is chosen per size, 1.4–1.6 for body and 1.1–1.3 for headings, so it is not what the ratio describes. |
| C | Each step in the scale is 1.25 times the size of the step below. | **Correct** | A ratio multiplies between steps. Section 5, Step 1. |
| D | The typeface provides 1.25 available weights, from light through to bold. | Incorrect | Weights are named whole steps such as regular, medium and bold, and a size multiplier never produces a count of them. |

**If the learner chose otherwise:** revisit Section 5, Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. What is the WCAG 2.2 AA minimum contrast for normal body text?

**Type:** applied · **Lesson reference:** Section 5, Step 6

**Correct answer: C. 4.5:1, the minimum SC 1.4.3 sets for normal-sized body text.**

**Why this is correct:** SC 1.4.3 sets 4.5:1 for normal text, 3:1 for large text. Section 5, Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | 2:1, a threshold that applies only to decorative borders and dividers. | Incorrect | 2:1 is below every text threshold in the standard, so body copy at that ratio would be unreadable for many users. |
| B | 3:1, the threshold shared by large text and essential icons. | Incorrect | 3:1 covers large text and essential non-text elements; normal-sized body copy is held to the higher 4.5:1. |
| C | 4.5:1, the minimum SC 1.4.3 sets for normal-sized body text. | **Correct** | SC 1.4.3 sets 4.5:1 for normal text, 3:1 for large text. Section 5, Step 6. |
| D | 7:1, the stricter AAA target for normal text above the AA baseline. | Incorrect | 7:1 is the AAA target and sits above the AA minimum, so it answers a stricter question than the one asked. |

**If the learner chose otherwise:** revisit Section 5, Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. What is the minimum for large text under AA?

**Type:** problem · **Lesson reference:** Section 5, Step 6

**Correct answer: C. 3:1, the lower threshold AA allows once text reaches large-text size.**

**Why this is correct:** Large text may use 3:1. Section 5, Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | 2:1, the floor for decorative separators that carry no information. | Incorrect | 2:1 falls below even the large-text minimum, so it would still fail at the size where AA is most lenient. |
| B | 4.5:1, the normal-text threshold applied here because large text is harder. | Incorrect | 4.5:1 is the normal-text requirement; large text is deliberately allowed the lower 3:1 because its strokes are easier to resolve. |
| C | 3:1, the lower threshold AA allows once text reaches large-text size. | **Correct** | Large text may use 3:1. Section 5, Step 6. |
| D | 7:1, the AAA target for small text that designers often over-apply. | Incorrect | 7:1 belongs to AAA, not to the AA large-text minimum the question asks for. |

**If the learner chose otherwise:** revisit Section 5, Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. Why is a placeholder not a label?

**Type:** applied · **Lesson reference:** Section 2 and Stop 0

**Correct answer: A. It disappears once typing starts, so the field's instruction is lost.**

**Why this is correct:** Persistent labels are required; placeholders vanish. Section 2 and Stop 0.3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It disappears once typing starts, so the field's instruction is lost. | **Correct** | Persistent labels are required; placeholders vanish. Section 2 and Stop 0.3. |
| B | It is always set too small to read comfortably on a phone screen. | Incorrect | A placeholder can be set at any size; the defect is that the text vanishes on input, not that it is rendered small. |
| C | It cannot be announced by screen readers, which skip placeholder text. | Incorrect | Screen readers do announce placeholder text, but it still disappears once the user types, so the instruction is gone. |
| D | It is not permitted in forms under the WCAG 2.2 AA standard. | Incorrect | Placeholders are allowed as format hints; they simply cannot replace a label that stays visible and is programmatically linked. |

**If the learner chose otherwise:** revisit Section 2 and Stop 0 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. A designer uses red text alone to indicate an error. Which principle is violated?

**Type:** problem · **Lesson reference:** Section 5, Step 7

**Correct answer: B. Use of colour alone (WCAG 1.4.1), because hue carries the meaning.**

**Why this is correct:** Meaning must not depend on colour alone; add icon and text. Section 5, Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The contrast minimum, because red text rarely reaches a 4.5:1 ratio. | Incorrect | The red may well pass 4.5:1 against its background; the failure is that the meaning rests on hue, not on luminance. |
| B | Use of colour alone (WCAG 1.4.1), because hue carries the meaning. | **Correct** | Meaning must not depend on colour alone; add icon and text. Section 5, Step 7. |
| C | Text resize, because the error message does not grow at 200% zoom. | Incorrect | Resize concerns text at 200% and reflow at narrow widths, and nothing in the stem describes enlarged text. |
| D | Focus visible, because the field shows no outline when tabbed to. | Incorrect | Focus visible concerns whether a keyboard user can locate the active control, which is a different question from marking a field invalid. |

**If the learner chose otherwise:** revisit Section 5, Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. Why use semantic colour roles instead of raw hex values in screens?

**Type:** best · **Lesson reference:** Section 5, Step 5

**Correct answer: A. Roles survive theme changes and keep meaning consistent across every screen.**

**Why this is correct:** Semantic tokens decouple intent from a specific value. Section 5, Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Roles survive theme changes and keep meaning consistent across every screen. | **Correct** | Semantic tokens decouple intent from a specific value. Section 5, Step 5. |
| B | Hex values take longer to load, so screens that use them render more slowly. | Incorrect | Rendering speed is identical whether a screen references a token or a hex value; nothing about lookup makes hex slower. |
| C | Roles raise contrast automatically, so a failing pair passes once it is tokenised. | Incorrect | A role is only a name pointing at a value, so if that value fails contrast the role fails with it and must still be measured. |
| D | Figma cannot store raw hex values reliably across shared team libraries. | Incorrect | Figma stores hex fills without trouble; the argument for roles is one edit per theme change, not a storage limit. |

**If the learner chose otherwise:** revisit Section 5, Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. Body text at 16 px with a line height of 16 px will most likely be…

**Type:** applied · **Lesson reference:** Section 5, Step 2

**Correct answer: B. Too tight, so ascenders and descenders collide and reading slows down.**

**Why this is correct:** 1.0 line height is too tight for body text; 1.4–1.6 is typical. Section 5, Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Perfectly readable, because the lines are spaced exactly one text size apart. | Incorrect | A 1.0 line height leaves no leading at all, so the lines crowd and the eye loses its place on the return sweep. |
| B | Too tight, so ascenders and descenders collide and reading slows down. | **Correct** | 1.0 line height is too tight for body text; 1.4–1.6 is typical. Section 5, Step 2. |
| C | Too loose, because each line occupies a full 16 px of vertical space. | Incorrect | 16 px on 16 px text is the tightest possible setting, the opposite of loose; 1.4–1.6 is the loose end of the range. |
| D | Inaccessible, because the grey text colour fails the 4.5:1 threshold. | Incorrect | Only size and line height are given in the stem; no colour pair is stated, so colour cannot be the cause. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. You check `#9CA3AF` grey text on white and get 2.6:1. It is used for 13 px helper text. What should you do?

**Type:** best · **Lesson reference:** Section 5, Step 6

**Correct answer: B. Darken it to at least 4.5:1, or enlarge it to the large-text threshold for 3:1.**

**Why this is correct:** Normal-sized text needs 4.5:1; helper text is not exempt. Section 5, Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Keep it as it is, because helper text is exempt from contrast requirements. | Incorrect | 13 px counts as normal text, and the lesson's named common error is exactly this: helper copy still needs 4.5:1. |
| B | Darken it to at least 4.5:1, or enlarge it to the large-text threshold for 3:1. | **Correct** | Normal-sized text needs 4.5:1; helper text is not exempt. Section 5, Step 6. |
| C | Make the helper text bold and keep the colour, since weight raises contrast. | Incorrect | Bold at 13 px stays under the 14 pt bold large-text threshold, and weight does not change luminance contrast, so 2.6:1 still fails. |
| D | Add an icon beside the helper text so the low contrast no longer matters. | Incorrect | An icon adds a second signal for a state but does nothing to make the helper text itself legible. |

**If the learner chose otherwise:** revisit Section 5, Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A learner needs a muted grey for 13 px helper text on a white card. Which action is correct?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: A. Pick a grey reaching 4.5:1 on white and confirm it with a checker.**

**Why this is correct:** Helper text is normal-sized text and must meet the 4.5:1 AA threshold.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Pick a grey reaching 4.5:1 on white and confirm it with a checker. | **Correct** | Helper text is normal-sized text and must meet the 4.5:1 AA threshold. |
| B | Pick any grey lighter than body text, since helper text is optional. | Incorrect | Choosing a lighter grey lowers the ratio further, and helper text carrying format rules is not information a user can skip. |
| C | Use 3:1, because all secondary text counts as large text. | Incorrect | 3:1 applies at 18 pt regular or 14 pt bold; 13 px is under both, so it remains normal text needing 4.5:1. |
| D | Trust your own screen; if the grey looks readable, it passes. | Incorrect | The lesson says record a measured ratio rather than trust the eye, because a bright monitor flatters pairs that fail elsewhere. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A form marks an invalid field only with a red border. Which user group is most directly excluded?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: A. People who cannot distinguish the red border from the surrounding border colour.**

**Why this is correct:** Meaning that relies on colour alone is unavailable to people with colour-vision deficiency or low vision.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | People who cannot distinguish the red border from the surrounding border colour. | **Correct** | Meaning that relies on colour alone is unavailable to people with colour-vision deficiency or low vision. |
| B | People who use a mouse instead of a keyboard to complete the form. | Incorrect | Mouse users see the red border as clearly as anyone; the exclusion falls on people who cannot separate that hue from its surroundings. |
| C | People on a fast internet connection who skip past the error message. | Incorrect | Connection speed has no bearing on whether a border colour can be perceived at all. |
| D | People who prefer dark mode and see a different surface colour. | Incorrect | Dark mode changes surface values, but a colour-only error still fails in any theme for someone who cannot distinguish the hue. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- A type scale with a stated ratio and at least six steps. — with a file, screenshot, link or log that a stranger can inspect.
- Line heights appropriate to size (body 1.4–1.6). — with a file, screenshot, link or log that a stranger can inspect.
- A specimen using real sentences. — with a file, screenshot, link or log that a stranger can inspect.
- Nine neutrals, one brand ramp and four semantic colours. — with a file, screenshot, link or log that a stranger can inspect.
- A role table with at least ten tokens. — with a file, screenshot, link or log that a stranger can inspect.
- Eight measured contrast pairs, with ratios and pass/fail labels. — with a file, screenshot, link or log that a stranger can inspect.
- No normal text below 4.5:1 presented as body text. — with a file, screenshot, link or log that a stranger can inspect.
- Greyscale version included and no meaning lost. — with a file, screenshot, link or log that a stranger can inspect.
- A rationale that explains the accessibility decision. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
