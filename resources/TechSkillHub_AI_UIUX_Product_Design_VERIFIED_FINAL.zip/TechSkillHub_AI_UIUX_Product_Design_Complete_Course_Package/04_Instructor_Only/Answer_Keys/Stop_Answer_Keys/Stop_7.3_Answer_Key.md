# Answer Key — Stop 7.3: Portfolio and Presence

**Instructor use only. Do not distribute.**
**Phase:** 7 · Capstone and career launch
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | C | judgment | Step 3 |
| Q2 | A | applied | Step 3 |
| Q3 | A | problem | Step 2 |
| Q4 | A | applied | Step 5 |
| Q5 | D | problem | Step 9 |
| Q6 | D | best | Step 6 |
| Q7 | C | applied | Step 8 |
| Q8 | B | best | Step 7 |
| Q9 | C | applied | Section 5 (worked steps) |
| Q10 | A | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. What should the first screen of a portfolio answer?

**Type:** judgment · **Lesson reference:** Step 3

**Correct answer: C. What you do, who you do it for, and what proof the visitor can see immediately.**

**Why this is correct:** Visitors scan for relevance and proof. Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Your life story, told from childhood, so visitors understand the experiences that shaped your design taste. | Incorrect | A life story does not belong on the first screen; the about page also avoids background padding and stays under 250 words. |
| B | Every tool you have used, listed by category, so visitors can confirm you know the relevant software. | Incorrect | Step 4 says list only tools you use well, and the first screen needs positioning and proof, not an inventory. |
| C | What you do, who you do it for, and what proof the visitor can see immediately. | **Correct** | Visitors scan for relevance and proof. Step 3. |
| D | Your favourite colour and typeface, so the page expresses a distinctive personal style right away. | Incorrect | A favourite colour tells a visitor nothing about relevance, capability or the evidence available. |

**If the learner chose otherwise:** revisit Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. Which case study title is strongest?

**Type:** applied · **Lesson reference:** Step 3

**Correct answer: A. Making delivery costs visible before checkout, and rebuilding trust in the final total.**

**Why this is correct:** Problem-led titles communicate value. Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Making delivery costs visible before checkout, and rebuilding trust in the final total. | **Correct** | Problem-led titles communicate value. Step 3. |
| B | Checkout redesign, covering the payment form, the fee display and the confirmation screen. | Incorrect | This names the screen and its parts, and the lesson uses it as the weaker example of a title that hides the problem. |
| C | Project 3 final final, the version submitted after the last round of client feedback. | Incorrect | A file-name label carries no problem or result, and 'final' is ambiguous rather than a dated version. |
| D | UI exploration, a visual study of colours, cards and buttons for the checkout flow. | Incorrect | UI exploration describes an activity and an output, not the user problem or the change it produced. |

**If the learner chose otherwise:** revisit Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. How many case studies should a beginner portfolio show?

**Type:** problem · **Lesson reference:** Step 2

**Correct answer: A. Three strong ones, or fewer if only fewer are strong, with the site labelled honestly.**

**Why this is correct:** Quality and coherence beat volume. Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Three strong ones, or fewer if only fewer are strong, with the site labelled honestly. | **Correct** | Quality and coherence beat volume. Step 2. |
| B | As many as possible, because a large archive shows range and proves you have shipped often. | Incorrect | More projects dilute the set; the lesson says a weak fourth project lowers the average, so do not include everything. |
| C | Exactly ten, because a round number signals a complete and well-organised body of work. | Incorrect | Ten is an arbitrary count with no reason; Amina drops one project and publishes three. |
| D | Only one, because a single deep project is always stronger than several shallower ones. | Incorrect | One project cannot show depth, range and judgement, which the three-study set is designed to demonstrate. |

**If the learner chose otherwise:** revisit Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. Why compress portfolio images?

**Type:** applied · **Lesson reference:** Step 5

**Correct answer: A. To reduce load time and data cost on mobile, where most visitors first open the portfolio.**

**Why this is correct:** Performance is part of the experience you claim. Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | To reduce load time and data cost on mobile, where most visitors first open the portfolio. | **Correct** | Performance is part of the experience you claim. Step 5. |
| B | To make the images slightly blurry, so visitors focus on the writing instead of the screenshots. | Incorrect | Blurring destroys the evidence; compression targets WebP under 200 KB while keeping the screenshots legible. |
| C | To hide confidential details inside the screenshots without having to edit each image by hand. | Incorrect | Hiding details is anonymisation, a separate privacy step; compression exists to cut load time and data cost. |
| D | To improve search ranking only, since page speed does not affect how visitors judge the work. | Incorrect | The lesson ties compression to mobile load and data cost, warning that a 12-second load contradicts the claimed skills. |

**If the learner chose otherwise:** revisit Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. A client project is under NDA. What should you do?

**Type:** problem · **Lesson reference:** Step 9

**Correct answer: D. Get permission, anonymise the details, or publish a clearly labelled reconstruction of the project.**

**Why this is correct:** Confidentiality and consent come first. Step 9.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Publish it anyway, because the portfolio is personal and the agreement binds the company rather than you. | Incorrect | Publishing regardless breaches the NDA and the rule against showing client work without permission. |
| B | Change the client's name and publish, since the work is unrecognisable once the logo is removed. | Incorrect | A false name still exposes the client's product; the lesson asks for permission, anonymisation or a labelled reconstruction. |
| C | Publish the metrics only, because numbers are abstract and reveal nothing about the client's product. | Incorrect | Metrics are confidential business data, so publishing them alone still discloses protected client information. |
| D | Get permission, anonymise the details, or publish a clearly labelled reconstruction of the project. | **Correct** | Confidentiality and consent come first. Step 9. |

**If the learner chose otherwise:** revisit Step 9 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. What makes a portfolio accessible?

**Type:** best · **Lesson reference:** Step 6

**Correct answer: D. Proper headings, alt text, sufficient contrast, visible keyboard focus and captions for any embedded video.**

**Why this is correct:** Accessibility is a set of concrete practices. Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A dark theme, because high-contrast dark backgrounds are easier for everyone to read on a phone. | Incorrect | A dark theme is a style choice; accessibility depends on the contrast ratio, not on light or dark. |
| B | A loading animation, because motion signals progress and keeps visitors patient on slower connections. | Incorrect | Motion does not help keyboard users or screen readers, and heavy animation is discouraged for mobile data. |
| C | A PDF download, because a fixed document preserves the layout for every visitor on every device. | Incorrect | A PDF is a file format that can itself be inaccessible; it supplies no headings, alt text or focus states. |
| D | Proper headings, alt text, sufficient contrast, visible keyboard focus and captions for any embedded video. | **Correct** | Accessibility is a set of concrete practices. Step 6. |

**If the learner chose otherwise:** revisit Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. Why align one professional profile with the portfolio?

**Type:** applied · **Lesson reference:** Step 8

**Correct answer: C. To create a consistent, recognisable impression and reduce confusion for anyone who checks both places.**

**Why this is correct:** Consistency builds trust. Step 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | To post more often, because regular publishing is what keeps a profile visible in crowded feeds. | Incorrect | Step 8 warns against spraying generic posts across platforms; posting volume is not the reason to align. |
| B | To collect more followers, because a larger audience makes employers much more likely to reply. | Incorrect | Follower count is not the aim; the aim is a recognisable, coherent impression across site and profile. |
| C | To create a consistent, recognisable impression and reduce confusion for anyone who checks both places. | **Correct** | Consistency builds trust. Step 8. |
| D | Because the platforms require it, and profiles that do not match a linked site may be restricted. | Incorrect | No platform requires matching your site; the reason is consistency and reduced confusion for visitors. |

**If the learner chose otherwise:** revisit Step 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. What is the best test of your home page?

**Type:** best · **Lesson reference:** Step 7

**Correct answer: B. A stranger can say what you do within 30 seconds of opening the page on a phone.**

**Why this is correct:** Clarity for the visitor is the goal. Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | You like it, because your own judgement is the only reliable measure of clarity and visual quality. | Incorrect | The designer's own taste is not the test; Step 7 asks two people to say what they think you do. |
| B | A stranger can say what you do within 30 seconds of opening the page on a phone. | **Correct** | Clarity for the visitor is the goal. Step 7. |
| C | It has many animations, because motion keeps visitors on the page long enough to read the text. | Incorrect | Many animations are discouraged for mobile load and say nothing about whether a stranger understands the work. |
| D | It uses the latest framework, because modern tooling signals to employers that your skills are current. | Incorrect | Visitors never see the framework in a 30-second scan; they need to know what you do and see proof. |

**If the learner chose otherwise:** revisit Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A portfolio home page opens with a large abstract illustration and the words 'I am passionate about design'. What should replace it first?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: C. A clear statement of who the designer helps, with what problem, and a link to proof.**

**Why this is correct:** Visitors scan for relevance and evidence; positioning and proof should lead.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A longer biography starting from childhood, so visitors understand the full path that led to design. | Incorrect | About pages should avoid a life story and stay under 250 words; biography does not establish positioning. |
| B | More abstract illustrations, so the page feels visually consistent and memorable at first glance to visitors. | Incorrect | More abstract art adds decoration without meaning, and the lesson puts clarity before beauty. |
| C | A clear statement of who the designer helps, with what problem, and a link to proof. | **Correct** | Visitors scan for relevance and evidence; positioning and proof should lead. |
| D | A list of every tool the designer has opened, ranked by how confidently each one is used. | Incorrect | A tool list names no user, problem or proof, so it cannot replace a positioning statement. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A portfolio's case study images are 5 MB each and the home page takes 12 seconds to load on mobile data. What is the main problem?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: A. Uncompressed images make the portfolio slow on mobile and contradict the user-centred claims it makes.**

**Why this is correct:** Performance is part of the experience; images should be compressed and responsive.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Uncompressed images make the portfolio slow on mobile and contradict the user-centred claims it makes. | **Correct** | Performance is part of the experience; images should be compressed and responsive. |
| B | The case studies are too short, so visitors leave before they reach the results or the lesson. | Incorrect | The symptom is a 12-second mobile load; case study word count is unrelated to image weight. |
| C | The portfolio has too many colours, which makes the layout feel busy on a small screen. | Incorrect | Colour choice is not the bottleneck when each image is 5 MB and the page takes 12 seconds. |
| D | The designer has too many case studies, and each one adds weight to the home page. | Incorrect | Three case studies are recommended; the page count is fine, and the images are the weight. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- Live URL works in a private window. — with a file, screenshot, link or log that a stranger can inspect.
- Positioning statement names who, outcome and approach. — with a file, screenshot, link or log that a stranger can inspect.
- Three case studies (or fewer, with a reason) have problem-led titles and results. — with a file, screenshot, link or log that a stranger can inspect.
- About section is under 250 words and includes a contact route. — with a file, screenshot, link or log that a stranger can inspect.
- Site works at 320px with no horizontal scrolling. — with a file, screenshot, link or log that a stranger can inspect.
- Images are compressed and have `alt` text. — with a file, screenshot, link or log that a stranger can inspect.
- Headings, links, focus states and contrast pass basic accessibility checks. — with a file, screenshot, link or log that a stranger can inspect.
- A professional profile matches the site's positioning. — with a file, screenshot, link or log that a stranger can inspect.
- All work is published with permission and participants are anonymised. — with a file, screenshot, link or log that a stranger can inspect.
- No invented clients, results or job titles. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
