# Answer Key — Stop 6.1: Usability Testing

**Instructor use only. Do not distribute.**
**Phase:** 6 · Testing, metrics and iteration
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | B | judgment | Section 3 |
| Q2 | B | applied | Step 2 |
| Q3 | C | problem | Step 5 |
| Q4 | D | applied | Step 6 |
| Q5 | A | problem | Step 7 |
| Q6 | B | best | Step 8 |
| Q7 | D | applied | Step 3 |
| Q8 | C | best | Step 9 |
| Q9 | D | applied | Section 5 (worked steps) |
| Q10 | B | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. What is the main purpose of a first usability test round?

**Type:** judgment · **Lesson reference:** Section 3

**Correct answer: B. To observe where real people actually struggle and replace the team's opinions with evidence early, while changes are still cheap.**

**Why this is correct:** Testing finds problems; it does not prove perfection. Section 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | To prove that the design is already good, so the team can stop testing and move on to the next feature. | Incorrect | Proving the design is already good would end testing, yet the lesson says inspection only shows plausibility and the round exists to find failure. |
| B | To observe where real people actually struggle and replace the team's opinions with evidence early, while changes are still cheap. | **Correct** | Testing finds problems; it does not prove perfection. Section 3. |
| C | To collect complimentary quotes from participants that the team can reuse in marketing material and on sales pages later. | Incorrect | Complimentary quotes are promotional material; the round produces observed behaviour on tasks, and praise would not show where the design breaks. |
| D | To replace product analytics entirely, because watching five people shows how often every event happens for every user. | Incorrect | Watching five people cannot show how often events happen across all users; that frequency comes from analytics, so the two methods are complementary. |

**If the learner chose otherwise:** revisit Section 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. Which task is written correctly?

**Type:** applied · **Lesson reference:** Step 2

**Correct answer: B. Find out how much delivery will cost before you pay, because you are ordering food to your house.**

**Why this is correct:** Tasks state a goal and context, not the interface path. Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Click the blue Delivery tab at the top of the basket page, then read the fee in the order summary. | Incorrect | It names a colour, a tab and a summary location, so the participant never has to work out where delivery costs live. |
| B | Find out how much delivery will cost before you pay, because you are ordering food to your house. | **Correct** | Tasks state a goal and context, not the interface path. Step 2. |
| C | Did you find the blue delivery button easy to use, or would you prefer a clearer label on it? | Incorrect | This is a leading wrap-up question rather than a task, because it suggests the answer and gives no goal to attempt. |
| D | Use the search bar on the menu page to look for a jollof rice option that serves two people. | Incorrect | It prescribes the search bar and the page, so a participant who cannot find either is guided instead of observed. |

**If the learner chose otherwise:** revisit Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. A participant asks, "Is this right?" What is the best response?

**Type:** problem · **Lesson reference:** Step 5

**Correct answer: C. What do you think, and what would you expect to happen next on this screen right now?**

**Why this is correct:** Neutral probes avoid leading and keep the participant thinking. Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Yes, that is right, well done for finding it so quickly without any help from me today. | Incorrect | Confirming the answer and praising speed tells the participant they were right, which shapes how they behave for the rest of the session. |
| B | Click the next button at the bottom of the form, then check whether the summary looks correct. | Incorrect | Directing them to the next button rescues them from the struggle, turning an observable failure into a guided success. |
| C | What do you think, and what would you expect to happen next on this screen right now? | **Correct** | Neutral probes avoid leading and keep the participant thinking. Step 5. |
| D | Most people get that wrong on their first attempt, so do not worry about it at this stage. | Incorrect | Saying most people fail applies social pressure and hints that something is wrong, changing how they explore the screen. |

**If the learner chose otherwise:** revisit Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. Why separate observation from interpretation?

**Type:** applied · **Lesson reference:** Step 6

**Correct answer: D. So that later claims and recommendations can be checked against what was actually seen in the session.**

**Why this is correct:** Evidence and meaning must be distinguishable. Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | To make each set of session notes longer and more detailed, so the final report looks thorough and professional. | Incorrect | Volume is not the goal; a short observation beside a labelled interpretation is enough, and padding makes the evidence harder to audit. |
| B | Because interpretations are not allowed in usability work and only recorded behaviour may appear in the findings. | Incorrect | Interpretations are expected; they only need their own column so a reader can see whether the observation supports them. |
| C | To hide the moderator's personal bias from readers, so the notes appear neutral even where judgement crept in. | Incorrect | Separation exposes bias instead of hiding it, because an unsupported interpretation becomes visible, and moderator bias still belongs in the limitations. |
| D | So that later claims and recommendations can be checked against what was actually seen in the session. | **Correct** | Evidence and meaning must be distinguishable. Step 6. |

**If the learner chose otherwise:** revisit Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. What does "3 of 5" communicate that "most users" does not?

**Type:** problem · **Lesson reference:** Step 7

**Correct answer: A. The exact count and the sample behind it, which is more honest than a vague majority claim.**

**Why this is correct:** Specific counts prevent overclaiming. Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The exact count and the sample behind it, which is more honest than a vague majority claim. | **Correct** | Specific counts prevent overclaiming. Step 7. |
| B | Nothing extra, since both phrases describe the same group of participants in a five-person round. | Incorrect | The two phrases differ: the count states both the number and the five-person denominator that 'most users' conceals. |
| C | Statistical significance, because a count out of five proves the difference is not due to chance. | Incorrect | A count out of five cannot establish significance; five is a starting round, and the lesson asks for uncertainty in plain words. |
| D | Severity, because the number of participants affected shows how badly the issue blocks the task. | Incorrect | Severity is rated separately from critical to low; the count reports frequency and says nothing about how badly the task is blocked. |

**If the learner chose otherwise:** revisit Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. One participant loses a saved order. Four do not. How should this be rated?

**Type:** best · **Lesson reference:** Step 8

**Correct answer: B. Critical, because losing a saved order is severe impact even though only one participant saw it.**

**Why this is correct:** Severity is impact, not just frequency. Step 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Low, because only one of the five participants hit it, and rare problems can wait for a later release. | Incorrect | Rarity is frequency, but the scale rates impact; losing a saved order prevents completion and causes data loss, which is critical however few hit it. |
| B | Critical, because losing a saved order is severe impact even though only one participant saw it. | **Correct** | Severity is impact, not just frequency. Step 8. |
| C | Not rated at all, because a single participant cannot show a pattern that is worth acting on. | Incorrect | The lesson says one participant can reveal a severe issue, so it must still be rated and reported as a single observation, not set aside. |
| D | Medium, because it affected one person only and the other four completed the same task fine. | Incorrect | Medium understates data loss, and the number affected is frequency, not impact, so one participant cannot pull the rating down. |

**If the learner chose otherwise:** revisit Step 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. What must be agreed before recording a session?

**Type:** applied · **Lesson reference:** Step 3

**Correct answer: D. Explicit consent covering the purpose, who will see the recording, and when it will be deleted.**

**Why this is correct:** Recording requires informed consent. Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Nothing in advance, because joining the call is generally taken as permission to record the screen. | Incorrect | Joining a call is not permission; consent must be explicit before the session and must say whether screen, audio or video is captured. |
| B | Only the participant's name, so the file can be labelled correctly when it is stored after the call. | Incorrect | A label is not consent: the conversation must cover purpose, the right to stop, who sees the file and the deletion date. |
| C | A small payment for their time, which stands in for written permission to keep and use the clip. | Incorrect | Payment is not a consent condition; peers can be tested free, and what is needed is a recorded, informed agreement about use. |
| D | Explicit consent covering the purpose, who will see the recording, and when it will be deleted. | **Correct** | Recording requires informed consent. Step 3. |

**If the learner chose otherwise:** revisit Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. Which is a limitation that belongs in the report?

**Type:** best · **Lesson reference:** Step 9

**Correct answer: C. Five participants and a prototype that could not take real payments during the checkout tasks at all.**

**Why this is correct:** Sample size and prototype gaps affect what can be concluded. Step 9.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The brand colour used on the primary button, which was chosen before the sessions and never changed. | Incorrect | Brand colour is visual polish, which the plan excludes from scope; a limitation must constrain what the sessions can conclude. |
| B | The designer's name and role, so readers know who was responsible for the prototype that was tested. | Incorrect | Naming the designer identifies no constraint on inference; limitations cover sample size, prototype gaps, moderator bias and the environment. |
| C | Five participants and a prototype that could not take real payments during the checkout tasks at all. | **Correct** | Sample size and prototype gaps affect what can be concluded. Step 9. |
| D | The number of headings on the checkout page, which the team had reduced before the sessions. | Incorrect | Heading count is a layout detail, not a boundary on inference; the report needs the five participants and the missing real payments. |

**If the learner chose otherwise:** revisit Step 9 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A usability test task says: 'Click Settings, then Privacy, then turn off sharing.' What is wrong with the task?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: D. It prescribes the exact interface path instead of stating a goal and the context around it.**

**Why this is correct:** A test task should describe what the participant wants to achieve, not how to navigate.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It is too short for the participant to understand what is being asked of them in the session. | Incorrect | Length is not the defect; a short goal-based task works well, and this one fails because it lists Settings, Privacy and the toggle in order. |
| B | It does not mention the participant's name, so the moderator cannot personalise the instruction before reading it aloud. | Incorrect | Tasks never need the participant's name, and adding one would leave the step-by-step path that causes the problem untouched. |
| C | It uses the word Privacy, which gives away the name of the screen the participant must find. | Incorrect | Privacy is only a menu label; the fault is the ordered click sequence, which removes the need to work out where the setting lives. |
| D | It prescribes the exact interface path instead of stating a goal and the context around it. | **Correct** | A test task should describe what the participant wants to achieve, not how to navigate. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A report says 'most users struggled' after testing five people but gives no counts. What is the reporting problem?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: B. The claim hides the small sample and gives no count, so the reader cannot judge its weight.**

**Why this is correct:** Reporting 3 of 5 or 4 of 5 is more honest than a vague majority claim.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The report is too long, so readers lose the main finding among details that do not matter. | Incorrect | Length is irrelevant; the sentence is short and still misleading because a vague quantifier replaces the count and denominator. |
| B | The claim hides the small sample and gives no count, so the reader cannot judge its weight. | **Correct** | Reporting 3 of 5 or 4 of 5 is more honest than a vague majority claim. |
| C | Five participants is always too many for a first round, so the sessions should have been cut short. | Incorrect | Five is the recommended starting round, not an excess, so the fault is the claim built on it rather than the number of sessions. |
| D | The report should say all instead of most, to make the finding sound stronger and more urgent. | Incorrect | Saying all would overclaim further, asserting that every participant failed when the real figure might be three of five. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- A one-sentence research question and a one-page plan. — with a file, screenshot, link or log that a stranger can inspect.
- Consent obtained and documented before each session. — with a file, screenshot, link or log that a stranger can inspect.
- 3–5 realistic tasks that do not name interface controls. — with a file, screenshot, link or log that a stranger can inspect.
- Five sessions (or three, clearly labelled as a pilot). — with a file, screenshot, link or log that a stranger can inspect.
- Notes separate observation from interpretation. — with a file, screenshot, link or log that a stranger can inspect.
- Findings table includes participants, evidence, severity and recommendation. — with a file, screenshot, link or log that a stranger can inspect.
- Summary reports what worked, what failed and limitations. — with a file, screenshot, link or log that a stranger can inspect.
- No participant's name, face or identifying detail appears without permission. — with a file, screenshot, link or log that a stranger can inspect.
- Storage and deletion plan stated. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
