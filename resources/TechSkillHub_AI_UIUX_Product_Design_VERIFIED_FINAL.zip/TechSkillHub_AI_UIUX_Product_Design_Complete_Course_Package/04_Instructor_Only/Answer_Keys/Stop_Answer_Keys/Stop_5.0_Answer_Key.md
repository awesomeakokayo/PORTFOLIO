# Answer Key — Stop 5.0: Web Basics

**Instructor use only. Do not distribute.**
**Phase:** 5 · Design to build
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | C | judgment | Section 2 and Step 1 |
| Q2 | B | applied | Section 2 |
| Q3 | B | problem | Step 7 |
| Q4 | D | applied | Step 4 |
| Q5 | B | problem | Step 2 |
| Q6 | C | best | Step 6 |
| Q7 | B | applied | Section 4 |
| Q8 | A | best | Step 7 |
| Q9 | A | applied | Section 5 (worked steps) |
| Q10 | B | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. Which language is responsible for the structure and meaning of a page?

**Type:** judgment · **Lesson reference:** Section 2 and Step 1

**Correct answer: C. HTML, because it marks each heading, paragraph, list and button with tags that carry meaning.**

**Why this is correct:** HTML defines elements and their meaning. Section 2 and Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | CSS, because it sets colour, type and spacing for the headings and paragraphs on the page. | Incorrect | CSS styles colour, type and spacing, but it never marks content as a heading or paragraph; that meaning comes from HTML tags. |
| B | JavaScript, because it runs first and builds the headings, paragraphs and buttons the visitor sees. | Incorrect | JavaScript does not run first or build the structure; the browser parses HTML into elements, and scripts only add behaviour afterwards. |
| C | HTML, because it marks each heading, paragraph, list and button with tags that carry meaning. | **Correct** | HTML defines elements and their meaning. Section 2 and Step 1. |
| D | SQL, because it stores the page's headings and paragraphs in a table the browser reads. | Incorrect | SQL is a database language with no role in a browser page, and the browser never queries a table to learn what a heading is. |

**If the learner chose otherwise:** revisit Section 2 and Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. What does CSS primarily control?

**Type:** applied · **Lesson reference:** Section 2

**Correct answer: B. The appearance and layout: colour, type, spacing, and how boxes sit on the page.**

**Why this is correct:** CSS controls colour, type, spacing and layout. Section 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The server's location and the domain name that visitors type to reach the page. | Incorrect | Server location and domain names are resolved by DNS and hosting, which sit outside the stylesheet; CSS cannot change an address. |
| B | The appearance and layout: colour, type, spacing, and how boxes sit on the page. | **Correct** | CSS controls colour, type, spacing and layout. Section 2. |
| C | The database queries that fetch records before the page is assembled for the visitor. | Incorrect | Database queries belong to a server application, not to the browser's styling layer, which only decides how rendered elements look. |
| D | The encrypted connection and the address the browser resolves before downloading any files. | Incorrect | HTTPS and DNS happen during the request in Step 5, before any style rule is read, so they are not what CSS controls. |

**If the learner chose otherwise:** revisit Section 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. A page looks fine on a laptop but requires horizontal scrolling on a phone. Which is the most likely missing piece?

**Type:** problem · **Lesson reference:** Step 7

**Correct answer: B. The viewport meta tag, plus layouts that use max-width instead of fixed pixel widths.**

**Why this is correct:** Without the viewport tag, mobile browsers assume a desktop width; fixed widths also overflow. Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A JavaScript framework that redraws the layout whenever the screen is resized or rotated. | Incorrect | A framework adds scripts and weight but does not change the desktop-width assumption; without the viewport tag the phone still lays out at desktop width. |
| B | The viewport meta tag, plus layouts that use max-width instead of fixed pixel widths. | **Correct** | Without the viewport tag, mobile browsers assume a desktop width; fixed widths also overflow. Step 7. |
| C | More images and larger headings, so the page fills the narrow screen instead of looking empty. | Incorrect | Bigger images and headings widen the page further at 320px, so they create overflow rather than remove the missing viewport rule. |
| D | A larger base font size, so the text scales down automatically on smaller phone screens. | Incorrect | Font size does not set the width the phone assumes; larger text makes lines longer and pushes content past the screen edge. |

**If the learner chose otherwise:** revisit Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. What is the difference between padding and margin?

**Type:** applied · **Lesson reference:** Step 4

**Correct answer: D. Padding is the space inside the border, while margin is the space outside it, between boxes.**

**Why this is correct:** Padding creates space inside the element; margin outside. Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Nothing meaningful: both add space around a box, so the two words describe the same property. | Incorrect | The lesson shows they differ: removing card padding makes text touch the border, while removing `margin: 0 auto` shifts the content left. |
| B | Margin is the space reserved for text only, while padding applies to images and buttons. | Incorrect | Margin is not reserved for text; `margin: 0 auto` centres the whole `main` block, and padding applies to cards and buttons as well. |
| C | Padding only works on images, while margin is the property used to space paragraphs and headings. | Incorrect | Padding is used on the card `div`, not just images, and margin is not a paragraph-specific property. |
| D | Padding is the space inside the border, while margin is the space outside it, between boxes. | **Correct** | Padding creates space inside the element; margin outside. Step 4. |

**If the learner chose otherwise:** revisit Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. Why is "Click here" a weak button label?

**Type:** problem · **Lesson reference:** Step 2

**Correct answer: B. It never says what will happen, so screen-reader users hear an identical label on every link on the page.**

**Why this is correct:** Labels must describe the action. Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It is too short to fill the button, so it looks unbalanced beside longer text on the page. | Incorrect | Label length is not the test; 'Call to order' is longer and works because it names the action rather than the click. |
| B | It never says what will happen, so screen-reader users hear an identical label on every link on the page. | **Correct** | Labels must describe the action. Step 2. |
| C | Buttons are limited to one word in HTML, so a label like 'Call to order' is invalid. | Incorrect | Nothing in HTML limits a button to one word, and the lesson's own good label, 'Call to order', is three. |
| D | The phrase is not valid HTML markup, so browsers ignore it and announce an empty button. | Incorrect | 'Click here' is valid HTML and renders normally; the weakness is meaning, which the lesson says CSS cannot fix. |

**If the learner chose otherwise:** revisit Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. What does GitHub Pages do?

**Type:** best · **Lesson reference:** Step 6

**Correct answer: C. It hosts the static files in a public repository and serves them at a shareable public URL.**

**Why this is correct:** It is static hosting from a repo branch. Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It designs the page automatically from a short description, then keeps the layout updated as content changes. | Incorrect | Pages is static hosting; it serves the file exactly as uploaded and never generates design or layout from a description. |
| B | It replaces the stylesheet with a generated theme, so you no longer write colour or spacing rules. | Incorrect | Your own CSS still runs in the visitor's browser; Pages delivers the file and does not substitute a theme for it. |
| C | It hosts the static files in a public repository and serves them at a shareable public URL. | **Correct** | It is static hosting from a repo branch. Step 6. |
| D | It compresses images and strips unused CSS on every upload, so pages load faster automatically. | Incorrect | No compression or CSS stripping happens on upload; image compression is work you do beforehand in a tool like Squoosh. |

**If the learner chose otherwise:** revisit Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. Why should you never commit an API key to a public repository?

**Type:** applied · **Lesson reference:** Section 4

**Correct answer: B. Because anyone who opens the public repository can read the key and use it, spending your quota or exposing data.**

**Why this is correct:** Public repos are public; secrets must stay out. Section 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Because the key adds several kilobytes to the file, which slows every clone and download of the repository. | Incorrect | File size is irrelevant; even a short key can be copied from a public repository in seconds by any visitor. |
| B | Because anyone who opens the public repository can read the key and use it, spending your quota or exposing data. | **Correct** | Public repos are public; secrets must stay out. Section 4. |
| C | Because GitHub deletes accounts that contain secrets, and you lose every repository along with the page you published. | Incorrect | GitHub does not delete accounts for committed secrets; the damage is that strangers can now use your credential. |
| D | Because keys only function inside private repositories, so a public one silently disables the integration you built. | Incorrect | A key committed publicly still works for whoever reads it — that exposure is the danger, not a limit on where keys run. |

**If the learner chose otherwise:** revisit Section 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. A page's text is readable but the layout breaks at 200% zoom. What is the main problem?

**Type:** best · **Lesson reference:** Step 7

**Correct answer: A. Content and containers are fixed in ways that cannot reflow, so they push past the viewport when text grows.**

**Why this is correct:** Reflow at 200% is a WCAG expectation; fixed widths and absolute positioning often break it. Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Content and containers are fixed in ways that cannot reflow, so they push past the viewport when text grows. | **Correct** | Reflow at 200% is a WCAG expectation; fixed widths and absolute positioning often break it. Step 7. |
| B | The font is too small at the default size, so increasing zoom exposes how little text fits on screen. | Incorrect | The stem says the text is already readable, so size is not the fault; larger type would not help containers that cannot reflow. |
| C | HTML is the wrong language for a zoomable page, so the browser cannot recalculate the layout correctly. | Incorrect | HTML is the correct language here; the break comes from fixed widths and heights, not from the markup language choice. |
| D | The server is slow to respond, so the browser draws the layout before all the styles have arrived. | Incorrect | A slow server delays when files arrive, but once loaded, reflow at 200% is decided by CSS sizing. |

**If the learner chose otherwise:** revisit Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A learner's page overflows horizontally at 320 px, forcing users to scroll sideways. Which check should they make first?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: A. Check that the viewport meta tag is present and that no container has a fixed width wider than 320px.**

**Why this is correct:** The viewport tag and fixed widths are the most common causes of mobile overflow.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Check that the viewport meta tag is present and that no container has a fixed width wider than 320px. | **Correct** | The viewport tag and fixed widths are the most common causes of mobile overflow. |
| B | Add more images and cards to fill the empty space, which usually stops the page stretching sideways. | Incorrect | Extra images and cards usually widen a narrow screen rather than fill it, so they add overflow instead of fixing it. |
| C | Increase the body font size to 24px so the text wraps sooner and no longer pushes the layout wider. | Incorrect | Raising text to 24px lengthens lines and makes overflow more likely at 320px; it does not remove a fixed width. |
| D | Remove the `lang` attribute from the html element, which lets the browser recalculate the page width. | Incorrect | `lang` tells screen readers and translators which language to use; removing it harms pronunciation and changes no widths. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A button says 'Copied' but the clipboard is empty, and the code changes the label before any copy operation finishes. What is the defect?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: B. The interface claims success before the asynchronous copy has finished, and there is no error fallback.**

**Why this is correct:** Feedback must reflect the actual result; the clipboard promise must be awaited and failures handled.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The button uses the wrong font, so the browser cannot attach the clipboard permission prompt to that element. | Incorrect | Font choice is cosmetic; it plays no part in clipboard permission, and the defect is the premature success claim. |
| B | The interface claims success before the asynchronous copy has finished, and there is no error fallback. | **Correct** | Feedback must reflect the actual result; the clipboard promise must be awaited and failures handled. |
| C | The page has too many headings, which interrupts the script that writes the order number to the clipboard. | Incorrect | Heading count cannot affect clipboard access; the fault is the script reporting success before `writeText` resolves. |
| D | The copy should run on page load rather than on click, so the clipboard is already filled. | Incorrect | Copying on load would still produce a false 'Copied' claim; the lesson copies on click and reports only after success. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- The page loads from a public URL on a device other than the one you built it on. — with a file, screenshot, link or log that a stranger can inspect.
- All visible text has been changed from the starter; nothing identifies a real person or business without permission. — with a file, screenshot, link or log that a stranger can inspect.
- At least one heading, paragraph, list, image or icon, and button are present and meaningful. — with a file, screenshot, link or log that a stranger can inspect.
- Body text contrast is at least 4.5:1 and is recorded. — with a file, screenshot, link or log that a stranger can inspect.
- Images have appropriate `alt` text, or `alt=""` if decorative. — with a file, screenshot, link or log that a stranger can inspect.
- The page works at 320px width without horizontal scrolling. — with a file, screenshot, link or log that a stranger can inspect.
- The button has a visible focus state and a label that describes its action. — with a file, screenshot, link or log that a stranger can inspect.
- The note explains at least one failed attempt and the fix. — with a file, screenshot, link or log that a stranger can inspect.
- No passwords, keys, phone numbers or personal addresses are in the repository. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
