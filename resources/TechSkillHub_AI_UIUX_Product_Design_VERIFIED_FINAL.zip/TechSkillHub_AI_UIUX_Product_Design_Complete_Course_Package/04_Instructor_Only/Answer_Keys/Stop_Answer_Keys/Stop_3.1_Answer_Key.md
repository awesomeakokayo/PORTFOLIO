# Answer Key — Stop 3.1: Figma Essentials

**Instructor use only. Do not distribute.**
**Phase:** 3 · Figma fluency and design systems
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | C | judgment | Section 5, Step 3 |
| Q2 | B | applied | Section 5, Step 4 |
| Q3 | D | problem | Section 5, Step 6 |
| Q4 | B | applied | Section 5, Step 7 |
| Q5 | B | problem | Section 5, Step 8 |
| Q6 | D | best | Section 5, Step 2 |
| Q7 | B | applied | Section 5, Step 9 |
| Q8 | C | best | Section 5, Step 10 |
| Q9 | C | applied | Section 5 (worked steps) |
| Q10 | A | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. What is the main difference between a frame and a group?

**Type:** judgment · **Lesson reference:** Section 5, Step 3

**Correct answer: C. A frame has size, clipping and export, while a group is only a container for its layers.**

**Why this is correct:** Frames behave like screens; groups organise. Section 5, Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A group can hold text layers and images, while a frame can hold only one shape. | Incorrect | Frames hold text and images as readily as groups, so the ability to contain content is shared; only size, clipping and export separate them. |
| B | A frame is always transparent, so anything placed behind it stays visible through the canvas. | Incorrect | Frames take fills and can be fully opaque, so transparency is not a property that distinguishes them from groups. |
| C | A frame has size, clipping and export, while a group is only a container for its layers. | **Correct** | Frames behave like screens; groups organise. Section 5, Step 3. |
| D | A group cannot be renamed in the layers panel, so it always keeps its default name. | Incorrect | Groups can be renamed in the layers panel like any other layer, and naming groups is part of the tidying the lesson requires. |

**If the learner chose otherwise:** revisit Section 5, Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. Why use pages for workstreams rather than one page per screen?

**Type:** applied · **Lesson reference:** Section 5, Step 4

**Correct answer: B. Pages per screen multiply navigation and make it harder to compare screens side by side.**

**Why this is correct:** Pages should separate kinds of work. Section 5, Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Figma limits a file to five pages, so each screen must share a page with other screens. | Incorrect | No page cap exists: the recommended structure lists eight pages and the pass criteria ask for five, so the reason is navigation rather than a limit. |
| B | Pages per screen multiply navigation and make it harder to compare screens side by side. | **Correct** | Pages should separate kinds of work. Section 5, Step 4. |
| C | Screens cannot be placed on pages at all, so each screen needs its own separate file. | Incorrect | Screens sit on frames that live on pages, and the Design page is exactly where those frames belong, so the claim reverses how pages work. |
| D | Pages are reserved for components only, so screens belong on the canvas and not on pages. | Incorrect | Components are only one workstream; the recommended structure also gives pages to Research, Flows, Design, Prototype, Handoff and Archive. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. What does a local text style do?

**Type:** problem · **Lesson reference:** Section 5, Step 6

**Correct answer: D. It saves reusable typography values that can be applied and updated in one place.**

**Why this is correct:** Styles centralise values. Section 5, Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It automatically writes sample copy into every text layer that uses the style. | Incorrect | A style stores font, size, weight and line height; it applies typography to existing copy and never generates words of its own. |
| B | It exports each text layer as a separate image file when the frame is exported. | Incorrect | Export is a property of a frame or object, and a style only holds typography values, so it cannot turn text into an image. |
| C | It translates the file's text into another language whenever the style is applied. | Incorrect | Translation is content work done on the words themselves, while a style only records typography values and applies them. |
| D | It saves reusable typography values that can be applied and updated in one place. | **Correct** | Styles centralise values. Section 5, Step 6. |

**If the learner chose otherwise:** revisit Section 5, Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. When should you create a component?

**Type:** applied · **Lesson reference:** Section 5, Step 7

**Correct answer: B. When an object repeats and will need consistent updates across several screens.**

**Why this is correct:** Reuse and consistency drive componentisation. Section 5, Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Only when a designer on the team explicitly asks you to create one. | Incorrect | The trigger is repetition, not permission: make a component when an object appears three or more times, or twice and will grow. |
| B | When an object repeats and will need consistent updates across several screens. | **Correct** | Reuse and consistency drive componentisation. Section 5, Step 7. |
| C | Only for buttons, because other objects change too often to be worth componentising. | Incorrect | Buttons are one example; the lesson also componentises cards, list rows, badges and modals, so limiting the rule to buttons is too narrow. |
| D | After handoff, once the final screens have been approved by the client. | Incorrect | Components must exist before handoff so instances receive updates; building them afterwards means rebuilding copies that already drifted. |

**If the learner chose otherwise:** revisit Section 5, Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. What does naming a version in history help with?

**Type:** problem · **Lesson reference:** Section 5, Step 8

**Correct answer: B. It marks a meaningful milestone that can be restored or referenced later.**

**Why this is correct:** Named versions are checkpoints. Section 5, Step 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It makes the file smaller by compressing earlier versions of every page. | Incorrect | A version name labels a saved checkpoint; it deletes no layers and reduces no weight, so the file size stays the same. |
| B | It marks a meaningful milestone that can be restored or referenced later. | **Correct** | Named versions are checkpoints. Section 5, Step 8. |
| C | It shares the file publicly with anyone who has the version name. | Incorrect | Sharing is set by link permissions such as Can view or Can comment, while a version name is only a label on a checkpoint. |
| D | It transfers ownership of the file to the person who named the version. | Incorrect | Ownership is a file or plan setting, not a history action; naming a version records a milestone and transfers nothing. |

**If the learner chose otherwise:** revisit Section 5, Step 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. Which shortcut opens command search?

**Type:** best · **Lesson reference:** Section 5, Step 2

**Correct answer: D. Ctrl/Cmd+/, which opens a search field for finding commands by name.**

**Why this is correct:** Command search finds tools by name when the UI moves. Section 5, Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Ctrl/Cmd+S, which saves the current file and shows the save confirmation. | Incorrect | Ctrl/Cmd + S saves the file, and Figma autosaves anyway; it never opens a search field for commands. |
| B | Shift+2, which zooms the canvas to the layer you have selected. | Incorrect | Shift + 2 zooms to the current selection, a navigation shortcut listed separately from command search. |
| C | Alt+F4, which closes the application window on a Windows machine. | Incorrect | Alt + F4 closes the application window on Windows and is not a Figma command at all. |
| D | Ctrl/Cmd+/, which opens a search field for finding commands by name. | **Correct** | Command search finds tools by name when the UI moves. Section 5, Step 2. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. Why compress images before placing them?

**Type:** applied · **Lesson reference:** Section 5, Step 9

**Correct answer: B. Figma stores the original, so large images bloat the file and slow collaboration.**

**Why this is correct:** File weight affects performance and sharing. Section 5, Step 9.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Figma rejects any image over 1 MB, so compression is required before placing. | Incorrect | No size threshold is described; the lesson's reason is that Figma stores the original, so weight slows collaboration rather than causing rejection. |
| B | Figma stores the original, so large images bloat the file and slow collaboration. | **Correct** | File weight affects performance and sharing. Section 5, Step 9. |
| C | Compression raises image contrast, which keeps small text legible on busy photos. | Incorrect | Compression reduces file weight, while contrast comes from colour and luminance and is checked separately, so compressing does nothing for it. |
| D | Compression converts every placed image into a lighter vector format automatically. | Incorrect | Placing an image keeps the original file and does not convert formats, so only compressing before placing reduces weight. |

**If the learner chose otherwise:** revisit Section 5, Step 9 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. What is the best sharing setting for a reviewer who only needs to comment?

**Type:** best · **Lesson reference:** Section 5, Step 10

**Correct answer: C. Can view or can comment, which lets the reviewer read and respond without editing.**

**Why this is correct:** Least privilege protects the file. Section 5, Step 10.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Can edit, so the reviewer can fix small issues without waiting for you. | Incorrect | Edit access is more than a commenter needs, and the lesson says not to share it unless the reviewer actually needs it. |
| B | Owner, so the reviewer has full control of the file during the review. | Incorrect | Owner is full control over the file and its settings, far beyond commenting, so it breaks the least-privilege rule. |
| C | Can view or can comment, which lets the reviewer read and respond without editing. | **Correct** | Least privilege protects the file. Section 5, Step 10. |
| D | A public edit link, so anyone who receives it can open and change the file. | Incorrect | A public edit link lets anyone change the design; the lesson lists it as a common mistake and prescribes view or comment links. |

**If the learner chose otherwise:** revisit Section 5, Step 10 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A learner is organising a Figma file with explorations, final screens and a component library. Which page structure is most useful to a collaborator?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: C. Separate pages for exploration, final screens and the component library, with clear names.**

**Why this is correct:** Pages should separate kinds of work so collaborators can find the current source quickly.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | One page holding every frame in creation order, with no sections or page names. | Incorrect | Creation order means nothing to a collaborator, and mixing exploration with final screens makes the current design impossible to identify. |
| B | One page for each colour used in the file, so the palette is easy to compare. | Incorrect | Pages separate kinds of work, not colour values; colour decisions belong in styles, and a page per colour multiplies navigation for no reason. |
| C | Separate pages for exploration, final screens and the component library, with clear names. | **Correct** | Pages should separate kinds of work so collaborators can find the current source quickly. |
| D | A separate file for every screen, with no index or shared navigation between them. | Incorrect | Splitting every screen into its own file destroys the single source of truth and defeats comparison, which is what pages exist to preserve. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A learner shares a file with 40 frames named Frame 1 to Frame 40 and no page structure. What will most likely happen in review?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: A. Reviewers will struggle to find the current screen and may comment on the wrong version.**

**Why this is correct:** Names and pages are navigation infrastructure; without them the file is ambiguous.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Reviewers will struggle to find the current screen and may comment on the wrong version. | **Correct** | Names and pages are navigation infrastructure; without them the file is ambiguous. |
| B | Figma will automatically rename the frames by reading the text inside each one. | Incorrect | Figma keeps the layer name the designer typed; it does not read text content and rename Frame 12 automatically. |
| C | The file will export faster, because unnamed layers take less time to process. | Incorrect | Naming has no effect on export speed, and unnamed frames make selection and handoff slower rather than faster. |
| D | The frames will convert themselves into components once the file is shared. | Incorrect | Componentisation is a deliberate command, Ctrl/Cmd + Alt + K, and forty unnamed frames stay plain frames until someone acts. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- Five pages with a clear purpose. — with a file, screenshot, link or log that a stranger can inspect.
- A cover frame with project, name, date and description. — with a file, screenshot, link or log that a stranger can inspect.
- Three named sections. — with a file, screenshot, link or log that a stranger can inspect.
- Six numbered frames in flow order. — with a file, screenshot, link or log that a stranger can inspect.
- Five text and five colour styles applied. — with a file, screenshot, link or log that a stranger can inspect.
- Two components with instances. — with a file, screenshot, link or log that a stranger can inspect.
- A named version in history. — with a file, screenshot, link or log that a stranger can inspect.
- No unnamed frames or groups on the main design page. — with a file, screenshot, link or log that a stranger can inspect.
- A file guide and shortcut sheet. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
