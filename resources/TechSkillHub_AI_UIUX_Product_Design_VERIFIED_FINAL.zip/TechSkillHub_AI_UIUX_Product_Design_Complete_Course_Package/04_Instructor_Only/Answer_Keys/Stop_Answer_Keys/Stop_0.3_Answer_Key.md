# Answer Key — Stop 0.3: Seeing Like a Designer

**Instructor use only. Do not distribute.**
**Phase:** 0 · Getting started
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | A | judgment | Section 5, Step 1 |
| Q2 | A | applied | Section 5, Step 2 |
| Q3 | B | problem | Section 2, terms 15-17 |
| Q4 | D | applied | Section 5, Step 3 |
| Q5 | D | problem | Section 2, term 24 |
| Q6 | A | best | Section 5, Step 4 |
| Q7 | A | applied | Section 2, term 10 |
| Q8 | C | best | Section 5, Step 5 |
| Q9 | C | applied | Section 5 (worked steps) |
| Q10 | A | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. Which part is drawn by the operating system rather than the app?

**Type:** judgment · **Lesson reference:** Section 5, Step 1

**Correct answer: A. The status bar at the top, showing the time, battery level and signal strength.**

**Why this is correct:** Time, battery and signal are system UI. Section 5, Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The status bar at the top, showing the time, battery level and signal strength. | **Correct** | Time, battery and signal are system UI. Section 5, Step 1. |
| B | The primary button at the bottom of the screen that submits the form. | Incorrect | A primary button belongs to the app's action layer; the OS only owns the status bar, gesture bar and keyboard. |
| C | The card in the content area that groups an image with its title. | Incorrect | A card is drawn by the app to group related content, so it belongs to the content layer. |
| D | The helper text under the field that explains the required format. | Incorrect | Helper text is app content placed near a form field, not system UI. |

**If the learner chose otherwise:** revisit Section 5, Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. What is the difference between a component and a pattern?

**Type:** applied · **Lesson reference:** Section 5, Step 2

**Correct answer: A. A component is a reusable part; a pattern is a reusable solution made of parts.**

**Why this is correct:** Button = component; checkout = pattern. Section 5, Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A component is a reusable part; a pattern is a reusable solution made of parts. | **Correct** | Button = component; checkout = pattern. Section 5, Step 2. |
| B | A pattern is always larger than a screen, while a component fits inside one. | Incorrect | A pattern is a reusable solution such as search-filter-results; it fits inside a screen rather than being larger than one. |
| C | A component is used only on mobile, while a pattern works on any platform. | Incorrect | Buttons and text fields appear on desktop as well, and Step 2 sets no mobile-only limit. |
| D | There is no real difference between the two terms in everyday design work. | Incorrect | Step 2 draws the distinction clearly: a broken button is a component fault, a checkout asking the address three times is a pattern fault. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. A form field shows "Enter your 11-digit phone number" inside the box, and the text disappears when the user types. What is missing?

**Type:** problem · **Lesson reference:** Section 2, terms 15-17

**Correct answer: B. A visible label above the field and helper text that stays on screen.**

**Why this is correct:** A placeholder vanishes once typing starts, so the requirement must live in a label or helper text. Section 2, terms 15-17.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A primary button that submits the completed form to the server. | Incorrect | The field already invites typing; a primary button is the action that submits the form, not the missing instruction. |
| B | A visible label above the field and helper text that stays on screen. | **Correct** | A placeholder vanishes once typing starts, so the requirement must live in a label or helper text. Section 2, terms 15-17. |
| C | A toast that confirms the number was accepted after submission. | Incorrect | A toast is a brief confirmation at the screen edge, not a field label or requirement. |
| D | A breadcrumb that shows where the form sits in the wider flow. | Incorrect | A breadcrumb shows where you are in a hierarchy such as Home > Orders > Receipt, not what a field needs. |

**If the learner chose otherwise:** revisit Section 2, terms 15-17 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. Which is the strongest annotation of a screen's purpose?

**Type:** applied · **Lesson reference:** Section 5, Step 3

**Correct answer: D. "This screen wants the user to check the amount and recipient, because the amount is largest and the button repeats it."**

**Why this is correct:** It names the intended action and points at evidence in the design. Section 5, Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | "This screen is for transfers between two accounts that the same person holds at one local bank branch." | Incorrect | "For transfers" names a topic but states no intended action and points at no evidence, both of which Step 3 requires. |
| B | "This screen is beautiful because the colours and the spacing feel very calm, modern and easy to read." | Incorrect | "Beautiful" is a taste judgement; it names nothing in the design to check. |
| C | "This screen has a blue button in the footer area of the layout, which looks clear and modern." | Incorrect | "Has a blue button" describes colour, the least useful starting place, and never says what the screen wants. |
| D | "This screen wants the user to check the amount and recipient, because the amount is largest and the button repeats it." | **Correct** | It names the intended action and points at evidence in the design. Section 5, Step 3. |

**If the learner chose otherwise:** revisit Section 5, Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. A screen shows "No orders yet" with a "Start shopping" button. What is this called?

**Type:** problem · **Lesson reference:** Section 2, term 24

**Correct answer: D. An empty state, because there is no content yet and a route forward.**

**Why this is correct:** It is the zero-content state with a route to the first action. Section 2, term 24.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | An error state, because the message reports that something failed. | Incorrect | An error state reports an action that failed; "No orders yet" reports zero content rather than a failure. |
| B | A loading state, because the screen is waiting for data to arrive. | Incorrect | A loading state shows progress while data arrives; here the data has arrived and is simply empty. |
| C | A modal, because it interrupts the user and demands a decision. | Incorrect | A modal interrupts the screen and demands a decision; this is a full screen with a route forward, not an overlay. |
| D | An empty state, because there is no content yet and a route forward. | **Correct** | It is the zero-content state with a route to the first action. Section 2, term 24. |

**If the learner chose otherwise:** revisit Section 2, term 24 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. Why should you annotate with a numbered legend instead of writing labels over the interface?

**Type:** best · **Lesson reference:** Section 5, Step 4

**Correct answer: A. Labels over the interface obscure the thing being analysed and become unreadable.**

**Why this is correct:** The annotation must not destroy the evidence. Section 5, Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Labels over the interface obscure the thing being analysed and become unreadable. | **Correct** | The annotation must not destroy the evidence. Section 5, Step 4. |
| B | Legends are required by Figma before a file can be exported or shared. | Incorrect | Figma imposes no legend requirement; the legend is a readability choice from Step 4. |
| C | Numbers look more professional than words on a design portfolio page. | Incorrect | Numbers are not inherently more professional; they work because the explanations sit in a legend that stays readable. |
| D | A numbered legend reduces the file size of the exported image noticeably. | Incorrect | A legend does not shrink the export; the real problem is that labels written over interface text become unreadable. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. Which action is tertiary?

**Type:** applied · **Lesson reference:** Section 2, term 10

**Correct answer: A. A plain text link under the form that says "Forgot password?" quietly.**

**Why this is correct:** Tertiary actions are low-emphasis text links. Section 2, term 10.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A plain text link under the form that says "Forgot password?" quietly. | **Correct** | Tertiary actions are low-emphasis text links. Section 2, term 10. |
| B | A large filled "Pay now" button that spans the width of the footer. | Incorrect | A large filled "Pay now" button is the primary action, the highest-emphasis control on the screen. |
| C | An outlined "Save draft" button placed beside the primary action in the footer. | Incorrect | An outlined button is a secondary action — less important than the primary, but still a button. |
| D | A floating action button in the corner of the screen for a new message. | Incorrect | A floating action button is a prominent primary-style control, not a low-emphasis text link. |

**If the learner chose otherwise:** revisit Section 2, term 10 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. Why is the empty state often revealing?

**Type:** best · **Lesson reference:** Section 5, Step 5

**Correct answer: C. It shows how the product behaves before the user has data, which every new user sees first.**

**Why this is correct:** Every new user meets the empty state first; poor empty states cause abandonment. Section 5, Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It is usually the prettiest screen because designers spend most of their time on it. | Incorrect | The empty state's value is informational; it is often plain or neglected rather than the prettiest screen. |
| B | It never contains buttons, so it shows the product without any actions at all. | Incorrect | Empty states usually do contain a button — "Start shopping" is the route to the first action. |
| C | It shows how the product behaves before the user has data, which every new user sees first. | **Correct** | Every new user meets the empty state first; poor empty states cause abandonment. Section 5, Step 5. |
| D | It is required by app stores before an app can be published to the public. | Incorrect | App stores do not mandate empty states; they matter because every new user meets one first. |

**If the learner chose otherwise:** revisit Section 5, Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A learner is annotating a checkout screen and wants to point out the order total, the primary button and a missing error message. Which annotation method keeps the evidence readable?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: C. Place numbered markers on a copy of the screen and put the explanations in a legend beside it.**

**Why this is correct:** A numbered legend preserves the screen as evidence and keeps the notes readable.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Write long labels directly over the interface elements so the notes sit close to them. | Incorrect | Long labels written over the interface hide the total and button you are pointing at, so the evidence becomes unreadable. |
| B | Replace the screen with a written paragraph that describes what it looks like in detail. | Incorrect | A paragraph replaces the screen with description, leaving nothing to verify the claim against. |
| C | Place numbered markers on a copy of the screen and put the explanations in a legend beside it. | **Correct** | A numbered legend preserves the screen as evidence and keeps the notes readable. |
| D | Use a different colour for every note without adding any single key to explain them. | Incorrect | Colours with no key create a private code no reviewer can decode, so the notes cannot be read. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A learner labels the phone's time, battery icon and signal bars as app interface elements. What is the conceptual error?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: A. They are system UI, drawn by the operating system rather than by the app.**

**Why this is correct:** Status-bar items belong to the operating system layer, not the app's interface.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | They are system UI, drawn by the operating system rather than by the app. | **Correct** | Status-bar items belong to the operating system layer, not the app's interface. |
| B | They are components because they appear on every screen of the same app. | Incorrect | Appearing on every screen does not make them components; components are app-drawn parts, and the OS draws these. |
| C | They are patterns because the same three items repeat across every screen. | Incorrect | Repetition does not make them patterns; a pattern is a reusable solution such as search-then-filter. |
| D | They are decorative images that carry no meaning for the person using the phone. | Incorrect | Time, battery and signal carry real meaning, so calling them decorative images misreads the status bar. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- Three different real screens from three different apps (or three clearly different flows). — with a file, screenshot, link or log that a stranger can inspect.
- At least 20 labelled parts in total, with terms used correctly. — with a file, screenshot, link or log that a stranger can inspect.
- Every screen has the "wants the user to…" sentence with evidence. — with a file, screenshot, link or log that a stranger can inspect.
- Every screen has one concrete improvement tied to a named part. — with a file, screenshot, link or log that a stranger can inspect.
- Private data is removed or blurred. — with a file, screenshot, link or log that a stranger can inspect.
- The missing-state note identifies at least one absent state and what it would need. — with a file, screenshot, link or log that a stranger can inspect.
- The comparison names the clearest primary action and uses at least four glossary terms. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
