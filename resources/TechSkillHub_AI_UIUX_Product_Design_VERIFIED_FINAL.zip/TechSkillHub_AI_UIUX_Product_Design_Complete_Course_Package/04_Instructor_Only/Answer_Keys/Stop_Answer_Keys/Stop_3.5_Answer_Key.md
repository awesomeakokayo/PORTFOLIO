# Answer Key — Stop 3.5: Building a Small Design System

**Instructor use only. Do not distribute.**
**Phase:** 3 · Figma fluency and design systems
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | A | judgment | Section 5, Step 2 |
| Q2 | B | applied | Section 5, Step 5 |
| Q3 | C | problem | Section 2 and Step 8 |
| Q4 | B | applied | Section 5, Step 7 |
| Q5 | C | problem | Section 5, Step 6 |
| Q6 | B | best | Section 5, Step 8 |
| Q7 | C | applied | Section 5, Step 1 |
| Q8 | B | best | Section 2 |
| Q9 | A | applied | Section 5 (worked steps) |
| Q10 | B | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. What is the difference between a primitive and a semantic token?

**Type:** judgment · **Lesson reference:** Section 5, Step 2

**Correct answer: A. A primitive is a raw value, while a semantic token names a role and aliases it.**

**Why this is correct:** Primitives are values; semantics express meaning. Section 5, Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A primitive is a raw value, while a semantic token names a role and aliases it. | **Correct** | Primitives are values; semantics express meaning. Section 5, Step 2. |
| B | A primitive is used for colour only, while semantics cover spacing and type. | Incorrect | Primitives cover space, radius, font size, weight and shadow as well as colour, so colour-only is far too narrow. |
| C | A semantic token is always darker, so it reads correctly on every surface. | Incorrect | Semantics express a role, not a brightness; color.action.on-primary resolves to white, which is lighter than the primitive it names. |
| D | There is no difference, because both resolve to the same value in code. | Incorrect | The lesson keeps two layers: raw palette values as primitives and role names that alias them as semantics. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. What should component documentation include beyond appearance?

**Type:** applied · **Lesson reference:** Section 5, Step 5

**Correct answer: B. Purpose, use, don't, accessibility, content and developer notes for each component.**

**Why this is correct:** Documentation is guidance for decisions, not a gallery. Section 5, Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Only a screenshot of the component in its default state, with a caption. | Incorrect | A screenshot shows appearance only, and the common mistakes table names docs that only show screenshots as the gap to fix. |
| B | Purpose, use, don't, accessibility, content and developer notes for each component. | **Correct** | Documentation is guidance for decisions, not a gallery. Section 5, Step 5. |
| C | The designer's name and the date the component was last edited. | Incorrect | Ownership belongs on the governance page, and a name and date tell a reader nothing about when or how to use the component. |
| D | The file size and the number of layers the component contains. | Incorrect | File weight and layer count are operational details, not usage guidance, and they do not help anyone choose the right component. |

**If the learner chose otherwise:** revisit Section 5, Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. What is design system drift?

**Type:** problem · **Lesson reference:** Section 2 and Step 8

**Correct answer: C. The gap between the system and the product as local changes accumulate.**

**Why this is correct:** Drift is divergence through overrides and one-offs. Section 2 and Step 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A file becoming corrupted, so components no longer open correctly. | Incorrect | Corruption is a technical file failure, while drift is people making local changes that diverge from the system. |
| B | A colour fading over time, so the palette gradually loses contrast. | Incorrect | Colours do not fade; drift accumulates through overrides, detached instances and one-off values, which the adoption table counts. |
| C | The gap between the system and the product as local changes accumulate. | **Correct** | Drift is divergence through overrides and one-offs. Section 2 and Step 8. |
| D | A component moving on the canvas, so the layout no longer aligns. | Incorrect | Canvas position is layout, not drift, and moving a component changes no decision the system records. |

**If the learner chose otherwise:** revisit Section 2 and Step 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. Why have a governance page for a one-person system?

**Type:** applied · **Lesson reference:** Section 5, Step 7

**Correct answer: B. Because future-you will not remember today's decisions, and the system may be handed over.**

**Why this is correct:** Governance preserves decisions and supports change. Section 5, Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Because Figma requires a governance page before a library can be published. | Incorrect | Figma imposes no governance page, and the lesson's reason is that future-you inherits decisions with no memory of them. |
| B | Because future-you will not remember today's decisions, and the system may be handed over. | **Correct** | Governance preserves decisions and supports change. Section 5, Step 7. |
| C | To increase the page count, so the file looks more thorough to reviewers. | Incorrect | Page count is not a goal, and a governance page is a decision record with version, owner and change log. |
| D | To satisfy clients only, since internal teams rarely read governance pages. | Incorrect | The lesson says even a one-person system needs governance because of handover and memory, not to satisfy clients. |

**If the learner chose otherwise:** revisit Section 5, Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. A screen needs a one-off component. What are the two legitimate options?

**Type:** problem · **Lesson reference:** Section 5, Step 6

**Correct answer: C. Add it to the system if it recurs, or document it as an exception.**

**Why this is correct:** Keep the system honest without forcing false reuse. Section 5, Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Detach a component from the library and adapt it until it fits the screen. | Incorrect | Detaching is how drift starts, and the lesson's two options are adding a recurring part or documenting a genuine exception. |
| B | Use a raw hex value for that one element and record nothing about it. | Incorrect | A raw hex bypasses tokens, cannot be themed, and leaves the component with a value no one can trace to a decision. |
| C | Add it to the system if it recurs, or document it as an exception. | **Correct** | Keep the system honest without forcing false reuse. Section 5, Step 6. |
| D | Copy a similar component from another product, then rename it locally to fit. | Incorrect | A copied component carries another product's decisions and will not match your tokens, naming or accessibility notes. |

**If the learner chose otherwise:** revisit Section 5, Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. What does an adoption table reveal?

**Type:** best · **Lesson reference:** Section 5, Step 8

**Correct answer: B. How much of the product uses the system, and where overrides live.**

**Why this is correct:** Adoption and drift are measured, not assumed. Section 5, Step 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | How many pages the file contains, and which ones are out of date. | Incorrect | Page count is file structure, while the adoption table counts components used, overrides, detached instances and one-off values. |
| B | How much of the product uses the system, and where overrides live. | **Correct** | Adoption and drift are measured, not assumed. Section 5, Step 8. |
| C | The total number of distinct colours used anywhere in the file. | Incorrect | Colour count is a token and style question, not a measure of how much of the screen uses system parts. |
| D | The number of contributors who have edited the library this month. | Incorrect | Contributor count comes from file activity and permissions, not from a per-screen adoption count. |

**If the learner chose otherwise:** revisit Section 5, Step 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. Why are principles only useful if they change a decision?

**Type:** applied · **Lesson reference:** Section 5, Step 1

**Correct answer: C. Otherwise they are decoration and cannot guide real trade-offs in the work.**

**Why this is correct:** A principle that never rejects anything has no operational value. Section 5, Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Because Figma limits how much text a principles page can hold. | Incorrect | There is no such text limit; principles are short by choice because a long one cannot guide a fast trade-off. |
| B | Because clients dislike principles and prefer to see finished screens. | Incorrect | The audience for a principle is the team making trade-offs, and client taste is not the test of whether it is operational. |
| C | Otherwise they are decoration and cannot guide real trade-offs in the work. | **Correct** | A principle that never rejects anything has no operational value. Section 5, Step 1. |
| D | Because principles must be numeric, so each one can be measured. | Incorrect | Principles are statements with consequences, not numbers; the examples are clarity before decoration and accessible by default. |

**If the learner chose otherwise:** revisit Section 5, Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. What does deprecation mean in a design system?

**Type:** best · **Lesson reference:** Section 2

**Correct answer: B. Retiring a component or token while giving teams time to migrate.**

**Why this is correct:** Deprecation is a managed transition, not a surprise removal. Section 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Deleting a file without notice, so nobody keeps using the old version. | Incorrect | Deleting without notice is an unmanaged removal, while deprecation keeps the old component available during migration. |
| B | Retiring a component or token while giving teams time to migrate. | **Correct** | Deprecation is a managed transition, not a surprise removal. Section 2. |
| C | Renaming a colour, so the old name no longer appears in the index. | Incorrect | A rename is a naming change with a mapping table, not a retirement that names a replacement and a migration window. |
| D | Adding a variant, so the component covers one more state or size. | Incorrect | Adding a variant is a minor addition to the set, which is the opposite of retiring something. |

**If the learner chose otherwise:** revisit Section 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A team changes its primary colour in 12 separate components and misses two. What should the system have provided?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: A. A semantic colour token or variable that all components reference.**

**Why this is correct:** A shared semantic token changes the value once and propagates consistently.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A semantic colour token or variable that all components reference. | **Correct** | A shared semantic token changes the value once and propagates consistently. |
| B | A longer brand guidelines PDF, with the new colour specified precisely. | Incorrect | A document cannot propagate edits, so the two missed components would still be missed after the PDF was updated. |
| C | More one-off components for each screen, so each can be edited separately. | Incorrect | More one-off components multiply the places to update, which is precisely the failure the question describes. |
| D | A rule that designers must remember all 12 places and check them. | Incorrect | Relying on memory of twelve locations is what failed; a semantic token changes the value once and every component follows. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A design system page lists component names and pictures but no usage rules. What is the main documentation gap?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: B. Guidance on when to use each component, its states, content rules and accessibility.**

**Why this is correct:** Documentation must enable correct use, not just recognition.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | More decorative illustrations, so the page feels finished and on brand. | Incorrect | Illustrations are decoration and do not tell a reader when to use a component or what it does in each state. |
| B | Guidance on when to use each component, its states, content rules and accessibility. | **Correct** | Documentation must enable correct use, not just recognition. |
| C | A larger logo, so readers recognise which team owns the system. | Incorrect | A larger logo is branding, and it says nothing about states, content rules or accessibility behaviour. |
| D | A list of every file the team has made since the system started. | Incorrect | A list of files is an inventory, not documentation of when and how to use the components. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- Five principles, each with a consequence. — with a file, screenshot, link or log that a stranger can inspect.
- 20+ primitives and 15+ semantic tokens. — with a file, screenshot, link or log that a stranger can inspect.
- Ten components with variants and documented properties. — with a file, screenshot, link or log that a stranger can inspect.
- Documentation covers purpose, anatomy, use, don't, accessibility, content and developer notes. — with a file, screenshot, link or log that a stranger can inspect.
- One screen composed only from system components. — with a file, screenshot, link or log that a stranger can inspect.
- Adoption table with overrides and detached instances counted. — with a file, screenshot, link or log that a stranger can inspect.
- Governance page with version, owner, change log, review, deprecation and contribution. — with a file, screenshot, link or log that a stranger can inspect.
- Reflection identifies a real documentation difficulty. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
