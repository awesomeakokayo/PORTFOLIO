# Answer Key — Stop 0.5: Your First Screen

**Instructor use only. Do not distribute.**
**Phase:** 0 · Getting started
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | A | judgment | Section 2 and Step 1 |
| Q2 | D | applied | Section 5, Step 2 |
| Q3 | D | problem | Section 5, Step 7 |
| Q4 | C | applied | Section 5, Step 4 and section 6 |
| Q5 | A | problem | Section 5, Step 5 |
| Q6 | B | best | Section 5, Step 8 |
| Q7 | B | applied | Section 7, step 10 |
| Q8 | D | best | Section 5, Step 6 |
| Q9 | A | applied | Section 5 (worked steps) |
| Q10 | D | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. What is the main difference between a frame and a group in Figma?

**Type:** judgment · **Lesson reference:** Section 2 and Step 1

**Correct answer: A. A frame has a fixed size and can clip and export; a group only keeps layers together.**

**Why this is correct:** Frames behave like screens/artboards; groups are organisational. Section 2 and Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A frame has a fixed size and can clip and export; a group only keeps layers together. | **Correct** | Frames behave like screens/artboards; groups are organisational. Section 2 and Step 1. |
| B | A group can contain text layers, while a frame can only contain shapes and images. | Incorrect | Frames commonly hold text layers, so text is not what separates a frame from a group. |
| C | A frame is always transparent, while a group takes the colour of its contents. | Incorrect | A frame can have a fill, no fill or an image; transparency is not what defines it. |
| D | A group appears in the layers panel, while a frame is hidden from that panel. | Incorrect | Both appear in the layers panel, which lists every layer including frames. |

**If the learner chose otherwise:** revisit Section 2 and Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. Why set X, Y, W and H with numbers instead of dragging?

**Type:** applied · **Lesson reference:** Section 5, Step 2

**Correct answer: D. Numbers are repeatable and precise, which makes later changes and handoff reliable.**

**Why this is correct:** Precision and repeatability. Section 5, Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Dragging is not allowed in Figma once a frame has been created. | Incorrect | Dragging is allowed for rough placement; Step 2 recommends numbers for repeatability rather than banning drag. |
| B | Numbers make the file smaller because Figma stores fewer position values. | Incorrect | Typing values instead of dragging does not change the file's size; the number only sets position and dimensions. |
| C | Dragging changes the font of the layer that you are moving. | Incorrect | Dragging moves a layer; it does not alter the font applied to its text. |
| D | Numbers are repeatable and precise, which makes later changes and handoff reliable. | **Correct** | Precision and repeatability. Section 5, Step 2. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. You export a frame and get a blank white image. What is the most likely cause?

**Type:** problem · **Lesson reference:** Section 5, Step 7

**Correct answer: D. The frame has no fill and you exported the wrong layer or an empty area.**

**Why this is correct:** Exporting the wrong selection or an empty frame produces blank output. Section 5, Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | PNG cannot export frames, so the format saves an empty white canvas instead. | Incorrect | Exporting a frame as PNG is the standard path in Step 7; the format supports it. |
| B | The font used in the frame is missing, so no text can be rendered. | Incorrect | A missing font substitutes or warns; it does not produce a blank image. |
| C | The file is too large, so Figma stops rendering before the export finishes. | Incorrect | File size affects how long an export takes, not whether the frame renders anything into the image. |
| D | The frame has no fill and you exported the wrong layer or an empty area. | **Correct** | Exporting the wrong selection or an empty frame produces blank output. Section 5, Step 7. |

**If the learner chose otherwise:** revisit Section 5, Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. Which is a good reason to repeat the amount inside the primary button label?

**Type:** applied · **Lesson reference:** Section 5, Step 4 and section 6

**Correct answer: C. It forces a final read of the most error-prone detail before an irreversible action.**

**Why this is correct:** The label names the consequence and supports verification. Section 5, Step 4 and section 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It makes the button wider, which makes it easier to tap with a thumb. | Incorrect | A wider button is a layout side effect, not a reason for repeating the amount. |
| B | It is required by app stores before a payment feature can be published. | Incorrect | No app store requires the amount inside a button label; the rule comes from reasoning about irreversible actions, not store policy. |
| C | It forces a final read of the most error-prone detail before an irreversible action. | **Correct** | The label names the consequence and supports verification. Section 5, Step 4 and section 6. |
| D | It fills the empty space on the right side of the button rectangle. | Incorrect | Filling empty space is decoration, and Step 8 rejects changes you cannot justify by user effect. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and section 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. Why name layers during the build rather than at the end?

**Type:** problem · **Lesson reference:** Section 5, Step 5

**Correct answer: A. Names are needed to find, reuse and hand off objects later, and renaming at the end is error-prone.**

**Why this is correct:** Naming is navigation and handoff infrastructure. Section 5, Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Names are needed to find, reuse and hand off objects later, and renaming at the end is error-prone. | **Correct** | Naming is navigation and handoff infrastructure. Section 5, Step 5. |
| B | Figma deletes any layer that still has no name when you close and reopen the file. | Incorrect | Figma keeps unnamed layers and labels them "Frame 42"; nothing is deleted, which is why the mess accumulates. |
| C | Named layers export faster because the renderer can skip over all of the unnamed items in the file. | Incorrect | Export speed does not depend on what the layers are called, only on what is being rendered. |
| D | Naming changes the stacking order of the layers, which makes the whole file easier to read. | Incorrect | Naming does not reorder layers; it only labels them in the panel. |

**If the learner chose otherwise:** revisit Section 5, Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. What makes a change "deliberate" rather than decorative?

**Type:** best · **Lesson reference:** Section 5, Step 8

**Correct answer: B. It states the expected effect on the user and how you would check it.**

**Why this is correct:** Deliberate changes have a predicted user effect and a check. Section 5, Step 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It uses a different colour from the one used in the first version. | Incorrect | A new colour is the lesson's own example of decoration: "make it blue because I like blue". |
| B | It states the expected effect on the user and how you would check it. | **Correct** | Deliberate changes have a predicted user effect and a check. Section 5, Step 8. |
| C | It is reviewed and approved by an experienced designer before you continue. | Incorrect | A designer's approval is not the test; the test is a predicted user effect you can check. |
| D | It makes the screen taller so that more content fits inside the frame. | Incorrect | Height is a visual side effect, not a rationale tied to the user's task. |

**If the learner chose otherwise:** revisit Section 5, Step 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. Why keep both v1 and v2 frames?

**Type:** applied · **Lesson reference:** Section 7, step 10

**Correct answer: B. To make the change and its effect visible and easy to review later.**

**Why this is correct:** Comparison is evidence of reasoning. Section 7, step 10.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | To keep a record of the older design in case the new one is rejected. | Incorrect | The pair exists so the change and its effect can be compared; v1 is not kept as insurance against a rejected design. |
| B | To make the change and its effect visible and easy to review later. | **Correct** | Comparison is evidence of reasoning. Section 7, step 10. |
| C | To satisfy Figma's requirement for a duplicate before any frame is exported. | Incorrect | Figma does not require duplicates; you duplicate to preserve the before state for comparison. |
| D | To practise exporting the same frame twice at two different image scales. | Incorrect | Practising export is a side benefit, not the reason; comparison is the evidence of reasoning. |

**If the learner chose otherwise:** revisit Section 7, step 10 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. A beginner aligns a value to the label next to it, and the value ends up in the middle of the row. What should they align it to instead?

**Type:** best · **Lesson reference:** Section 5, Step 6

**Correct answer: D. The frame's right margin, so values line up along a consistent edge.**

**Why this is correct:** Labels align left, values align right to a consistent margin. Section 5, Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The title at the top of the content area, which shares the same left edge. | Incorrect | Aligning the value to the title gives it the title's left edge, not the row's right margin. |
| B | The primary button in the footer, which is centred across the screen. | Incorrect | The button spans the footer with 24 px margins; it does not define the value column. |
| C | The status bar at the top, which the operating system draws for you. | Incorrect | The status bar is the OS strip at the very top and has no bearing on aligning a row. |
| D | The frame's right margin, so values line up along a consistent edge. | **Correct** | Labels align left, values align right to a consistent margin. Section 5, Step 6. |

**If the learner chose otherwise:** revisit Section 5, Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A learner wants to build a 393 by 852 mobile screen in Figma. Which starting choice best supports later responsive work?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: A. Create a frame at 393 by 852 and place elements inside it using a layout structure.**

**Why this is correct:** A frame defines the screen boundary and allows constraints or auto layout later.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Create a frame at 393 by 852 and place elements inside it using a layout structure. | **Correct** | A frame defines the screen boundary and allows constraints or auto layout later. |
| B | Draw loose rectangles directly on the canvas with no frame around them at all. | Incorrect | Loose rectangles have no screen boundary, clipping or export, which section 11 lists as the first mistake. |
| C | Use a group as the screen and set a fixed width for the whole group. | Incorrect | A group has no fixed screen size and does not clip, so it cannot act as the phone screen. |
| D | Start at 1440 pixels wide and shrink the export down to phone size later. | Incorrect | Starting at 1440 px sets a desktop width; shrinking the export later does not give mobile constraints. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A learner's mobile mock-up looks correct at 393 px but every element overlaps when the frame is narrowed to 320 px. What is the most likely cause?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: D. Elements are positioned with fixed coordinates instead of a layout that can reflow.**

**Why this is correct:** Absolute positions do not respond to a narrower container; constraints or auto layout are needed.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The text uses a system font that is not installed on the phone. | Incorrect | A system font affects how text renders, not whether elements reflow inside a narrower frame. |
| B | The file has too many pages, which slows down the layout engine. | Incorrect | The number of pages has no effect on how layers sit inside a frame. |
| C | The export scale is set to 2x, so the exported image is twice as wide. | Incorrect | Export scale changes image resolution, not the positions or sizes of layers. |
| D | Elements are positioned with fixed coordinates instead of a layout that can reflow. | **Correct** | Absolute positions do not respond to a narrower container; constraints or auto layout are needed. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- A named frame at a stated phone size. — with a file, screenshot, link or log that a stranger can inspect.
- At least 12 named layers with consistent naming. — with a file, screenshot, link or log that a stranger can inspect.
- Three levels of text hierarchy. — with a file, screenshot, link or log that a stranger can inspect.
- One primary action aligned with alignment tools. — with a file, screenshot, link or log that a stranger can inspect.
- Two versions with exactly one deliberate change. — with a file, screenshot, link or log that a stranger can inspect.
- The rationale states the expected user effect and how it would be checked. — with a file, screenshot, link or log that a stranger can inspect.
- Exports are not blank, not cut off, and readable at phone size. — with a file, screenshot, link or log that a stranger can inspect.
- No real bank branding, logos or personal data. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
