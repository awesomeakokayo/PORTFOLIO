# Answer Key — Stop 1.4: Competitive and Market Review

**Instructor use only. Do not distribute.**
**Phase:** 1 · Product thinking and research
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | A | judgment | Section 5, Step 1 |
| Q2 | A | applied | Section 5, Step 2 |
| Q3 | B | problem | Section 5, Step 4 |
| Q4 | C | applied | Section 5, Step 6 |
| Q5 | A | problem | Section 5, Step 8 |
| Q6 | C | best | Section 5, Step 7 |
| Q7 | B | applied | Section 5, Step 1 |
| Q8 | C | best | Section 5, Step 2 and Step 6 |
| Q9 | D | applied | Section 5 (worked steps) |
| Q10 | A | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. What makes a product "comparable" in a competitive review?

**Type:** judgment · **Lesson reference:** Section 5, Step 1

**Correct answer: A. A real user might choose it for the same job, including substitutes like a cash agent.**

**Why this is correct:** Comparability is about the job and the user's alternatives, not brand or category. Section 5, Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A real user might choose it for the same job, including substitutes like a cash agent. | **Correct** | Comparability is about the job and the user's alternatives, not brand or category. Section 5, Step 1. |
| B | It is famous, because widely used products set the standard that smaller products must match. | Incorrect | Fame is not comparability, since a widely used app may serve a completely different job for different people. |
| C | It has a similar logo, so users recognise it as part of the same category of products. | Incorrect | A similar logo is a visual coincidence and says nothing about whether users would choose either product for the job. |
| D | It is in the same app store category, where the store groups products that compete directly. | Incorrect | Store category is retail taxonomy; the lesson compares products a real person might pick, including substitutes outside it. |

**If the learner chose otherwise:** revisit Section 5, Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. Why must every product be tested on the same task?

**Type:** applied · **Lesson reference:** Section 5, Step 2

**Correct answer: A. Otherwise the observations are not comparable, and the matrix cannot support a conclusion about any product.**

**Why this is correct:** A controlled task makes differences attributable to the design. Section 5, Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Otherwise the observations are not comparable, and the matrix cannot support a conclusion about any product. | **Correct** | A controlled task makes differences attributable to the design. Section 5, Step 2. |
| B | To make the table symmetrical, so each product has the same number of cells filled in. | Incorrect | Symmetry is cosmetic; the reason is that a controlled task lets you attribute observed differences to the design. |
| C | Because users only do one task, so testing more than one would not reflect their behaviour. | Incorrect | Users perform many tasks, and Step 2 fixes one so rows can be compared, not because people only do one thing. |
| D | To save time, because fewer distinct tasks mean fewer screenshots and notes to organise. | Incorrect | Saving time is not the motive, since running the identical task across three products usually costs more effort. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. Which is a gap rather than a difference?

**Type:** problem · **Lesson reference:** Section 5, Step 4

**Correct answer: B. All three products hide the fee until after confirmation, and users abandon when it appears.**

**Why this is correct:** A gap is an unmet need with a user consequence, evidenced. Section 5, Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Product A uses blue buttons while Product B uses green, and users notice the change immediately. | Incorrect | Button colour is styling with no stated user harm, and Step 4 says a difference becomes a gap only with evidence of harm. |
| B | All three products hide the fee until after confirmation, and users abandon when it appears. | **Correct** | A gap is an unmet need with a user consequence, evidenced. Section 5, Step 4. |
| C | Product A has a dark mode while Product B does not, so night-time use feels harsher. | Incorrect | Lacking dark mode is a feature difference, with no abandonment, cost or trust consequence attached to it. |
| D | Product C uses a different font from the others, which some reviewers found harder to read. | Incorrect | A different font is a visual variation, and a few reviewers' reading preference says nothing about abandonment or lost trust. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. What is the purpose of the evidence log's date?

**Type:** applied · **Lesson reference:** Section 5, Step 6

**Correct answer: C. To mark the observation as a historical record, because interfaces change after you capture them.**

**Why this is correct:** Dated evidence prevents stale observations becoming false current claims. Section 5, Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | To prove you worked on a certain day, so the review can be credited as your own effort. | Incorrect | The date is not evidence of effort; it marks when the observation was true, because interfaces change. |
| B | To sort screenshots alphabetically, so the folder stays tidy when the review grows larger over time. | Incorrect | Alphabetical sorting is a filing convenience, unrelated to why each observation needs a capture date. |
| C | To mark the observation as a historical record, because interfaces change after you capture them. | **Correct** | Dated evidence prevents stale observations becoming false current claims. Section 5, Step 6. |
| D | To satisfy app store rules, which require a capture date before a screenshot can be published. | Incorrect | App store rules do not require capture dates; the log uses dates so later claims stay checkable. |

**If the learner chose otherwise:** revisit Section 5, Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. What does "parity" mean in a direction statement?

**Type:** problem · **Lesson reference:** Section 5, Step 8

**Correct answer: A. Matching the expectations users need to trust the product, before you differentiate anywhere else.**

**Why this is correct:** Parity covers expected baseline patterns; differentiation is where you choose to be better. Section 5, Step 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Matching the expectations users need to trust the product, before you differentiate anywhere else. | **Correct** | Parity covers expected baseline patterns; differentiation is where you choose to be better. Section 5, Step 8. |
| B | Copying every competitor feature, so the product cannot be criticised for missing anything obvious. | Incorrect | Copying every feature is what Step 8 warns against, since parity covers only the baseline users already expect. |
| C | Having the same price as the market leader, so users compare the products on design alone. | Incorrect | Price is a commercial term, not the parity a direction statement describes when separating baseline from differentiation. |
| D | Using the same colours as competitors, so the product feels familiar the moment it opens. | Incorrect | Sharing colours is visual imitation, not matching the expected patterns users need before you differentiate. |

**If the learner chose otherwise:** revisit Section 5, Step 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. A competitor has a feature. What is the best reason to include it?

**Type:** best · **Lesson reference:** Section 5, Step 7

**Correct answer: C. It addresses an evidenced user problem within your scope and constraints, at a cost you can bear.**

**Why this is correct:** Features should answer evidence, not competitor presence. Section 5, Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | They have it, so users expect it, and its absence would make the product look incomplete beside rivals. | Incorrect | Competitor presence is exactly the reason Step 7 rejects; the question is whether the feature fixes an evidenced user problem. |
| B | It is easy to build, so the team can ship it quickly without delaying the rest of the release. | Incorrect | Ease of building is an effort argument and says nothing about user need, harm or consequence. |
| C | It addresses an evidenced user problem within your scope and constraints, at a cost you can bear. | **Correct** | Features should answer evidence, not competitor presence. Section 5, Step 7. |
| D | It looks modern, so the interface feels current and reviewers are more likely to praise it. | Incorrect | Looking modern is an aesthetic appeal with no evidence of a user consequence behind it. |

**If the learner chose otherwise:** revisit Section 5, Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. Which is an indirect competitor for "book a tutor"?

**Type:** applied · **Lesson reference:** Section 5, Step 1

**Correct answer: B. A WhatsApp group where tutors and students arrange lessons by messaging each other directly.**

**Why this is correct:** It serves the same job through a different mechanism. Section 5, Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Another tutoring app that lets students search tutors, compare prices and book a lesson directly. | Incorrect | Another tutoring app serves the booking job the same way, making it a direct competitor rather than an indirect one. |
| B | A WhatsApp group where tutors and students arrange lessons by messaging each other directly. | **Correct** | It serves the same job through a different mechanism. Section 5, Step 1. |
| C | A school that assigns teachers to students and schedules lessons through its own academic timetable. | Incorrect | A school teaches through the same formal education model, so it competes on the learning job itself rather than offering a different booking route. |
| D | A textbook that students study alone when no tutor is available to explain the difficult topics. | Incorrect | A textbook is self-study material: it never arranges or books a tutor, so it is not a route to the same job. |

**If the learner chose otherwise:** revisit Section 5, Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. You cannot complete a transfer without spending money. What should you record?

**Type:** best · **Lesson reference:** Section 5, Step 2 and Step 6

**Correct answer: C. Not tested up to the confirmation screen, with the limit and the reason stated clearly.**

**Why this is correct:** Honest limits preserve the integrity of the review. Section 5, Step 2 and Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A guessed result, based on how the flow usually ends in apps with a similar confirmation screen. | Incorrect | A guessed result fabricates a matrix cell, while Step 3 requires observed values or an explicit not tested with a reason. |
| B | A note that the product failed, because stopping before the success screen means the flow could not work. | Incorrect | Calling it a failure overreaches, because you stopped at confirmation and never saw whether the transfer worked. |
| C | Not tested up to the confirmation screen, with the limit and the reason stated clearly. | **Correct** | Honest limits preserve the integrity of the review. Section 5, Step 2 and Step 6. |
| D | A competitor's screenshot as if it were yours, since the screens look almost identical anyway. | Incorrect | Presenting a competitor's screenshot as your own breaks the log, which must record where every observation came from. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A learner is comparing three money-transfer apps. Which comparison gives the most defensible evidence?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: D. Run the same transfer task with the same starting conditions in each app, recording steps and failures.**

**Why this is correct:** A controlled task makes differences attributable to the design rather than to different goals.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Review each app's marketing page and score the visual style against the other two brands. | Incorrect | Marketing pages show claims and styling, not behaviour, so they cannot reveal where the transfer task breaks. |
| B | Ask friends which brand they like best, then rank the three apps by stated preference. | Incorrect | Brand preference among friends is opinion about reputation, not evidence of what happens during a transfer. |
| C | Compare only the features listed in each app store description, because those lists are standardised. | Incorrect | App store descriptions are advertising copy listing features, not observed steps, states or failures. |
| D | Run the same transfer task with the same starting conditions in each app, recording steps and failures. | **Correct** | A controlled task makes differences attributable to the design rather than to different goals. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A competitive review tests a different task in each product, then concludes one product has the best checkout. What invalidates the conclusion?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: A. The tasks and starting conditions differ, so the comparison is not controlled across the three products.**

**Why this is correct:** Differences may come from the task rather than the product design.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The tasks and starting conditions differ, so the comparison is not controlled across the three products. | **Correct** | Differences may come from the task rather than the product design. |
| B | Three products is too many to review, so the scores cannot be checked by a second reviewer. | Incorrect | Three products is the lesson's own minimum for a review, not an excessive sample. |
| C | The review did not include screenshots, so nobody can confirm what each checkout screen looked like. | Incorrect | Screenshots support the log, but their absence is not what ruins the conclusion; the differing tasks are. |
| D | The reviewer used a laptop instead of a phone, so the checkout looked different from the mobile version. | Incorrect | A laptop is not disqualifying, since the lesson asks only for consistent conditions; unmatched tasks are the problem. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- Three products including at least one direct and one indirect/substitute. — with a file, screenshot, link or log that a stranger can inspect.
- One precisely defined task and starting state. — with a file, screenshot, link or log that a stranger can inspect.
- An 8–12 row pattern matrix with "not tested" where applicable. — with a file, screenshot, link or log that a stranger can inspect.
- Five heuristic scores per product, each with evidence. — with a file, screenshot, link or log that a stranger can inspect.
- A dated evidence log with screenshot references. — with a file, screenshot, link or log that a stranger can inspect.
- Three filtered opportunity statements. — with a file, screenshot, link or log that a stranger can inspect.
- A direction statement separating parity, differentiation and rejection. — with a file, screenshot, link or log that a stranger can inspect.
- A Limits note naming what could not be tested. — with a file, screenshot, link or log that a stranger can inspect.
- No copied logos, illustrations or proprietary content; no real payments. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
