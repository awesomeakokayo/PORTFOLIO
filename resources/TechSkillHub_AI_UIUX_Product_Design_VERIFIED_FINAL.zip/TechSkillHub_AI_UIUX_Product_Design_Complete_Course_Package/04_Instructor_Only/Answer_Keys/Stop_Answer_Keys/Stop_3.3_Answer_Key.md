# Answer Key — Stop 3.3: Components, Variants and Variables

**Instructor use only. Do not distribute.**
**Phase:** 3 · Figma fluency and design systems
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | C | judgment | Section 2 |
| Q2 | C | applied | Section 5, Step 3 |
| Q3 | B | problem | Section 5, Step 6 |
| Q4 | D | applied | Section 5, Step 4 |
| Q5 | D | problem | Section 5, Step 7 |
| Q6 | A | best | Section 5, Step 7 |
| Q7 | A | applied | Section 5, Step 8 |
| Q8 | D | best | Section 5, Step 4 |
| Q9 | A | applied | Section 5 (worked steps) |
| Q10 | C | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. What is the difference between a main component and an instance?

**Type:** judgment · **Lesson reference:** Section 2

**Correct answer: C. An instance inherits the main's structure, while the main defines what that structure is.**

**Why this is correct:** Instances inherit; overrides are local. Section 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | An instance cannot be edited at all, because its structure is owned by the main. | Incorrect | Instances can be edited through overrides such as text, colour or icon without detaching; detaching is what breaks the link. |
| B | A main component is always larger, since it holds every variant inside it. | Incorrect | Size is unrelated to the role: a main can be a small icon, and an instance matches the main's dimensions rather than exceeding them. |
| C | An instance inherits the main's structure, while the main defines what that structure is. | **Correct** | Instances inherit; overrides are local. Section 2. |
| D | There is no real difference, because both are copies of the same object. | Incorrect | The lesson defines the main as the original that sets structure and the instance as the linked copy that inherits it. |

**If the learner chose otherwise:** revisit Section 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. Why use a component property instead of an override?

**Type:** applied · **Lesson reference:** Section 5, Step 3

**Correct answer: C. Properties are visible and repeatable, while overrides are hidden one-off changes.**

**Why this is correct:** Properties expose what can change. Section 5, Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Properties make the file smaller, because they remove the need for extra layers. | Incorrect | Properties add metadata to a component, and their benefit is visibility and repeatability rather than any reduction in file weight. |
| B | Overrides are not allowed in Figma, so a property is the only option available. | Incorrect | Overrides are allowed and are the documented alternative; the problem is that they are hidden one-off changes, not that they are forbidden. |
| C | Properties are visible and repeatable, while overrides are hidden one-off changes. | **Correct** | Properties expose what can change. Section 5, Step 3. |
| D | Properties change the font automatically, keeping every instance on the brand. | Incorrect | A text property changes the label's content, such as Continue to Send, while the typeface stays a typography or style decision. |

**If the learner chose otherwise:** revisit Section 5, Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. What does a semantic variable alias do?

**Type:** problem · **Lesson reference:** Section 5, Step 6

**Correct answer: B. It points a role name at a primitive, separating meaning from raw values.**

**Why this is correct:** Semantic layers enable theming and consistent meaning. Section 5, Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It deletes the primitive it pointed to, so the palette holds only role names. | Incorrect | An alias points at the primitive, so deleting it would break the semantic layer; the lesson keeps both layers and removes neither. |
| B | It points a role name at a primitive, separating meaning from raw values. | **Correct** | Semantic layers enable theming and consistent meaning. Section 5, Step 6. |
| C | It creates a new component that carries the role name in its title. | Incorrect | Variables live in collections and apply to fills, strokes, text and spacing; they never create components or variants. |
| D | It exports the aliased values as CSS custom properties for developers. | Incorrect | Exporting token names to CSS happens later in Stop 5.3, while an alias only maps a role name to a primitive inside Figma. |

**If the learner chose otherwise:** revisit Section 5, Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. Why should variants differ in values, not structure?

**Type:** applied · **Lesson reference:** Section 5, Step 4

**Correct answer: D. So properties and swaps work consistently across every variant in the set.**

**Why this is correct:** Structural differences break the property model. Section 5, Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Because Figma cannot handle variants that contain different layers at all. | Incorrect | Figma can hold different layer structures; the failure is the property model, because a boolean or swap cannot work when layers differ. |
| B | To reduce the number of colours used across the component set. | Incorrect | Colour count is a token and variable decision, unrelated to whether variants share the same layer structure. |
| C | To make the file larger, so the library looks more complete to reviewers. | Incorrect | No one builds variants to grow a file; one shared structure keeps a single template that every variant inherits, which is simpler. |
| D | So properties and swaps work consistently across every variant in the set. | **Correct** | Structural differences break the property model. Section 5, Step 4. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. What is a variable mode used for?

**Type:** problem · **Lesson reference:** Section 5, Step 7

**Correct answer: D. Switching a set of values, such as light and dark themes.**

**Why this is correct:** Modes swap values without editing components. Section 5, Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Changing the file owner, so another designer can edit the collection. | Incorrect | Ownership is a file or plan setting, not a variable mode, which only swaps values inside a collection. |
| B | Adding new pages to the file, one for each theme you support. | Incorrect | Pages are file structure, while a mode changes values such as light and dark without adding or rearranging pages. |
| C | Compressing the images inside components so the file loads faster. | Incorrect | Image weight is reduced by compressing before placing, and a mode only swaps variable values without touching image files. |
| D | Switching a set of values, such as light and dark themes. | **Correct** | Modes swap values without editing components. Section 5, Step 7. |

**If the learner chose otherwise:** revisit Section 5, Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. Why check contrast again in dark mode?

**Type:** best · **Lesson reference:** Section 5, Step 7

**Correct answer: A. Dark mode is not an inversion, so pairs that pass on white may fail.**

**Why this is correct:** Luminance relationships change. Section 5, Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Dark mode is not an inversion, so pairs that pass on white may fail. | **Correct** | Luminance relationships change. Section 5, Step 7. |
| B | Dark mode always fails contrast, so every dark theme needs a full redesign. | Incorrect | Dark mode can pass contrast when explicit dark values are set, which is why the lesson asks for three recorded checks per theme. |
| C | Figma resets colours whenever a mode is applied, discarding the stored values. | Incorrect | Figma keeps the values you set in the dark mode; nothing is reset, and unchecked pairs are the actual risk. |
| D | Contrast only applies to light mode, so dark values need no checking. | Incorrect | Contrast is a luminance relationship present in every theme, and the 4.5:1 label target applies on dark surfaces too. |

**If the learner chose otherwise:** revisit Section 5, Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. Which name follows the course convention?

**Type:** applied · **Lesson reference:** Section 5, Step 8

**Correct answer: A. color.action.primary, lower-case with consistent dot separators and a role.**

**Why this is correct:** Role-based, lowercase, consistent separators. Section 5, Step 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | color.action.primary, lower-case with consistent dot separators and a role. | **Correct** | Role-based, lowercase, consistent separators. Section 5, Step 8. |
| B | BlueButtonColorFinal, which is descriptive but adds no role or separators. | Incorrect | This names by appearance, adds an ambiguous final, uses capitals and drops the role, so no one can tell what it controls. |
| C | #1D4ED8, the exact hex value copied straight from the brand palette. | Incorrect | A raw hex is a value rather than a name, and tokens exist so components reference a role instead of a hard-coded colour. |
| D | primary-button-color-new, hyphenated and ending with a version word. | Incorrect | It is hyphenated, reverses the role order, and ends with new, a version word rather than a stable role like color.action.primary. |

**If the learner chose otherwise:** revisit Section 5, Step 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. A disabled variant removes the icon layer. Why is this a problem?

**Type:** best · **Lesson reference:** Section 5, Step 4

**Correct answer: D. It changes structure across variants, so the boolean property cannot work consistently.**

**Why this is correct:** Keep structure stable; change visibility or values. Section 5, Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It makes the button too small, because the icon no longer adds width. | Incorrect | Removing the icon changes structure, not necessarily size; padding and the 44 px minimum still govern the button's height. |
| B | It changes the button's colour, because the fill is tied to the icon. | Incorrect | Colour comes from the disabled state's variable values, not from whether the icon layer exists in that variant. |
| C | It is not a problem, since disabled buttons rarely show an icon anyway. | Incorrect | It is the documented failure: structure must stay identical so a boolean can hide the icon instead of the layer disappearing. |
| D | It changes structure across variants, so the boolean property cannot work consistently. | **Correct** | Keep structure stable; change visibility or values. Section 5, Step 4. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A learner needs the same button to work in light and dark themes. Which structure is most maintainable?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: A. Use semantic colour variables and switch their values with a variable mode.**

**Why this is correct:** Semantic variables with modes change values without duplicating components.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Use semantic colour variables and switch their values with a variable mode. | **Correct** | Semantic variables with modes change values without duplicating components. |
| B | Create a separate unconnected button for each theme and maintain both. | Incorrect | Unconnected copies duplicate the component, so each theme must be maintained separately and drifts as soon as one is edited. |
| C | Override the fill on every instance by hand whenever a theme is needed. | Incorrect | Hand overrides are invisible, must be repeated on every instance, and nothing updates when the theme or brand changes. |
| D | Use one hard-coded hex value that works acceptably in both themes. | Incorrect | A single hex cannot serve light and dark, and the lesson requires explicit values per mode plus a contrast re-check. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A designer detaches a button instance to change its icon, then the team updates the main component. What is the consequence?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: C. The detached copy no longer receives the update and drifts from the system.**

**Why this is correct:** Detaching breaks inheritance; the local copy must be maintained separately.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The main component is deleted, leaving the file without a source object. | Incorrect | Detaching only breaks the link for that copy; the main component stays and the other linked instances keep updating. |
| B | All other instances change automatically, including the detached copy in the file. | Incorrect | That applies to linked instances when the main changes, which is exactly the update the detached copy no longer receives. |
| C | The detached copy no longer receives the update and drifts from the system. | **Correct** | Detaching breaks inheritance; the local copy must be maintained separately. |
| D | The file becomes read-only, because detaching an instance changes its permission. | Incorrect | Read-only is a link permission chosen when sharing, and detaching an instance changes nothing about who can open the file. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- At least 12 variants, or a documented reduction with a reason. — with a file, screenshot, link or log that a stranger can inspect.
- Text, boolean and instance-swap properties used. — with a file, screenshot, link or log that a stranger can inspect.
- 15+ primitives and 10+ semantic aliases. — with a file, screenshot, link or log that a stranger can inspect.
- Semantic variables applied to components, not raw hex values. — with a file, screenshot, link or log that a stranger can inspect.
- Light and dark modes with three recorded contrast checks. — with a file, screenshot, link or log that a stranger can inspect.
- Component structure consistent across variants. — with a file, screenshot, link or log that a stranger can inspect.
- Naming index and component doc complete. — with a file, screenshot, link or log that a stranger can inspect.
- The trade-off note is specific. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
