# Answer Key — Stop 4.1: AI for Research Synthesis

**Instructor use only. Do not distribute.**
**Phase:** 4 · The AI design workflow
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | A | judgment | Section 3 |
| Q2 | B | applied | Section 5, Step 5 |
| Q3 | A | problem | Section 5, Step 4 |
| Q4 | D | applied | Section 5, Step 3 |
| Q5 | A | problem | Section 5, Step 5 |
| Q6 | B | best | Section 5, Step 7 |
| Q7 | D | applied | Section 5, Step 4 |
| Q8 | A | best | Section 4 |
| Q9 | C | applied | Section 5 (worked steps) |
| Q10 | C | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. What is the safest role for AI in research synthesis?

**Type:** judgment · **Lesson reference:** Section 3

**Correct answer: A. Clustering the notes into candidate themes that a human then checks against every quote.**

**Why this is correct:** AI can assist clustering; evidence must come from real notes and be verified. Section 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Clustering the notes into candidate themes that a human then checks against every quote. | **Correct** | AI can assist clustering; evidence must come from real notes and be verified. Section 3. |
| B | Generating findings directly from the project brief, so the team saves the reading time. | Incorrect | A brief holds no participant words, so findings generated from it would be invented rather than clustered from real notes. |
| C | Conducting the interviews itself and reporting what participants said about the product. | Incorrect | Interviews produce the primary evidence; AI can organise existing notes but cannot supply real participant experience. |
| D | Writing participant quotes that read naturally, then filling gaps the notes left open. | Incorrect | Quotes must be participants' exact words, so drafting them is fabrication and destroys the traceability synthesis depends on. |

**If the learner chose otherwise:** revisit Section 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. An AI says "all participants distrusted the app". What should you do first?

**Type:** applied · **Lesson reference:** Section 5, Step 5

**Correct answer: B. Check each participant's notes separately to verify whether the quantifier is true.**

**Why this is correct:** Quantifiers are a common over-generalisation; verify per participant. Section 5, Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Accept it, because the model has read every note and summarised them consistently. | Incorrect | The summary is unverified output, and 'all' is the exact over-generalisation Step 5 says to test participant by participant. |
| B | Check each participant's notes separately to verify whether the quantifier is true. | **Correct** | Quantifiers are a common over-generalisation; verify per participant. Section 5, Step 5. |
| C | Delete the whole theme, since one exaggerated word makes the entire grouping unusable. | Incorrect | Deleting discards a possibly valid grouping; the lesson says verify each participant ID and rewrite the quantifier to the real sample. |
| D | Add a percentage beside the claim so the strength of the finding is clearer. | Incorrect | Percentages from a handful of interviews are meaningless; the lesson bans frequency percentages and asks for wording like '2 of 5'. |

**If the learner chose otherwise:** revisit Section 5, Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. What does a traceability matrix contain?

**Type:** problem · **Lesson reference:** Section 5, Step 4

**Correct answer: A. Theme, participant, exact quote, context, whether it supports or contradicts, and verification status.**

**Why this is correct:** It links claims to evidence. Section 5, Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Theme, participant, exact quote, context, whether it supports or contradicts, and verification status. | **Correct** | It links claims to evidence. Section 5, Step 4. |
| B | Theme names only, kept short so the synthesis document stays easy to scan. | Incorrect | Names alone cannot be traced to evidence, which is the matrix's purpose: linking each theme to a quote, participant and context. |
| C | The AI model version and date, so a reviewer can reproduce the same summary later. | Incorrect | Model version belongs in the prompt log and provenance record, not in the table that links claims to quotes. |
| D | The list of interview questions, so a reviewer can see what each participant was asked. | Incorrect | Questions record what you asked, not which participant said what in support of a theme. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. Why chunk long notes before synthesis?

**Type:** applied · **Lesson reference:** Section 5, Step 3

**Correct answer: D. Because long inputs get truncated or lose attribution, and chunks give checkpoints.**

**Why this is correct:** Chunking preserves attribution and allows verification. Section 5, Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Because the assistant cannot process long text at all and returns an empty answer. | Incorrect | Long inputs are not unreadable; they get truncated or internally summarised, which is why attribution is lost. |
| B | Because a longer output makes the synthesis look more thorough to reviewers. | Incorrect | Chunking usually shortens output; its purpose is preserved attribution and checkpoints, not document length. |
| C | Because shorter sections contain fewer names, so anonymising can be skipped. | Incorrect | Anonymising happens before any upload and is required regardless of chunk size, so chunking cannot replace it. |
| D | Because long inputs get truncated or lose attribution, and chunks give checkpoints. | **Correct** | Chunking preserves attribution and allows verification. Section 5, Step 3. |

**If the learner chose otherwise:** revisit Section 5, Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. An AI proposes "users want biometric login" but no participant mentioned it. What is this?

**Type:** problem · **Lesson reference:** Section 5, Step 5

**Correct answer: A. A fabricated solution presented as a finding, which you reject and record as unsupported.**

**Why this is correct:** It is an invention, not evidence. Section 5, Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A fabricated solution presented as a finding, which you reject and record as unsupported. | **Correct** | It is an invention, not evidence. Section 5, Step 5. |
| B | A valid insight, because it follows logically from the trust problems participants described. | Incorrect | Nobody mentioned biometrics, so it is an inferred solution rather than a pattern supported by the notes. |
| C | A useful counter-example showing where participants disagreed with the proposed theme. | Incorrect | Counter-evidence is an observation that contradicts a theme, not a feature no participant raised. |
| D | A sample limitation, since only five participants were interviewed about the product. | Incorrect | A sample limitation is too few participants; here the problem is content absent from the notes entirely. |

**If the learner chose otherwise:** revisit Section 5, Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. What is the difference between a theme and an insight?

**Type:** best · **Lesson reference:** Section 5, Step 7

**Correct answer: B. A theme is a pattern in the evidence; an insight interprets what it means for design.**

**Why this is correct:** Themes describe; insights interpret. Section 5, Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A theme is simply the longer version of an insight, written up in more detail. | Incorrect | Length is irrelevant; a theme is a repeated pattern across participants, while an insight interprets what the pattern means for design. |
| B | A theme is a pattern in the evidence; an insight interprets what it means for design. | **Correct** | Themes describe; insights interpret. Section 5, Step 7. |
| C | An insight is always a direct quote, while a theme is the label attached to it. | Incorrect | Quotes are raw evidence; an insight is your interpretation of the evidence and must be labelled as interpretation. |
| D | There is no real difference, since both describe the same pattern from interviews. | Incorrect | Step 7 separates them: the theme describes the pattern, the insight makes the design and causal claim you own. |

**If the learner chose otherwise:** revisit Section 5, Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. Why record rejected themes?

**Type:** applied · **Lesson reference:** Section 5, Step 4

**Correct answer: D. To preserve the audit trail and stop the same unsupported claim returning.**

**Why this is correct:** Rejections are part of the evidence of judgment. Section 5, Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | To make the document longer, since a fuller appendix looks more thorough. | Incorrect | Length is not the point; the rejection row records that a proposed theme had no supporting quote, which is evidence of judgement. |
| B | To satisfy the design tool, which requires a rejection row before export. | Incorrect | No tool requires this; the audit trail is a professional practice, not a software rule imposed by a design tool. |
| C | To show the assistant where it went wrong, so its next answer improves. | Incorrect | The assistant does not learn from your log; the record exists so a reviewer can see the claim was checked and rejected. |
| D | To preserve the audit trail and stop the same unsupported claim returning. | **Correct** | Rejections are part of the evidence of judgment. Section 5, Step 4. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. Which is a privacy failure?

**Type:** best · **Lesson reference:** Section 4

**Correct answer: A. Pasting a transcript with a participant's phone number into a free chat tool.**

**Why this is correct:** Identifying data must not be uploaded. Section 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Pasting a transcript with a participant's phone number into a free chat tool. | **Correct** | Identifying data must not be uploaded. Section 4. |
| B | Using P1 and P2 as identifiers when quoting participants in the synthesis table. | Incorrect | Using P1 and P2 is the lesson's recommended anonymisation, so it prevents identification instead of causing a privacy failure. |
| C | Storing the anonymised notes in a password-protected folder on the team drive. | Incorrect | A password-protected folder is secure storage; the failure the lesson names is uploading identifying data, not protecting it locally. |
| D | Removing an employer name from a quote before sending it for synthesis. | Incorrect | Removing an employer name is exactly the de-identification Step 1 asks for before any notes reach a tool. |

**If the learner chose otherwise:** revisit Section 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. An AI summary says '8 out of 10 participants distrusted the app', but the learner only has six interview notes. What should they do first?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: C. Reject the statistic, then check every claim against the six notes that actually exist.**

**Why this is correct:** The denominator is fabricated; every synthesized claim must trace to a real note.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Add four invented interviews so the sample matches the number the summary reports. | Incorrect | Fabricating participants to match a denominator is the confabulation the lesson says to catch and reject, not complete. |
| B | Publish the 8/10 figure because a larger-sounding sample makes the finding persuasive. | Incorrect | An 8/10 figure drawn from six notes is an invented statistic built on a fabricated denominator. |
| C | Reject the statistic, then check every claim against the six notes that actually exist. | **Correct** | The denominator is fabricated; every synthesized claim must trace to a real note. |
| D | Ask the AI to explain its confidence, then quote that explanation in the report. | Incorrect | The model's explanation is more generated text; the count must be checked against the six real notes. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A themes table contains labels such as 'trust' and 'speed' but no quotes or participant IDs. What is missing?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: C. Traceability from each theme back to specific evidence and participant IDs in the notes.**

**Why this is correct:** Themes without evidence cannot be verified or defended.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A more attractive colour scheme, so reviewers can tell the themes apart at a glance. | Incorrect | A better colour scheme does not make a theme checkable; without quotes and participant IDs the claim still cannot be traced. |
| B | More themes on the page, so the synthesis looks comprehensive rather than thin. | Incorrect | Adding labels without evidence increases unverifiable claims and invites theme inflation, where synonyms become separate themes. |
| C | Traceability from each theme back to specific evidence and participant IDs in the notes. | **Correct** | Themes without evidence cannot be verified or defended. |
| D | A second AI summary, so the two outputs can be compared for agreement. | Incorrect | A second summary is still output to verify; it does not supply the missing quote-to-theme link. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- Input is anonymised, or the substitution is explained. — with a file, screenshot, link or log that a stranger can inspect.
- Prompts and raw output are included. — with a file, screenshot, link or log that a stranger can inspect.
- Every theme has a traceability row with a verified quote. — with a file, screenshot, link or log that a stranger can inspect.
- At least three AI errors or weak claims are caught and corrected. — with a file, screenshot, link or log that a stranger can inspect.
- Quantifiers match the sample size. — with a file, screenshot, link or log that a stranger can inspect.
- Insights are labelled as interpretation. — with a file, screenshot, link or log that a stranger can inspect.
- Counter-evidence is reported. — with a file, screenshot, link or log that a stranger can inspect.
- Human review explains what only the researcher could know. — with a file, screenshot, link or log that a stranger can inspect.
- No fabricated quote, participant or percentage. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
