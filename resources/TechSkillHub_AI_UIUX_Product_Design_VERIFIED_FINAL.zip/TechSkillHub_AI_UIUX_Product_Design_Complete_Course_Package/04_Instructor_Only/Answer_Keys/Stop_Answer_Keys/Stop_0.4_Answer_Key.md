# Answer Key — Stop 0.4: Using AI as a Tutor

**Instructor use only. Do not distribute.**
**Phase:** 0 · Getting started
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | A | judgment | Section 5, Step 1 |
| Q2 | B | applied | Section 5, Step 4 |
| Q3 | A | problem | Section 5, Step 5 |
| Q4 | A | applied | Section 5, Step 6 |
| Q5 | B | problem | Section 2 and section 4 |
| Q6 | D | best | Section 5, Step 2 |
| Q7 | A | applied | Section 5, Step 5 |
| Q8 | C | best | Section 5, Step 7 |
| Q9 | A | applied | Section 5 (worked steps) |
| Q10 | A | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. Why can an AI assistant give a confident but false answer?

**Type:** judgment · **Lesson reference:** Section 5, Step 1

**Correct answer: A. It generates likely text from patterns instead of looking up verified facts.**

**Why this is correct:** LLMs predict plausible continuations; fluency is not evidence. Section 5, Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It generates likely text from patterns instead of looking up verified facts. | **Correct** | LLMs predict plausible continuations; fluency is not evidence. Section 5, Step 1. |
| B | It always copies its answers from unreliable websites that it finds online. | Incorrect | The model does not copy pages; it generates likely text from patterns in training data, which is why it invents sources. |
| C | It is designed to lie to users when it does not know the correct answer. | Incorrect | Step 1 describes no intent to deceive; it produces plausible continuations and has no reliable uncertainty signal. |
| D | It only works while offline, so it cannot check any current information. | Incorrect | Assistants run online, so being offline is not the mechanism; guessing likely next words is. |

**If the learner chose otherwise:** revisit Section 5, Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. Which is a primary source for a WCAG contrast requirement?

**Type:** applied · **Lesson reference:** Section 5, Step 4

**Correct answer: B. The W3C WCAG 2.2 specification, including the success criteria text.**

**Why this is correct:** The standard itself is the primary source. Section 5, Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A design blog post that summarises the WCAG contrast rules clearly. | Incorrect | A blog summarising WCAG is the lesson's example of a secondary source, one step removed from the standard. |
| B | The W3C WCAG 2.2 specification, including the success criteria text. | **Correct** | The standard itself is the primary source. Section 5, Step 4. |
| C | A comment under a YouTube tutorial that quotes the contrast number. | Incorrect | A YouTube comment is anonymous opinion with no normative standing against a standard. |
| D | An AI answer that mentions WCAG and gives a contrast ratio. | Incorrect | An AI answer mentioning WCAG is a claim to check, not the specification; Step 3 says open the cited document. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. An AI says: "A primary button is always blue and always the largest element on screen." What is the best verdict?

**Type:** problem · **Lesson reference:** Section 5, Step 5

**Correct answer: A. Partly right: the role is right, but "always blue" and "always largest" are false absolutes.**

**Why this is correct:** It identifies the role correctly but states false absolute rules. Section 5, Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Partly right: the role is right, but "always blue" and "always largest" are false absolutes. | **Correct** | It identifies the role correctly but states false absolute rules. Section 5, Step 5. |
| B | Right, because primary buttons are usually blue and usually the largest element. | Incorrect | Saying primary buttons are usually blue does not rescue "always blue"; Step 5 treats that absolute as the false part. |
| C | Wrong, because primary buttons are never blue and are never the largest element. | Incorrect | "Never blue" is the opposite absolute; blue is common in practice but no rule requires it. |
| D | Right, because the AI was trained on a large amount of design data. | Incorrect | Training on design data explains why the answer sounds fluent, not why it is correct. |

**If the learner chose otherwise:** revisit Section 5, Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. What is the best follow-up when you suspect an AI claim is unsupported?

**Type:** applied · **Lesson reference:** Section 5, Step 6

**Correct answer: A. Ask which official source supports the claim, request the sentence and section, and accept a clear no.**

**Why this is correct:** Asking for a checkable source exposes grounding or its absence. Section 5, Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Ask which official source supports the claim, request the sentence and section, and accept a clear no. | **Correct** | Asking for a checkable source exposes grounding or its absence. Section 5, Step 6. |
| B | Tell the assistant it is wrong, demand an apology, and ask for a corrected answer right away. | Incorrect | Demanding an apology invites a fold under pressure, which Step 6 says shows the first answer was not grounded. |
| C | Start a new chat and ask the same question again using slightly different wording this time. | Incorrect | A fresh chat asks the same question again and still gets no evidence for the claim. |
| D | Accept the answer if it sounds confident and matches what you already expected to hear. | Incorrect | Accepting a confident answer is the habit the stop corrects; confidence is not evidence. |

**If the learner chose otherwise:** revisit Section 5, Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. Why should you avoid pasting a real client's interview transcript into a free AI chat?

**Type:** problem · **Lesson reference:** Section 2 and section 4

**Correct answer: B. The service may store or review personal and confidential data afterwards.**

**Why this is correct:** Privacy and confidentiality. Use anonymised or invented data. Section 2 and section 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It makes the answer arrive much more slowly than a short prompt would. | Incorrect | Speed is not the concern; the risk in section 2 is privacy and confidentiality of stored data. |
| B | The service may store or review personal and confidential data afterwards. | **Correct** | Privacy and confidentiality. Use anonymised or invented data. Section 2 and section 4. |
| C | It changes the language and spelling that the AI uses in its reply. | Incorrect | Language or spelling is not the risk; identifiable personal data being stored or reviewed is. |
| D | It is impossible to paste a long transcript into the chat box. | Incorrect | Long text can be pasted, though the context window may truncate it — a separate and lesser issue. |

**If the learner chose otherwise:** revisit Section 2 and section 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. Which prompt is most likely to produce a useful beginner explanation?

**Type:** best · **Lesson reference:** Section 5, Step 2

**Correct answer: D. "You are a patient tutor: explain a primary button in 120 words, with jargon defined, one banking example and a test question."**

**Why this is correct:** It sets role, level, task, constraints, example and check. Section 5, Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | "Explain UI to me, covering everything that a complete beginner might ever need to know about the subject area." | Incorrect | "Explain UI" sets no role, level, length, example or test question, so the answer sprawls. |
| B | "Explain what a primary button is, in a way that a complete beginner can easily understand and then use." | Incorrect | "Explain primary button" names a task but sets no level, constraints, example or closing test question. |
| C | "Write everything about design, including its full history, its main tools, its underlying theory and everyday practice in real detail." | Incorrect | "Write everything about design" is unbounded, so the model writes an encyclopaedia entry instead of a beginner explanation. |
| D | "You are a patient tutor: explain a primary button in 120 words, with jargon defined, one banking example and a test question." | **Correct** | It sets role, level, task, constraints, example and check. Section 5, Step 2. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. An AI answer is accurate but leaves out an important exception. Which verdict fits best?

**Type:** applied · **Lesson reference:** Section 5, Step 5

**Correct answer: A. Right, with a noted omission — unless the omission makes the advice misleading.**

**Why this is correct:** Accuracy plus a non-misleading omission is still right; note the gap. Section 5, Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Right, with a noted omission — unless the omission makes the advice misleading. | **Correct** | Accuracy plus a non-misleading omission is still right; note the gap. Section 5, Step 5. |
| B | Wrong, because any omission means the answer cannot be trusted. | Incorrect | "Wrong" is for a false core claim or invented rule; here the core claim is accurate and only an exception is missing. |
| C | Partly right only if the answer also cites a checkable official source. | Incorrect | A cited source is not a condition of the verdict; Step 5 grades the claim and you check the source separately. |
| D | Unclear, because the missing exception cannot be seen from the answer alone. | Incorrect | Step 5 supplies three verdicts plus "what was off", so the answer can be judged. |

**If the learner chose otherwise:** revisit Section 5, Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. What is the main purpose of keeping a tutor log?

**Type:** best · **Lesson reference:** Section 5, Step 7

**Correct answer: C. To build evidence that you can verify and judge AI output, not just generate it.**

**Why this is correct:** The log is evidence of judgment and a reusable learning record. Section 5, Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | To prove to a reviewer that you used an AI assistant during the course. | Incorrect | The log records verdicts and sources, not proof that AI was used; using AI is not the skill being assessed. |
| B | To make each chat session faster by storing your previous prompts and answers. | Incorrect | The log is written after the chat and does not speed it up; it preserves your judgement. |
| C | To build evidence that you can verify and judge AI output, not just generate it. | **Correct** | The log is evidence of judgment and a reusable learning record. Section 5, Step 7. |
| D | To replace your course notes with a record of every AI conversation. | Incorrect | Course notes use the four fields from Stop 0.2; the tutor log is a separate evidence record. |

**If the learner chose otherwise:** revisit Section 5, Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. An AI assistant says the WCAG 2.2 AA minimum contrast for normal text is 3:1. What is the strongest verification step?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: A. Check the success criterion in the official W3C WCAG 2.2 document and record the result.**

**Why this is correct:** The normative standard is the primary source; 4.5:1 is the normal-text requirement.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Check the success criterion in the official W3C WCAG 2.2 document and record the result. | **Correct** | The normative standard is the primary source; 4.5:1 is the normal-text requirement. |
| B | Ask the same assistant to confirm its answer and explain where the number came from. | Incorrect | Asking the same assistant again tests its consistency, not the standard; it may repeat the error or flip. |
| C | Search for a blog post that agrees with the number and quote it as evidence. | Incorrect | A blog that agrees is a secondary source and may simply repeat the same mistaken number. |
| D | Use the number because it sounds precise and comes from a design tool. | Incorrect | A precise-sounding number is not evidence; 3:1 is the large-text threshold, not the normal-text one. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A learner pastes a real client's interview transcript into a free AI chat and asks for themes. What is the first problem to address?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: A. Confidential personal data has been sent to a third-party service without a lawful basis or consent.**

**Why this is correct:** Privacy and confidentiality must be protected before any synthesis work begins.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Confidential personal data has been sent to a third-party service without a lawful basis or consent. | **Correct** | Privacy and confidentiality must be protected before any synthesis work begins. |
| B | The transcript is too long for the model to hold inside its context window. | Incorrect | Length is a context-window issue and secondary to the fact that confidential data has already left your control. |
| C | The AI may reply using American spelling instead of the learner's local spelling. | Incorrect | Spelling or locale is trivial beside a confidentiality breach involving a real client's transcript. |
| D | The learner did not ask for a short summary first before requesting the themes. | Incorrect | Summarising first does not help; the transcript still enters the tool, and it should never be pasted. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- Three terms, none of which are the worked example ("toast"). — with a file, screenshot, link or log that a stranger can inspect.
- Each entry has an exact prompt, a summary, a verdict and a specific reason. — with a file, screenshot, link or log that a stranger can inspect.
- Each entry names a real source with a working URL. — with a file, screenshot, link or log that a stranger can inspect.
- At least one entry records a genuine error or omission in the AI answer. — with a file, screenshot, link or log that a stranger can inspect.
- No personal, client or confidential data appears in any prompt. — with a file, screenshot, link or log that a stranger can inspect.
- The reflection names one thing the AI did well and one thing you will always check. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
