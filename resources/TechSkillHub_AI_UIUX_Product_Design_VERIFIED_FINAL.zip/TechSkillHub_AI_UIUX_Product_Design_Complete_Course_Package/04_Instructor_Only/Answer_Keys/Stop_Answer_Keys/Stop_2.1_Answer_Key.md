# Answer Key — Stop 2.1: Layout, Grid, Spacing and Hierarchy

**Instructor use only. Do not distribute.**
**Phase:** 2 · Visual and interaction foundations
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | A | judgment | Section 5, Step 1 |
| Q2 | B | applied | Section 5, Step 2 |
| Q3 | A | problem | Section 5, Step 4 |
| Q4 | C | applied | Section 5, Step 3 |
| Q5 | B | problem | Section 5, Step 8 |
| Q6 | D | best | Section 5, Step 3 |
| Q7 | C | applied | Section 2 |
| Q8 | B | best | Section 5, Step 7 |
| Q9 | C | applied | Section 5 (worked steps) |
| Q10 | B | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. Why use a spacing scale instead of choosing each gap by eye?

**Type:** judgment · **Lesson reference:** Section 5, Step 1

**Correct answer: A. It creates consistency and removes arbitrary decisions that accumulate into visual noise.**

**Why this is correct:** A scale constrains decisions and produces rhythm. Section 5, Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It creates consistency and removes arbitrary decisions that accumulate into visual noise. | **Correct** | A scale constrains decisions and produces rhythm. Section 5, Step 1. |
| B | It keeps the design file smaller, because repeated gap values can be stored once. | Incorrect | Reusing a value does not shrink the document; gaps are stored per layer either way, so file size is untouched by having a scale. |
| C | It is required by WCAG, which sets minimum spacing for all text blocks. | Incorrect | WCAG sets contrast, target size and text-resize rules, but it never prescribes a spacing scale or minimum gaps between blocks. |
| D | It makes body text render larger, so fewer elements are needed per screen. | Incorrect | The scale sets gaps and margins only; type size comes from the separate type scale, so body text stays exactly the same size. |

**If the learner chose otherwise:** revisit Section 5, Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. In a 4-column mobile grid with 24 px margins and 16 px gutters, what is the content width on a 393 px screen?

**Type:** applied · **Lesson reference:** Section 5, Step 2

**Correct answer: B. 345 px, after subtracting both 24 px margins from the 393 px frame.**

**Why this is correct:** 393 − (2 × 24) = 345. Section 5, Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | 393 px, the width of the frame before either 24 px margin is deducted. | Incorrect | 393 px is the raw frame width; both 24 px margins must come off before you have the space that content can occupy. |
| B | 345 px, after subtracting both 24 px margins from the 393 px frame. | **Correct** | 393 − (2 × 24) = 345. Section 5, Step 2. |
| C | 369 px, after subtracting a single 24 px margin from the 393 px frame. | Incorrect | 369 px removes one margin only, leaving the opposite edge unaccounted for, so the figure ends up 24 px too wide. |
| D | 321 px, after subtracting both margins and then one 24 px gutter again. | Incorrect | 321 px takes off the margins and then a further 24 px, but gutters sit inside the content width and never reduce it. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. Which technique best groups a label with its value?

**Type:** problem · **Lesson reference:** Section 5, Step 4

**Correct answer: A. Make the gap inside the pair smaller than the gap between neighbouring pairs.**

**Why this is correct:** Proximity is the strongest grouping cue. Section 5, Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Make the gap inside the pair smaller than the gap between neighbouring pairs. | **Correct** | Proximity is the strongest grouping cue. Section 5, Step 4. |
| B | Draw a bordered box around each pair so the grouping is explicit. | Incorrect | A border on every pair adds ink and turns each into a card; space should group first, and containers are for real boundaries. |
| C | Give every label its own colour so related values are easy to spot. | Incorrect | Colour per label adds competing signals and says nothing about which value belongs with which label; one accent is the limit. |
| D | Centre each label and value in the row so the pair looks balanced. | Incorrect | Centring each item separately leaves no shared edge, so a value no longer visibly belongs to the label above it. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. A screen has a 36 px title, a 34 px subtitle, a 32 px amount and a 30 px button label. What is the main problem?

**Type:** applied · **Lesson reference:** Section 5, Step 3

**Correct answer: C. The four sizes are so close that hierarchy reads as noise instead of order.**

**Why this is correct:** Four near-identical sizes create competition without meaning. Section 5, Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The screen has too much contrast between its four main text elements. | Incorrect | Contrast between the four levels is far too low, not too high: 36, 34, 32 and 30 are nearly the same size. |
| B | The text is too small to read, so each element needs a larger size. | Incorrect | Every size listed is large, between 30 and 36 px, so smallness cannot be the defect described. |
| C | The four sizes are so close that hierarchy reads as noise instead of order. | **Correct** | Four near-identical sizes create competition without meaning. Section 5, Step 3. |
| D | The elements sit on no shared grid, so nothing lines up vertically. | Incorrect | Nothing in the stem says the elements are off-grid; the given evidence is four sizes only one step apart. |

**If the learner chose otherwise:** revisit Section 5, Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. What is the fastest first response to a crowded screen?

**Type:** problem · **Lesson reference:** Section 5, Step 8

**Correct answer: B. Remove or defer content that does not support the task at hand.**

**Why this is correct:** Subtraction addresses crowding at the cause. Section 5, Step 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Reduce every text size by about 2 px so the screen holds more content. | Incorrect | Shrinking comes last in the lesson's order, because shrinking first leaves the screen still crowded and now harder to read. |
| B | Remove or defer content that does not support the task at hand. | **Correct** | Subtraction addresses crowding at the cause. Section 5, Step 8. |
| C | Add divider lines between sections so the content is clearly separated. | Incorrect | Dividers add ink and a third way of grouping; the fix is to remove dividers and let 24 px of space separate the groups. |
| D | Add a second accent colour so the sections become easier to tell apart. | Incorrect | Another accent adds a competing signal, and crowding comes from carrying too much content rather than too few colours. |

**If the learner chose otherwise:** revisit Section 5, Step 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. What does the squint test reveal?

**Type:** best · **Lesson reference:** Section 5, Step 3

**Correct answer: D. Whether the intended hierarchy still survives once fine detail is blurred away.**

**Why this is correct:** Blurring removes detail and exposes structural weight. Section 5, Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Whether the colour pairs on the screen reach the required contrast ratio. | Incorrect | Contrast needs a measured ratio from a checker; blurring removes the colour detail that any such judgement depends on. |
| B | Whether the design file will export cleanly to a shareable image format. | Incorrect | Export is a technical file concern, and squinting at a canvas tells you nothing about how the file will leave the tool. |
| C | Whether the visible text has been proofread for spelling and grammar. | Incorrect | Squinting destroys letter detail, which is exactly why it cannot be used to check spelling or anything set in small type. |
| D | Whether the intended hierarchy still survives once fine detail is blurred away. | **Correct** | Blurring removes detail and exposes structural weight. Section 5, Step 3. |

**If the learner chose otherwise:** revisit Section 5, Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. Why is optical alignment sometimes needed?

**Type:** applied · **Lesson reference:** Section 2

**Correct answer: C. Because mathematically equal spacing can look uneven around round or irregular shapes.**

**Why this is correct:** Perceived alignment can differ from measured alignment. Section 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Because grids are optional once the designer trusts their own eye. | Incorrect | The grid remains the base of the layout; an optical nudge moves a shape within those shared lines rather than making alignment optional. |
| B | Because users generally prefer deliberate asymmetry to perfectly even spacing. | Incorrect | Optical alignment corrects an illusion so elements look evenly spaced; it is not a preference for deliberate asymmetry. |
| C | Because mathematically equal spacing can look uneven around round or irregular shapes. | **Correct** | Perceived alignment can differ from measured alignment. Section 2. |
| D | Because Figma cannot align circles and rounded icons to a grid. | Incorrect | Figma aligns circles mathematically without difficulty; the mismatch is between the maths and what the eye perceives, not a tool limit. |

**If the learner chose otherwise:** revisit Section 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. A confirmation screen puts the primary button first in the reading order. Why is that a problem?

**Type:** best · **Lesson reference:** Section 5, Step 7

**Correct answer: B. It invites commitment before the facts are checked, which is risky for irreversible actions.**

**Why this is correct:** Hierarchy should support the task sequence: verify, then act. Section 5, Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Buttons should never be visible before the user has read every other element. | Incorrect | The lesson keeps the button visible, full width and last in the order; hiding it is never the recommendation. |
| B | It invites commitment before the facts are checked, which is risky for irreversible actions. | **Correct** | Hierarchy should support the task sequence: verify, then act. Section 5, Step 7. |
| C | It makes the screen taller than the viewport and forces the user to scroll. | Incorrect | Height is not the risk described; the problem is that the eye reaches commitment before the amount and recipient. |
| D | It breaks the spacing scale by placing a large element above smaller ones. | Incorrect | Reading order comes from size, weight and position, so an off-scale gap is a separate spacing fault rather than this one. |

**If the learner chose otherwise:** revisit Section 5, Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A learner is placing a balance label and value on a row. Which alignment choice best supports scanning?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: C. Align all labels to the left edge and all values to one right edge.**

**Why this is correct:** Two stable edges let the eye compare labels and values without re-reading each row.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Centre every label and value independently so each row looks symmetrical. | Incorrect | Independent centring gives no shared edge, so values form a ragged line and cannot be compared down the page. |
| B | Place each value directly beneath its label with no gap between them. | Incorrect | Stacking value under label removes the row structure, forcing a vertical read of every pair instead of one comparison down a column. |
| C | Align all labels to the left edge and all values to one right edge. | **Correct** | Two stable edges let the eye compare labels and values without re-reading each row. |
| D | Use a different alignment on each row so the list feels less repetitive. | Incorrect | Changing alignment per row destroys the shared edges that let the eye travel straight down the list without re-reading. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A card's title, body text and button all have the same 16 px gap between them. What is the most likely hierarchy problem?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: B. Equal spacing fails to group related content and separate the action from the description.**

**Why this is correct:** Spacing is a grouping cue; equal gaps make the card read as one undifferentiated block.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The card uses too many colours, so the eye cannot tell which part matters. | Incorrect | Colour is not mentioned in the stem, and the given evidence is a uniform 16 px gap, which is a grouping fault. |
| B | Equal spacing fails to group related content and separate the action from the description. | **Correct** | Spacing is a grouping cue; equal gaps make the card read as one undifferentiated block. |
| C | The button is too large for the card and crowds the body text above it. | Incorrect | Nothing is said about the button's size; the stated fact is that all three gaps are identical, which concerns grouping. |
| D | The body text is written in sentence case, which flattens the card's hierarchy. | Incorrect | Capitalisation is a copy convention that does not change how gaps group elements, and the stem gives no case problem. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- Before and after versions of the same screen. — with a file, screenshot, link or log that a stranger can inspect.
- A visible grid with consistent margins and gutters. — with a file, screenshot, link or log that a stranger can inspect.
- At least eight spacing annotations using values from the scale. — with a file, screenshot, link or log that a stranger can inspect.
- No more than three type sizes and one accent colour. — with a file, screenshot, link or log that a stranger can inspect.
- A stated intended reading order that matches the design. — with a file, screenshot, link or log that a stranger can inspect.
- Five-second test notes with verbatim answers from one person. — with a file, screenshot, link or log that a stranger can inspect.
- The explanation links each technique to the reading order, not to taste. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
