# Answer Key — Stop 4.2: AI for Ideation and Flows

**Instructor use only. Do not distribute.**
**Phase:** 4 · The AI design workflow
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | D | judgment | Section 5, Step 1 |
| Q2 | A | applied | Section 2 |
| Q3 | B | problem | Section 5, Step 6 |
| Q4 | C | applied | Section 5, Step 2 |
| Q5 | A | problem | Section 5, Step 5 |
| Q6 | B | best | Section 5, Step 4 |
| Q7 | B | applied | Section 5, Step 7 |
| Q8 | A | best | Section 5, Step 8 |
| Q9 | C | applied | Section 5 (worked steps) |
| Q10 | D | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. Why ask for three structurally different flows rather than "three options"?

**Type:** judgment · **Lesson reference:** Section 5, Step 1

**Correct answer: D. To force real divergence rather than three cosmetic variations of the same structure.**

**Why this is correct:** Naming the structural difference produces genuine alternatives. Section 5, Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | To make the prompt longer, because detailed prompts are treated as higher quality. | Incorrect | Prompt length is not the aim; naming the structural difference is what prevents three cosmetic variations of one flow. |
| B | To give the assistant enough examples that it can produce one usable flow. | Incorrect | The assistant does not need extra examples to produce one flow; asking for one returns the most conventional structure. |
| C | To postpone critique, since comparing options feels more productive than judging one. | Incorrect | Three flows exist to be compared and critiqued against criteria, so divergence adds judgement work rather than postponing it. |
| D | To force real divergence rather than three cosmetic variations of the same structure. | **Correct** | Naming the structural difference produces genuine alternatives. Section 5, Step 1. |

**If the learner chose otherwise:** revisit Section 5, Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. What is a hallucinated feature?

**Type:** applied · **Lesson reference:** Section 2

**Correct answer: A. A capability the AI invents that the product does not have or support.**

**Why this is correct:** It is an invented capability, not a prioritisation issue. Section 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A capability the AI invents that the product does not have or support. | **Correct** | It is an invented capability, not a prioritisation issue. Section 2. |
| B | A feature that is technically hard to build within the current project timeline. | Incorrect | Difficulty is a Build or Assume judgement about a real capability, not an invented feature that exists nowhere. |
| C | A feature that users dislike, according to the research themes already gathered. | Incorrect | Dislike is a research finding about an existing feature, not a capability the model made up. |
| D | A feature already listed in the product backlog but not yet designed. | Incorrect | Backlog items are known, planned scope; a hallucinated feature appears in no product plan at all. |

**If the learner chose otherwise:** revisit Section 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. What does the Have/Build/Assume/Invent marking do?

**Type:** problem · **Lesson reference:** Section 5, Step 6

**Correct answer: B. Separates what already exists from what is feasible, assumed or invented.**

**Why this is correct:** It exposes dependencies and fabrications. Section 5, Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Scores each step for visual quality, so the most polished flow can be selected. | Incorrect | The marks classify capability status, not visual quality, which is scored separately in the critique matrix. |
| B | Separates what already exists from what is feasible, assumed or invented. | **Correct** | It exposes dependencies and fabrications. Section 5, Step 6. |
| C | Counts the screens in each flow, so the shortest path can be identified. | Incorrect | It labels each step's support status; it does not total the screens in the flow. |
| D | Measures accessibility risk per step, using contrast and target sizes as criteria. | Incorrect | Accessibility is checked in the review criteria; the marks say whether a step exists, is buildable, assumed or invented. |

**If the learner chose otherwise:** revisit Section 5, Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. Why generate IA separately from the flow?

**Type:** applied · **Lesson reference:** Section 5, Step 2

**Correct answer: C. Because IA covers structure and naming while a flow covers sequence, and mixing hides structural faults.**

**Why this is correct:** Separate artefacts make separate problems visible. Section 5, Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Because IA only applies to websites, while mobile products rely on flows instead. | Incorrect | IA organises content and destinations in any product, including mobile apps and services, not only websites. |
| B | Because flows cannot contain screens, so their structure has to be described elsewhere. | Incorrect | Flows are sequences of screens and decisions, so the claim reverses the lesson's own definitions. |
| C | Because IA covers structure and naming while a flow covers sequence, and mixing hides structural faults. | **Correct** | Separate artefacts make separate problems visible. Section 5, Step 2. |
| D | Because the assistant can only handle one artefact per prompt and cannot do both. | Incorrect | The lesson prompts for IA separately precisely because AI can produce each artefact; separation makes problems visible. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. What is a pre-mortem?

**Type:** problem · **Lesson reference:** Section 5, Step 5

**Correct answer: A. Imagining the flow has failed in production and listing the most likely reasons.**

**Why this is correct:** It surfaces hidden risks before selection. Section 5, Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Imagining the flow has failed in production and listing the most likely reasons. | **Correct** | It surfaces hidden risks before selection. Section 5, Step 5. |
| B | Testing the flow with five users and recording where they hesitate or stop. | Incorrect | Testing with five users is usability testing; a pre-mortem assumes the flow already failed and lists likely reasons. |
| C | Critiquing the visual hierarchy, spacing and consistency of each screen. | Incorrect | A pre-mortem attacks the flow for production failures and confirming evidence, not the appearance of its screens. |
| D | Mapping the project timeline, including design, build and release milestones. | Incorrect | A pre-mortem lists likely failure reasons and the evidence that would confirm each, not scheduled project work. |

**If the learner chose otherwise:** revisit Section 5, Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. A flow has six steps and low cognitive load per step. Is it automatically better than a three-step flow?

**Type:** best · **Lesson reference:** Section 5, Step 4

**Correct answer: B. No, because total effort, abandonment and context switching matter more than per-step load.**

**Why this is correct:** Step count is not the only measure; total effort matters. Section 5, Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Yes, because more steps keep each screen simpler and users rarely mind the extra taps. | Incorrect | The worked example scores the six-step flow worse on total cognitive load and error recovery, so more steps are not clearer. |
| B | No, because total effort, abandonment and context switching matter more than per-step load. | **Correct** | Step count is not the only measure; total effort matters. Section 5, Step 4. |
| C | Yes, because users prefer wizards and will abandon a flow that asks for everything at once. | Incorrect | The lesson records no preference for wizards; the wizard won because it made the name check a dedicated step. |
| D | No, because step count is irrelevant and only the visual design of each screen matters. | Incorrect | Steps are one criterion in the matrix; they matter alongside load, recovery, offline support and fit with evidence. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. What belongs in a decision log?

**Type:** applied · **Lesson reference:** Section 5, Step 7

**Correct answer: B. What was selected, what was kept, changed or rejected, and the reason for each.**

**Why this is correct:** The log records judgment and trade-offs. Section 5, Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Only the final flow, presented cleanly so the choice needs no further explanation. | Incorrect | A bare final flow hides the alternatives and reasons, so a reviewer cannot see the judgement behind the choice. |
| B | What was selected, what was kept, changed or rejected, and the reason for each. | **Correct** | The log records judgment and trade-offs. Section 5, Step 7. |
| C | The AI model's name and version, so the output can be reproduced later. | Incorrect | The model name is provenance; the log must record what was kept, changed and rejected, and why. |
| D | A list of the colours and components used in the selected flow. | Incorrect | A list of colours is design detail; it does not record which flow was kept, changed or rejected, or why. |

**If the learner chose otherwise:** revisit Section 5, Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. Why draw the selected flow yourself?

**Type:** best · **Lesson reference:** Section 5, Step 8

**Correct answer: A. Because drawing forces you to notice gaps and dependencies that copying hides.**

**Why this is correct:** Manual reconstruction is a comprehension check. Section 5, Step 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Because drawing forces you to notice gaps and dependencies that copying hides. | **Correct** | Manual reconstruction is a comprehension check. Section 5, Step 8. |
| B | Because AI diagrams are usually wrong, so redrawing is the only way to correct them. | Incorrect | AI diagrams can be plausible; redrawing is a comprehension check, not a claim that every AI diagram is wrong. |
| C | Because the export process requires a hand-drawn frame before the file can be shared. | Incorrect | No export rule requires this; drawing by hand forces you to notice gaps that pasting a diagram hides. |
| D | Because a hand-drawn flow looks more professional in a portfolio case study. | Incorrect | Appearance is not the reason; manual reconstruction exposes missing dependencies and failure paths. |

**If the learner chose otherwise:** revisit Section 5, Step 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. An AI produces three flows that are almost identical. Which follow-up prompt is most likely to produce genuinely different options?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: C. Ask for one flow minimising steps, one maximising control, one working offline, with trade-offs stated.**

**Why this is correct:** Naming a structural difference forces alternatives rather than cosmetic variations.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Ask for three more flows with no additional constraints and compare them again. | Incorrect | The same vague prompt produced the near-identical flows, so repeating it without new constraints yields cosmetic variants again. |
| B | Ask the assistant to make the three screens prettier, then choose the clearest one. | Incorrect | Prettier screens change the surface, not the structure, so the three flows remain effectively the same. |
| C | Ask for one flow minimising steps, one maximising control, one working offline, with trade-offs stated. | **Correct** | Naming a structural difference forces alternatives rather than cosmetic variations. |
| D | Ask for one flow, then copy it three times and label the copies as alternatives. | Incorrect | Copying one flow three times guarantees identical options and removes any basis for comparison. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A generated flow includes a 'Scan QR to pay' step, but the product has no camera permissions or QR feature. What is the defect?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: D. The flow invents a capability the product lacks, namely camera access and a QR feature.**

**Why this is correct:** Invented capabilities must be removed or explicitly marked as new scope.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The flow has too few steps for the task and skips the confirmation stage. | Incorrect | The step count is not the problem; the QR step itself depends on a capability the product lacks. |
| B | The flow uses a modal where a full page would be clearer on small screens. | Incorrect | Container choice is a layout detail; the defect is an invented capability, not a modal versus a page. |
| C | The flow lacks a colour palette, so the payment action is not visually distinct. | Incorrect | Colour is cosmetic and unrelated to the missing camera permission and QR feature. |
| D | The flow invents a capability the product lacks, namely camera access and a QR feature. | **Correct** | Invented capabilities must be removed or explicitly marked as new scope. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- Three flows with genuinely different structures. — with a file, screenshot, link or log that a stranger can inspect.
- An IA with five or fewer top-level destinations. — with a file, screenshot, link or log that a stranger can inspect.
- A critique matrix with six criteria and justifications. — with a file, screenshot, link or log that a stranger can inspect.
- Every step marked Have/Build/Assume/Invent. — with a file, screenshot, link or log that a stranger can inspect.
- At least three unsupported features identified and handled. — with a file, screenshot, link or log that a stranger can inspect.
- A pre-mortem with five reasons. — with a file, screenshot, link or log that a stranger can inspect.
- A hand-drawn or FigJam flow including failure paths. — with a file, screenshot, link or log that a stranger can inspect.
- A decision log explaining kept, changed and rejected. — with a file, screenshot, link or log that a stranger can inspect.
- No unmarked invented capability. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
