# Answer Key — Stop 7.1: Case Study Writing

**Instructor use only. Do not distribute.**
**Phase:** 7 · Capstone and career launch
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | A | judgment | Step 1 |
| Q2 | A | applied | Step 3 |
| Q3 | A | problem | Step 4 |
| Q4 | A | applied | Step 7 |
| Q5 | D | problem | Step 7 |
| Q6 | B | best | Step 6 |
| Q7 | D | applied | Step 8 |
| Q8 | C | best | Step 1 and task |
| Q9 | C | applied | Section 5 (worked steps) |
| Q10 | C | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. What should a case study lead with?

**Type:** judgment · **Lesson reference:** Step 1

**Correct answer: A. A one-line summary stating the problem, the action taken and the result, placed before any images.**

**Why this is correct:** Readers need the argument first. Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A one-line summary stating the problem, the action taken and the result, placed before any images. | **Correct** | Readers need the argument first. Step 1. |
| B | A gallery of polished final screens, arranged to show the visual range of the finished product. | Incorrect | Starting with final screens shows the solution before the argument; the lesson says evidence images should support the case study, not replace it. |
| C | A short list of the design tools used, with a note on how long you have used each. | Incorrect | A tool list is the output inventory that Bola's weak draft relied on; Step 9 says cut sentences that only report researching and designing. |
| D | A short personal biography describing your education, design influences and how you became interested in the field. | Incorrect | Context is scaffolding, not the building; Step 2 limits background to three short paragraphs and warns against 500 words of company history. |

**If the learner chose otherwise:** revisit Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. Which is a precise problem statement?

**Type:** applied · **Lesson reference:** Step 3

**Correct answer: A. New users abandon at payment because the delivery fee appears late, so the total feels untrustworthy.**

**Why this is correct:** It names who, what, barrier and consequence. Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | New users abandon at payment because the delivery fee appears late, so the total feels untrustworthy. | **Correct** | It names who, what, barrier and consequence. Step 3. |
| B | The interface looks outdated next to competitors, so the visual style should be refreshed before launch. | Incorrect | Step 3 names 'the design was outdated' as an opinion about a solution; a refreshed style is a remedy, not a description of who is blocked. |
| C | Users want a better experience overall, and the product should feel more modern and more welcoming. | Incorrect | 'A better experience' names no affected group, blocked task or cost, and Step 3 calls that an opinion about a solution. |
| D | The app needs more colour and personality, because the current palette feels flat on most screens. | Incorrect | Adding colour is a presentation remedy; it identifies no user, no task and no barrier that the design should remove. |

**If the learner chose otherwise:** revisit Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. Why show a rejected alternative?

**Type:** problem · **Lesson reference:** Step 4

**Correct answer: A. To demonstrate the judgement behind the decision by explaining what you considered and why you set it aside.**

**Why this is correct:** Rejected options reveal reasoning. Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | To demonstrate the judgement behind the decision by explaining what you considered and why you set it aside. | **Correct** | Rejected options reveal reasoning. Step 4. |
| B | To fill space in the case study so the document reaches the required length without extra research. | Incorrect | Padding reaches a word count without revealing judgement; the rejected option earns its place by showing why the alternative lost. |
| C | To criticise the teammates who preferred the other option, showing that your own judgement was the correct one. | Incorrect | Blaming teammates is not rationale; Step 2 asks for your own role, and the rejected option explains the decision rather than people. |
| D | To show that you can use more design tools than the other candidates applying for the same role. | Incorrect | Tool variety is an output; the worked example rejects extra goal templates and explains why, not which software was used. |

**If the learner chose otherwise:** revisit Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. What is the difference between an output and an outcome?

**Type:** applied · **Lesson reference:** Step 7

**Correct answer: A. An output is what you made, such as a prototype; an outcome is what changed for users or the business.**

**Why this is correct:** Case studies need outcomes, not just deliverables. Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | An output is what you made, such as a prototype; an outcome is what changed for users or the business. | **Correct** | Case studies need outcomes, not just deliverables. Step 7. |
| B | An output is longer and more detailed, while an outcome is a brief note that summarises the same work. | Incorrect | Length does not separate the terms; a long deliverable is still an output, and a one-line change in behaviour is still an outcome. |
| C | An outcome is a screenshot of the finished screen, while an output is the written report that explains it. | Incorrect | A screenshot is something you made, so it is an output; Step 7 defines the outcome as a change in capability or behaviour. |
| D | There is no meaningful difference, because both terms describe the same deliverables listed in the final handoff. | Incorrect | Step 7 separates output, outcome and evidence strength precisely because they make different claims about what changed. |

**If the learner chose otherwise:** revisit Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. How should a small-sample result be reported?

**Type:** problem · **Lesson reference:** Step 7

**Correct answer: D. Three of five participants improved, and the result comes from a small sample with no controlled test.**

**Why this is correct:** Counts and limits prevent overclaiming. Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Users loved the new flow, and several said they would happily recommend it to friends and colleagues. | Incorrect | Step 6 forbids 'users loved it' without evidence; the sentence turns five informal reactions into an unsupported claim. |
| B | Conversion increased by 40%, proving that the redesign worked and should now be rolled out to everyone. | Incorrect | Step 7 criticises this framing: a percentage with no denominator, sample size or limitation proves nothing about causation. |
| C | The sample was small but encouraging, so the detailed numbers can safely be left out of the summary. | Incorrect | Dropping the numbers removes the denominator a reader needs to judge how far a five-person result can be trusted. |
| D | Three of five participants improved, and the result comes from a small sample with no controlled test. | **Correct** | Counts and limits prevent overclaiming. Step 7. |

**If the learner chose otherwise:** revisit Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. A client project is under NDA. What is acceptable?

**Type:** best · **Lesson reference:** Step 6

**Correct answer: B. Publish a reconstructed example with a clear label, or describe the method without any confidential client detail.**

**Why this is correct:** Confidentiality must be respected. Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Publish the full project, because the work is yours and the client's confidentiality agreement covers only their staff. | Incorrect | NDA work is not yours to publish; Step 6 also bars showing a client's unreleased product or logo without permission. |
| B | Publish a reconstructed example with a clear label, or describe the method without any confidential client detail. | **Correct** | Confidentiality must be respected. Step 6. |
| C | Invent a different client name and change the logo, so the work can be shown without identifying anyone. | Incorrect | Renaming the client still exposes confidential content; Step 6 asks for anonymisation or a labelled reconstruction, not a false identity. |
| D | Publish the internal metrics only, since figures reveal far less about the client than screenshots or names would. | Incorrect | Internal metrics are confidential business data, so publishing them alone still discloses protected client information. |

**If the learner chose otherwise:** revisit Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. What makes a lesson useful?

**Type:** applied · **Lesson reference:** Step 8

**Correct answer: D. It is specific about what you would do differently and about what you would test next time.**

**Why this is correct:** Specific lessons show learning. Step 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It is inspirational and reminds the reader why design work matters in a difficult and fast-moving industry. | Incorrect | Step 8 calls 'I learned to empathise with users' a slogan; inspiration is not a specific change you would make. |
| B | It mentions a famous company, which shows that the method has already been validated at a large scale. | Incorrect | A famous name is decoration; the useful lesson answers what you would do differently and what you would test next. |
| C | It is short enough to fit in one word, so readers remember it easily after finishing the case study. | Incorrect | One word cannot name a concrete change, such as testing fee placement before polishing the payment screen. |
| D | It is specific about what you would do differently and about what you would test next time. | **Correct** | Specific lessons show learning. Step 8. |

**If the learner chose otherwise:** revisit Step 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. Why include a short version?

**Type:** best · **Lesson reference:** Step 1 and task

**Correct answer: C. Portfolio cards and introductions need a scannable summary that leads interested readers to the full case study.**

**Why this is correct:** Short and long versions serve different contexts. Step 1 and task.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Recruiters never read long text, so the short version is the only part of the case study anyone will see. | Incorrect | The lesson keeps the long version alongside the short one, so the claim that nobody reads long text is unsupported. |
| B | It replaces the long version entirely, which becomes unnecessary once the key points have been compressed into a card. | Incorrect | The short version points readers to the full study; the artifact requires both the long case study and the 150-word card. |
| C | Portfolio cards and introductions need a scannable summary that leads interested readers to the full case study. | **Correct** | Short and long versions serve different contexts. Step 1 and task. |
| D | It is required by Figma when a project is published, and the portfolio cannot go live without one. | Incorrect | No tool imposes this; the lesson allows plain text or a free document, so Figma plays no required role. |

**If the learner chose otherwise:** revisit Step 1 and task and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A learner's case study opens with 'I designed a beautiful banking app' and then shows final screens. What is the most important missing element?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: C. The user problem, evidence, decisions and outcomes that together explain why the design exists at all.**

**Why this is correct:** A case study needs an argument about a problem and decisions, not a gallery of outputs.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | More decorative mockup frames, so the finished screens look consistent with a polished case study. | Incorrect | Decorative frames dress the same screen gallery; Bola's draft failed for missing problem and evidence, not for its framing. |
| B | A longer list of software tools, including the exact versions used for each screen and each prototype. | Incorrect | The draft already listed tools, and the lesson treats that inventory as a list of outputs rather than an argument. |
| C | The user problem, evidence, decisions and outcomes that together explain why the design exists at all. | **Correct** | A case study needs an argument about a problem and decisions, not a gallery of outputs. |
| D | A brighter colour palette, so the banking app feels more modern than the current screens do. | Incorrect | Visual polish does not supply reasoning; the lesson says the fix is better storytelling and honesty, not more design. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A case study reports 'users loved the new design' after five informal conversations, with no quotes or counts. What is the problem?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: C. A small, undocumented sample is being turned into an unsupported claim that users loved the design.**

**Why this is correct:** The claim exceeds the evidence; counts, quotes and limits are needed.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The case study is too short, and a longer narrative would make the same point more convincingly. | Incorrect | Length is not the defect; the sentence makes a claim without counts, quotes or limits, however long the page becomes. |
| B | Five conversations are never allowed in a portfolio, so the evidence should have come from a survey. | Incorrect | Five-person tests and re-tests are the lesson's own method; what matters is reporting counts and stating limits. |
| C | A small, undocumented sample is being turned into an unsupported claim that users loved the design. | **Correct** | The claim exceeds the evidence; counts, quotes and limits are needed. |
| D | The design should have used more colours, since visual appeal is what makes users respond well. | Incorrect | Colour choice is unrelated; the weakness is the evidence behind 'users loved the new design'. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- One-line summary includes problem, action and result. — with a file, screenshot, link or log that a stranger can inspect.
- Context states the product, user and your specific role. — with a file, screenshot, link or log that a stranger can inspect.
- Problem statement includes who, what, barrier and why it matters. — with a file, screenshot, link or log that a stranger can inspect.
- At least two decision points include rationale. — with a file, screenshot, link or log that a stranger can inspect.
- At least one rejected alternative and one trade-off are explained. — with a file, screenshot, link or log that a stranger can inspect.
- 4–6 images carry evidence and have captions. — with a file, screenshot, link or log that a stranger can inspect.
- Results include counts, denominators and limitations. — with a file, screenshot, link or log that a stranger can inspect.
- Lessons are specific and include a next step. — with a file, screenshot, link or log that a stranger can inspect.
- Participants and clients are anonymised or permission is documented. — with a file, screenshot, link or log that a stranger can inspect.
- Course work is labelled as course work; no invented metrics. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
