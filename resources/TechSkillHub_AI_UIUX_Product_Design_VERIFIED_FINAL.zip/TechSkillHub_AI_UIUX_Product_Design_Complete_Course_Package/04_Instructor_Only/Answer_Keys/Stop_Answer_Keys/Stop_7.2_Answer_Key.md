# Answer Key — Stop 7.2: Working With Developers and Product Managers

**Instructor use only. Do not distribute.**
**Phase:** 7 · Capstone and career launch
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | A | judgment | Step 2 |
| Q2 | B | applied | Step 3 |
| Q3 | C | problem | Step 4 |
| Q4 | B | applied | Step 5 |
| Q5 | B | problem | Step 6 |
| Q6 | C | best | Step 7 |
| Q7 | D | applied | Step 8 |
| Q8 | B | best | Step 9 |
| Q9 | D | applied | Section 5 (worked steps) |
| Q10 | B | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. What is the most useful way to present a design decision to a PM?

**Type:** judgment · **Lesson reference:** Step 2

**Correct answer: A. As two or three options with user benefit, cost and risk, plus one recommendation and its rationale.**

**Why this is correct:** Options with consequences enable decisions. Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | As two or three options with user benefit, cost and risk, plus one recommendation and its rationale. | **Correct** | Options with consequences enable decisions. Step 2. |
| B | As a firm demand supported by your professional judgement, so the team can move forward without further debate. | Incorrect | A demand gives no benefit, cost or risk to weigh, while Step 2 says a recommendation with rationale is easier to approve. |
| C | As a finished screen with no written context, so the PM can react to the visual result immediately. | Incorrect | A finished screen hides cost and risk, so the PM cannot compare options the way the decision table requires. |
| D | As a complaint about the deadline, so the PM understands the pressure the design team is facing. | Incorrect | The deadline is a constraint to respect, not a decision frame; a complaint offers no options and no recommendation. |

**If the learner chose otherwise:** revisit Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. What makes a ticket buildable?

**Type:** applied · **Lesson reference:** Step 3

**Correct answer: B. Context, scope, acceptance criteria, a design link, edge cases and open questions with named owners.**

**Why this is correct:** A ticket must stand alone. Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A clear title alone, because the developer can ask for the rest of the context during stand-up. | Incorrect | With only a title the developer must still ask where the design is, leaving the ticket unable to stand alone. |
| B | Context, scope, acceptance criteria, a design link, edge cases and open questions with named owners. | **Correct** | A ticket must stand alone. Step 3. |
| C | A screenshot and a deadline, so the developer can see the target and plan the work backwards. | Incorrect | Tickets with only a screenshot are the listed mistake, because assumed context leaves no testable acceptance criteria. |
| D | A link to a competitor's page, so the developer can copy the behaviour that already works there. | Incorrect | A competitor link shows someone else's solution, not your user story, scope or definition of done. |

**If the learner chose otherwise:** revisit Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. In a critique, which comment is most useful?

**Type:** problem · **Lesson reference:** Step 4

**Correct answer: C. At 320px the primary button sits below the fold, so users may never see it on a small phone.**

**Why this is correct:** Specific, evidence-linked feedback is actionable. Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | I don't like green, because it makes the whole product feel cheaper than the competitors' products. | Incorrect | 'I don't like green' is taste; Step 6 says acknowledge preferences and do not spend a meeting on them. |
| B | Make it pop, so the primary action stands out more clearly against everything else on the page. | Incorrect | 'Make it pop' is an opinion with no observable problem, unlike a specific failure at 320px that can be checked. |
| C | At 320px the primary button sits below the fold, so users may never see it on a small phone. | **Correct** | Specific, evidence-linked feedback is actionable. Step 4. |
| D | My old team did it differently, and their version tested better with the users we surveyed. | Incorrect | Appealing to an old team gives no evidence about this goal, so nobody can act on the comment. |

**If the learner chose otherwise:** revisit Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. What is scope creep?

**Type:** applied · **Lesson reference:** Step 5

**Correct answer: B. Unplanned additions that expand the work without adjusting the agreed timeline, cost or quality.**

**Why this is correct:** Scope creep is uncontrolled expansion. Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A design pattern where components grow in size as the screen width increases across breakpoints. | Incorrect | Scope creep is a planning failure, not a UI pattern; it describes unplanned additions that expand the work. |
| B | Unplanned additions that expand the work without adjusting the agreed timeline, cost or quality. | **Correct** | Scope creep is uncontrolled expansion. Step 5. |
| C | A type of estimate that assumes the team will work faster than the original forecast allowed. | Incorrect | An estimate predicts effort and is always uncertain; creep is the unapproved growth that breaks that estimate. |
| D | A critique method where reviewers keep adding suggestions until the design has changed substantially. | Incorrect | A critique is structured feedback on the work; creep concerns the boundary of included work and time. |

**If the learner chose otherwise:** revisit Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. A disagreement is about speed versus completeness. What kind is it?

**Type:** problem · **Lesson reference:** Step 6

**Correct answer: B. A values disagreement, because the two sides are prioritising different things and neither is factually wrong.**

**Why this is correct:** It is a priority trade-off, not a factual dispute. Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A fact disagreement, because one side must be wrong about how long the work will actually take. | Incorrect | Facts are settled with evidence, such as whether the API returns a fee; speed versus completeness is a priority choice. |
| B | A values disagreement, because the two sides are prioritising different things and neither is factually wrong. | **Correct** | It is a priority trade-off, not a factual dispute. Step 6. |
| C | A taste disagreement, because the argument is really about which visual style looks more finished. | Incorrect | Taste is preference about the work; the lesson names speed versus completeness as an example of competing values. |
| D | A technical bug, because the disagreement will disappear once the underlying defect has been fixed. | Incorrect | A bug is a defect to fix, not a disagreement about how much speed to trade against completeness. |

**If the learner chose otherwise:** revisit Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. What should an escalation brief include?

**Type:** best · **Lesson reference:** Step 7

**Correct answer: C. The decision needed, the options, a recommendation, a deadline and the default if nobody decides.**

**Why this is correct:** Escalation asks for a decision efficiently. Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A long history of the conflict, so the decision maker understands how the disagreement developed. | Incorrect | A conflict history is complaining; Step 7 asks for the decision needed, why now, options, recommendation, date and default. |
| B | Only the designer's preferred option, stated clearly enough that the decision maker can approve it. | Incorrect | A bare preference gives the decider no options, user impact or default to weigh against each other. |
| C | The decision needed, the options, a recommendation, a deadline and the default if nobody decides. | **Correct** | Escalation asks for a decision efficiently. Step 7. |
| D | A list of everyone who is wrong, so responsibility for the delay can be assigned properly. | Incorrect | Blaming people breaks the rule that escalation stays about the work; the retry variant asks for no mention of personalities. |

**If the learner chose otherwise:** revisit Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. Why keep a decision log?

**Type:** applied · **Lesson reference:** Step 8

**Correct answer: D. To preserve the rationale behind choices, prevent relitigating and help new team members understand earlier decisions.**

**Why this is correct:** Decisions outlive the meeting. Step 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | To fill the project documentation, so the repository looks maintained when a new manager reviews it. | Incorrect | The log prevents relitigating and helps onboarding; the volume of documentation is not its purpose. |
| B | To prove you attended the meetings, which is useful when performance and contribution are reviewed each quarter. | Incorrect | Attendance records prove nothing; the log's value lies in rationale, owner, date and revisit point. |
| C | To replace the design file, so nobody needs to open the source frames once a decision is recorded. | Incorrect | It records decisions and reasons, not designs, so it complements the design file rather than replacing it. |
| D | To preserve the rationale behind choices, prevent relitigating and help new team members understand earlier decisions. | **Correct** | Decisions outlive the meeting. Step 8. |

**If the learner chose otherwise:** revisit Step 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. What builds trust fastest with a developer?

**Type:** best · **Lesson reference:** Step 9

**Correct answer: B. Reliable delivery, early risk flags, updated designs and turning up to the build review each sprint.**

**Why this is correct:** Reliability matters more than polish. Step 9.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Beautiful mockups, because visual quality is what convinces engineers that a designer is worth listening to. | Incorrect | Step 9 says a reliable designer gains more influence than a merely talented one; polish is not the trust mechanism. |
| B | Reliable delivery, early risk flags, updated designs and turning up to the build review each sprint. | **Correct** | Reliability matters more than polish. Step 9. |
| C | More meetings, because frequent contact shows the developer that the designer is engaged and reliable. | Incorrect | Extra meetings are not among the trust behaviours, which are delivering, flagging risk early and admitting unknowns. |
| D | Avoiding all constraints, because a designer who never compromises keeps the original product vision intact. | Incorrect | Ignoring constraints makes you a source of unplanned work; trust comes from respecting the developer's limits. |

**If the learner chose otherwise:** revisit Step 9 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A developer says a design interaction is technically impossible in the current sprint. What is the most useful response?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: D. Ask what constraint makes it impossible, then offer a smaller or alternative interaction with its trade-off.**

**Why this is correct:** Understanding the constraint and offering options keeps the user goal alive without denying reality.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Insist that the original design ships exactly as drawn, because the interaction carries the whole experience. | Incorrect | Insisting on the drawing denies the constraint; Kelechi reframes into a smaller option rather than demanding the animation. |
| B | Remove the feature without telling the product manager, so the sprint stays on schedule and nobody notices. | Incorrect | Cutting the feature silently breaks scope ownership and the decision log; deferrals must be told to the PM. |
| C | Escalate immediately without asking a question, because the developer is blocking work that was already agreed. | Incorrect | Escalation is for blocked decisions and needs options; here you should first learn what the constraint is. |
| D | Ask what constraint makes it impossible, then offer a smaller or alternative interaction with its trade-off. | **Correct** | Understanding the constraint and offering options keeps the user goal alive without denying reality. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A ticket says 'make the settings page nicer' and gives no acceptance criteria. What will most likely happen?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: B. The developer and designer will interpret 'nicer' differently, causing rework and a much slower review.**

**Why this is correct:** A ticket needs observable acceptance criteria to be buildable and reviewable.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The page will automatically become accessible, because the design system handles labels and focus order. | Incorrect | Accessibility needs explicit criteria such as labels and focus behaviour, none of which 'nicer' supplies. |
| B | The developer and designer will interpret 'nicer' differently, causing rework and a much slower review. | **Correct** | A ticket needs observable acceptance criteria to be buildable and reviewable. |
| C | The design system will update itself, because vague requests usually trigger a routine component refresh. | Incorrect | A design system changes through documented decisions and drift checks, which a vague ticket never triggers. |
| D | The sprint will end early, because the developer can stop once the page looks better than before. | Incorrect | Without acceptance criteria the work expands into interpretation and rework instead of finishing early. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- Ticket is self-contained with testable acceptance criteria. — with a file, screenshot, link or log that a stranger can inspect.
- Decision log has at least four entries with rationale and owner. — with a file, screenshot, link or log that a stranger can inspect.
- Critique note has one strength and three specific improvements tied to the goal. — with a file, screenshot, link or log that a stranger can inspect.
- Escalation brief states the decision, options, recommendation, deadline and default. — with a file, screenshot, link or log that a stranger can inspect.
- At least one trade-off is explained in user, cost and risk terms. — with a file, screenshot, link or log that a stranger can inspect.
- The reflection names a constraint and its effect on the design. — with a file, screenshot, link or log that a stranger can inspect.
- No confidential or personnel information is included. — with a file, screenshot, link or log that a stranger can inspect.
- Language is professional and focused on the work. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
