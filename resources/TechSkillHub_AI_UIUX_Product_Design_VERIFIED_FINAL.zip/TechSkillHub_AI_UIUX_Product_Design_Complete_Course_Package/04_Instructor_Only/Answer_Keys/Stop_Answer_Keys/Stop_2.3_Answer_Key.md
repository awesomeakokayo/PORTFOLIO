# Answer Key — Stop 2.3: Components and Patterns

**Instructor use only. Do not distribute.**
**Phase:** 2 · Visual and interaction foundations
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | D | judgment | Section 5, Step 1 |
| Q2 | D | applied | Section 5, Step 1 |
| Q3 | C | problem | Section 2 |
| Q4 | D | applied | Section 5, Step 4 |
| Q5 | D | problem | Section 5, Step 3 |
| Q6 | A | best | Section 5, Step 6 |
| Q7 | C | applied | Section 5, Step 2 |
| Q8 | A | best | Section 5, Step 1 |
| Q9 | D | applied | Section 5 (worked steps) |
| Q10 | D | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. Which control should turn a setting on immediately, with no Save step?

**Type:** judgment · **Lesson reference:** Section 5, Step 1

**Correct answer: D. A toggle, because it changes the setting at once with no confirmation step.**

**Why this is correct:** A toggle implies immediate effect. Section 5, Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A checkbox, because it records a choice that is applied when the form is saved. | Incorrect | A checkbox is for options applied later, usually behind a Save step, which is exactly the situation the stem excludes. |
| B | A radio button, because it shows a small set of options side by side. | Incorrect | A radio chooses one item from a small visible set and normally commits on submit, so it also assumes a Save step. |
| C | A dropdown, because it hides the list until the user opens it. | Incorrect | A dropdown hides a longer list until opened and then commits on submit, adding both a tap and a confirmation step. |
| D | A toggle, because it changes the setting at once with no confirmation step. | **Correct** | A toggle implies immediate effect. Section 5, Step 1. |

**If the learner chose otherwise:** revisit Section 5, Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. When is a dropdown a poor choice?

**Type:** applied · **Lesson reference:** Section 5, Step 1

**Correct answer: D. When only two or three options exist and all could be shown.**

**Why this is correct:** Hiding a small set adds effort and hides choices. Section 5, Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | When the list holds forty options and the user must find one bank. | Incorrect | A long list of forty is the dropdown's proper use, because hiding it saves the space forty visible options would take. |
| B | When the option labels are long enough to wrap onto two lines. | Incorrect | Long labels are a width problem you solve with layout; a long list is still a case where a select is appropriate. |
| C | When the user is on a mobile screen with limited vertical space. | Incorrect | The lesson's own worked example uses a select for a bank list on mobile, so mobile alone does not disqualify a dropdown. |
| D | When only two or three options exist and all could be shown. | **Correct** | Hiding a small set adds effort and hides choices. Section 5, Step 1. |

**If the learner chose otherwise:** revisit Section 5, Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. What is the difference between a button and a link?

**Type:** problem · **Lesson reference:** Section 2

**Correct answer: C. A button triggers an action, while a link navigates or reveals more content.**

**Why this is correct:** Semantics and expectation differ. Section 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A link is always blue and underlined, while a button uses a filled background. | Incorrect | Blue underlining is a convention, not the definition; the real difference lies in what each control does when used. |
| B | A button can only be used once, whereas a link can be followed repeatedly. | Incorrect | Buttons can be pressed many times; the lesson's rule is one primary button per screen, not one press per button. |
| C | A button triggers an action, while a link navigates or reveals more content. | **Correct** | Semantics and expectation differ. Section 2. |
| D | There is no real difference; both simply respond when the user clicks them. | Incorrect | The lesson separates them clearly: a button commits an action now, while a link moves the user or reveals content. |

**If the learner chose otherwise:** revisit Section 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. Which content is best as a list rather than a card?

**Type:** applied · **Lesson reference:** Section 5, Step 4

**Correct answer: D. Ten beneficiaries, each with a name and a bank and nothing else.**

**Why this is correct:** Uniform, scannable rows are efficient as a list. Section 5, Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A product with an image, a price and an Add to cart action. | Incorrect | Varied content with an image, a price and an action is the textbook card case, since a card holds mixed elements plus one action. |
| B | A promotional banner announcing a seasonal discount across the store. | Incorrect | A single promotional block is one section of a page, better handled as a plain section than as a repeated row. |
| C | A photo gallery of customer images from the past month. | Incorrect | A gallery is image-led content needing the bounded card treatment, not a uniform text row built for fast scanning. |
| D | Ten beneficiaries, each with a name and a bank and nothing else. | **Correct** | Uniform, scannable rows are efficient as a list. Section 5, Step 4. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. What must a text field label do?

**Type:** problem · **Lesson reference:** Section 5, Step 3

**Correct answer: D. Remain visible above the field so its purpose is never lost.**

**Why this is correct:** Persistent labels support memory and accessibility. Section 5, Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Disappear once the user starts typing so the field looks less cluttered. | Incorrect | Disappearing is the placeholder behaviour the lesson rejects: once the text is gone, nothing on screen names the field. |
| B | Sit inside the field as grey placeholder text until the input begins. | Incorrect | A placeholder vanishes on input and is not reliably announced as the field's name, so the input ends up unlabelled. |
| C | Stay optional, so only the fields a user cares about carry a label. | Incorrect | Every input needs a persistent visible label; only the field's content can be optional, and the label must still say so. |
| D | Remain visible above the field so its purpose is never lost. | **Correct** | Persistent labels support memory and accessibility. Section 5, Step 3. |

**If the learner chose otherwise:** revisit Section 5, Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. Which is a good empty-state message?

**Type:** best · **Lesson reference:** Section 5, Step 6

**Correct answer: A. 'No saved beneficiaries yet. Save someone you pay often to skip this next time,' plus an action.**

**Why this is correct:** It explains the state and offers a route forward. Section 5, Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | 'No saved beneficiaries yet. Save someone you pay often to skip this next time,' plus an action. | **Correct** | It explains the state and offers a route forward. Section 5, Step 6. |
| B | 'No data is available for this section right now,' with no explanation and no action. | Incorrect | It states only that data is missing, explains nothing about what belongs here, and offers no action to create the first item. |
| C | 'Nothing here yet,' shown with a small illustration but no route forward for the user. | Incorrect | It acknowledges emptiness but gives no explanation of what would appear and no route forward, so the user is stuck. |
| D | A sad face illustration on its own, with no text message and no button at all. | Incorrect | An illustration alone names nothing and offers no first action, leaving the user with no idea what to do next. |

**If the learner chose otherwise:** revisit Section 5, Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. Why is a visible focus state essential?

**Type:** applied · **Lesson reference:** Section 5, Step 2

**Correct answer: C. Keyboard users need to see which control will receive their next input.**

**Why this is correct:** Focus visibility is a WCAG requirement and a usability necessity. Section 5, Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It makes the interface look modern and up to date with current design trends. | Incorrect | Looking current is not the reason; the focus state exists so a keyboard user can see where the next keystroke lands. |
| B | It raises the control's contrast ratio automatically whenever the ring appears. | Incorrect | A ring adds a visible outline around the control; it does not raise the measured contrast of the text or the control's colours. |
| C | Keyboard users need to see which control will receive their next input. | **Correct** | Focus visibility is a WCAG requirement and a usability necessity. Section 5, Step 2. |
| D | It matters only on forms, where several fields sit close together. | Incorrect | Focus applies to every interactive element, including links, tabs, buttons and menu items, not only to form fields. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. A toggle is used for "Subscribe to marketing emails" inside a form with a Save button. What is wrong?

**Type:** best · **Lesson reference:** Section 5, Step 1

**Correct answer: A. The toggle implies immediate effect, yet the setting only applies after Save.**

**Why this is correct:** The control's affordance contradicts the interaction model. Section 5, Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The toggle implies immediate effect, yet the setting only applies after Save. | **Correct** | The control's affordance contradicts the interaction model. Section 5, Step 1. |
| B | Nothing is wrong, because toggles are always acceptable for binary settings. | Incorrect | The lesson's first rule forbids a toggle wherever a Save step exists, so this is the exact failure described rather than a non-issue. |
| C | It should be a link, because subscribing is really a navigation choice. | Incorrect | A link navigates somewhere; a marketing preference is a choice that gets submitted, so a checkbox is the nearest correct control. |
| D | It should be a table, because the preference is one row of data. | Incorrect | A table compares attributes across rows of data; it is not a control for a single on/off preference. |

**If the learner chose otherwise:** revisit Section 5, Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A learner must let users choose one of three delivery speeds before confirming an order. Which control is the best fit?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: D. A radio group showing all three speeds and what each one costs.**

**Why this is correct:** A small set of mutually exclusive choices is visible and comparable in a radio group.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A dropdown that hides two of the three speeds until the user opens it. | Incorrect | Hiding two of three options adds a tap and conceals choices the user should be able to compare side by side. |
| B | A toggle switch for each speed, so users can enable any they like. | Incorrect | Toggles are independent on/off settings, so three of them would let the user switch on contradictory speeds at once. |
| C | A free-text field where the user types the speed they want. | Incorrect | Free text invites typos and invalid entries and leaves the available speeds unguessable, when the set is small enough to show. |
| D | A radio group showing all three speeds and what each one costs. | **Correct** | A small set of mutually exclusive choices is visible and comparable in a radio group. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A learner uses a toggle for 'Email me offers' inside a form that only takes effect when the user presses Save. What is the interaction problem?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: D. The toggle implies an immediate change, but the setting only applies on Save.**

**Why this is correct:** The control's affordance contradicts the actual interaction model.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The toggle is too small to see, so users miss it beside the longer fields. | Incorrect | Size is a target and visibility concern; the described fault is that the control looks immediate while the effect waits for Save. |
| B | The label is written as a sentence rather than a short verb phrase. | Incorrect | Sentence case is the lesson's recommended content style, so capitalisation is not the defect in this form. |
| C | The form has no Submit button, so the setting can never be applied. | Incorrect | The stem says the setting applies when the user presses Save, so a Save control plainly exists. |
| D | The toggle implies an immediate change, but the setting only applies on Save. | **Correct** | The control's affordance contradicts the actual interaction model. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- Seven components, each with the required states. — with a file, screenshot, link or log that a stranger can inspect.
- Buttons have primary, secondary and tertiary variants. — with a file, screenshot, link or log that a stranger can inspect.
- Text field includes visible label, helper, error and focus states. — with a file, screenshot, link or log that a stranger can inspect.
- Usage notes include do, don't and an accessibility note. — with a file, screenshot, link or log that a stranger can inspect.
- One screen uses at least four components consistently. — with a file, screenshot, link or log that a stranger can inspect.
- The choice defence compares two controls and names the nearest alternative. — with a file, screenshot, link or log that a stranger can inspect.
- Missing states are listed honestly. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
