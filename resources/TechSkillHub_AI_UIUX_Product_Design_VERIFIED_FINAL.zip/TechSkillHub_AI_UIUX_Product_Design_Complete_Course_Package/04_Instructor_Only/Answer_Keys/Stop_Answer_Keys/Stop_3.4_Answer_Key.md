# Answer Key — Stop 3.4: Prototyping

**Instructor use only. Do not distribute.**
**Phase:** 3 · Figma fluency and design systems
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | B | judgment | Section 5, Step 1 |
| Q2 | D | applied | Section 5, Step 4 |
| Q3 | A | problem | Section 5, Step 4 |
| Q4 | D | applied | Section 5, Step 2 |
| Q5 | B | problem | Section 2 |
| Q6 | B | best | Section 5, Step 6 |
| Q7 | A | applied | Section 5, Step 5 |
| Q8 | C | best | Section 5, Step 7 |
| Q9 | D | applied | Section 5 (worked steps) |
| Q10 | C | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. What is a flow starting point?

**Type:** judgment · **Lesson reference:** Section 5, Step 1

**Correct answer: B. The frame where the prototype begins when a flow is presented.**

**Why this is correct:** It sets the entry frame for a named flow. Section 5, Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The first component in the file, which the presentation opens by default. | Incorrect | A component is a reusable object, not a prototype entry; the starting point is a frame property set in the Prototype panel. |
| B | The frame where the prototype begins when a flow is presented. | **Correct** | It sets the entry frame for a named flow. Section 5, Step 1. |
| C | The last screen in the flow, where the participant finishes the task. | Incorrect | The last screen is where a flow ends, while the starting point is the first frame the tester lands on. |
| D | The file cover, which introduces the project before the flow starts. | Incorrect | The cover is documentation for the file, and a flow begins on the first screen of the task, such as the entry frame. |

**If the learner chose otherwise:** revisit Section 5, Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. When is an overlay better than a new screen?

**Type:** applied · **Lesson reference:** Section 5, Step 4

**Correct answer: D. For modals, menus and pickers that sit above the current context.**

**Why this is correct:** Overlays preserve context and avoid duplicating screens. Section 5, Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | For every navigation, because overlays avoid duplicating any screen. | Incorrect | Pushing to a new screen is the normal navigation case; overlays are for content that sits above the current context. |
| B | For long forms, because a sheet keeps the form shorter on mobile. | Incorrect | A long form needs its own screen and scrolling, and an overlay that tall would cover the context it is meant to preserve. |
| C | For the home screen, because it should appear above the previous screen. | Incorrect | The home screen is a destination, not something layered above another screen, so there is no context underneath to keep visible. |
| D | For modals, menus and pickers that sit above the current context. | **Correct** | Overlays preserve context and avoid duplicating screens. Section 5, Step 4. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. What must every overlay have?

**Type:** problem · **Lesson reference:** Section 5, Step 4

**Correct answer: A. At least one clear way for the participant to close it.**

**Why this is correct:** An overlay without an exit is a trap. Section 5, Step 4.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | At least one clear way for the participant to close it. | **Correct** | An overlay without an exit is a trap. Section 5, Step 4. |
| B | An animation, so the participant notices that the overlay appeared. | Incorrect | Animation is optional polish; the requirement is an exit, and the lesson says an overlay with no close behaviour is a trap. |
| C | A back button, so the participant can return to the previous screen. | Incorrect | An overlay closes by tapping outside or a close control, and a back button is screen navigation that does not guarantee dismissal. |
| D | A logo, so the overlay looks like part of the same product. | Incorrect | A logo is branding, and an overlay with a logo but no exit still traps the participant with no way back. |

**If the learner chose otherwise:** revisit Section 5, Step 4 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. Why use "After delay" sparingly in a test prototype?

**Type:** applied · **Lesson reference:** Section 5, Step 2

**Correct answer: D. It makes the test slower without testing the thing you care about.**

**Why this is correct:** Simulate processing briefly; do not make participants wait. Section 5, Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Figma charges for each delay, so long delays increase the plan cost. | Incorrect | No delay trigger is billed; the real issue is test time, and the lesson keeps processing delays to one or two seconds. |
| B | Delay triggers break scrolling, so a scrolling screen cannot use them. | Incorrect | Delay and scrolling are independent frame settings, and a scrollable screen can still use an after-delay connection. |
| C | A delayed connection cannot be reset, so each session starts mid-flow. | Incorrect | Reset is handled by reopening the link or choosing Restart, whatever the trigger, so a delay does not prevent resetting. |
| D | It makes the test slower without testing the thing you care about. | **Correct** | Simulate processing briefly; do not make participants wait. Section 5, Step 2. |

**If the learner chose otherwise:** revisit Section 5, Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. What is a dead end?

**Type:** problem · **Lesson reference:** Section 2

**Correct answer: B. A screen with no forward or back path out of it.**

**Why this is correct:** Dead ends trap participants and invalidate the test. Section 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A screen with too many buttons, so the participant cannot choose one. | Incorrect | Too many buttons is a hierarchy problem; a dead end specifically means no forward or back path from the screen. |
| B | A screen with no forward or back path out of it. | **Correct** | Dead ends trap participants and invalidate the test. Section 2. |
| C | A screen with no images, so nothing indicates where to tap next. | Incorrect | Images are optional content, and a text-only screen with working forward and back links is not a dead end. |
| D | A screen with a modal that covers most of the underlying content. | Incorrect | A modal is a normal pattern with a close behaviour, and it does not stop the participant from continuing the flow. |

**If the learner chose otherwise:** revisit Section 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. Why add a test path to an error state?

**Type:** best · **Lesson reference:** Section 5, Step 6

**Correct answer: B. So you can observe recovery, which is often the most important behaviour.**

**Why this is correct:** Unreachable states cannot be tested. Section 5, Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | To make the prototype longer, so it looks more complete to reviewers. | Incorrect | Length is never the goal; a test path exists so the facilitator can observe how a participant recovers from failure. |
| B | So you can observe recovery, which is often the most important behaviour. | **Correct** | Unreachable states cannot be tested. Section 5, Step 6. |
| C | Because errors are required by Figma before a prototype can be presented. | Incorrect | Figma has no requirement for error states; the branch is a design and testing decision, not a tool rule. |
| D | To show off the animation that plays when the error message appears. | Incorrect | Animation is polish, and the error path is there to test recovery rather than to demonstrate a transition. |

**If the learner chose otherwise:** revisit Section 5, Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. What does "fix position when scrolling" do?

**Type:** applied · **Lesson reference:** Section 5, Step 5

**Correct answer: A. Keeps an element in place while the content behind it scrolls.**

**Why this is correct:** It creates sticky headers and bars. Section 5, Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Keeps an element in place while the content behind it scrolls. | **Correct** | It creates sticky headers and bars. Section 5, Step 5. |
| B | Locks the frame size, so the frame cannot be resized afterwards. | Incorrect | Frame size is set by width and height or resize constraints, while fixed position only changes how a layer behaves during scrolling. |
| C | Stops the prototype, so the participant cannot continue the flow. | Incorrect | Nothing in the setting halts a flow; it keeps an element still while the content underneath moves. |
| D | Pins the file, so it stays at the top of recent files. | Incorrect | There is no file pinning; the option applies to a layer inside a scrolling frame, holding it in view. |

**If the learner chose otherwise:** revisit Section 5, Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. A participant taps a label that is not connected. What should you do?

**Type:** best · **Lesson reference:** Section 5, Step 7

**Correct answer: C. Fix the prototype or the design so the affordance matches the interaction.**

**Why this is correct:** If it looks interactive, it should be; otherwise the affordance misleads. Section 5, Step 7.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Tell them not to tap there, and ask them to use the button instead. | Incorrect | That fixes the participant instead of the prototype, and the lesson's rule is to fix the prototype, not the person. |
| B | Ignore it, because the participant will find the right control eventually. | Incorrect | An unconnected label that looks tappable is a real affordance failure and will distort every later session too. |
| C | Fix the prototype or the design so the affordance matches the interaction. | **Correct** | If it looks interactive, it should be; otherwise the affordance misleads. Section 5, Step 7. |
| D | Remove the label, so nothing on the screen looks tappable but is not. | Incorrect | Deleting the label hides the problem; if the label communicates something, it should work or stop looking interactive. |

**If the learner chose otherwise:** revisit Section 5, Step 7 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A prototype's back button always returns to the home screen instead of the previous step. What should the learner fix?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: D. Connect each back control to the screen the user actually came from.**

**Why this is correct:** Prototype navigation must match the user's expected history, not a single default.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Remove the back button from every screen so the flow cannot loop. | Incorrect | Removing the back button deletes the required back path and turns every screen into a dead end. |
| B | Add a longer transition animation, so the change of screen feels clearer. | Incorrect | Transition length does not change the destination, and the connection itself points at the wrong frame. |
| C | Change the button colour to show it is secondary rather than primary. | Incorrect | Restyling the control does not change where it navigates, so the tester still lands on home instead of the previous step. |
| D | Connect each back control to the screen the user actually came from. | **Correct** | Prototype navigation must match the user's expected history, not a single default. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A clickable prototype has no path to its error state, so the error screen cannot be reached during a test. What is the testing consequence?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: C. The error state cannot be evaluated, so the test cannot show whether users recover.**

**Why this is correct:** Unreachable states cannot be tested; the prototype must include a path to them.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The prototype will load more slowly, because the missing screen is loaded. | Incorrect | An unreachable frame adds no runtime cost; the loss is evidence about recovery, not loading speed. |
| B | The error state will automatically appear at random during the session. | Incorrect | Prototypes follow connections, so nothing appears without a trigger and an unconnected error screen stays invisible. |
| C | The error state cannot be evaluated, so the test cannot show whether users recover. | **Correct** | Unreachable states cannot be tested; the prototype must include a path to them. |
| D | Participants will assume the product has no errors at all after testing. | Incorrect | Participants never encounter the state, so the test produces no evidence either way about what they expect from errors. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- Six or more connected screens in flow order. — with a file, screenshot, link or log that a stranger can inspect.
- A named flow and a starting point. — with a file, screenshot, link or log that a stranger can inspect.
- A working overlay with two exits. — with a file, screenshot, link or log that a stranger can inspect.
- A scrolling screen with a fixed element. — with a file, screenshot, link or log that a stranger can inspect.
- Loading and error states, with a recovery path. — with a file, screenshot, link or log that a stranger can inspect.
- No dead ends; a back path from every screen. — with a file, screenshot, link or log that a stranger can inspect.
- Test-readiness note covers reset and branches. — with a file, screenshot, link or log that a stranger can inspect.
- Observation notes record a real person's hesitations. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
