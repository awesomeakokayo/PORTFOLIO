# Answer Key — Stop 6.2: Product Metrics

**Instructor use only. Do not distribute.**
**Phase:** 6 · Testing, metrics and iteration
**Pass target:** 8 of 10 (80%). The comprehension check and the practical criteria are both required; a high quiz score cannot compensate for missing practical evidence.

## Marking summary

| Question | Answer | Type | Lesson reference |
|---|---|---|---|
| Q1 | A | judgment | Step 2 |
| Q2 | A | applied | Step 1 |
| Q3 | C | problem | Step 3 |
| Q4 | C | applied | Step 6 |
| Q5 | C | problem | Step 5 |
| Q6 | C | best | Step 8 |
| Q7 | B | applied | Step 6 |
| Q8 | A | best | Section 2 |
| Q9 | B | applied | Section 5 (worked steps) |
| Q10 | A | problem | Section 5 (worked steps) and Section 11 (common mistakes) |

## Full rationale and distractor analysis

### Q1. What makes a metric useful?

**Type:** judgment · **Lesson reference:** Step 2

**Correct answer: A. A precise definition, a stated formula and a time window tied to a decision someone will make.**

**Why this is correct:** Precision and purpose make a metric useful. Step 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A precise definition, a stated formula and a time window tied to a decision someone will make. | **Correct** | Precision and purpose make a metric useful. Step 2. |
| B | A large total that grows every month, so it looks impressive on the dashboard during reviews. | Incorrect | A large growing total is the lesson's example of a vanity number when no decision depends on it, so scale alone proves nothing. |
| C | A place on the main dashboard, so the whole team sees it every morning without extra work. | Incorrect | Dashboard placement is visibility, not usefulness; a screenshot without definitions, window and interpretation is a listed mistake. |
| D | A number that is easy to increase, so any change the team ships will show visible progress. | Incorrect | Easy to increase is the danger: more clicks or sign-ups can mean confusion or a misleading promise rather than a better experience. |

**If the learner chose otherwise:** revisit Step 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q2. Which is the best activation event for a savings app?

**Type:** applied · **Lesson reference:** Step 1

**Correct answer: A. Creating a goal and making a first deposit of a set amount within the first week.**

**Why this is correct:** Activation is first real value, not a preliminary action. Step 1.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Creating a goal and making a first deposit of a set amount within the first week. | **Correct** | Activation is first real value, not a preliminary action. Step 1. |
| B | Opening the app for the first time after installing it and reaching the home screen. | Incorrect | Opening the app is the preliminary action the lesson names as not activation; no goal exists and no value has been received. |
| C | Seeing the logo on the splash screen while the app loads for the first few seconds. | Incorrect | The splash logo is brand exposure with no user action toward the goal, so it marks nothing about first meaningful value. |
| D | Installing the app from the store and granting the permissions it asks for at start-up. | Incorrect | Installing and granting permissions happen before any goal or deposit, which puts them in acquisition, like signing up. |

**If the learner chose otherwise:** revisit Step 1 and re-attempt the matching practice step. Do not simply supply the answer.

### Q3. A funnel shows a 58% drop between product view and cart. What does it tell you?

**Type:** problem · **Lesson reference:** Step 3

**Correct answer: C. Where people left the sequence at that step, but not the reason, which needs observation or interviews.**

**Why this is correct:** Funnels locate loss; they do not explain it. Step 3.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Why people left at that step, because the size of the drop shows what they were thinking. | Incorrect | Emotional cause is not in the counts; the funnel only shows how many stopped, and feelings need observation or interviews. |
| B | That the design is bad, because a loss that large cannot happen in a well-made interface. | Incorrect | A large loss shows where people stopped, and price, trust or traffic quality could explain it, so design quality is not established. |
| C | Where people left the sequence at that step, but not the reason, which needs observation or interviews. | **Correct** | Funnels locate loss; they do not explain it. Step 3. |
| D | That the sample is significant, because a 58% difference is too large to be chance. | Incorrect | Funnel counts carry no significance test, and the fictional 1,000 views say nothing about whether the gap is real. |

**If the learner chose otherwise:** revisit Step 3 and re-attempt the matching practice step. Do not simply supply the answer.

### Q4. In a product metric tree, what is a guardrail metric?

**Type:** applied · **Lesson reference:** Step 6

**Correct answer: C. A metric you protect from harm while you try to improve the primary metric for the change.**

**Why this is correct:** Guardrails catch harmful side effects. Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | A metric you try to increase at any cost, because it is the main sign that the change worked. | Incorrect | Pursuing it at any cost is what a guardrail prevents; the lesson says a completion rate bought with doubled refunds is not a win. |
| B | A metric that is always larger than the others, so it stands out when the dashboard is scanned. | Incorrect | Guardrails are often numbers you want low or stable, such as refund rate or support contacts per thousand orders, not the largest figure. |
| C | A metric you protect from harm while you try to improve the primary metric for the change. | **Correct** | Guardrails catch harmful side effects. Step 6. |
| D | A vanity metric that looks impressive in a review but does not guide any product decision. | Incorrect | A vanity metric impresses without guiding a decision, while a guardrail is chosen precisely to catch harm while the primary metric moves. |

**If the learner chose otherwise:** revisit Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q5. Why are cohorts more informative than a single average?

**Type:** problem · **Lesson reference:** Step 5

**Correct answer: C. They show change over time for comparable groups, which a flat overall average can hide.**

**Why this is correct:** Cohorts expose trends hidden by averages. Step 5.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | They are easier to calculate, since the spreadsheet can total every user in one simple sum. | Incorrect | Cohorts take more work, since each sign-up week is tracked separately, which is harder than reporting one overall average. |
| B | They remove the need for definitions, because the groups already share a start period. | Incorrect | Definitions are still required, because a cohort needs a stated population, window and formula before the comparison means anything. |
| C | They show change over time for comparable groups, which a flat overall average can hide. | **Correct** | Cohorts expose trends hidden by averages. Step 5. |
| D | They increase the sample size, so every group has more users than the overall figure did. | Incorrect | Splitting the same users by sign-up week shrinks every group, so cohorts make the sample problem worse rather than better. |

**If the learner chose otherwise:** revisit Step 5 and re-attempt the matching practice step. Do not simply supply the answer.

### Q6. "6 of 20 users completed the task" is better than "30% of users" because:

**Type:** best · **Lesson reference:** Step 8

**Correct answer: C. It shows the count and the sample size, so readers can see how uncertain the result is.**

**Why this is correct:** Counts and denominators prevent overclaiming. Step 8.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | It is shorter, so the finding fits more easily into a summary slide or a status email. | Incorrect | The count form is longer than the percentage, so brevity is not the reason, and the lesson never asks for shorter reports. |
| B | Percentages are always wrong in usability work and should never appear in a written research report. | Incorrect | Percentages work when the denominator is stated, as the lesson's own 62% and 68% comparison does with sample sizes attached. |
| C | It shows the count and the sample size, so readers can see how uncertain the result is. | **Correct** | Counts and denominators prevent overclaiming. Step 8. |
| D | It sounds more technical, which makes the report more credible to the engineers and senior managers. | Incorrect | Technical tone is not the point; the visible count and denominator make uncertainty honest rather than merely sounding expert. |

**If the learner chose otherwise:** revisit Step 8 and re-attempt the matching practice step. Do not simply supply the answer.

### Q7. A completion rate rises while refunds double. What should you conclude?

**Type:** applied · **Lesson reference:** Step 6

**Correct answer: B. The guardrail signals possible harm, so investigate the refunds before celebrating the result or shipping anything.**

**Why this is correct:** Guardrails exist to catch this. Step 6.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The change is a clear success, because completion is the primary metric the team chose. | Incorrect | Completion is the primary metric, but the lesson says a rise accompanied by doubled refunds is not a win, because guardrails exist for this. |
| B | The guardrail signals possible harm, so investigate the refunds before celebrating the result or shipping anything. | **Correct** | Guardrails exist to catch this. Step 6. |
| C | Refunds are unrelated to this change, so the doubling is probably seasonal and can be ignored. | Incorrect | Refunds are the guardrail against pushing people into bad purchases, so doubling is the harm signal, not a seasonal coincidence. |
| D | The sample is too small to read anything, so no conclusion is possible until next quarter. | Incorrect | No sample size is given, and the actionable fact is the broken guardrail, which more users would confirm rather than excuse. |

**If the learner chose otherwise:** revisit Step 6 and re-attempt the matching practice step. Do not simply supply the answer.

### Q8. Which is a vanity metric?

**Type:** best · **Lesson reference:** Section 2

**Correct answer: A. Total cumulative page views with no decision attached to the number in any review.**

**Why this is correct:** It looks impressive but does not guide a decision. Section 2.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | Total cumulative page views with no decision attached to the number in any review. | **Correct** | It looks impressive but does not guide a decision. Section 2. |
| B | Week-4 retention for a defined cohort of users who signed up in the same month. | Incorrect | Week-4 retention has a defined cohort and window and guides a decision about returning users, so it is not decorative. |
| C | Task success rate measured with a defined protocol and a stated denominator per task. | Incorrect | Task success with a protocol has a denominator and formula and informs usability decisions, which is the opposite of vanity. |
| D | Drop-off at a named step of the checkout funnel, compared with the previous release. | Incorrect | Drop-off at a named step tells you where to investigate next, so the number drives a decision rather than only looking impressive. |

**If the learner chose otherwise:** revisit Section 2 and re-attempt the matching practice step. Do not simply supply the answer.

### Q9. A savings app wants an activation metric. Which event best represents first real value?

**Type:** applied · **Lesson reference:** Section 5 (worked steps)

**Correct answer: B. The user completes a first deposit and sees the confirmed balance in the account view.**

**Why this is correct:** Activation should mark the first time the user receives the product's core value.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | The user opens the app for the first time and reaches the welcome screen after installing it. | Incorrect | Opening the app is the preliminary action the lesson explicitly excludes; no deposit has been made and no balance confirmed. |
| B | The user completes a first deposit and sees the confirmed balance in the account view. | **Correct** | Activation should mark the first time the user receives the product's core value. |
| C | The user taps the sign-up button on the landing page and starts filling in the form. | Incorrect | Tapping sign-up records intent before an account or deposit exists, and the lesson rules out signing up for the same reason. |
| D | The user views the marketing page before deciding whether to create an account at all. | Incorrect | A marketing page view happens during acquisition, before sign-up, so it cannot represent first real value inside the product. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and re-attempt the matching practice step. Do not simply supply the answer.

### Q10. A funnel shows a 58% drop between product view and cart, but the team does not know why. What can the funnel itself tell them?

**Type:** problem · **Lesson reference:** Section 5 (worked steps) and Section 11 (common mistakes)

**Correct answer: A. That the loss occurs between the steps, not the reason people left at that point.**

**Why this is correct:** Funnels locate drop-off; explaining it needs observation, interviews or experiments.

| Option | Answer text | Verdict | Explanation |
|---|---|---|---|
| A | That the loss occurs between the steps, not the reason people left at that point. | **Correct** | Funnels locate drop-off; explaining it needs observation, interviews or experiments. |
| B | The exact emotional cause of the drop, because the size shows how people felt. | Incorrect | The funnel counts steps, not feelings; emotion requires session observation or interviews and would still be labelled interpretation. |
| C | That the product is definitely too expensive, since price is the usual reason for a drop. | Incorrect | Price is one hypothesis, and the funnel carries no price data, so a drop cannot be treated as its own explanation. |
| D | That the checkout code is broken, because a 58% loss points to a technical fault. | Incorrect | The loss occurs before the cart, not at checkout, and a code fault is speculation until instrumentation and observation check it. |

**If the learner chose otherwise:** revisit Section 5 (worked steps) and Section 11 (common mistakes) and re-attempt the matching practice step. Do not simply supply the answer.

## Critical-error override

A score of 8/10 does not pass if the learner's practical work contains any of the following. Require rework and a fresh submission:

- fabricated research, quotes, participants, metrics or client work;
- a privacy breach: real personal data, unwarranted recording, or publication without consent;
- an accessibility failure that blocks a core task (keyboard trap, missing label, contrast below 3:1 for essential text);
- an unsafe design instruction (for example, hiding fees, dark patterns, or bypassing consent).

Record the override and the evidence in the learner's file.

## Remediation guidance

- 1–2 wrong: targeted re-read of the cited section, then a short oral explanation.
- 3–4 wrong: re-teach the two weakest steps, then a fresh retry variant.
- 5 or more wrong: repeat the stop with instructor support; do not unlock the next stop.
- Any critical error: rework regardless of score.

## Practical task marking

Use the pass criteria in the learner assessment and the stop rubric. Mark each of the four rubric criteria 1–4 with one sentence of evidence. A criterion below 3 requires rework. A criterion without evidence is "Not yet met".

## Example of a passing response

There is no single correct wording. A passing response makes every pass criterion independently checkable. For this stop, a strong submission would show:

- User job stated in one sentence. — with a file, screenshot, link or log that a stranger can inspect.
- Activation event defined with a window. — with a file, screenshot, link or log that a stranger can inspect.
- Four metrics have explicit formulas. — with a file, screenshot, link or log that a stranger can inspect.
- Funnel has at least five steps with counts and conversion rates. — with a file, screenshot, link or log that a stranger can inspect.
- Cohort table has at least three cohorts. — with a file, screenshot, link or log that a stranger can inspect.
- One primary metric and two guardrails are chosen for a proposed change. — with a file, screenshot, link or log that a stranger can inspect.
- Interpretation separates measurement, observation, interpretation and limits. — with a file, screenshot, link or log that a stranger can inspect.
- At least three limitations are stated. — with a file, screenshot, link or log that a stranger can inspect.
- All data is labelled fictional or clearly sourced and aggregated. — with a file, screenshot, link or log that a stranger can inspect.
- No real user-level data is included. — with a file, screenshot, link or log that a stranger can inspect.

A weak response usually stops at a description of what the learner intended to do. Do not mark intent as evidence. Ask for the artifact, then re-mark.
