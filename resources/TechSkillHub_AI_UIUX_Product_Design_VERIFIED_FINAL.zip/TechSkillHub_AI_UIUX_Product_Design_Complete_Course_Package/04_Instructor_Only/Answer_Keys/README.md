# Answer Keys — Index and Marking Rules

**Instructor use only.** Do not place these files in a learner-facing folder, LMS module, public repository or shared drive.

## Contents

- `Stop_Answer_Keys/` — 38 files, one per stop, covering 380 questions. Each contains the correct option, why it is correct, why each distractor is wrong, the outcome tested, marking rules, critical-error overrides and remediation guidance.
- `../Rubrics/Gate_Rubrics.md` — seven phase-gate rubrics.
- `../Rubrics/Capstone_Rubric.md` — capstone score sheet.
- `../Rubrics/Instructor_Handbook.md` — delivery, feedback and integrity policy.
- `../Rubrics/Reviewer_Panel_Guide.md` — capstone panel process.

## Marking the stop check

- Ten questions per stop; 380 in total.
- 8/10 = 80%, a pass.
- 7/10 = 70%, below the 80% floor; retry.
- Record the score and the questions missed.
- Do not round 7/10 up to 80%.

Each question has exactly one best answer. The key gives:

- the correct letter;
- one or two sentences explaining why it is correct;
- a specific reason each of the three distractors is wrong;
- the lesson section to revisit.

If a learner disputes a question, check the cited section in the lesson. If the question is ambiguous, accept the best-supported alternative, note the ambiguity and flag it for the next package revision. Do not change the key silently.

## Question composition

Each stop has four applied-scenario questions, three problem-identification questions, two best-solution questions and one judgment question. Across the course the correct letters are balanced: A = 95, B = 95, C = 95, D = 95. This is deliberate; do not reorder options without rebalancing and rebuilding the browser hashes.

## Remediation ladder

| Score | Action |
|---|---|
| 10/10 | Move on; confirm the practical task. |
| 8–9/10 | Move on; re-read the cited section for any miss and explain it in two sentences. |
| 5–7/10 | Re-teach the two weakest steps; complete a fresh retry variant; re-check with new questions where possible. |
| 0–4/10 | Repeat the stop with instructor support; do not unlock the next stop. |
| Any critical error | Rework regardless of score. |

## Critical errors

A pass on the quiz does not override:

- fabricated research, quotes, participants, metrics or client work;
- personal data in a shared file, or recording without consent;
- an accessibility failure that blocks a core task;
- an unsafe or deceptive design instruction;
- a claim that a test or measurement was performed when it was not.

Record the evidence and the override in the learner file.

## Privacy of keys

- Do not paste keys into a chat tool that learners can access.
- Do not include keys in exported SCORM packages, public repos or screenshots.
- The learner HTML stores only salted SHA-256 hashes, but a hash is not confidentiality against a determined learner who can guess all four options; keep the key files out of the learner bundle.
- If a key leaks, replace the affected questions rather than pretending it did not happen.
- Keep the learner assessment and the key in separate systems where possible.

## Maintenance

When a lesson changes, re-check the matching key and rationale. When a video or source changes, update the lesson and the research register, then recompute the package hashes. After any option edit, re-run `validate.js` and the browser quiz test so the hashes and the key cannot drift apart.
