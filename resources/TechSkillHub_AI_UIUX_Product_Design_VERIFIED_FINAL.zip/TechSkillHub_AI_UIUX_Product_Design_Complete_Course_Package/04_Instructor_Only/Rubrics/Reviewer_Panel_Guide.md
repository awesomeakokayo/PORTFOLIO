# Reviewer Panel Guide

**Instructor and panel use only.** The learner-facing capstone brief is in `03_Assessments/Learner/Capstone.md`. The score sheet is in `Capstone_Rubric.md`.

## Purpose

The panel decides whether a learner can take a product from problem to tested, deployed v2 and explain the work under questioning. It is a professional judgment, not a celebration and not an interrogation.

## Panel composition

Where possible:

- one design practitioner (product, UX or UI);
- one adjacent discipline (engineering, research, product management or accessibility);
- one provider representative.

A panel of two is acceptable for small cohorts, but the provider must document the reason. A single reviewer should not decide a capstone alone unless the provider has an approved exception.

## Before the session

1. Read the learner's submission pack at least 24 hours ahead.
2. Open the live product and try the core task yourself.
3. Check consent documentation and the AI use statement.
4. Score each criterion independently using the rubric.
5. Prepare at least six questions, including one on failure and one on evidence.
6. Declare any conflict of interest: prior employment, family, financial interest, close friendship.

Do not read the learner's case study as the only source. The product and evidence are the primary material.

## Session structure

| Time | Segment |
|---|---|
| 0–2 min | Chair explains process and timings |
| 2–17 min | Learner presents (15 minutes, hard stop) |
| 17–32 min | Panel questions |
| 32–37 min | Learner responds to factual corrections, then leaves |
| 37–50 min | Panel deliberates and records the decision |

Adjust only if the provider has an accessibility agreement with the learner.

## Questions that reveal judgment

Ask about decisions, not definitions:

- "What did you get wrong, and how did you find out?"
- "Why this option rather than the obvious alternative?"
- "What does your evidence actually support, and what does it not?"
- "Which participant surprised you, and what did you change?"
- "What would you cut if you had half the time?"
- "Where did AI help, and where did it mislead you?"
- "How do you know a keyboard user can complete the task?"
- "What would make you abandon this direction?"
- "If you had one more week, what would you test and why?"
- "Which claim in your case study is weakest?"

Follow up on vague answers. "More research" is not a plan. "Five more users from the same group" may not answer the question.

## What strong evidence looks like

- A specific user and task, not a demographic slogan.
- Quotes traceable to notes, with participant codes.
- A decision with a rejected alternative and a trade-off.
- A live product that works on a small screen and by keyboard.
- A test with counts and severity, not adjectives.
- A v2 that addresses a finding.
- A limitation the learner names before the panel does.

## What weak evidence looks like

- "Users loved it" with no count.
- A case study that starts with the final screen.
- Metrics with no denominator or definition.
- A "test" with friends who helped design it.
- An accessibility claim without a keyboard or screen-reader check.
- AI-generated copy with invented statistics.
- A product that only works on the learner's laptop.

## Deliberation

1. Chair confirms there is no conflict.
2. Each reviewer states their independent scores before discussion.
3. Discuss only criteria with a difference of two levels or more.
4. Apply critical failures first.
5. Check the 60% per-criterion floor.
6. Calculate the weighted score.
7. Agree the decision and the resubmission scope.
8. Record dissent if the panel is not unanimous.

Do not average away a critical failure. Do not pass a learner because the presentation was charming. Do not fail a learner because the visual style is not to your taste.

## Decision outcomes

- **Pass:** 80%+ overall, no criterion below 60%, no critical failure.
- **Pass with minor corrections:** the provider may allow a short correction window for documentation only, not for new design work. Record what may be corrected.
- **Rework:** one or more criteria below pass, or a critical failure. Specify the scope.

## Feedback

Give the learner:

- the decision;
- scores by criterion;
- two specific strengths;
- one or two required changes;
- the resubmission scope and date;
- the route to correct a factual error in the review.

Keep it under ten minutes. The learner needs clarity, not a second lecture.

## Appeals and factual errors

A learner may appeal:

- a factual error in the review;
- a procedural breach (conflict not declared, rubric not followed);
- a decision unsupported by the evidence.

They may not appeal "I disagree with the grade" without identifying the error. The provider should have a named person to review appeals who was not on the original panel.

## Records

Keep:

- the submission pack;
- each reviewer's independent score sheet;
- the final rubric;
- the decision and resubmission scope;
- conflict declarations;
- the learner's factual response.

Store consent records separately and securely. Delete recordings at the stated date.

## Calibration

Before the first capstone of a cohort, score one anonymised sample as a panel and compare. If reviewers differ by more than one level, discuss the descriptors and record the calibration. Re-calibrate when the rubric changes.
