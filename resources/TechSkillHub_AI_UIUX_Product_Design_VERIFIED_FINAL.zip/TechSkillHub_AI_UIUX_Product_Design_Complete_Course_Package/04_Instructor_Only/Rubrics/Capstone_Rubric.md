# Capstone Rubric and Score Sheet

**Instructor and panel use only.** Do not distribute to learners. The learner-facing requirements are in `03_Assessments/Learner/Capstone.md`.

## Scoring model

- Six criteria, weighted.
- Each criterion scored 4 (strong), 3 (pass), 2 (not yet), 1 (critical gap).
- Overall weighted score must be **80% or above**.
- No criterion may be below **60%** (a 2 at 50% fails the capstone even if the total passes).
- Any critical failure requires rework regardless of score.

> The 80% / 60% rule is a **proposed TechSkillHub policy** for this package, not an external standard. Confirm it before delivery.

Convert levels: 4 = 100%, 3 = 80%, 2 = 50%, 1 = 0%. Weighted score = Σ(weight × level score).

## Criterion 1 — Problem framing and evidence (20%)

| Level | Descriptor |
|---|---|
| 4 | A specific user, task, barrier and consequence, supported by evidence. Scope and non-scope are clear. The problem is not a solution in disguise. |
| 3 | Clear problem with minor gaps in evidence or scope. |
| 2 | Vague, broad or partly solution-shaped; evidence is thin. |
| 1 | No real problem, or the problem is invented. |

**Look for:** who is affected, what they are trying to do, what blocks them, why it matters, and what is out of scope.

## Criterion 2 — Research and synthesis (15%)

| Level | Descriptor |
|---|---|
| 4 | Ethical, consent-documented research; traceable themes; counter-evidence; rejected themes; limitations stated. |
| 3 | Mostly traceable, consent present, minor gaps in counter-evidence. |
| 2 | Thin sample or overgeneralised themes; consent unclear. |
| 1 | Fabricated, absent or unethical research. |

**Look for:** quotes match notes, counts match participants, synthetic data labelled, no "users want" from five people.

## Criterion 3 — Design and build (20%)

| Level | Descriptor |
|---|---|
| 4 | Live product works end to end; responsive at 320px; accessible by keyboard; states and edge cases covered; code or prototype is explainable. |
| 3 | Works with minor gaps in states or responsiveness. |
| 2 | Partial, fragile, or inaccessible in a core task. |
| 1 | Does not work for the reviewer. |

**Look for:** the core task, an error state, 320px, keyboard, focus, contrast, labels, and an honest known-issues list.

## Criterion 4 — Testing and iteration (20%)

| Level | Descriptor |
|---|---|
| 4 | Five participants, neutral moderation, evidence-linked findings, severity, must-fix first, deployed v2, same-task re-test, limits. |
| 3 | Five participants or a labelled pilot; real v2; minor analysis gaps. |
| 2 | Token testing, cosmetic v2, or no re-test. |
| 1 | No testing or invented results. |

**Look for:** consent, counts not adjectives, a change that addresses a finding, and a before/after that is comparable.

## Criterion 5 — Communication and case study (15%)

| Level | Descriptor |
|---|---|
| 4 | Clear, honest, specific; problem-led; decisions and trade-offs; results with denominators; limitations; strong visuals that carry evidence. |
| 3 | Clear with minor inflation or missing limitation. |
| 2 | Descriptive, screen-led, or overclaims results. |
| 1 | Misleading, fabricated or unreadable. |

**Look for:** the one-line summary, a rejected alternative, one trade-off, and results that match the evidence.

## Criterion 6 — Panel Q&A and judgment (10%)

| Level | Descriptor |
|---|---|
| 4 | Specific, reflective, evidence-led; admits uncertainty; explains AI use and verification; answers the question asked. |
| 3 | Adequate answers with minor deflection. |
| 2 | Vague, defensive or unable to explain key decisions. |
| 1 | Cannot explain the work or misrepresents it. |

**Look for:** "What did you get wrong?", "What does your evidence support?", "Where did AI mislead you?"

## Critical failures

Rework regardless of score:

- fabricated research, participants, quotes, metrics, clients or outcomes;
- recording or publishing without consent;
- exposed personal data;
- accessibility failure blocking a core task;
- live product that does not work for the reviewer;
- AI-generated work presented as unaided, or inability to explain shipped code;
- misleading claim about results or impact.

## Score sheet

| Criterion | Weight | Level (4–1) | Percent | Weighted |
|---|---|---|---|---|
| Problem framing and evidence | 20% | | | |
| Research and synthesis | 15% | | | |
| Design and build | 20% | | | |
| Testing and iteration | 20% | | | |
| Communication and case study | 15% | | | |
| Panel Q&A and judgment | 10% | | | |
| **Total** | **100%** | | | **____%** |

**Decision:** Pass / Rework
**Critical failure:** Yes / No
**Criterion below 60%:** Yes / No
**Resubmission scope:**
**Panel members:**
**Date:**
**Learner response (factual errors only):**

## Panel calibration

Before the first capstone, panels should score one sample together and compare. Disagreements above one level should be discussed against the descriptors, not personal preference. Record the calibration decision.

## Feedback to the learner

Give:

- the decision;
- the score by criterion;
- two strengths with evidence;
- the one or two changes required;
- the resubmission scope and date;
- how to appeal a factual error.

Do not give a list of everything wrong. A capstone review is a decision, not a redesign.
