# Instructor Handbook

**Instructor use only.** This handbook explains how to deliver the course consistently without turning it into a deadline-driven bootcamp or an employment promise.

## 1. What the course is

A self-paced, beginner-friendly course in AI-assisted UI/UX and product design. It has 38 stops across eight phases, seven phase gates and a capstone. Every stop follows the same anatomy:

1. observable outcome;
2. plain-English glossary;
3. why it matters and an everyday example;
4. short teaching steps;
5. a worked example with reasoning;
6. guided practice;
7. independent task;
8. ten-question comprehension check;
9. practical task and pass criteria;
10. common mistakes and a retry variant;
11. proof artifact;
12. low-data path;
13. curated resources and one verified video recommendation.

The course does not promise a job, a salary or a client. It promises practice, feedback and evidence. Say that plainly.

## 2. Delivery model

- **Self-paced.** There are no weeks or deadlines in the learner content. Suggested session times are guidance, not requirements.
- **Mastery first.** A learner moves on when they meet the outcome, not when the calendar says so.
- **Small cohorts.** Human feedback at gates is the constraint. Do not accept more learners than you can review.
- **Low-resource by default.** Every stop has a low-data path. Do not require paid tools, a fast connection or a new device.
- **Practice over lecture.** If a session is mostly slides, it is not this course.

## 3. Mastery and gates

- Default target: 80%.
- Stop checks have ten questions; 8/10 is the pass mark. 7/10 is 70% and must be retried.
- The browser check is a self-check only. It is not saved to a TechSkillHub account and is not sent anywhere; record scores yourself if you need a record.
- Gates require every criterion met, not an average.
- Critical failures override the score: fabrication, privacy, accessibility blockers, unsafe design, false claims.
- One resubmission without penalty; a second requires a conversation.
- Record the original attempt and the resubmission decision.

Do not "curve" a gate. If the evidence is missing, the answer is "not yet".

## 4. Feedback that works

Every "not yet" should contain four things:

1. the criterion;
2. the evidence you saw;
3. what specifically must change;
4. the resubmission scope.

Weak: "Needs more depth."
Strong: "The findings table has no participant counts, so I cannot tell whether the fee issue affected one person or four. Add counts and evidence for each finding, then resubmit only the table and the summary paragraph."

Give feedback within five working days where possible. Feedback that arrives after the learner has moved on is administrative, not educational.

## 5. AI use policy

The course teaches AI as a directed assistant. The instructor's role is to check judgment, not to police tool use.

Expect learners to:

- disclose tools and stages in the AI use statement;
- keep a prompt and decision log for substantial work;
- verify factual claims against sources or raw notes;
- explain any code or design decision they ship;
- avoid uploading personal or confidential data to unapproved tools.

Treat these as gate criteria:

- presenting AI output as unaided work;
- inability to explain a shipped decision;
- a fabricated claim that survives review.

Do not ban AI outright. A ban is unenforceable and teaches the wrong lesson. Do not accept "the AI said so" as evidence either.

## 6. Privacy, consent and safeguarding

- Consent is required before recording. Record the purpose, access and deletion date.
- Anonymise participant names in notes. Use P1, P2.
- Do not store raw recordings longer than consent allows.
- Do not publish a participant's face or voice without a separate release.
- If a learner discloses a safeguarding concern, follow your organisation's policy and do not investigate alone.
- If a learner is under 18, require guardian consent and provider approval before research or recording.
- Do not ask learners to upload identity documents, bank details or client contracts.

## 7. Accessibility

- Make all materials available as text, not only video.
- Caption or transcribe your own sessions.
- Accept alternative evidence: audio notes, phone photos, hand-drawn wireframes, a live walkthrough.
- Do not require a specific tool. Figma is taught, but an equivalent file plus screenshots can meet the outcome.
- Check your own review process: can a learner with a disability complete every task?
- Treat accessibility failures in learner work as critical when they block a core task, not as a cosmetic deduction.

## 8. Regional and cultural context

The course uses Nigerian and wider African examples where relevant, without assuming every learner is in one country.

- Currency examples use naira and state that they are fictional.
- Do not assume constant electricity, unlimited data, a bank account, a smartphone model or a particular family structure.
- Do not treat "African user" as a single category. Ask about context: language, connectivity, device, income, trust, locality.
- Accept local payment methods and low-bandwidth evidence.
- Avoid examples that require a credit card, a formal address or a particular ID.

## 9. Running a gate review

1. Read the learner's evidence before the meeting.
2. Mark independently against the rubric.
3. Check critical failures first.
4. Write one sentence of evidence per criterion.
5. Meet for 15–20 minutes: strengths, gaps, decision.
6. Record the decision and the resubmission scope.

Do not review live for the first time in the meeting. Do not let a learner negotiate a criterion without new evidence.

## 10. Running the capstone panel

- Three reviewers where possible: design, adjacent discipline, provider.
- Declare conflicts of interest.
- Score independently, then discuss.
- Ask at least six questions, including one about failure and one about evidence.
- Keep the presentation to 15 minutes and questions to 15.
- Record the decision with the rubric.
- Give the learner a chance to correct factual errors.

The reviewer guide is in `Reviewer_Panel_Guide.md`; the rubric is in `Capstone_Rubric.md`.

## 11. Common learner problems

| Pattern | Likely cause | Response |
|---|---|---|
| Beautiful screens, no evidence | Portfolio culture, not research habit | Require a traceable finding before the next gate. |
| "Users want..." from five people | Overgeneralisation | Ask for counts and rewrite the claim. |
| AI output accepted without review | Trust in fluency | Ask the learner to explain one rejected output. |
| Scope too large | Ambition | Cut to one core task and one failure state. |
| No testing | Recruitment anxiety | Offer a three-person pilot and label it. |
| Accessibility as a checklist | Taught as compliance | Require a keyboard walkthrough and one real fix. |
| Plagiarised case study | Time pressure | Apply the integrity policy; require a new project. |
| Cannot explain code | Copy-paste | Require removal or explanation before the gate. |

## 12. Record keeping

For each learner, keep:

- gate submissions and evidence links;
- rubric with criterion marks and evidence;
- score and decision;
- critical-failure record, if any;
- resubmission scope and date;
- consent records (stored separately and securely).

Retention should follow your organisation's policy and the consent given. Delete raw recordings on the stated date. Do not keep personal data "just in case".

## 13. What not to do

- Do not add deadlines to learner-facing files.
- Do not promise employment, income or clients.
- Do not present fictional data as real.
- Do not share answer keys or rubrics with learners.
- Do not require a paid tool to pass.
- Do not approve a gate you have not reviewed.
- Do not let AI approve a capstone.

## 14. Improving the course

Collect:

- which stops learners fail most;
- which criteria produce the most resubmissions;
- which resources are unavailable in low-data settings;
- which videos fail to embed or disappear;
- learner feedback on clarity and workload.

Review the package at least annually. Re-check every URL and video, because links rot. Update the verification log and re-compute the audit hashes after any change.
