# Stop Rubric — 1.4: Competitive and Market Review

**Instructor use only. Do not distribute to learners.**
**Phase:** 1 · Product thinking and research
**Prerequisites:** Stop 1.3
**Suggested time:** 80-110 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the eight-part competitive review.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — Three products including at least one direct and one indirect/substitute.

**Evidence type:** sampling products

**Required evidence (the Level 3 standard):** Three products include at least one direct and one indirect or substitute competitor. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Three products include a direct and an indirect or substitute competitor, and the learner explains why the substitute belongs in the set. |
| **3 — Competent / pass** | Three products include at least one direct and one indirect or substitute competitor. |
| **2 — Developing** | Three products are listed, but all are direct competitors, so substitute behaviour is not examined. |
| **1 — Not yet competent** | Fewer than three products are listed, or no competitor rationale is given. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — One precisely defined task and starting state.

**Evidence type:** test control

**Required evidence (the Level 3 standard):** One task and one starting state are defined precisely, and the same task is used across products. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The task and starting state are defined precisely enough that two reviewers would run the same test, and the learner notes what was held constant. |
| **3 — Competent / pass** | One task and one starting state are defined precisely, and the same task is used across products. |
| **2 — Developing** | The task is vague or differs between products, so differences cannot be attributed to design. |
| **1 — Not yet competent** | No task or starting state is defined; the comparison is impressionistic. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — Five heuristic scores per product, each with evidence.

**Evidence type:** evidence scores

**Required evidence (the Level 3 standard):** Five heuristic scores per product are present, each with evidence from the interface. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Every heuristic score cites a specific observation, and the learner distinguishes a violation from a personal preference. |
| **3 — Competent / pass** | Five heuristic scores per product are present, each with evidence from the interface. |
| **2 — Developing** | Scores are present, but some have no evidence or the evidence is a general impression. |
| **1 — Not yet competent** | Scores are absent or unsupported, so the review cannot be audited. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — A Limits note naming what could not be tested.

**Evidence type:** limitations

**Required evidence (the Level 3 standard):** A Limits note names at least one thing that could not be tested. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The Limits note names what could not be tested, why, and how that limits the conclusion, plus one thing that would change the recommendation. |
| **3 — Competent / pass** | A Limits note names at least one thing that could not be tested. |
| **2 — Developing** | Limitations are generic, such as "time was short", and do not say what could not be tested. |
| **1 — Not yet competent** | No limitations are acknowledged; the review overclaims certainty. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] An 8–12 row pattern matrix with "not tested" where applicable.
- [ ] A dated evidence log with screenshot references.
- [ ] Three filtered opportunity statements.
- [ ] A direction statement separating parity, differentiation and rejection.
- [ ] No copied logos, illustrations or proprietary content; no real payments.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A competitive review with three products, a pattern matrix, a gap analysis and a dated evidence log.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Reviewing only famous global apps | Include a local substitute and a product people actually use. |
| Turning the review into a feature list | Audit the same task and record behaviour. |
| Copying the market leader | Separate parity from differentiation; justify each choice. |
| No evidence dates | Log date, version and file name. |
| Calling every difference a gap | Require a user consequence and evidence. |
| Testing with real money | Stop at confirmation; record the limit. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Review **three products for a different job**: booking a bus or ride from a phone. Include one product that works mainly by WhatsApp or phone call. Produce the same eight parts, but add a "market context" paragraph (100 words) on device, data, payment and trust conditions that change what "good" means. Submit the new review plus a corrected version of one heuristic score from your first attempt, with the missing evidence supplied.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. Three products including at least one direct and one indirect/substitute. |  |  |  |
| 2. One precisely defined task and starting state. |  |  |  |
| 3. Five heuristic scores per product, each with evidence. |  |  |  |
| 4. A Limits note naming what could not be tested. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
