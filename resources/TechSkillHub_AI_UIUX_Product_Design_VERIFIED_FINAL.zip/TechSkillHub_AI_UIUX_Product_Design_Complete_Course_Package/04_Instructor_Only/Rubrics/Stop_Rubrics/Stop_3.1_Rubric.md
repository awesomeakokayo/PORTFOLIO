# Stop Rubric — 3.1: Figma Essentials

**Instructor use only. Do not distribute to learners.**
**Phase:** 3 · Figma fluency and design systems
**Prerequisites:** Phase 2 gate passed
**Suggested time:** 70-90 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the file link (view access) and the one-page file guide PDF.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — Five pages with a clear purpose.

**Evidence type:** file structure

**Required evidence (the Level 3 standard):** Five pages exist, each with a clear purpose and name. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Five pages have clear purposes, and the learner explains the navigation model so a collaborator can find current work in seconds. |
| **3 — Competent / pass** | Five pages exist, each with a clear purpose and name. |
| **2 — Developing** | Pages exist, but their purposes overlap or their names are unclear. |
| **1 — Not yet competent** | One undifferentiated page is used, or there is no page structure. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — A cover frame with project, name, date and description.

**Evidence type:** cover metadata

**Required evidence (the Level 3 standard):** A cover frame states project, name, date and description. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The cover frame states project, designer, date and description, and the learner keeps it current as the file changes. |
| **3 — Competent / pass** | A cover frame states project, name, date and description. |
| **2 — Developing** | The cover is missing one required field or contains stale information. |
| **1 — Not yet competent** | No cover frame is present. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — No unnamed frames or groups on the main design page.

**Evidence type:** figma naming

**Required evidence (the Level 3 standard):** No unnamed frames or groups remain on the main design page. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | No unnamed frames or groups remain on the main design page, and the learner shows the layer panel to prove it. |
| **3 — Competent / pass** | No unnamed frames or groups remain on the main design page. |
| **2 — Developing** | A few unnamed layers remain, but the main screens are identifiable. |
| **1 — Not yet competent** | Many unnamed layers remain; the file is hard to navigate. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — A file guide and shortcut sheet.

**Evidence type:** file guide

**Required evidence (the Level 3 standard):** A file guide and shortcut sheet are present and accurate. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | A file guide and shortcut sheet are present, accurate for the learner's platform, and short enough to use during work. |
| **3 — Competent / pass** | A file guide and shortcut sheet are present and accurate. |
| **2 — Developing** | One of the two is missing, or the shortcuts are wrong for the platform. |
| **1 — Not yet competent** | Neither the file guide nor the shortcut sheet is present. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] Three named sections.
- [ ] Six numbered frames in flow order.
- [ ] Five text and five colour styles applied.
- [ ] Two components with instances.
- [ ] A named version in history.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** An organised Figma starter file with named pages, a frame library, text and colour styles, and a shortcut sheet.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Every screen on one page | Split by workstream; use sections within a page. |
| `Frame 42` names | Rename on creation; use `area_element`. |
| Manual colours everywhere | Apply styles; fix one value later. |
| Detaching components to change one thing | Use overrides or a variant. |
| Huge screenshots pasted in | Crop and compress; place only what is needed. |
| Public edit links | Use view/comment links. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Take a messy file (your own or a practice file you deliberately mess up), clean it, and record a five-minute screen recording or a ten-step written log of every rename, style and component decision. Submit the cleaned file link and the log. The log must explain one decision you reversed.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. Five pages with a clear purpose. |  |  |  |
| 2. A cover frame with project, name, date and description. |  |  |  |
| 3. No unnamed frames or groups on the main design page. |  |  |  |
| 4. A file guide and shortcut sheet. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
