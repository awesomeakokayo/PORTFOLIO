# Stop Rubric — 6.1: Usability Testing

**Instructor use only. Do not distribute to learners.**
**Phase:** 6 · Testing, metrics and iteration
**Prerequisites:** Phase 5 gate passed; a deployed prototype
**Suggested time:** 90-120 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the complete test pack and summary.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — Consent obtained and documented before each session.

**Evidence type:** consent

**Required evidence (the Level 3 standard):** Consent is obtained and documented before each session. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Consent is documented before each session, and the learner explains how it was obtained, recorded and how a participant could withdraw it. |
| **3 — Competent / pass** | Consent is obtained and documented before each session. |
| **2 — Developing** | Consent is obtained but not documented, or it is documented after the session. |
| **1 — Not yet competent** | No consent is obtained. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — 3–5 realistic tasks that do not name interface controls.

**Evidence type:** task quality

**Required evidence (the Level 3 standard):** 3–5 realistic tasks are present and do not name interface controls. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | 3–5 realistic tasks state a goal and context without naming controls, and the learner explains why each task is realistic for the product. |
| **3 — Competent / pass** | 3–5 realistic tasks are present and do not name interface controls. |
| **2 — Developing** | There are too few tasks, or one task names a control, such as "click Settings". |
| **1 — Not yet competent** | The tasks are instructions or leading questions rather than goals. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — Notes separate observation from interpretation.

**Evidence type:** observation separation test

**Required evidence (the Level 3 standard):** Notes separate observation from interpretation. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Notes separate observation from interpretation for every task, and the learner quotes the observation that supports each interpretation. |
| **3 — Competent / pass** | Notes separate observation from interpretation. |
| **2 — Developing** | Some interpretations appear in the observation column. |
| **1 — Not yet competent** | The notes are opinion only. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — No participant's name, face or identifying detail appears without permission.

**Evidence type:** privacy participant

**Required evidence (the Level 3 standard):** No participant's name, face or identifying detail appears without permission. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | No participant's name, face or identifying detail appears without permission, and the learner explains the anonymisation method used. |
| **3 — Competent / pass** | No participant's name, face or identifying detail appears without permission. |
| **2 — Developing** | An identifying detail remains, but it is minor and can be removed. |
| **1 — Not yet competent** | A participant is identifiable without permission. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] A one-sentence research question and a one-page plan.
- [ ] Five sessions (or three, clearly labelled as a pilot).
- [ ] Findings table includes participants, evidence, severity and recommendation.
- [ ] Summary reports what worked, what failed and limitations.
- [ ] Storage and deletion plan stated.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A test pack: plan, consent script, task list, session notes for five participants, a findings table with severity and evidence, and a short summary.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Leading the participant | Use neutral probes and wait five seconds. |
| Tasks that name buttons | State the goal and context only. |
| Testing only friends who know the design | Recruit people outside the project. |
| Recording without consent | Get explicit, written permission. |
| Reporting opinions as findings | Require an observation for every finding. |
| Claiming "users want" from five people | Say "3 of 5 participants". |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Run a **three-participant pilot** on a different flow with a stricter constraint: you may not speak at all during tasks except to read the task and ask one probe. Submit the notes and a reflection on what the silence revealed. The constraint targets the most common moderation failure.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. Consent obtained and documented before each session. |  |  |  |
| 2. 3–5 realistic tasks that do not name interface controls. |  |  |  |
| 3. Notes separate observation from interpretation. |  |  |  |
| 4. No participant's name, face or identifying detail appears without permission. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
