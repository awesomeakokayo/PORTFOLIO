# Stop Rubric — 6.3: Iteration

**Instructor use only. Do not distribute to learners.**
**Phase:** 6 · Testing, metrics and iteration
**Prerequisites:** Stops 6.1 and 6.2 passed
**Suggested time:** 80-100 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the v2 plan, implemented changes, re-test table and change log.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — Findings are normalised with evidence and frequency.

**Evidence type:** findings normalised

**Required evidence (the Level 3 standard):** Findings are normalised with evidence and frequency. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Findings are normalised with evidence and frequency, and duplicates are merged without losing the count. |
| **3 — Competent / pass** | Findings are normalised with evidence and frequency. |
| **2 — Developing** | Findings are listed but not normalised, or the frequency is missing. |
| **1 — Not yet competent** | Findings are a raw dump. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — Must-fix items are identified separately from scored items.

**Evidence type:** prioritisation

**Required evidence (the Level 3 standard):** Must-fix items are identified separately from scored items. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Must-fix items are separated from scored items, and the learner explains the severity threshold used. |
| **3 — Competent / pass** | Must-fix items are identified separately from scored items. |
| **2 — Developing** | Must-fix and scored items are mixed, or the separation is unclear. |
| **1 — Not yet competent** | No prioritisation is done; everything is treated equally. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — At least five items are scored with defined scales.

**Evidence type:** scoring

**Required evidence (the Level 3 standard):** At least five items are scored with defined scales. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | At least five items are scored with defined scales, and the learner explains what each scale point means. |
| **3 — Competent / pass** | At least five items are scored with defined scales. |
| **2 — Developing** | Fewer than five items are scored, or the scales are undefined. |
| **1 — Not yet competent** | No scoring is done. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — An A/B hypothesis is complete, or its absence is justified.

**Evidence type:** hypothesis

**Required evidence (the Level 3 standard):** An A/B hypothesis is complete, or its absence is justified. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The A/B hypothesis is complete (change, audience, metric, expected effect, guardrail), or its absence is justified with a reason. |
| **3 — Competent / pass** | An A/B hypothesis is complete, or its absence is justified. |
| **2 — Developing** | The hypothesis lacks a metric, guardrail or expected effect. |
| **1 — Not yet competent** | No hypothesis and no justification are provided. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] Three change entries include problem, change, reason, expected effect, risk and check.
- [ ] v2 changes are implemented or prototyped in enough detail to test.
- [ ] Before/after re-test results are reported with the same tasks.
- [ ] Change log has at least three entries, including a revert or revision.
- [ ] No unsupported claim of causation from a small sample.
- [ ] No live experiment on real users without approval.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A v2 plan with a prioritised backlog, rationale for each change, one written A/B hypothesis, a change log and a re-test plan.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Fixing the easiest thing | Score impact and confidence first. |
| Treating every comment as a requirement | Require evidence and frequency. |
| Bundling changes | Change one thing, check, then next. |
| A/B testing everything | Use qualitative tests when volume is low. |
| No decision rule | Define ship/iterate/stop before the test. |
| Ignoring guardrails | Protect against harm explicitly. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Take three findings and write **only** the must-fix decision and one change entry, with no scoring. Then write a 100-word argument for why scoring the other two would be premature. This tests judgment about when process helps and when it becomes theatre.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. Findings are normalised with evidence and frequency. |  |  |  |
| 2. Must-fix items are identified separately from scored items. |  |  |  |
| 3. At least five items are scored with defined scales. |  |  |  |
| 4. An A/B hypothesis is complete, or its absence is justified. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
