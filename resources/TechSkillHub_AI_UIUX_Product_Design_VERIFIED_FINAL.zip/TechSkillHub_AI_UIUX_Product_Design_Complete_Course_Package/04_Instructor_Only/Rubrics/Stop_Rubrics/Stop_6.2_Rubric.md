# Stop Rubric — 6.2: Product Metrics

**Instructor use only. Do not distribute to learners.**
**Phase:** 6 · Testing, metrics and iteration
**Prerequisites:** Stop 6.1 passed
**Suggested time:** 75-95 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the metric pack and interpretation page.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — Four metrics have explicit formulas.

**Evidence type:** metric formula

**Required evidence (the Level 3 standard):** Four metrics have explicit formulas. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Four metrics have explicit formulas with numerator, denominator and time window, and the learner explains one edge case. |
| **3 — Competent / pass** | Four metrics have explicit formulas. |
| **2 — Developing** | Fewer than four metrics are defined, or a formula omits the denominator or time window. |
| **1 — Not yet competent** | Metrics are named without formulas. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — Funnel has at least five steps with counts and conversion rates.

**Evidence type:** funnel

**Required evidence (the Level 3 standard):** The funnel has at least five steps with counts and conversion rates. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The funnel has at least five steps with counts and rates, and the learner identifies the largest drop and a hypothesis for it. |
| **3 — Competent / pass** | The funnel has at least five steps with counts and conversion rates. |
| **2 — Developing** | Fewer than five steps are present, or the counts and rates are missing. |
| **1 — Not yet competent** | No funnel is provided; drop-off is asserted. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — Cohort table has at least three cohorts.

**Evidence type:** cohort

**Required evidence (the Level 3 standard):** A cohort table has at least three cohorts. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The cohort table has at least three cohorts, and the learner compares retention across them with a stated limitation. |
| **3 — Competent / pass** | A cohort table has at least three cohorts. |
| **2 — Developing** | Fewer than three cohorts are present, or the table lacks a time dimension. |
| **1 — Not yet competent** | No cohort analysis is done. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — Interpretation separates measurement, observation, interpretation and limits.

**Evidence type:** interpretation layers

**Required evidence (the Level 3 standard):** Interpretation separates measurement, observation, interpretation and limits. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Interpretation separates measurement, observation, interpretation and limits, and the learner shows how the conclusion would change if one layer were wrong. |
| **3 — Competent / pass** | Interpretation separates measurement, observation, interpretation and limits. |
| **2 — Developing** | Two or more layers are merged, usually observation and interpretation. |
| **1 — Not yet competent** | The conclusion is stated as fact with no separation or limits. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] User job stated in one sentence.
- [ ] Activation event defined with a window.
- [ ] One primary metric and two guardrails are chosen for a proposed change.
- [ ] At least three limitations are stated.
- [ ] All data is labelled fictional or clearly sourced and aggregated.
- [ ] No real user-level data is included.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A metric definition sheet with formulas, a fictional funnel with drop-off, and a one-page interpretation that separates what the data shows from what it does not.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| "Engagement" with no definition | Define the event, window and population. |
| Sign-up counted as activation | Define first real value. |
| Funnel treated as explanation | Pair it with qualitative evidence. |
| Averages hiding cohort change | Break out cohorts. |
| No guardrails | Add two harm metrics. |
| Tiny samples with big claims | Report counts and uncertainty. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Take a different product — a public library booking system — and define only three metrics: activation, task success and one guardrail. Write a one-page memo explaining why those three and not others. The constraint tests whether you can choose metrics rather than list them.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. Four metrics have explicit formulas. |  |  |  |
| 2. Funnel has at least five steps with counts and conversion rates. |  |  |  |
| 3. Cohort table has at least three cohorts. |  |  |  |
| 4. Interpretation separates measurement, observation, interpretation and limits. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
