# Stop Rubric — 0.3: Seeing Like a Designer

**Instructor use only. Do not distribute to learners.**
**Phase:** 0 · Getting started
**Prerequisites:** Stop 0.1, Stop 0.2
**Suggested time:** 50-70 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the three-screen teardown described in section 8, as a PDF or a shared document.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — Three different real screens from three different apps (or three clearly different flows).

**Evidence type:** sampling screens

**Required evidence (the Level 3 standard):** Three different real screens from three different apps or clearly different flows are included. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Three screens come from three distinct apps or flows, and the learner notes why each was chosen and what it does differently. |
| **3 — Competent / pass** | Three different real screens from three different apps or clearly different flows are included. |
| **2 — Developing** | Three screens are included, but two are variants of the same flow, so coverage is narrower than claimed. |
| **1 — Not yet competent** | Fewer than three screens, invented screens, or three near-identical copies are submitted. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — At least 20 labelled parts in total, with terms used correctly.

**Evidence type:** terminology

**Required evidence (the Level 3 standard):** At least 20 parts are labelled and the terms are correct; no label points to the wrong element. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | At least 20 parts are labelled, every term is used correctly, and ambiguous cases such as chip versus button are explained. |
| **3 — Competent / pass** | At least 20 parts are labelled and the terms are correct; no label points to the wrong element. |
| **2 — Developing** | Fewer than 20 labels are present, or several terms are misapplied, such as calling the system status bar an app component. |
| **1 — Not yet competent** | Labels are missing, mostly incorrect or attached to the wrong parts, so the annotation cannot teach the vocabulary. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — Every screen has one concrete improvement tied to a named part.

**Evidence type:** critique link

**Required evidence (the Level 3 standard):** Every screen has one concrete improvement tied to a named part, not a generic "make it cleaner". The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Each improvement names the part, the user consequence and a check that would show whether the change worked. |
| **3 — Competent / pass** | Every screen has one concrete improvement tied to a named part, not a generic "make it cleaner". |
| **2 — Developing** | Some improvements are generic or not tied to a named part, so the critique could apply to any screen. |
| **1 — Not yet competent** | No specific improvement is given, or the improvement contradicts the labelled evidence. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — Private data is removed or blurred.

**Evidence type:** privacy visual

**Required evidence (the Level 3 standard):** No private data is visible; removal or blurring is applied consistently. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Private data is removed or blurred in every screen, and the learner confirms the method (crop, blur or fictional data) and checks that no text remains readable. |
| **3 — Competent / pass** | No private data is visible; removal or blurring is applied consistently. |
| **2 — Developing** | Private data is mostly removed, but a name, balance, number or avatar remains readable in at least one place. |
| **1 — Not yet competent** | Real personal or client data is visible, or blurring is claimed but the underlying text is still readable. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] Every screen has the "wants the user to…" sentence with evidence.
- [ ] The missing-state note identifies at least one absent state and what it would need.
- [ ] The comparison names the clearest primary action and uses at least four glossary terms.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A three-screen annotated teardown with at least 20 correctly named interface parts and a short note on what each screen wants the user to do.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Labelling everything "button" | Use the primary/secondary/tertiary distinction and name the container. |
| Writing opinions with no evidence | Every claim must point to a named part, spacing, weight or wording. |
| Leaving account numbers visible | Crop or blur before saving; never upload raw banking screenshots. |
| Annotating 30 parts per screen | Choose the 7–12 parts that explain the screen's job. |
| Confusing placeholder with label | Ask: does the text disappear when I type? Then it is a placeholder. |
| Describing colour first | Read system → structure → content → action first. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Do the teardown again with **three different screens from the same app**: its onboarding, its empty state, and its error state. Label at least 18 parts and write a paragraph on how the same product changes its visual language across those three moments. Submit the new teardown plus a corrected version of your original legend, with any misused terms fixed and explained.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. Three different real screens from three different apps (or three clearly different flows). |  |  |  |
| 2. At least 20 labelled parts in total, with terms used correctly. |  |  |  |
| 3. Every screen has one concrete improvement tied to a named part. |  |  |  |
| 4. Private data is removed or blurred. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
