# Stop Rubric — 5.4: Responsive, Mobile-First and Low-Bandwidth Design

**Instructor use only. Do not distribute to learners.**
**Phase:** 5 · Design to build
**Prerequisites:** Stop 5.2 passed; a working page to adapt
**Suggested time:** 90-120 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the responsive, low-bandwidth page with before/after measurements and a trade-off note.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — No horizontal scrolling at 320px; primary action is reachable.

**Evidence type:** responsive 320

**Required evidence (the Level 3 standard):** The page works at 320 px width without horizontal scrolling. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The page works at 320 px without horizontal scrolling, and the learner shows the primary action and a long word wrapping correctly. |
| **3 — Competent / pass** | The page works at 320 px width without horizontal scrolling. |
| **2 — Developing** | Minor horizontal overflow or a clipped primary action appears at 320 px. |
| **1 — Not yet competent** | The page requires horizontal scrolling or hides the primary action on mobile. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — At least one image uses `srcset`/`sizes` or is correctly compressed for display size.

**Evidence type:** image performance

**Required evidence (the Level 3 standard):** At least one image uses srcset or sizes, or is correctly compressed for its display size. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | At least one image uses srcset or sizes, or is compressed to display size, and the learner shows the bytes saved. |
| **3 — Competent / pass** | At least one image uses srcset or sizes, or is correctly compressed for its display size. |
| **2 — Developing** | Images are compressed inconsistently, or a large image is served at a small size. |
| **1 — Not yet competent** | Full-resolution images are served everywhere. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — Total page weight is at or below 500 KB, or the overage is explained with a plan.

**Evidence type:** page weight

**Required evidence (the Level 3 standard):** Total page weight is at or below 500 KB, or the overage is explained with a plan. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Total page weight is at or below 500 KB, or the overage is explained with a measured plan, and the learner records the measurement. |
| **3 — Competent / pass** | Total page weight is at or below 500 KB, or the overage is explained with a plan. |
| **2 — Developing** | Weight exceeds 500 KB without a plan, or the measurement is missing. |
| **1 — Not yet competent** | The page is multiple megabytes with no consideration of weight. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — Loading, offline and error behaviour are described and at least one is implemented.

**Evidence type:** failure states web

**Required evidence (the Level 3 standard):** Loading, offline and error behaviour are described, and at least one is implemented. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Loading, offline and error behaviour are described, at least one is implemented, and the learner tests it with the network disabled. |
| **3 — Competent / pass** | Loading, offline and error behaviour are described, and at least one is implemented. |
| **2 — Developing** | The behaviour is described, but none is implemented, or only the loading state exists. |
| **1 — Not yet competent** | No failure behaviour is provided; the page shows a blank screen or a false success. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] Layout remains usable at 200% zoom.
- [ ] All images have dimensions and appropriate `alt`.
- [ ] LCP on Slow 4G is 2.5 s or less, or the miss is measured and explained.
- [ ] CLS is 0.1 or less.
- [ ] Before/after table includes weight, requests, LCP, CLS and INP.
- [ ] The note states what was removed, what was kept and what could not be tested.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A responsive, low-bandwidth version of the page with a before/after performance table, screenshots at 320px and 1280px, and a note on offline and error behaviour.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Designing desktop-first and squeezing | Start at 320px and enhance. |
| Fixed widths | Use `max-width`, percentages and `min()`/`clamp()`. |
| Too many breakpoints | Add queries only where content breaks. |
| Uncompressed photos | Compress to display size; use WebP. |
| Lazy-loading the hero | Load the LCP image eagerly. |
| Third-party bloat | Question each script; use a facade or remove it. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Take a different page — a simple article page with one image — and hit the same budget of 300 KB and LCP 2 s. Because there is less to remove, you must focus on image strategy, font loading and critical CSS. Submit the measurements and a 100-word explanation of the hardest trade-off.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. No horizontal scrolling at 320px; primary action is reachable. |  |  |  |
| 2. At least one image uses `srcset`/`sizes` or is correctly compressed for display size. |  |  |  |
| 3. Total page weight is at or below 500 KB, or the overage is explained with a plan. |  |  |  |
| 4. Loading, offline and error behaviour are described and at least one is implemented. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
