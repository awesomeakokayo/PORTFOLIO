# Stop Rubric — 3.3: Components, Variants and Variables

**Instructor use only. Do not distribute to learners.**
**Phase:** 3 · Figma fluency and design systems
**Prerequisites:** Stop 3.2
**Suggested time:** 90-120 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the component set, variables, modes, naming index and documentation.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — At least 12 variants, or a documented reduction with a reason.

**Evidence type:** variants

**Required evidence (the Level 3 standard):** At least twelve variants exist, or a documented reduction gives a reason. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | At least twelve variants exist, or a documented reduction explains why fewer are sufficient, and the properties are named. |
| **3 — Competent / pass** | At least twelve variants exist, or a documented reduction gives a reason. |
| **2 — Developing** | Variants exist, but they are duplicated components rather than properties, or the reduction is undocumented. |
| **1 — Not yet competent** | No meaningful variants exist; every state is a separate detached copy. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — 15+ primitives and 10+ semantic aliases.

**Evidence type:** tokens

**Required evidence (the Level 3 standard):** At least the required primitive and semantic token counts are defined. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The stated primitive and semantic token counts are met, and the learner explains the naming logic that separates raw values from purpose. |
| **3 — Competent / pass** | At least the required primitive and semantic token counts are defined. |
| **2 — Developing** | The token counts fall short, or primitives and semantics are mixed without a naming rule. |
| **1 — Not yet competent** | No token structure exists; values are hard-coded. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — Semantic variables applied to components, not raw hex values.

**Evidence type:** token application

**Required evidence (the Level 3 standard):** Semantic variables are applied to components; no raw hex remains in the checked components. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Components reference semantic variables rather than raw hex, and the learner shows a value change propagating without editing components. |
| **3 — Competent / pass** | Semantic variables are applied to components; no raw hex remains in the checked components. |
| **2 — Developing** | Some components still use raw hex or detached overrides. |
| **1 — Not yet competent** | Components are hard-coded, so the system cannot update centrally. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — Light and dark modes with three recorded contrast checks.

**Evidence type:** theming contrast

**Required evidence (the Level 3 standard):** Light and dark modes exist with three recorded contrast checks. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Light and dark modes both work, three contrast checks are recorded for each mode, and the learner notes any token that needed a different value. |
| **3 — Competent / pass** | Light and dark modes exist with three recorded contrast checks. |
| **2 — Developing** | Modes exist, but contrast is unchecked, or one mode fails a check. |
| **1 — Not yet competent** | Only one mode exists, or dark mode is a simple inversion that fails contrast. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] Text, boolean and instance-swap properties used.
- [ ] Component structure consistent across variants.
- [ ] Naming index and component doc complete.
- [ ] The trade-off note is specific.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A button component set (3 variants × 4 states × 2 sizes) using variables, plus a one-page explanation of properties and naming.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| 30 variants built before use | Build what the flow needs; expand later. |
| Detaching to change one thing | Use a property or an override. |
| Raw hex in components | Apply semantic variables. |
| Different layer structures per variant | Rebuild from one structure; hide, don't remove. |
| Appearance-based names | Name by role; keep an index. |
| Dark mode by inversion | Set explicit dark values and re-check contrast. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Build a **text field component set** with states default, focus, error, disabled and read-only, plus a boolean for helper text and a text property for the label. Add variables for border, surface and text. Submit the set, a light/dark comparison and a 120-word note on which state was hardest to model and why.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. At least 12 variants, or a documented reduction with a reason. |  |  |  |
| 2. 15+ primitives and 10+ semantic aliases. |  |  |  |
| 3. Semantic variables applied to components, not raw hex values. |  |  |  |
| 4. Light and dark modes with three recorded contrast checks. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
