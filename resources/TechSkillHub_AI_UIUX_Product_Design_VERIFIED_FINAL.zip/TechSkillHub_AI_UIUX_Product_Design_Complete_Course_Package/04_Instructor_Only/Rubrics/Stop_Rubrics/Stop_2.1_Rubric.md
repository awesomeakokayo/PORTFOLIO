# Stop Rubric — 2.1: Layout, Grid, Spacing and Hierarchy

**Instructor use only. Do not distribute to learners.**
**Phase:** 2 · Visual and interaction foundations
**Prerequisites:** Phase 1 gate passed
**Suggested time:** 60-80 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the before/after layout, annotations, change list, 150-word explanation and five-second test notes.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — Before and after versions of the same screen.

**Evidence type:** comparison

**Required evidence (the Level 3 standard):** Before and after versions of the same screen are present and comparable. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Before and after show the same screen and content, and the learner annotates which change produced which effect. |
| **3 — Competent / pass** | Before and after versions of the same screen are present and comparable. |
| **2 — Developing** | The versions differ in content or screen, so the comparison is not controlled. |
| **1 — Not yet competent** | No before/after pair is present, or the "after" is a different screen. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — A visible grid with consistent margins and gutters.

**Evidence type:** layout grid

**Required evidence (the Level 3 standard):** A visible grid with consistent margins and gutters underlies the screen. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The grid is visible with consistent margins and gutters, and the learner shows how it holds at a second width. |
| **3 — Competent / pass** | A visible grid with consistent margins and gutters underlies the screen. |
| **2 — Developing** | A grid is claimed, but margins or gutters vary, or the grid is not visible in the file. |
| **1 — Not yet competent** | No grid is used; elements are placed by eye with inconsistent spacing. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — A stated intended reading order that matches the design.

**Evidence type:** hierarchy

**Required evidence (the Level 3 standard):** A stated intended reading order is present and matches the design's emphasis. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The stated reading order matches the visual hierarchy, and the learner shows the eye path through size, weight, spacing and contrast decisions. |
| **3 — Competent / pass** | A stated intended reading order is present and matches the design's emphasis. |
| **2 — Developing** | A reading order is stated, but the design emphasises a different element first. |
| **1 — Not yet competent** | No reading order is stated, or the hierarchy has no clear entry point. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — The explanation links each technique to the reading order, not to taste.

**Evidence type:** rationale link

**Required evidence (the Level 3 standard):** The explanation links each technique to the reading order rather than to taste. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Each technique is linked to a specific effect on reading order, and the learner distinguishes that reason from personal taste. |
| **3 — Competent / pass** | The explanation links each technique to the reading order rather than to taste. |
| **2 — Developing** | Some links are asserted, such as "it looks better", without explaining the effect on reading order. |
| **1 — Not yet competent** | The explanation is taste-based or missing. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] At least eight spacing annotations using values from the scale.
- [ ] No more than three type sizes and one accent colour.
- [ ] Five-second test notes with verbatim answers from one person.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A before/after layout of one screen with a marked 8-point spacing scale, a 4-column mobile grid, and a one-paragraph explanation of the reading order.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Random 13/17/22 px spacing | Snap to 4/8/12/16/24/32/48. |
| Every section in a card | Use space first; cards only where a boundary is meaningful. |
| Too many type sizes | Limit to three levels; use weight and colour for nuance. |
| Centring everything | Left-align text for scanning; centre only short, isolated content. |
| Divider lines everywhere | Space separates without adding ink. |
| Shrinking to fit | Remove or defer content; then adjust size. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Lay out a **settings screen** with eight rows, each with a label and a toggle, plus a section header and a destructive "Delete account" action. Use a 4-column grid and the same spacing scale. Then produce a second version for a **low-vision user** at 200% text size, and explain what breaks and how you fixed it. Submit both versions and a 120-word note on which layout decision was hardest.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. Before and after versions of the same screen. |  |  |  |
| 2. A visible grid with consistent margins and gutters. |  |  |  |
| 3. A stated intended reading order that matches the design. |  |  |  |
| 4. The explanation links each technique to the reading order, not to taste. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
