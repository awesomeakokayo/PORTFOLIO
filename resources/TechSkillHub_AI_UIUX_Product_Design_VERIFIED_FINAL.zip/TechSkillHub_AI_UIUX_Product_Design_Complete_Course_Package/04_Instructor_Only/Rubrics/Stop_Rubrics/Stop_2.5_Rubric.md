# Stop Rubric — 2.5: Accessibility and Inclusive Design

**Instructor use only. Do not distribute to learners.**
**Phase:** 2 · Visual and interaction foundations
**Prerequisites:** Stop 2.4
**Suggested time:** 80-100 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the twelve-check audit, corrected screen, prioritised fixes, developer notes and reflection.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — At least twelve checks across POUR.

**Evidence type:** accessibility audit

**Required evidence (the Level 3 standard):** At least twelve checks across POUR are recorded. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | At least twelve checks span POUR, and the learner explains why each check belongs to its principle. |
| **3 — Competent / pass** | At least twelve checks across POUR are recorded. |
| **2 — Developing** | Fewer than twelve checks are recorded, or the checks cluster in one POUR principle. |
| **1 — Not yet competent** | The audit is missing or does not cover POUR. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — Evidence for every result, with ratios or measurements where relevant.

**Evidence type:** audit evidence

**Required evidence (the Level 3 standard):** Evidence is present for every result, with ratios or measurements where relevant. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Every result has evidence, such as a ratio, measurement, recording or code reference, and the learner distinguishes tested from inferred. |
| **3 — Competent / pass** | Evidence is present for every result, with ratios or measurements where relevant. |
| **2 — Developing** | Some results have evidence and others are assertions. |
| **1 — Not yet competent** | Results are asserted without evidence. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — Failures honestly marked, including "not testable".

**Evidence type:** honesty failures

**Required evidence (the Level 3 standard):** Failures are honestly marked, including "not testable" where applicable. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Failures are marked, "not testable" is used only where true, and the learner explains what would be needed to test it. |
| **3 — Competent / pass** | Failures are honestly marked, including "not testable" where applicable. |
| **2 — Developing** | Some failures are softened or omitted, or "not testable" is used to avoid a test that was possible. |
| **1 — Not yet competent** | Failures are hidden, or the audit claims full compliance without evidence. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — Developer notes that name element, value, behaviour and reason.

**Evidence type:** dev notes

**Required evidence (the Level 3 standard):** Developer notes name the element, value, behaviour and reason for each finding. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Developer notes name the element, value, behaviour and reason, and are specific enough to implement without a meeting. |
| **3 — Competent / pass** | Developer notes name the element, value, behaviour and reason for each finding. |
| **2 — Developing** | Notes name the element but omit the value, behaviour or reason. |
| **1 — Not yet competent** | No developer notes are provided, or they are too vague to implement. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] A corrected screen with at least five fixes applied.
- [ ] A prioritisation with a stated rationale.
- [ ] The reflection distinguishes compliance from inclusion with a concrete example.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** An accessibility audit of one screen with at least ten checks, pass/fail results, fixes and a prioritised remediation list.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Checking only the headline contrast | Check all text, borders, icons and focus rings. |
| Automated checker only | Add keyboard, resize and greyscale tests. |
| Icon-only buttons | Add an accessible name and a visible label where possible. |
| Placeholder as label | Add a persistent label. |
| Fixed heights on text containers | Use min-height and padding; test 200%. |
| Claiming a pass without testing | Mark "not testable" and specify the test. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Audit a **public government or banking page** instead of your own screen. Do at least twelve checks, including keyboard navigation and 200% zoom in a browser. Record three failures and write developer notes for each. Then compare: which failures are design decisions, and which are engineering? Submit the audit and a 120-word comparison.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. At least twelve checks across POUR. |  |  |  |
| 2. Evidence for every result, with ratios or measurements where relevant. |  |  |  |
| 3. Failures honestly marked, including "not testable". |  |  |  |
| 4. Developer notes that name element, value, behaviour and reason. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
