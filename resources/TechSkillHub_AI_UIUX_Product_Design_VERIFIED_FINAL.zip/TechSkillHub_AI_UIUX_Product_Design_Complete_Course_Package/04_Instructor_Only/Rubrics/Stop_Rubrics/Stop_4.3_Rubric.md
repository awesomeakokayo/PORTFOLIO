# Stop Rubric — 4.3: AI for UI Generation and Prototyping

**Instructor use only. Do not distribute to learners.**
**Phase:** 4 · The AI design workflow
**Prerequisites:** Stop 4.2
**Suggested time:** 80-100 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the eight-part generated-UI review pack.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — A constraint stack covering all seven layers.

**Evidence type:** constraints

**Required evidence (the Level 3 standard):** A constraint stack covers all seven layers. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The constraint stack covers all seven layers, and the learner identifies the binding constraint and its consequence. |
| **3 — Competent / pass** | A constraint stack covers all seven layers. |
| **2 — Developing** | One or more layers are missing or treated superficially. |
| **1 — Not yet competent** | No constraint stack is provided; the design ignores platform or business limits. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — Ten-point review completed for each.

**Evidence type:** review ten

**Required evidence (the Level 3 standard):** A ten-point review is completed for each generated screen. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The ten-point review is completed for each screen, and the learner records which checks changed the design. |
| **3 — Competent / pass** | A ten-point review is completed for each generated screen. |
| **2 — Developing** | The review is partial or completed for only some screens. |
| **1 — Not yet competent** | No review is done; generated output is accepted as finished. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — One corrected screen with at least two states.

**Evidence type:** correction states

**Required evidence (the Level 3 standard):** One corrected screen includes at least two states. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | One corrected screen includes at least two states, and the learner shows the before/after and the reason for each change. |
| **3 — Competent / pass** | One corrected screen includes at least two states. |
| **2 — Developing** | A correction exists but covers only the default state. |
| **1 — Not yet competent** | No correction is made, or the correction introduces a new defect. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — No unlicensed asset or fabricated claim.

**Evidence type:** legal assets

**Required evidence (the Level 3 standard):** No unlicensed asset or fabricated claim is present. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | No unlicensed asset or fabricated claim remains, and the learner records the licence or source for each asset used. |
| **3 — Competent / pass** | No unlicensed asset or fabricated claim is present. |
| **2 — Developing** | An asset's licence is unclear, or a claim is unsupported. |
| **1 — Not yet competent** | An unlicensed asset or fabricated claim is shipped. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] Three drafts with different emphases.
- [ ] Invented features and token violations listed.
- [ ] Provenance and licence recorded.
- [ ] Time and defect measurement included.
- [ ] Verdict is specific and honest.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A prompt pack, three generated drafts, a review sheet with at least ten checks, and one corrected screen that meets your tokens and accessibility rules.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Short, vague prompt | Use the seven-layer stack. |
| Accepting the first draft | Generate three; compare structurally. |
| Importing without review | Review before and after import. |
| Keeping invented features | Remove and log. |
| Generated copy left unchanged | Replace with specific, honest copy. |
| No licence record | Record tool, terms and assets. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Generate a **desktop dashboard** instead of a mobile screen, with a table, filters and a status column. Review it for density, data-table accessibility and responsive behaviour. Submit three drafts, the review, one corrected screen and a 150-word note on which defect was hardest to see.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. A constraint stack covering all seven layers. |  |  |  |
| 2. Ten-point review completed for each. |  |  |  |
| 3. One corrected screen with at least two states. |  |  |  |
| 4. No unlicensed asset or fabricated claim. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
