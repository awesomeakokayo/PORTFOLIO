# Stop Rubric — 3.4: Prototyping

**Instructor use only. Do not distribute to learners.**
**Phase:** 3 · Figma fluency and design systems
**Prerequisites:** Stop 3.3
**Suggested time:** 80-100 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the prototype link, the test-readiness note and the observation notes.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — Six or more connected screens in flow order.

**Evidence type:** flow

**Required evidence (the Level 3 standard):** Six or more screens are connected in flow order. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Six or more screens are connected in flow order, and the learner annotates the entry, decision and exit points. |
| **3 — Competent / pass** | Six or more screens are connected in flow order. |
| **2 — Developing** | Screens exist, but the connections are missing or out of order. |
| **1 — Not yet competent** | Fewer than six screens are present, or there is no flow structure. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — A working overlay with two exits.

**Evidence type:** overlay

**Required evidence (the Level 3 standard):** A working overlay has two exits. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The overlay works with two exits, dismiss and complete, and the learner tests both paths. |
| **3 — Competent / pass** | A working overlay has two exits. |
| **2 — Developing** | The overlay has one exit, or the second is present but broken. |
| **1 — Not yet competent** | No overlay exists, or it traps the user. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — Loading and error states, with a recovery path.

**Evidence type:** prototype states

**Required evidence (the Level 3 standard):** Loading and error states exist, with a recovery path. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Loading and error states are reachable with a recovery path, and the learner tests the failure branch. |
| **3 — Competent / pass** | Loading and error states exist, with a recovery path. |
| **2 — Developing** | One state is missing or unreachable. |
| **1 — Not yet competent** | Only the happy path is prototyped. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — No dead ends; a back path from every screen.

**Evidence type:** navigation back

**Required evidence (the Level 3 standard):** No dead ends remain; a back path exists from every screen. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | No dead ends remain; every screen has a back path to the screen the user came from, and the learner tests the longest path. |
| **3 — Competent / pass** | No dead ends remain; a back path exists from every screen. |
| **2 — Developing** | One or more screens lack a back path, or back always returns to the home screen. |
| **1 — Not yet competent** | Multiple dead ends exist; the prototype cannot be navigated. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] A named flow and a starting point.
- [ ] A scrolling screen with a fixed element.
- [ ] Test-readiness note covers reset and branches.
- [ ] Observation notes record a real person's hesitations.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A clickable prototype of one complete flow, with at least six screens, a start point, back navigation, one overlay and one loading/error state, plus a test-readiness note.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Hotspots on the label only | Make the whole button the hotspot. |
| No back path | Connect back on every screen. |
| Modal with one exit | Add "cancel" and tap-outside. |
| Different transition everywhere | Standardise push, modal, state change. |
| Error state unreachable | Add a test branch and document it. |
| Prototype starts mid-flow | Reset to the starting point before each session. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Build a **booking flow** prototype with a seat-selection screen, a payment sheet overlay, a "seat taken" conflict, and a confirmation. Add a horizontal scroll for date selection. Submit the prototype, a test-readiness note and three observations from a person attempting to book two seats.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. Six or more connected screens in flow order. |  |  |  |
| 2. A working overlay with two exits. |  |  |  |
| 3. Loading and error states, with a recovery path. |  |  |  |
| 4. No dead ends; a back path from every screen. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
