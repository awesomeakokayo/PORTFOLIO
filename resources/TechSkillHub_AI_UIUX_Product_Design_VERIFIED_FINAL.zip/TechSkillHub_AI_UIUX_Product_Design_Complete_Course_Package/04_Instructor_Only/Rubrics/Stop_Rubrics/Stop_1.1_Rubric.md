# Stop Rubric — 1.1: What Product Design Actually Is

**Instructor use only. Do not distribute to learners.**
**Phase:** 1 · Product thinking and research
**Prerequisites:** Phase 0 gate passed
**Suggested time:** 45-60 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the ten-decision table, the three trade-off sentences and the 150-word answer.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — Ten decisions from at least three real products.

**Evidence type:** coverage decisions

**Required evidence (the Level 3 standard):** Ten decisions from at least three real products are recorded. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Ten decisions span at least three products, and the learner explains why the set covers different kinds of decision rather than ten variations of one. |
| **3 — Competent / pass** | Ten decisions from at least three real products are recorded. |
| **2 — Developing** | Fewer than ten decisions are recorded, or all come from one or two products. |
| **1 — Not yet competent** | The log is missing or the decisions are invented rather than observed. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — At least two of each type: research, UX, UI, business.

**Evidence type:** classification

**Required evidence (the Level 3 standard):** At least two of each type (research, UX, UI, business) are present and the classifications are correct. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Every decision is classified correctly, and mixed cases name the dominant type plus the secondary type with a reason. |
| **3 — Competent / pass** | At least two of each type (research, UX, UI, business) are present and the classifications are correct. |
| **2 — Developing** | One type is missing, or several decisions are misclassified without explanation. |
| **1 — Not yet competent** | Classifications are absent or mostly wrong, so the framework is not demonstrated. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — At least two omissions treated as decisions.

**Evidence type:** classification omission

**Required evidence (the Level 3 standard):** At least two omissions are recorded as decisions rather than as gaps. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | At least two omissions are treated as decisions, and the learner explains the user consequence of leaving each one out. |
| **3 — Competent / pass** | At least two omissions are recorded as decisions rather than as gaps. |
| **2 — Developing** | One omission is recorded, or omissions are listed without treating them as decisions. |
| **1 — Not yet competent** | No omissions are considered; the log implies every possible decision was made. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — At least three mixed decisions with dominant and secondary type.

**Evidence type:** classification mixed

**Required evidence (the Level 3 standard):** At least three mixed decisions name a dominant and a secondary type. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | At least three mixed decisions name a dominant and a secondary type, and the learner explains why the boundary is arguable. |
| **3 — Competent / pass** | At least three mixed decisions name a dominant and a secondary type. |
| **2 — Developing** | Mixed decisions are labelled with one type only, or the secondary type is unjustified. |
| **1 — Not yet competent** | Mixed decisions are absent or misclassified. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] Evidence or "assumption" recorded for every row, with no invented statistics.
- [ ] One trade-off sentence per product.
- [ ] The 150-word answer uses at least five glossary terms correctly.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A ten-item classification table (research / UX / UI / business) with a one-line justification for each, plus a short definition of product design in your own words.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Starting with "make an app" | Write the situation sentence first; list three non-app responses. |
| Calling every decision UX | Use the dominant-type test; note secondary types. |
| Inventing a statistic to support a point | Write "assumption" and plan a check. Fabrication is a critical issue. |
| Ignoring the business model | Ask "who pays, and what does this cost them?" |
| Treating constraints as excuses | Constraints are design material; they force better trade-offs. |
| No trade-off named | Every choice gives something up; naming it shows judgment. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Classify ten decisions from **one** product across its full journey (signup, first use, repeat use, failure, cancellation). Ensure at least one decision is about **pricing or policy**, not interface. Write a 120-word paragraph on which type of decision was hardest to classify and why. Submit the new table plus a corrected row from your first attempt.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. Ten decisions from at least three real products. |  |  |  |
| 2. At least two of each type: research, UX, UI, business. |  |  |  |
| 3. At least two omissions treated as decisions. |  |  |  |
| 4. At least three mixed decisions with dominant and secondary type. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
