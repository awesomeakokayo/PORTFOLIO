# Stop Rubric — 1.2: User Research Basics

**Instructor use only. Do not distribute to learners.**
**Phase:** 1 · Product thinking and research
**Prerequisites:** Stop 1.1
**Suggested time:** 90-120 minutes across two sessions
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the six-part research pack from section 8.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — Two real practice interviews, or an honest statement that one did not happen.

**Evidence type:** research conduct

**Required evidence (the Level 3 standard):** Two real practice interviews are documented, or an honest statement explains why one did not happen. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Two real practice interviews are documented, or a missing interview is stated honestly with the reason and the alternative evidence used. |
| **3 — Competent / pass** | Two real practice interviews are documented, or an honest statement explains why one did not happen. |
| **2 — Developing** | One interview is documented, or the second is described but has no notes. |
| **1 — Not yet competent** | Interviews are invented or claimed without any notes or honest limitation. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — Two-column notes for each interview.

**Evidence type:** observation separation

**Required evidence (the Level 3 standard):** Two-column notes exist for each interview and separate what happened from what it might mean. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Notes use two columns for every interview, and each interpretation is traceable to a specific observation rather than stated as fact. |
| **3 — Competent / pass** | Two-column notes exist for each interview and separate what happened from what it might mean. |
| **2 — Developing** | The columns exist, but interpretation leaks into the observation column, or one interview has no notes. |
| **1 — Not yet competent** | Notes are a single narrative of opinions, so observation and interpretation cannot be distinguished. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — Consent recorded for each participant, with no real names in the notes.

**Evidence type:** consent privacy

**Required evidence (the Level 3 standard):** Consent is recorded for each participant and no real names appear in the notes. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Consent is recorded for each participant, names are replaced by codes, and the learner explains how the record will be stored and deleted. |
| **3 — Competent / pass** | Consent is recorded for each participant and no real names appear in the notes. |
| **2 — Developing** | Consent is mentioned but not documented, or a real name remains in the notes. |
| **1 — Not yet competent** | No consent is recorded, or participants are identifiable without permission. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — A discussion guide with at least seven open, non-leading questions.

**Evidence type:** question quality

**Required evidence (the Level 3 standard):** At least seven questions are open and non-leading; no question suggests the desired answer. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | At least seven questions are open and non-leading, and the guide includes follow-up probes that avoid introducing the interviewer's hypothesis. |
| **3 — Competent / pass** | At least seven questions are open and non-leading; no question suggests the desired answer. |
| **2 — Developing** | Some questions are leading, closed or hypothetical, so the guide would bias the answers. |
| **1 — Not yet competent** | The guide is mostly leading or closed, or it is absent. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] 3–5 themes, each with a count, a direct quote and a separate interpretation.
- [ ] A Limits section that names who was not included and what cannot be concluded.
- [ ] No fabricated participant, quote, number or finding.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** Two anonymised interview notes, a consent record, and a findings table that separates direct quotes from your interpretation.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Asking "would you use…" | Ask about the last real occasion. |
| Explaining the design mid-interview | Stay in question mode; save explanations for later. |
| Recording interpretations as findings | Keep the two columns; label interpretation explicitly. |
| Generalising from two people | State the sample size and the limits. |
| Publishing names or faces | Anonymise at the point of writing, not later. |
| Asking five questions at once | One question, then silence. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Run **one** new interview on a different topic with a participant who is **not** a close friend (a classmate, colleague or family member you do not usually discuss this with). Use a guide of five questions, all about a specific past event. Submit the two-column notes, the consent record, a three-theme findings table, and a 120-word note on how the stranger's answers differed from what you expected. If you cannot find a participant, do not invent one; instead submit a revised guide and a written plan for recruitment, and mark the task as not yet passed.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. Two real practice interviews, or an honest statement that one did not happen. |  |  |  |
| 2. Two-column notes for each interview. |  |  |  |
| 3. Consent recorded for each participant, with no real names in the notes. |  |  |  |
| 4. A discussion guide with at least seven open, non-leading questions. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
