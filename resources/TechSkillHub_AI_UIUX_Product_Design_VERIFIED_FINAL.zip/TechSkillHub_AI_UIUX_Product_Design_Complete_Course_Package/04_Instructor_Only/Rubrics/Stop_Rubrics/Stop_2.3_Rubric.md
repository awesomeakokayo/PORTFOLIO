# Stop Rubric — 2.3: Components and Patterns

**Instructor use only. Do not distribute to learners.**
**Phase:** 2 · Visual and interaction foundations
**Prerequisites:** Stop 2.2
**Suggested time:** 70-90 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the component sheet, the applied screen, the choice defence and the missing-states list.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — Seven components, each with the required states.

**Evidence type:** component states

**Required evidence (the Level 3 standard):** Seven components are present, each with the required states. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Seven components each show the required states, and the learner documents the trigger and content rule for each state. |
| **3 — Competent / pass** | Seven components are present, each with the required states. |
| **2 — Developing** | Components exist, but states are missing or inconsistently covered across the set. |
| **1 — Not yet competent** | Fewer than seven components are present, or states are not designed. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — Buttons have primary, secondary and tertiary variants.

**Evidence type:** button variants

**Required evidence (the Level 3 standard):** Buttons have primary, secondary and tertiary variants that are distinguishable. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Primary, secondary and tertiary variants are visually and semantically distinct, and the learner states when each is used. |
| **3 — Competent / pass** | Buttons have primary, secondary and tertiary variants that are distinguishable. |
| **2 — Developing** | Variants exist, but hierarchy is unclear, or one variant is just a recolour with no use rule. |
| **1 — Not yet competent** | Only one button style exists, or the variants are indistinguishable. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — Text field includes visible label, helper, error and focus states.

**Evidence type:** form states

**Required evidence (the Level 3 standard):** The text field includes a visible label, helper, error and focus states. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The text field shows label, helper, error and focus states, and the learner explains how the error is announced and recovered. |
| **3 — Competent / pass** | The text field includes a visible label, helper, error and focus states. |
| **2 — Developing** | One or more states are missing, or the label disappears on focus. |
| **1 — Not yet competent** | The field has no persistent label or no error or focus treatment. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — One screen uses at least four components consistently.

**Evidence type:** composition

**Required evidence (the Level 3 standard):** One screen uses at least four components consistently. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | One screen uses at least four components consistently, and the learner shows how the components compose without one-off overrides. |
| **3 — Competent / pass** | One screen uses at least four components consistently. |
| **2 — Developing** | Four components appear, but they are restyled per instance, so consistency is superficial. |
| **1 — Not yet competent** | Fewer than four components appear, or each is a one-off copy. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] Usage notes include do, don't and an accessibility note.
- [ ] The choice defence compares two controls and names the nearest alternative.
- [ ] Missing states are listed honestly.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A component sheet with seven components (button, text field, select, checkbox/radio, card, list item, navigation), each with states and usage notes.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Toggle for a form setting | Use checkbox/radio when a Save step exists. |
| Icon-only navigation | Add labels; test recognition. |
| Cards for everything | Use lists for uniform rows, sections for single content. |
| Placeholder as label | Add a visible label above. |
| No focus state | Add a 2 px visible ring; test with Tab. |
| Error text "Invalid input" | Name the rule and the fix. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Build a **five-component sheet for a desktop dashboard**: side navigation, table, filter bar, status badge and modal. Add a "density" variant for the table (comfortable and compact). Document when each density is appropriate. Submit the sheet plus a 120-word note on how desktop choices differ from mobile and why.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. Seven components, each with the required states. |  |  |  |
| 2. Buttons have primary, secondary and tertiary variants. |  |  |  |
| 3. Text field includes visible label, helper, error and focus states. |  |  |  |
| 4. One screen uses at least four components consistently. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
