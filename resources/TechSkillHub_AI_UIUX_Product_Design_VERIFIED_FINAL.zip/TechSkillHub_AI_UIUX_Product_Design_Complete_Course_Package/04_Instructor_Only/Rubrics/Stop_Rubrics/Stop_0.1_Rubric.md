# Stop Rubric — 0.1: Your Workspace

**Instructor use only. Do not distribute to learners.**
**Phase:** 0 · Getting started
**Prerequisites:** None. This is the first stop.
**Suggested time:** 45-60 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Set up your course workspace, create the design account (and, if you choose, an AI account), and prove that you can recover a saved file. Submit:

1. A screenshot of your full folder tree with the folders expanded.
2. Your completed workspace checklist (the one-page text file).
3. The `Kudi` project folder from section 8, zipped, containing the four subfolders and the README.
4. One exported PNG from your Figma practice file.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — A single source of truth is named in the checklist.

**Evidence type:** source truth

**Required evidence (the Level 3 standard):** The checklist names one source of truth and the folder tree matches it. No competing working copy is visible. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | One authoritative location is named, the folder tree matches it, and the learner records how a second copy will be treated as a dated backup rather than a rival working copy. |
| **3 — Competent / pass** | The checklist names one source of truth and the folder tree matches it. No competing working copy is visible. |
| **2 — Developing** | A location is named, but the tree or a second copy contradicts it, so a reviewer cannot tell which copy is authoritative. |
| **1 — Not yet competent** | No source of truth is named, or two folders are both presented as official with no rule for resolving them. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — At least four files use the naming rule with date, project, item and version.

**Evidence type:** naming

**Required evidence (the Level 3 standard):** At least four files follow the pattern with the date first, hyphens instead of spaces and a version suffix, using one consistent extension. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | At least four files follow date_project_item_version, and the learner explains how the pattern resolved a real version conflict, such as choosing between v2 and a later export. |
| **3 — Competent / pass** | At least four files follow the pattern with the date first, hyphens instead of spaces and a version suffix, using one consistent extension. |
| **2 — Developing** | Some files follow the pattern, but others use spaces, "final" or a missing date or version, so the set cannot be sorted reliably. |
| **1 — Not yet competent** | Files are unnamed or use ad-hoc labels such as "final new", so a reviewer cannot order or identify versions. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — The recovered file is named and the recovery method is described in one sentence.

**Evidence type:** recovery

**Required evidence (the Level 3 standard):** The recovered file is named and the recovery method is described in one sentence that matches the steps taken. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The recovered file is named, the exact recovery route is stated (account, workspace, search term), and the reopened file or search result is shown as evidence. |
| **3 — Competent / pass** | The recovered file is named and the recovery method is described in one sentence that matches the steps taken. |
| **2 — Developing** | Recovery is mentioned, but the file name, the method or the evidence that it actually reopened is missing. |
| **1 — Not yet competent** | No recovery is demonstrated, or the account of recovery is contradicted by a missing or blank file. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — No personal or client data appears in the AI chat screenshot (if the AI route is used) or the checklist. If the no-AI route is used, the equivalent written explanation and any source notes contain no personal data.

**Evidence type:** privacy record

**Required evidence (the Level 3 standard):** No personal, client or credential data is visible; only readiness states such as "account ready: yes" appear. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The screenshot and checklist contain no email address, password, token or client identifier, and the learner states the rule they will use to keep identifiers out in future. |
| **3 — Competent / pass** | No personal, client or credential data is visible; only readiness states such as "account ready: yes" appear. |
| **2 — Developing** | A minor identifier, such as an email address or account name, is visible even though no password is exposed, and no removal plan is stated. |
| **1 — Not yet competent** | A password, recovery code, client identity or other sensitive record is exposed, or the submission cannot be shown without exposing one. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] The folder tree contains the six top-level folders and Phase 0–7 subfolders, or a documented equivalent that serves the same purposes.
- [ ] The checklist records the selected tools and confirms each chosen account is ready; if the no-AI route is used, it is recorded as a valid choice. No email addresses, passwords or tokens appear.
- [ ] The screenshot shows the folders expanded, not just a closed parent folder.
- [ ] The exported PNG opens and is not blank.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A screenshot of your folder tree plus a one-page workspace checklist showing each account is active and one file was recovered after closing the browser.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Saving everything in `Downloads` | Change the save location once per download; move existing course files into `TechSkillHub` today. |
| Two "official" copies (desktop and cloud) | Declare one source of truth; keep the other as a dated backup, not a working copy. |
| Names like `final`, `final2`, `new` | Use `v1`, `v2`, `v3`; never use "final". |
| Signing up with a different email than expected | Check the account avatar before creating another account; use a password manager or a private nickname hint. Do not copy the address into the checklist. |
| Losing a Figma file | Use the file search, check the account menu, then check the team/project breadcrumb. |
| Storing real passwords in a notes file | Use hints or a password manager; enable 2FA. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Create a workspace for a fictional **tailoring business** called `Stitch` instead of `Kudi`. It must include a `measurements` folder and a `client-photos` folder, a file named with yesterday's date, and a `README.txt` that names the source of truth. Then demonstrate recovery by signing out of Figma, signing back in, and opening the practice file from search rather than from recents. Submit a screenshot of the search result and the file's name.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. A single source of truth is named in the checklist. |  |  |  |
| 2. At least four files use the naming rule with date, project, item and version. |  |  |  |
| 3. The recovered file is named and the recovery method is described in one sentence. |  |  |  |
| 4. No personal or client data appears in the AI chat screenshot (if the AI route is used) or  |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
