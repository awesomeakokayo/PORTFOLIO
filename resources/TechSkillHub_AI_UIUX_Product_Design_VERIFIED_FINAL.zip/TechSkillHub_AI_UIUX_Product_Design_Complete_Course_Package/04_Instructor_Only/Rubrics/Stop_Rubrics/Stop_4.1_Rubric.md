# Stop Rubric — 4.1: AI for Research Synthesis

**Instructor use only. Do not distribute to learners.**
**Phase:** 4 · The AI design workflow
**Prerequisites:** Phase 3 gate passed
**Suggested time:** 70-90 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the eight-part synthesis pack.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — Every theme has a traceability row with a verified quote.

**Evidence type:** traceability

**Required evidence (the Level 3 standard):** Every theme has a traceability row with a verified quote. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Every theme has a traceability row with a verified quote and participant code, and the learner can open the source note for each. |
| **3 — Competent / pass** | Every theme has a traceability row with a verified quote. |
| **2 — Developing** | Some themes lack quotes, or a quote cannot be found in the notes. |
| **1 — Not yet competent** | Themes are unsourced, or the quotes are invented. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — At least three AI errors or weak claims are caught and corrected.

**Evidence type:** ai errors

**Required evidence (the Level 3 standard):** At least three AI errors or weak claims are caught and corrected. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | At least three AI errors or weak claims are caught, corrected and explained, including how each was detected. |
| **3 — Competent / pass** | At least three AI errors or weak claims are caught and corrected. |
| **2 — Developing** | One or two errors are caught, or corrections are made without explanation. |
| **1 — Not yet competent** | No errors are caught; the AI output is accepted wholesale. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — Quantifiers match the sample size.

**Evidence type:** quantifiers

**Required evidence (the Level 3 standard):** Quantifiers match the sample size throughout. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Every quantifier matches the sample size, and the learner explains why "most" or "all" would overclaim. |
| **3 — Competent / pass** | Quantifiers match the sample size throughout. |
| **2 — Developing** | At least one quantifier exceeds the sample, such as "8 of 10" from six notes. |
| **1 — Not yet competent** | Quantifiers are invented or contradict the sample. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — No fabricated quote, participant or percentage.

**Evidence type:** integrity research

**Required evidence (the Level 3 standard):** No fabricated quote, participant or percentage appears. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | No fabricated quote, participant or percentage appears, and the learner explains how they would spot a fabricated claim in future. |
| **3 — Competent / pass** | No fabricated quote, participant or percentage appears. |
| **2 — Developing** | A claim is unsupported but not clearly fabricated; it still needs correction. |
| **1 — Not yet competent** | A fabricated quote, participant or percentage is present. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] Input is anonymised, or the substitution is explained.
- [ ] Prompts and raw output are included.
- [ ] Insights are labelled as interpretation.
- [ ] Counter-evidence is reported.
- [ ] Human review explains what only the researcher could know.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** An AI-assisted synthesis with a prompt log, a theme table, a quote-to-theme traceability matrix and a verification note listing what the AI got wrong.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Pasting raw notes with names | Anonymise first; use P1/P2. |
| Accepting a clean summary | Verify every quote and participant. |
| Turning two mentions into "users want" | State the sample: "2 of 5". |
| Letting AI infer demographics | Ban inference in the prompt; check output. |
| No counter-evidence | Ask explicitly and verify. |
| Themes that are really solutions | Separate evidence from recommendation. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Repeat the synthesis using **invented practice notes** that you write yourself, containing two deliberate contradictions and one single-participant observation. Ask the AI to synthesise, then audit it against your known ground truth. Submit the notes, the AI output, your audit and a 150-word note on which error was hardest to catch. This variant tests detection without risking real participant data.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. Every theme has a traceability row with a verified quote. |  |  |  |
| 2. At least three AI errors or weak claims are caught and corrected. |  |  |  |
| 3. Quantifiers match the sample size. |  |  |  |
| 4. No fabricated quote, participant or percentage. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
