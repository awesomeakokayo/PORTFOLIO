# Stop Rubric — 4.2: AI for Ideation and Flows

**Instructor use only. Do not distribute to learners.**
**Phase:** 4 · The AI design workflow
**Prerequisites:** Stop 4.1
**Suggested time:** 70-90 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the nine-part flow pack.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — Three flows with genuinely different structures.

**Evidence type:** divergence

**Required evidence (the Level 3 standard):** Three flows have genuinely different structures, not cosmetic variations. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Three flows differ structurally in steps, control or offline behaviour, and the learner states the trade-off each makes. |
| **3 — Competent / pass** | Three flows have genuinely different structures, not cosmetic variations. |
| **2 — Developing** | Flows differ only in visual style or step order, so real alternatives are not explored. |
| **1 — Not yet competent** | One flow is copied three times. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — A critique matrix with six criteria and justifications.

**Evidence type:** critique matrix

**Required evidence (the Level 3 standard):** A critique matrix scores six criteria with justifications. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Six criteria are scored with justifications tied to evidence, and the learner explains which criterion drove the choice. |
| **3 — Competent / pass** | A critique matrix scores six criteria with justifications. |
| **2 — Developing** | Fewer than six criteria are used, or the scores lack justification. |
| **1 — Not yet competent** | No matrix is used; the choice is asserted. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — Every step marked Have/Build/Assume/Invent.

**Evidence type:** capability marking

**Required evidence (the Level 3 standard):** Every step is marked Have, Build, Assume or Invent. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Every step is marked Have, Build, Assume or Invent, and the learner explains the risk and validation needed for each Assume or Invent. |
| **3 — Competent / pass** | Every step is marked Have, Build, Assume or Invent. |
| **2 — Developing** | Some steps are unmarked, or the labels are used inconsistently. |
| **1 — Not yet competent** | No capability marking is done; invented steps are presented as existing. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — No unmarked invented capability.

**Evidence type:** no invented capability

**Required evidence (the Level 3 standard):** No unmarked invented capability remains. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | No unmarked invented capability remains, and the learner shows where each new capability would be built or validated. |
| **3 — Competent / pass** | No unmarked invented capability remains. |
| **2 — Developing** | One invented capability is unmarked or implied to exist already. |
| **1 — Not yet competent** | The flow depends on capabilities the product does not have. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] An IA with five or fewer top-level destinations.
- [ ] At least three unsupported features identified and handled.
- [ ] A pre-mortem with five reasons.
- [ ] A hand-drawn or FigJam flow including failure paths.
- [ ] A decision log explaining kept, changed and rejected.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** Three AI-generated flows, a critique matrix, one selected flow with edge cases, and a decision log explaining what was kept, changed and rejected.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Accepting the first flow | Ask for structural alternatives; critique. |
| Three cosmetic variants | Name the structural differences. |
| Ignoring failure paths | Generate edge cases explicitly; draw them. |
| Missing invented features | Mark every step Have/Build/Assume/Invent. |
| Choosing the most complex flow | Score against evidence and constraints. |
| No decision log | Record kept, changed, rejected. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Generate flows for a **different task**: cancelling a subscription or disputing a charge. Focus on the failure and recovery paths, and include a regulatory or policy constraint. Submit three flows, a critique matrix, a decision log and a 150-word note on which assumption was most dangerous.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. Three flows with genuinely different structures. |  |  |  |
| 2. A critique matrix with six criteria and justifications. |  |  |  |
| 3. Every step marked Have/Build/Assume/Invent. |  |  |  |
| 4. No unmarked invented capability. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
