# Stop Rubric — 3.5: Building a Small Design System

**Instructor use only. Do not distribute to learners.**
**Phase:** 3 · Figma fluency and design systems
**Prerequisites:** Stop 3.4
**Suggested time:** 120-150 minutes across two sessions
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the system file link and the documentation PDF.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — 20+ primitives and 15+ semantic tokens.

**Evidence type:** tokens

**Required evidence (the Level 3 standard):** At least the required primitive and semantic token counts are defined. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The stated primitive and semantic token counts are met, and the learner explains the naming logic that separates raw values from purpose. |
| **3 — Competent / pass** | At least the required primitive and semantic token counts are defined. |
| **2 — Developing** | The token counts fall short, or primitives and semantics are mixed without a naming rule. |
| **1 — Not yet competent** | No token structure exists; values are hard-coded. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — Ten components with variants and documented properties.

**Evidence type:** component library

**Required evidence (the Level 3 standard):** Ten components have variants and documented properties. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Ten components have variants and documented properties, and the learner shows how a new instance is configured. |
| **3 — Competent / pass** | Ten components have variants and documented properties. |
| **2 — Developing** | Fewer than ten components are present, or the properties are undocumented. |
| **1 — Not yet competent** | Components are one-off frames with no reusable properties. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — Documentation covers purpose, anatomy, use, don't, accessibility, content and developer notes.

**Evidence type:** documentation

**Required evidence (the Level 3 standard):** Documentation covers all seven required areas for the components. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Documentation covers purpose, anatomy, use, don't, accessibility, content and developer notes for each component, with worked examples. |
| **3 — Competent / pass** | Documentation covers all seven required areas for the components. |
| **2 — Developing** | Some areas are missing, usually accessibility or content rules. |
| **1 — Not yet competent** | Documentation is a gallery of images with no usage guidance. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — Adoption table with overrides and detached instances counted.

**Evidence type:** governance

**Required evidence (the Level 3 standard):** An adoption table records overrides and detached instances. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The adoption table counts overrides and detached instances, and the learner identifies one cause and one system fix. |
| **3 — Competent / pass** | An adoption table records overrides and detached instances. |
| **2 — Developing** | The table exists but is incomplete or has no interpretation. |
| **1 — Not yet competent** | No adoption evidence is provided; drift is unknown. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] Five principles, each with a consequence.
- [ ] One screen composed only from system components.
- [ ] Governance page with version, owner, change log, review, deprecation and contribution.
- [ ] Reflection identifies a real documentation difficulty.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A mini design system file: token pages, ten documented components, a documentation page and one screen built only from system components.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| A component library with no documentation | Document purpose, use, don't and accessibility. |
| Tokens named by appearance | Name by role; alias primitives. |
| Ten components nobody uses | Build what the screen needs; add only recurring parts. |
| Hiding overrides | Count them; some are legitimate. |
| No governance | Write a one-page rule set; future-you needs it. |
| Detaching to compose | Use slots, properties or a documented exception. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Build a **second theme** (high-contrast or dark) for your system using variable modes, and document which components required structural changes. Submit the themed system, a migration note for developers and a 150-word reflection on what the theme revealed about hidden assumptions.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. 20+ primitives and 15+ semantic tokens. |  |  |  |
| 2. Ten components with variants and documented properties. |  |  |  |
| 3. Documentation covers purpose, anatomy, use, don't, accessibility, content and developer no |  |  |  |
| 4. Adoption table with overrides and detached instances counted. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
