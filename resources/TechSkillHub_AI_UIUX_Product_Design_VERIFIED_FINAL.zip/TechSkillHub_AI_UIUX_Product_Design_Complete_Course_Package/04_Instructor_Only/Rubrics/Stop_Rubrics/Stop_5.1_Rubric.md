# Stop Rubric — 5.1: Handoff That Developers Love

**Instructor use only. Do not distribute to learners.**
**Phase:** 5 · Design to build
**Prerequisites:** Stop 5.0 passed, or equivalent ability to publish a page
**Suggested time:** 75-95 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the handoff pack for one screen, plus a short record of a review with a peer or developer.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — One screen is fully specified, with values and units.

**Evidence type:** specification

**Required evidence (the Level 3 standard):** One screen is fully specified with values and units. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | One screen is fully specified with values and units, and the learner shows how a developer would build it without guessing. |
| **3 — Competent / pass** | One screen is fully specified with values and units. |
| **2 — Developing** | Some values lack units or are marked "approx", so implementation would require guesses. |
| **1 — Not yet competent** | The handoff is an image with no measurements. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — At least 6 states are defined with triggers and behaviour.

**Evidence type:** states handoff

**Required evidence (the Level 3 standard):** At least six states are defined with triggers and behaviour. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | At least six states are defined with triggers and behaviour, and the learner shows the transition between two of them. |
| **3 — Competent / pass** | At least six states are defined with triggers and behaviour. |
| **2 — Developing** | Fewer than six states are defined, or the behaviour is described without triggers. |
| **1 — Not yet competent** | Only the happy path is handed off. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — Content rules cover at least 4 text slots, including overflow.

**Evidence type:** content rules

**Required evidence (the Level 3 standard):** Content rules cover at least four text slots, including overflow. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Content rules cover at least four text slots including overflow, and the learner gives a realistic long-string example. |
| **3 — Competent / pass** | Content rules cover at least four text slots, including overflow. |
| **2 — Developing** | Fewer than four slots are covered, or overflow is not addressed. |
| **1 — Not yet competent** | No content rules are provided; the copy is left to the developer. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — 5–10 acceptance criteria are testable.

**Evidence type:** acceptance

**Required evidence (the Level 3 standard):** 5–10 acceptance criteria are present and testable. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | 5–10 acceptance criteria are testable, and each names an observable outcome rather than an implementation detail. |
| **3 — Competent / pass** | 5–10 acceptance criteria are present and testable. |
| **2 — Developing** | The criteria are vague, such as "works well", or fewer than five are present. |
| **1 — Not yet competent** | No acceptance criteria are provided. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] Assets are listed with names, formats, sizes and licence status.
- [ ] A naming convention is defined and applied.
- [ ] Edge cases cover content, data, network, permission and device.
- [ ] Open questions have owners and defaults.
- [ ] The review record shows at least three questions asked and how the pack was improved.
- [ ] No real personal or confidential data is included.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A handoff pack for one screen: annotated spec, state matrix, asset list, edge-case list, naming conventions and an open-questions log.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Handing over only the happy path | Add loading, empty, error, disabled and success. |
| Specs in adjectives | Replace with values and tokens. |
| Three "final" files | Name one file as canonical and archive the rest. |
| Icons as screenshots | Export SVG; name it; state colour behaviour. |
| Real customer data in mockups | Replace with fictional data and label it. |
| Open questions hidden in chat | Put them in the table with an owner and default. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Take a different screen — a login form or a search results page — and produce a **one-page** handoff using only a table and five annotations. The constraint forces you to prioritise the decisions that actually block a build. Submit the one-pager plus a list of what you deliberately left out and why.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. One screen is fully specified, with values and units. |  |  |  |
| 2. At least 6 states are defined with triggers and behaviour. |  |  |  |
| 3. Content rules cover at least 4 text slots, including overflow. |  |  |  |
| 4. 5–10 acceptance criteria are testable. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
