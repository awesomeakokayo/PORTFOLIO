# Stop Rubric — 4.6: Verification and Judgment

**Instructor use only. Do not distribute to learners.**
**Phase:** 4 · The AI design workflow
**Prerequisites:** Stop 4.5
**Suggested time:** 80-100 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the eight-part verification review.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — Findings table with type, element, evidence, severity and fix.

**Evidence type:** findings table

**Required evidence (the Level 3 standard):** A findings table records type, element, evidence, severity and fix. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The findings table records type, element, evidence, severity and fix for every finding, and severity is justified by user impact. |
| **3 — Competent / pass** | A findings table records type, element, evidence, severity and fix. |
| **2 — Developing** | One or more columns are missing, or severity is unjustified. |
| **1 — Not yet competent** | Findings are a list of opinions with no evidence or severity. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — All five failure types addressed or explicitly checked.

**Evidence type:** failure types

**Required evidence (the Level 3 standard):** All five failure types are addressed or explicitly checked. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | All five failure types are addressed or explicitly checked, and the learner explains why an absent type is not a gap. |
| **3 — Competent / pass** | All five failure types are addressed or explicitly checked. |
| **2 — Developing** | One or two failure types are missing. |
| **1 — Not yet competent** | Only visual issues are reviewed. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — Two corrected screens.

**Evidence type:** correction screens

**Required evidence (the Level 3 standard):** Two corrected screens are present. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Two corrected screens show the before/after, the fix and the check that proves the issue is resolved. |
| **3 — Competent / pass** | Two corrected screens are present. |
| **2 — Developing** | One corrected screen is present, or the corrections are described but not shown. |
| **1 — Not yet competent** | No corrected screens are provided. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — No invented finding, and no unsourced claim left in a corrected screen.

**Evidence type:** integrity findings

**Required evidence (the Level 3 standard):** No invented finding and no unsourced claim remain in a corrected screen. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | No invented finding or unsourced claim remains, and the learner shows how each corrected screen was re-checked. |
| **3 — Competent / pass** | No invented finding and no unsourced claim remain in a corrected screen. |
| **2 — Developing** | A finding is speculative, or a corrected screen contains an unsourced claim. |
| **1 — Not yet competent** | Invented findings or unsourced claims are presented as fact. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] Three screens reviewed with annotations.
- [ ] A rationale for every fix.
- [ ] A regression check.
- [ ] A personal checklist with a stop rule.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** An annotated review of three generated screens, a personal review checklist, and corrected versions of two screens with a rationale for every fix.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Judging by visual polish | Check facts, accessibility and flow first. |
| Accepting an unsourced stat | Trace or remove it. |
| Fixing colours only | Address flow and integrity failures too. |
| No severity | Rate by harm and frequency. |
| Rationale missing | Write change + effect + reason. |
| Skipping regression | Re-test related states. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Review **three screens generated by a different tool or person**, and include one screen that is mostly correct. Your job is to avoid inventing problems in the good screen while still catching real ones. Submit the review and a 150-word note on how you calibrated.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. Findings table with type, element, evidence, severity and fix. |  |  |  |
| 2. All five failure types addressed or explicitly checked. |  |  |  |
| 3. Two corrected screens. |  |  |  |
| 4. No invented finding, and no unsourced claim left in a corrected screen. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
