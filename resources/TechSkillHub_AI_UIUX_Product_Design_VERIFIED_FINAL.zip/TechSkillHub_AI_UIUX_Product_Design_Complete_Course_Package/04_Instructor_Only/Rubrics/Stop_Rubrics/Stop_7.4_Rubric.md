# Stop Rubric — 7.4: Getting Paid

**Instructor use only. Do not distribute to learners.**
**Phase:** 7 · Capstone and career launch
**Prerequisites:** Stop 7.3 passed
**Suggested time:** 90-120 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the pricing calculator, proposal, application pack and negotiation plan.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — Rate calculation includes costs, tax reserve, savings, billable hours and assumptions.

**Evidence type:** rate

**Required evidence (the Level 3 standard):** The rate calculation includes costs, tax reserve, savings, billable hours and assumptions. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The rate calculation includes costs, tax reserve, savings, billable hours and assumptions, and the learner shows the resulting floor and target rate. |
| **3 — Competent / pass** | The rate calculation includes costs, tax reserve, savings, billable hours and assumptions. |
| **2 — Developing** | One or more components are missing, or the calculation cannot be reproduced. |
| **1 — Not yet competent** | The rate is copied from a competitor with no cost basis. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — Proposal has scope, exclusions, deliverables, timeline, revisions and payment schedule.

**Evidence type:** proposal

**Required evidence (the Level 3 standard):** The proposal includes scope, exclusions, deliverables, timeline, revisions and payment schedule. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The proposal includes scope, exclusions, deliverables, timeline, revisions and payment schedule, and the learner explains how each protects both sides. |
| **3 — Competent / pass** | The proposal includes scope, exclusions, deliverables, timeline, revisions and payment schedule. |
| **2 — Developing** | One or more sections are missing, usually exclusions or revisions. |
| **1 — Not yet competent** | The proposal is a price with no scope. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — At least one deposit or milestone structure is defined.

**Evidence type:** payment

**Required evidence (the Level 3 standard):** At least one deposit or milestone structure is defined. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | At least one deposit or milestone structure is defined, with amounts, triggers and consequences for late payment. |
| **3 — Competent / pass** | At least one deposit or milestone structure is defined. |
| **2 — Developing** | Payment is mentioned but has no trigger or amount. |
| **1 — Not yet competent** | No payment protection is provided; work starts on trust. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — Negotiation plan includes target, walk-away, priorities and three tradeables.

**Evidence type:** negotiation

**Required evidence (the Level 3 standard):** The negotiation plan includes target, walk-away, priorities and three tradeables. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The negotiation plan includes target, walk-away, priorities and three tradeables, and the learner explains the order of concessions. |
| **3 — Competent / pass** | The negotiation plan includes target, walk-away, priorities and three tradeables. |
| **2 — Developing** | One or two elements are missing, so the plan cannot guide a real conversation. |
| **1 — Not yet competent** | No negotiation plan is provided; the learner intends to accept whatever is offered. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] Application pack is tailored to a named role and company.
- [ ] Design-challenge policy states what you accept, decline and ask.
- [ ] Payment and tax responsibilities are acknowledged as country-specific.
- [ ] No real bank details, ID numbers or signed contracts are included.
- [ ] No promise of employment or income is made.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A pricing calculator, a one-page proposal, a remote application pack and a negotiation plan with your walk-away number.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Pricing by competitor guess | Calculate your floor first. |
| Vague scope | Write deliverables and exclusions. |
| Unlimited revisions | Define rounds and extra-round pricing. |
| No deposit | Ask for 40–50% to start. |
| Delivering finals before payment | Hold final files until the balance clears. |
| Mass-applying | Tailor fewer applications. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Recalculate your rate assuming **only 15 billable hours per week** and a three-month buffer. Then write a 100-word note on how the number changes and what you would do differently. The constraint exposes hidden costs and unrealistic assumptions.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. Rate calculation includes costs, tax reserve, savings, billable hours and assumptions. |  |  |  |
| 2. Proposal has scope, exclusions, deliverables, timeline, revisions and payment schedule. |  |  |  |
| 3. At least one deposit or milestone structure is defined. |  |  |  |
| 4. Negotiation plan includes target, walk-away, priorities and three tradeables. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
