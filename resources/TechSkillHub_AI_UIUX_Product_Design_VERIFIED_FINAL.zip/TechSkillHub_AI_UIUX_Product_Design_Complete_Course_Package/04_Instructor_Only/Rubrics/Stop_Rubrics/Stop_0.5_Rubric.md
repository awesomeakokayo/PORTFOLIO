# Stop Rubric — 0.5: Your First Screen

**Instructor use only. Do not distribute to learners.**
**Phase:** 0 · Getting started
**Prerequisites:** Stop 0.1 (Figma account), Stop 0.3 (interface vocabulary)
**Suggested time:** 60-90 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the Figma file link (view access) and a PDF containing the two PNG exports, your build notes and your 120–180 word rationale.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — A named frame at a stated phone size.

**Evidence type:** figma frame

**Required evidence (the Level 3 standard):** A named frame exists at a stated phone size and contains the screen content. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The frame is named, set to a stated phone size, and the learner shows it resizing or explains the constraint choice that keeps the layout intact. |
| **3 — Competent / pass** | A named frame exists at a stated phone size and contains the screen content. |
| **2 — Developing** | A frame exists but is unnamed, or its size is unstated or inconsistent with the intended device. |
| **1 — Not yet competent** | No frame is used; content sits loose on the canvas, so there is no screen boundary. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — At least 12 named layers with consistent naming.

**Evidence type:** figma layers

**Required evidence (the Level 3 standard):** At least 12 layers are named consistently; no critical layer is left as "Rectangle 7". The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | At least 12 layers are named by role, follow one naming convention, and are grouped so another designer can find and edit them. |
| **3 — Competent / pass** | At least 12 layers are named consistently; no critical layer is left as "Rectangle 7". |
| **2 — Developing** | Some layers are named, but unnamed or duplicated names make the structure hard to follow. |
| **1 — Not yet competent** | Layers are largely unnamed or flattened, so the file cannot be edited or reviewed efficiently. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — Two versions with exactly one deliberate change.

**Evidence type:** version control

**Required evidence (the Level 3 standard):** Two versions exist and exactly one deliberate change separates them. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Two versions exist with exactly one deliberate change, and the learner records what changed, why, and what stayed fixed. |
| **3 — Competent / pass** | Two versions exist and exactly one deliberate change separates them. |
| **2 — Developing** | Two versions exist, but several changes are bundled, so the effect of the intended change cannot be isolated. |
| **1 — Not yet competent** | Only one version exists, or the second is a duplicate with no stated change. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — No real bank branding, logos or personal data.

**Evidence type:** legal brand

**Required evidence (the Level 3 standard):** No real bank branding, logos or personal data appear; fictional content is used throughout. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | No real bank branding, logo or personal data is used, and the learner states the fictional brand and the source of the content. |
| **3 — Competent / pass** | No real bank branding, logos or personal data appear; fictional content is used throughout. |
| **2 — Developing** | A real logo or brand cue appears in a minor place, or the fictional status of the content is not stated. |
| **1 — Not yet competent** | Real branding or personal data is used in a way that could imply affiliation. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] Three levels of text hierarchy.
- [ ] One primary action aligned with alignment tools.
- [ ] The rationale states the expected user effect and how it would be checked.
- [ ] Exports are not blank, not cut off, and readable at phone size.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A Figma frame of the recreated screen plus a one-paragraph rationale for the change, exported as PNG and PDF.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Drawing directly on the canvas with no frame | Always start with a frame; move loose layers into it. |
| Using a group as a screen | Convert to frame (`Ctrl/Cmd + Alt + G`) or start with `F`. |
| Everything dragged by eye | Type X/Y/W/H; use alignment and distribution. |
| Text boxes that resize unexpectedly | Set fixed width for paragraphs; auto width for short labels. |
| Button label not centred | Select both and align horizontal/vertical centres, or make the button a frame with auto layout later. |
| One giant "final" version | Duplicate before changes; name versions. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Recreate a **login screen** instead, with: a title, two fields with labels, a primary button, a tertiary "Forgot password?" link, and one helper text. Build it at 360 × 800. Then make one change that improves **error recovery** (for example, adding a password visibility toggle or moving the error message next to the field), and justify it. Submit both versions and a 150-word rationale.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. A named frame at a stated phone size. |  |  |  |
| 2. At least 12 named layers with consistent naming. |  |  |  |
| 3. Two versions with exactly one deliberate change. |  |  |  |
| 4. No real bank branding, logos or personal data. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
