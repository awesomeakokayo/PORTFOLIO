# Stop Rubric — 7.2: Working With Developers and Product Managers

**Instructor use only. Do not distribute to learners.**
**Phase:** 7 · Capstone and career launch
**Prerequisites:** Stop 7.1 passed
**Suggested time:** 75-95 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the collaboration pack and reflection.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — Ticket is self-contained with testable acceptance criteria.

**Evidence type:** ticket

**Required evidence (the Level 3 standard):** The ticket is self-contained with testable acceptance criteria. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The ticket is self-contained with testable acceptance criteria, and the learner shows how a developer would verify each one. |
| **3 — Competent / pass** | The ticket is self-contained with testable acceptance criteria. |
| **2 — Developing** | The ticket assumes context or has vague acceptance criteria. |
| **1 — Not yet competent** | The ticket is a one-line request with no criteria. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — Decision log has at least four entries with rationale and owner.

**Evidence type:** decision log

**Required evidence (the Level 3 standard):** The decision log has at least four entries with rationale and owner. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The decision log has at least four entries with rationale and owner, and the learner shows how a reversed decision is recorded. |
| **3 — Competent / pass** | The decision log has at least four entries with rationale and owner. |
| **2 — Developing** | Fewer than four entries are present, or the rationale or owner is missing. |
| **1 — Not yet competent** | No decision log is provided. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — Critique note has one strength and three specific improvements tied to the goal.

**Evidence type:** critique note

**Required evidence (the Level 3 standard):** The critique note gives one strength and three specific improvements tied to the goal. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The critique note gives one strength and three specific improvements tied to the goal, with evidence for each. |
| **3 — Competent / pass** | The critique note gives one strength and three specific improvements tied to the goal. |
| **2 — Developing** | The improvements are generic or not tied to the goal. |
| **1 — Not yet competent** | No critique is provided, or it is only praise or criticism without specifics. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — Escalation brief states the decision, options, recommendation, deadline and default.

**Evidence type:** escalation

**Required evidence (the Level 3 standard):** The escalation brief states the decision, options, recommendation, deadline and default. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The escalation brief states the decision, options, recommendation, deadline and default, and the learner explains the cost of each option. |
| **3 — Competent / pass** | The escalation brief states the decision, options, recommendation, deadline and default. |
| **2 — Developing** | One or two elements are missing, so the decision cannot be made asynchronously. |
| **1 — Not yet competent** | No escalation brief is provided; the issue is raised without a decision request. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] At least one trade-off is explained in user, cost and risk terms.
- [ ] The reflection names a constraint and its effect on the design.
- [ ] No confidential or personnel information is included.
- [ ] Language is professional and focused on the work.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A collaboration pack: a scoped ticket, a decision log, a critique note with three actionable points, and a written escalation for one disagreement.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Presenting one option as inevitable | Present two or three with consequences. |
| Tickets with only a screenshot | Add context, criteria and edge cases. |
| Critique as taste debate | Use goal, evidence, specific change. |
| Saying yes to everything | Show the cost of added scope. |
| Escalating without options | Bring a one-page decision brief. |
| No decision log | Log one line per decision. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Rewrite a real or imagined disagreement as a **one-page decision brief** with no mention of personalities. Then write a 100-word note on what changed when you removed emotion from the framing. This targets the most common collaboration failure.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. Ticket is self-contained with testable acceptance criteria. |  |  |  |
| 2. Decision log has at least four entries with rationale and owner. |  |  |  |
| 3. Critique note has one strength and three specific improvements tied to the goal. |  |  |  |
| 4. Escalation brief states the decision, options, recommendation, deadline and default. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
