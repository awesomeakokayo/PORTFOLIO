# Stop Rubric — 7.3: Portfolio and Presence

**Instructor use only. Do not distribute to learners.**
**Phase:** 7 · Capstone and career launch
**Prerequisites:** Stop 7.1 passed; at least two case studies drafted
**Suggested time:** 90-120 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Publish the portfolio and submit the URL plus screenshots and an improvement note.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — Live URL works in a private window.

**Evidence type:** deployment

**Required evidence (the Level 3 standard):** The page loads from a public URL on a device other than the one it was built on. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The public URL loads in a private window on a second device, and the learner records the URL, date and what they checked. |
| **3 — Competent / pass** | The page loads from a public URL on a device other than the one it was built on. |
| **2 — Developing** | The URL works only on the build device, or the link is private or broken. |
| **1 — Not yet competent** | No public URL is provided, or the page does not load. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — Positioning statement names who, outcome and approach.

**Evidence type:** positioning

**Required evidence (the Level 3 standard):** The positioning statement names who, outcome and approach. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The positioning statement names who, outcome and approach, and is specific enough that a visitor can decide whether they are in the target audience. |
| **3 — Competent / pass** | The positioning statement names who, outcome and approach. |
| **2 — Developing** | One element is missing, or the statement is generic, such as "passionate designer". |
| **1 — Not yet competent** | No positioning is provided; the home page is decorative. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — Three case studies (or fewer, with a reason) have problem-led titles and results.

**Evidence type:** portfolio cases

**Required evidence (the Level 3 standard):** Three case studies, or fewer with a reason, have problem-led titles and results. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Three case studies, or fewer with a reason, have problem-led titles and results, and the learner explains the selection logic. |
| **3 — Competent / pass** | Three case studies, or fewer with a reason, have problem-led titles and results. |
| **2 — Developing** | The case studies are output-led, or the results are missing. |
| **1 — Not yet competent** | No case studies are provided, or they are galleries of screens. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — Images are compressed and have `alt` text.

**Evidence type:** images alt

**Required evidence (the Level 3 standard):** Images are compressed and have alt text. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Images are compressed and have meaningful alt text, and the learner shows the page weight and a screen-reader check. |
| **3 — Competent / pass** | Images are compressed and have alt text. |
| **2 — Developing** | Some images are uncompressed, or alt text is missing or decorative where meaning is conveyed. |
| **1 — Not yet competent** | Full-size images are served and no alt text is provided. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] About section is under 250 words and includes a contact route.
- [ ] Site works at 320px with no horizontal scrolling.
- [ ] Headings, links, focus states and contrast pass basic accessibility checks.
- [ ] A professional profile matches the site's positioning.
- [ ] All work is published with permission and participants are anonymised.
- [ ] No invented clients, results or job titles.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A live portfolio URL with three case studies, an about page, contact method and a mobile check; plus a one-paragraph positioning statement.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| "Passionate designer" hero | State who you help and what you do. |
| Too many projects | Choose three strong ones. |
| Screenshots without context | Add problem, decision and result. |
| Heavy hero video | Compress or remove; prioritise text. |
| Broken contact form | Use an email link and test it. |
| Client work without permission | Ask, anonymise or reconstruct. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Build a **one-page text-only** portfolio with three case study summaries and contact details. No images, no animations. If the positioning and results are clear without visuals, the argument works; then add visuals selectively.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. Live URL works in a private window. |  |  |  |
| 2. Positioning statement names who, outcome and approach. |  |  |  |
| 3. Three case studies (or fewer, with a reason) have problem-led titles and results. |  |  |  |
| 4. Images are compressed and have `alt` text. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
