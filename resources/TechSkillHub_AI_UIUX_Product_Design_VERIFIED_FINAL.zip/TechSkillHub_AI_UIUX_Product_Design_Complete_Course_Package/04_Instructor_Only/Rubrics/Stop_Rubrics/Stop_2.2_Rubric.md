# Stop Rubric — 2.2: Typography and Colour

**Instructor use only. Do not distribute to learners.**
**Phase:** 2 · Visual and interaction foundations
**Prerequisites:** Stop 2.1
**Suggested time:** 70-90 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the seven-part type and colour specification.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — A type scale with a stated ratio and at least six steps.

**Evidence type:** type system

**Required evidence (the Level 3 standard):** A type scale with a stated ratio and at least six steps is applied in the screen. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The scale states a ratio and at least six steps, and the learner shows where each step is used and why the ratio suits the content. |
| **3 — Competent / pass** | A type scale with a stated ratio and at least six steps is applied in the screen. |
| **2 — Developing** | A scale exists, but the ratio is unstated, steps are too close, or fewer than six are used. |
| **1 — Not yet competent** | No scale is used; sizes are chosen ad hoc. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — Eight measured contrast pairs, with ratios and pass/fail labels.

**Evidence type:** contrast measure

**Required evidence (the Level 3 standard):** Eight contrast pairs are measured, with ratios and pass/fail labels that match the thresholds. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Eight pairs are measured with ratios and pass/fail labels, and the learner includes at least one non-text boundary or focus indicator. |
| **3 — Competent / pass** | Eight contrast pairs are measured, with ratios and pass/fail labels that match the thresholds. |
| **2 — Developing** | Some pairs are measured and others are eyeballed, or a failing pair is labelled as passing. |
| **1 — Not yet competent** | Contrast is asserted without measurement, or body text below 4.5:1 is shipped. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — No normal text below 4.5:1 presented as body text.

**Evidence type:** contrast thresholds

**Required evidence (the Level 3 standard):** No normal text below 4.5:1 is presented as body text; where the task requires large text or UI boundaries, they meet 3:1. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Normal text meets 4.5:1, large text and UI boundaries meet 3:1 where the task requires them, and the learner records the measured pairs and the tool used. |
| **3 — Competent / pass** | No normal text below 4.5:1 is presented as body text; where the task requires large text or UI boundaries, they meet 3:1. |
| **2 — Developing** | One or more pairs fall below the required threshold but are still presented as compliant, or the values are not measured. |
| **1 — Not yet competent** | Multiple contrast failures block reading or identifying controls, or failures are hidden by calling failing text decorative. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — Greyscale version included and no meaning lost.

**Evidence type:** colour independence

**Required evidence (the Level 3 standard):** A greyscale version is included and no meaning is lost. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The greyscale version loses no meaning, and the learner explains which redundant cues, such as text, icon or pattern, carry the meaning. |
| **3 — Competent / pass** | A greyscale version is included and no meaning is lost. |
| **2 — Developing** | A greyscale version exists, but at least one state or category becomes indistinguishable. |
| **1 — Not yet competent** | No greyscale check is done, or meaning depends on colour alone. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] Line heights appropriate to size (body 1.4–1.6).
- [ ] A specimen using real sentences.
- [ ] Nine neutrals, one brand ramp and four semantic colours.
- [ ] A role table with at least ten tokens.
- [ ] A rationale that explains the accessibility decision.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A type scale and colour token sheet with contrast ratios recorded, applied to one screen, plus a rationale.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Sixteen greys and no system | Build a 9-step ramp and assign roles. |
| Light grey body text | Check contrast at 4.5:1; test outdoors. |
| Placeholder used as label | Add a persistent label above the field. |
| Colour-only status | Add icon and text; test in greyscale. |
| Too many font sizes | Limit to the scale; use weight for nuance. |
| Tiny text to fit more | Remove content or restructure; never go below 12 px for essential text. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Build a **dark-mode** version of the same specification. Every text/background pair must be re-measured; dark mode is not an inversion. Add a table of five pairs that passed in light mode but fail in dark mode, and explain how you fixed each. Submit the dark specification, the comparison table and a 120-word note on what surprised you.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. A type scale with a stated ratio and at least six steps. |  |  |  |
| 2. Eight measured contrast pairs, with ratios and pass/fail labels. |  |  |  |
| 3. No normal text below 4.5:1 presented as body text. |  |  |  |
| 4. Greyscale version included and no meaning lost. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
