# Stop Rubric — 4.5: AI for Content and Microcopy

**Instructor use only. Do not distribute to learners.**
**Phase:** 4 · The AI design workflow
**Prerequisites:** Stop 4.4
**Suggested time:** 70-90 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the six-part microcopy pack.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — Voice and tone page with rules and four contexts.

**Evidence type:** voice system

**Required evidence (the Level 3 standard):** A voice and tone page states rules for four contexts. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Voice and tone rules are stated for four contexts, and the learner shows how the tone shifts without changing the voice. |
| **3 — Competent / pass** | A voice and tone page states rules for four contexts. |
| **2 — Developing** | Rules exist, but there are fewer than four contexts or the examples are missing. |
| **1 — Not yet competent** | No voice or tone guidance is provided; the copy is ad hoc. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — Five AI variants with edits and rejection reasons.

**Evidence type:** variant edits

**Required evidence (the Level 3 standard):** Five AI variants are shown with edits and rejection reasons. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Five AI variants are shown with edits and rejection reasons, and the learner explains the deciding criterion. |
| **3 — Competent / pass** | Five AI variants are shown with edits and rejection reasons. |
| **2 — Developing** | Fewer than five variants are shown, or the edits and rejections are unexplained. |
| **1 — Not yet competent** | AI copy is used unedited. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — Claim check table with unverified claims removed or substantiated.

**Evidence type:** claim check

**Required evidence (the Level 3 standard):** A claim check table exists and unverified claims are removed or substantiated. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The claim table covers every factual claim, and unverified claims are removed or substantiated with a source. |
| **3 — Competent / pass** | A claim check table exists and unverified claims are removed or substantiated. |
| **2 — Developing** | Some claims are unchecked or left in with a note. |
| **1 — Not yet competent** | No claim check is done; unverified marketing claims ship. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — No blaming, false urgency or fake social proof.

**Evidence type:** ethics copy

**Required evidence (the Level 3 standard):** No blaming, false urgency or fake social proof is present. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | No blaming, false urgency or fake social proof remains, and the learner explains the user harm each pattern causes. |
| **3 — Competent / pass** | No blaming, false urgency or fake social proof is present. |
| **2 — Developing** | A mild instance remains, such as "only 2 left" with no basis. |
| **1 — Not yet competent** | Manipulative copy is used deliberately. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] Five before/after elements.
- [ ] A reader test with a verbatim restatement.
- [ ] Reflection is specific about AI's limits.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A microcopy pack for one flow: before/after copy for five elements, a tone guide, a clarity check and notes from one reader test.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| "Submit" / "OK" labels | Use verb + object + consequence. |
| "Invalid input" | Name the rule and the fix. |
| Cute error copy | Be calm and factual in failure. |
| Fake social proof | Substantiate or remove. |
| Asking "do you like it?" | Test comprehension. |
| AI copy left unedited | Check every claim and local fit. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Rewrite the copy for a **failed payment at an agent** where the user has already handed over cash and the agent's app shows a pending state. Include a message for the agent and one for the customer. Test both with a reader and submit the copy, the claim check and a 150-word note on which message was harder to make honest.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. Voice and tone page with rules and four contexts. |  |  |  |
| 2. Five AI variants with edits and rejection reasons. |  |  |  |
| 3. Claim check table with unverified claims removed or substantiated. |  |  |  |
| 4. No blaming, false urgency or fake social proof. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
