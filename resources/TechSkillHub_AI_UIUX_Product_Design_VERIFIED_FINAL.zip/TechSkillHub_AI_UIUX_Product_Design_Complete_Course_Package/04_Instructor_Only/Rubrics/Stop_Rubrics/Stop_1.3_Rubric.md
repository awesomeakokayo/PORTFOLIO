# Stop Rubric — 1.3: Problem Framing

**Instructor use only. Do not distribute to learners.**
**Phase:** 1 · Product thinking and research
**Prerequisites:** Stop 1.2
**Suggested time:** 60-80 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the one-page brief and the 120-word "What I am not solving" note.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — All ten sections present, in order, on one page.

**Evidence type:** completeness

**Required evidence (the Level 3 standard):** All ten sections are present in the required order on one page. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | All ten sections are present in order, and each section is substantive rather than a placeholder. |
| **3 — Competent / pass** | All ten sections are present in the required order on one page. |
| **2 — Developing** | One or two sections are missing, empty or out of order. |
| **1 — Not yet competent** | The brief is largely incomplete, so it cannot guide the next stop. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — At least one job story and one problem statement with no solution nouns.

**Evidence type:** framing

**Required evidence (the Level 3 standard):** At least one job story and one problem statement are present and contain no solution nouns. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The job story and problem statement name the situation, motivation and outcome without prescribing a feature, and the learner explains the difference between them. |
| **3 — Competent / pass** | At least one job story and one problem statement are present and contain no solution nouns. |
| **2 — Developing** | A job story or problem statement is present but includes a solution, such as "needs a notification", or omits the outcome. |
| **1 — Not yet competent** | No usable job story or problem statement is present; the brief is solution-first. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — One guardrail and one counter-metric.

**Evidence type:** measurement guardrail

**Required evidence (the Level 3 standard):** One guardrail and one counter-metric are defined and are distinguishable from the primary metric. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | A guardrail and a counter-metric are paired with the primary metric, and the learner explains what a harmful win would look like. |
| **3 — Competent / pass** | One guardrail and one counter-metric are defined and are distinguishable from the primary metric. |
| **2 — Developing** | Only one of the two is present, or both merely restate the primary metric. |
| **1 — Not yet competent** | Neither is defined; success is measured by a single number with no protection against harm. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — Three open questions.

**Evidence type:** uncertainty

**Required evidence (the Level 3 standard):** Three open questions are recorded and are relevant to the brief. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Three open questions are genuinely unresolved, and each names the evidence or test that would answer it. |
| **3 — Competent / pass** | Three open questions are recorded and are relevant to the brief. |
| **2 — Developing** | Fewer than three questions are recorded, or they are rhetorical or already answered by the brief. |
| **1 — Not yet competent** | No open questions are recorded; the brief pretends to have no uncertainty. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] Every factual claim traceable to evidence or labelled assumption/hypothesis.
- [ ] One primary metric with definition, baseline (or measurement plan) and target.
- [ ] At least two non-goals with reasons.
- [ ] At least one accessibility risk and one privacy/ethical risk with mitigations.
- [ ] No invented statistics, quotes or baselines.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A one-page problem brief for a real product idea, with evidence links, success metrics, scope, non-goals, assumptions and risks.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| A brief that is really a feature list | Start with the job story; ban solution nouns from the problem statement. |
| Metric with no definition | Define exactly who counts, when and how. |
| Scope with no non-goals | Write non-goals with reasons; they protect the scope. |
| Assumptions presented as evidence | Use the strength column; label honestly. |
| Ignoring harmful side effects | Add a guardrail and an ethical risk. |
| Brief runs to four pages | Cut background; keep decisions and evidence. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Rewrite the brief for a **different** problem in the same product: not the confirmation step, but the **failed-transfer recovery** experience. Keep it to one page. Add a "decision I changed after writing v1" paragraph explaining what the new frame revealed. Submit the new brief plus a marked-up version of your first brief showing three cuts.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. All ten sections present, in order, on one page. |  |  |  |
| 2. At least one job story and one problem statement with no solution nouns. |  |  |  |
| 3. One guardrail and one counter-metric. |  |  |  |
| 4. Three open questions. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
