# Stop Rubric — 0.4: Using AI as a Tutor

**Instructor use only. Do not distribute to learners.**
**Phase:** 0 · Getting started
**Prerequisites:** Stop 0.3
**Suggested time:** 45-60 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit your three-term AI tutor log and the 150-word reflection.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — Three terms, none of which are the worked example ("toast").

**Evidence type:** coverage terms

**Required evidence (the Level 3 standard):** Three terms are covered, and none is the worked example ("toast"). The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Three terms outside the worked example are covered, and the learner explains why each term is commonly confused with a neighbouring term. |
| **3 — Competent / pass** | Three terms are covered, and none is the worked example ("toast"). |
| **2 — Developing** | Fewer than three terms are covered, or one entry repeats the worked example. |
| **1 — Not yet competent** | The log is missing, or all entries repeat the worked example, so no new vocabulary is demonstrated. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — Each entry has an exact prompt, a summary, a verdict and a specific reason.

**Evidence type:** verification record

**Required evidence (the Level 3 standard):** Each entry has a prompt, summary, verdict and specific reason; the reason is more than "it sounded right". The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Each entry records the exact prompt, a faithful summary, a verdict and a reason that cites the specific source passage that settled it. |
| **3 — Competent / pass** | Each entry has a prompt, summary, verdict and specific reason; the reason is more than "it sounded right". |
| **2 — Developing** | Entries have prompts, but verdicts or reasons are vague, or the summary adds claims that were not in the answer. |
| **1 — Not yet competent** | No verdict or reason is recorded, or the verdict is asserted without any check. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — Each entry names a real source with a working URL.

**Evidence type:** source quality

**Required evidence (the Level 3 standard):** Each entry names a real source, and the URL opens to content that supports the claim. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Each source is authoritative for the claim, the URL opens to the relevant passage, and the learner notes one limitation of the source. |
| **3 — Competent / pass** | Each entry names a real source, and the URL opens to content that supports the claim. |
| **2 — Developing** | A source is a blog or aggregator rather than the authority, or the URL opens but does not contain the claim. |
| **1 — Not yet competent** | Sources are missing, invented, broken or unrelated to the claim. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — No personal, client or confidential data appears in any prompt.

**Evidence type:** privacy research

**Required evidence (the Level 3 standard):** No personal, client or confidential data appears in any prompt or screenshot. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | No personal, client or confidential data appears in any prompt, and the learner describes how a real transcript would be anonymised before use. |
| **3 — Competent / pass** | No personal, client or confidential data appears in any prompt or screenshot. |
| **2 — Developing** | A real name, employer or identifiable detail appears even though the rest is anonymised. |
| **1 — Not yet competent** | A real transcript, client identity or confidential detail is pasted into a prompt. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] At least one entry records a genuine error or omission in the AI answer.
- [ ] The reflection names one thing the AI did well and one thing you will always check.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A three-question AI tutor log with the prompt used, the answer summary, a verdict (right / partly right / wrong), the source used to check it, and what you would ask next.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Accepting the first answer | Always open one source and check the central claim. |
| Asking "is this right?" | Ask for the source and the reasoning, then check it yourself. |
| Treating a citation as proof | Open the link; invented citations are common. |
| Pasting real transcripts | Anonymise or use invented data. |
| Writing a vague prompt | Use the five parts; specificity saves iterations. |
| Recording only "right/wrong" | Record what was off; that is the learning. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Repeat the log with three **accessibility** terms (for example: contrast ratio, focus indicator, alt text) and check every claim against W3C WCAG 2.2 or the WAI quick reference. This variant is harder because the standard is precise, so vague AI answers are easier to catch. Submit the new log plus a corrected version of one earlier entry where your verdict was too generous.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. Three terms, none of which are the worked example ("toast"). |  |  |  |
| 2. Each entry has an exact prompt, a summary, a verdict and a specific reason. |  |  |  |
| 3. Each entry names a real source with a working URL. |  |  |  |
| 4. No personal, client or confidential data appears in any prompt. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
