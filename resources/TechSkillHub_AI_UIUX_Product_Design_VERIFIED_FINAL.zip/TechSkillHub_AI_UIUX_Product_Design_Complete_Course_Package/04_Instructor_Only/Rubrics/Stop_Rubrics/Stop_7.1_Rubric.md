# Stop Rubric — 7.1: Case Study Writing

**Instructor use only. Do not distribute to learners.**
**Phase:** 7 · Capstone and career launch
**Prerequisites:** Phase 6 gate passed
**Suggested time:** 90-120 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the full case study and the 150-word short version.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — Context states the product, user and your specific role.

**Evidence type:** case context

**Required evidence (the Level 3 standard):** Context states the product, the user and the learner's specific role. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Context states the product, the user and the learner's specific role, and distinguishes team decisions from the learner's own. |
| **3 — Competent / pass** | Context states the product, the user and the learner's specific role. |
| **2 — Developing** | One of the three is missing, or the role is vague, such as "worked on". |
| **1 — Not yet competent** | No context is provided; the work appears without a user or a role. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — Problem statement includes who, what, barrier and why it matters.

**Evidence type:** problem statement

**Required evidence (the Level 3 standard):** The problem statement includes who, what, barrier and why it matters. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The problem statement names who, what, barrier and why it matters, and avoids solution nouns. |
| **3 — Competent / pass** | The problem statement includes who, what, barrier and why it matters. |
| **2 — Developing** | One element is missing, or a solution noun narrows the problem prematurely. |
| **1 — Not yet competent** | No problem statement is provided, or it is a solution in disguise. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — At least two decision points include rationale.

**Evidence type:** decision rationale

**Required evidence (the Level 3 standard):** At least two decision points include rationale. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | At least two decision points include rationale, alternatives considered and the trade-off accepted. |
| **3 — Competent / pass** | At least two decision points include rationale. |
| **2 — Developing** | One decision has rationale, or the rationale is asserted without alternatives. |
| **1 — Not yet competent** | No decisions or rationale are recorded; the work is presented as inevitable. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — Results include counts, denominators and limitations.

**Evidence type:** results honesty

**Required evidence (the Level 3 standard):** Results include counts, denominators and limitations. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Results include counts, denominators and limitations, and the learner explains what the numbers do and do not show. |
| **3 — Competent / pass** | Results include counts, denominators and limitations. |
| **2 — Developing** | Results are percentages without denominators, or limitations are missing. |
| **1 — Not yet competent** | Results are invented or asserted without data. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] One-line summary includes problem, action and result.
- [ ] At least one rejected alternative and one trade-off are explained.
- [ ] 4–6 images carry evidence and have captions.
- [ ] Lessons are specific and include a next step.
- [ ] Participants and clients are anonymised or permission is documented.
- [ ] Course work is labelled as course work; no invented metrics.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A 900-1,200 word case study with a one-line summary, evidence images, decision rationale, results and limitations, plus a 150-word short version.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Starting with the final screen | Start with the problem and the summary. |
| A timeline of activities | Replace with decision points. |
| No rejected option | Show the alternative you considered. |
| Claiming causation from five users | Say "consistent with" and state limits. |
| Real client data | Anonymise or reconstruct with a label. |
| Every screen included | Choose evidence, not volume. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Rewrite the same project as a **one-page decision memo** for a product manager: problem, three options, recommendation, evidence, risk, decision needed. No images. This forces you to separate reasoning from visual presentation.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. Context states the product, user and your specific role. |  |  |  |
| 2. Problem statement includes who, what, barrier and why it matters. |  |  |  |
| 3. At least two decision points include rationale. |  |  |  |
| 4. Results include counts, denominators and limitations. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
