# Stop Rubric — 5.0: Web Basics

**Instructor use only. Do not distribute to learners.**
**Phase:** 5 · Design to build
**Prerequisites:** Phase 4 gate passed
**Suggested time:** 60-80 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Publish your edited one-page profile and submit the URL, a screenshot, and your "what I changed and why" note.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — The page loads from a public URL on a device other than the one you built it on.

**Evidence type:** deployment

**Required evidence (the Level 3 standard):** The page loads from a public URL on a device other than the one it was built on. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The public URL loads in a private window on a second device, and the learner records the URL, date and what they checked. |
| **3 — Competent / pass** | The page loads from a public URL on a device other than the one it was built on. |
| **2 — Developing** | The URL works only on the build device, or the link is private or broken. |
| **1 — Not yet competent** | No public URL is provided, or the page does not load. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — Body text contrast is at least 4.5:1 and is recorded.

**Evidence type:** contrast record

**Required evidence (the Level 3 standard):** Body text contrast is at least 4.5:1 and the measured ratio is recorded. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Body text contrast is at least 4.5:1, the ratio and tool are recorded, and the learner also checks one large-text or UI boundary. |
| **3 — Competent / pass** | Body text contrast is at least 4.5:1 and the measured ratio is recorded. |
| **2 — Developing** | Contrast looks acceptable but is not measured, or one body pair fails. |
| **1 — Not yet competent** | Body text fails 4.5:1, or contrast is claimed without measurement. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — The page works at 320px width without horizontal scrolling.

**Evidence type:** responsive 320

**Required evidence (the Level 3 standard):** The page works at 320 px width without horizontal scrolling. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The page works at 320 px without horizontal scrolling, and the learner shows the primary action and a long word wrapping correctly. |
| **3 — Competent / pass** | The page works at 320 px width without horizontal scrolling. |
| **2 — Developing** | Minor horizontal overflow or a clipped primary action appears at 320 px. |
| **1 — Not yet competent** | The page requires horizontal scrolling or hides the primary action on mobile. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — No passwords, keys, phone numbers or personal addresses are in the repository.

**Evidence type:** secrets

**Required evidence (the Level 3 standard):** No passwords, keys, phone numbers or personal addresses are in the repository. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | No passwords, keys, phone numbers or personal addresses are in the repository, and the learner shows the check they ran, such as a search for "key" and a .gitignore review. |
| **3 — Competent / pass** | No passwords, keys, phone numbers or personal addresses are in the repository. |
| **2 — Developing** | A personal address, private phone number or non-public email is present, or the check is incomplete. |
| **1 — Not yet competent** | A password, API key, home address or private phone number is committed. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] All visible text has been changed from the starter; nothing identifies a real person or business without permission.
- [ ] At least one heading, paragraph, list, image or icon, and button are present and meaningful.
- [ ] Images have appropriate `alt` text, or `alt=""` if decorative.
- [ ] The button has a visible focus state and a label that describes its action.
- [ ] The note explains at least one failed attempt and the fix.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A live URL of your edited page plus a short "what I changed and why" note and a screenshot of the published page.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| File saved as `.txt` | Rename to `index.html`; enable file extensions. |
| Page shows code instead of rendering | Double-click the file, or drag it into a browser tab. |
| Styles not applying | Check the selector matches the element; check the declaration ends with a semicolon. |
| Published URL shows 404 | Confirm `index.html` is in the repo root and Pages is set to `main` / root; wait and refresh. |
| Text overflows on mobile | Use `max-width`, percentages, and let text wrap; add the viewport meta tag. |
| Low contrast | Check with a contrast tool; aim for 4.5:1. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

If you do not pass, take a different starter page (a simple event invitation) and make the same four kinds of change — text, colour, layout, and one behaviour — then publish it to a **new** repository. Submit the new URL plus a two-column table listing each change and the check you ran on it. This proves the skill transferred, not just that you can repeat one file.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. The page loads from a public URL on a device other than the one you built it on. |  |  |  |
| 2. Body text contrast is at least 4.5:1 and is recorded. |  |  |  |
| 3. The page works at 320px width without horizontal scrolling. |  |  |  |
| 4. No passwords, keys, phone numbers or personal addresses are in the repository. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
