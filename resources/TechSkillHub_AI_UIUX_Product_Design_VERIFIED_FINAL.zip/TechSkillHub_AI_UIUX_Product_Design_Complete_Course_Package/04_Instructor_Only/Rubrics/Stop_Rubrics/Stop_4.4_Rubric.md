# Stop Rubric — 4.4: AI for Critique

**Instructor use only. Do not distribute to learners.**
**Phase:** 4 · The AI design workflow
**Prerequisites:** Stop 4.3
**Suggested time:** 70-90 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the eight-part critique pack.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — A brief with role, task, standards and output format.

**Evidence type:** prompt quality

**Required evidence (the Level 3 standard):** The brief contains role, task, standards and output format. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The brief names role, task, standards and output format, and the learner explains how each part constrains the answer. |
| **3 — Competent / pass** | The brief contains role, task, standards and output format. |
| **2 — Developing** | One or two parts are missing, so the output is under-specified. |
| **1 — Not yet competent** | The prompt is a vague request with no standards or format. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — Verification table with labels and evidence.

**Evidence type:** verification table

**Required evidence (the Level 3 standard):** A verification table records labels and evidence for the findings. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The verification table labels each finding's status and evidence, and the learner shows at least one finding they rejected. |
| **3 — Competent / pass** | A verification table records labels and evidence for the findings. |
| **2 — Developing** | The table exists, but the labels are vague or evidence is missing for some rows. |
| **1 — Not yet competent** | No verification is done; findings are accepted as given. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — At least one false negative found independently.

**Evidence type:** false negative

**Required evidence (the Level 3 standard):** At least one false negative is found independently. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | At least one false negative is found independently, and the learner explains why the original method missed it. |
| **3 — Competent / pass** | At least one false negative is found independently. |
| **2 — Developing** | A false negative is claimed but not demonstrated. |
| **1 — Not yet competent** | No independent check is done; the review only repeats the AI's findings. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — No accepted finding without evidence.

**Evidence type:** evidence discipline

**Required evidence (the Level 3 standard):** No accepted finding lacks evidence. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | No accepted finding lacks evidence, and the learner explains the standard used to accept or reject a finding. |
| **3 — Competent / pass** | No accepted finding lacks evidence. |
| **2 — Developing** | One or two accepted findings are assertions without evidence. |
| **1 — Not yet competent** | Findings are accepted because they sound plausible. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] Four passes completed.
- [ ] At least two false positives rejected with evidence.
- [ ] Severity ratings tied to harm and frequency.
- [ ] Action list with owner, fix and verification.
- [ ] Revised screen with at least three fixes.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** An AI critique transcript, a verification table with accepted/rejected findings, a severity-rated issue list and a revised screen.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| "Review my design" prompt | Brief role, task, standards, format. |
| Accepting every finding | Verify against the artifact. |
| Fixing cosmetics first | Triage by severity, not effort. |
| No false-negative check | Add keyboard, network, culture and content checks. |
| Vague fixes | Name element, value and behaviour. |
| No rejected log | Record rejections with evidence. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Critique a **competitor's public screen** instead of your own. Run the same four passes, verify findings, and write a 150-word note on which findings were context-dependent and could not be judged from a screenshot alone. Submit the pack and the note.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. A brief with role, task, standards and output format. |  |  |  |
| 2. Verification table with labels and evidence. |  |  |  |
| 3. At least one false negative found independently. |  |  |  |
| 4. No accepted finding without evidence. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
