# Stop Rubric — 3.2: Auto Layout and Constraints

**Instructor use only. Do not distribute to learners.**
**Phase:** 3 · Figma fluency and design systems
**Prerequisites:** Stop 3.1
**Suggested time:** 80-100 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the three components, the screen at three widths, the behaviour table and the note.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — Three components with auto layout and documented sizing rules.

**Evidence type:** auto layout

**Required evidence (the Level 3 standard):** Three components use auto layout with documented sizing rules. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Three components use auto layout, sizing rules are documented, and the learner shows them surviving a content change. |
| **3 — Competent / pass** | Three components use auto layout with documented sizing rules. |
| **2 — Developing** | Auto layout is used, but the sizing rules are undocumented or break on resize. |
| **1 — Not yet competent** | Components use absolute positioning only. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — Card grows with long titles and description.

**Evidence type:** reflow content

**Required evidence (the Level 3 standard):** The card grows with long titles and descriptions without clipping. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The card grows with long titles and descriptions, and the learner tests a realistic worst-case string. |
| **3 — Competent / pass** | The card grows with long titles and descriptions without clipping. |
| **2 — Developing** | The card clips or overlaps with longer content. |
| **1 — Not yet competent** | A fixed height clips content even in the default case. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — List row keeps the trailing action visible at 320 px.

**Evidence type:** responsive row

**Required evidence (the Level 3 standard):** The list row keeps the trailing action visible at 320 px. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The list row keeps the trailing action visible at 320 px, and the learner shows the row with a long label and large text. |
| **3 — Competent / pass** | The list row keeps the trailing action visible at 320 px. |
| **2 — Developing** | The action is pushed off-screen or overlapped at 320 px. |
| **1 — Not yet competent** | The row breaks or hides the action on mobile. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — Form field includes label, helper and error states.

**Evidence type:** form states

**Required evidence (the Level 3 standard):** The text field includes a visible label, helper, error and focus states. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The text field shows label, helper, error and focus states, and the learner explains how the error is announced and recovered. |
| **3 — Competent / pass** | The text field includes a visible label, helper, error and focus states. |
| **2 — Developing** | One or more states are missing, or the label disappears on focus. |
| **1 — Not yet competent** | The field has no persistent label or no error or focus treatment. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] Screen tested at 320, 393 and 430 px.
- [ ] Behaviour table covers all three components.
- [ ] No fixed heights on text containers.
- [ ] The note names one rule that was hard to get right and how it was resolved.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** Three responsive components (a card, a list row, a form field) and one screen tested at 320, 393 and 430 px widths, with a behaviour note.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Fixed heights everywhere | Use Hug for text containers. |
| Spacers instead of gap | Remove spacer frames; set gap. |
| Everything Fill | Use Hug for buttons and tags; Fill for content. |
| Text box too narrow | Set the text block to Fill width. |
| Constraints used for lists | Use auto layout for reflowing content. |
| Testing only at one width | Test 320/393/430 and long content. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Build a **responsive pricing card** that changes from a vertical stack at 320 px to a horizontal layout at 768 px. Use auto layout wrap or two variants, and explain the trade-off. Test with a long plan name and a missing price. Submit both widths and a 120-word note on which approach you chose and why.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. Three components with auto layout and documented sizing rules. |  |  |  |
| 2. Card grows with long titles and description. |  |  |  |
| 3. List row keeps the trailing action visible at 320 px. |  |  |  |
| 4. Form field includes label, helper and error states. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
