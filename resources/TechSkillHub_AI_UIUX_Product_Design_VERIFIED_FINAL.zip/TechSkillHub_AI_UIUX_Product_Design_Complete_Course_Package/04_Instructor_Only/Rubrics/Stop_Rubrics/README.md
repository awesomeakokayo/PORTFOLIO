# Stop Rubrics

**Instructor use only.** One rubric per stop. Each rubric has exactly four criterion-specific criteria, four distinct performance levels per criterion, a stated evidence standard, common failure signals, minimum gates, a retry requirement, remediation references and a feedback record.

## How to use

1. Mark each of the four criteria 4, 3, 2 or 1. Write one sentence of evidence. No evidence, no mark.
2. A stop passes only when every criterion is 3 or 4 and every minimum gate is met.
3. Apply the critical-failure override before reporting a pass.
4. Use the retry variant for a fresh attempt; do not accept the same submission twice.
5. Record the decision and give targeted feedback.

## Rubrics

| Stop | Title | Criteria | Minimum gates | Rubric |
|---|---|---|---|---|
| 0.1 | Your Workspace | 4 | 4 | [Rubric](Stop_0.1_Rubric.md) |
| 0.2 | How This Course Works | 4 | 3 | [Rubric](Stop_0.2_Rubric.md) |
| 0.3 | Seeing Like a Designer | 4 | 3 | [Rubric](Stop_0.3_Rubric.md) |
| 0.4 | Using AI as a Tutor | 4 | 2 | [Rubric](Stop_0.4_Rubric.md) |
| 0.5 | Your First Screen | 4 | 4 | [Rubric](Stop_0.5_Rubric.md) |
| 1.1 | What Product Design Actually Is | 4 | 3 | [Rubric](Stop_1.1_Rubric.md) |
| 1.2 | User Research Basics | 4 | 3 | [Rubric](Stop_1.2_Rubric.md) |
| 1.3 | Problem Framing | 4 | 5 | [Rubric](Stop_1.3_Rubric.md) |
| 1.4 | Competitive and Market Review | 4 | 5 | [Rubric](Stop_1.4_Rubric.md) |
| 2.1 | Layout, Grid, Spacing and Hierarchy | 4 | 3 | [Rubric](Stop_2.1_Rubric.md) |
| 2.2 | Typography and Colour | 4 | 5 | [Rubric](Stop_2.2_Rubric.md) |
| 2.3 | Components and Patterns | 4 | 3 | [Rubric](Stop_2.3_Rubric.md) |
| 2.4 | Interaction and States | 4 | 3 | [Rubric](Stop_2.4_Rubric.md) |
| 2.5 | Accessibility and Inclusive Design | 4 | 3 | [Rubric](Stop_2.5_Rubric.md) |
| 3.1 | Figma Essentials | 4 | 5 | [Rubric](Stop_3.1_Rubric.md) |
| 3.2 | Auto Layout and Constraints | 4 | 4 | [Rubric](Stop_3.2_Rubric.md) |
| 3.3 | Components, Variants and Variables | 4 | 4 | [Rubric](Stop_3.3_Rubric.md) |
| 3.4 | Prototyping | 4 | 4 | [Rubric](Stop_3.4_Rubric.md) |
| 3.5 | Building a Small Design System | 4 | 4 | [Rubric](Stop_3.5_Rubric.md) |
| 4.1 | AI for Research Synthesis | 4 | 5 | [Rubric](Stop_4.1_Rubric.md) |
| 4.2 | AI for Ideation and Flows | 4 | 5 | [Rubric](Stop_4.2_Rubric.md) |
| 4.3 | AI for UI Generation and Prototyping | 4 | 5 | [Rubric](Stop_4.3_Rubric.md) |
| 4.4 | AI for Critique | 4 | 5 | [Rubric](Stop_4.4_Rubric.md) |
| 4.5 | AI for Content and Microcopy | 4 | 3 | [Rubric](Stop_4.5_Rubric.md) |
| 4.6 | Verification and Judgment | 4 | 4 | [Rubric](Stop_4.6_Rubric.md) |
| 4.7 | Repeatable Personal Workflow | 4 | 5 | [Rubric](Stop_4.7_Rubric.md) |
| 5.0 | Web Basics | 4 | 5 | [Rubric](Stop_5.0_Rubric.md) |
| 5.1 | Handoff That Developers Love | 4 | 6 | [Rubric](Stop_5.1_Rubric.md) |
| 5.2 | Turning a Design Into Working UI With AI Coding Tools | 4 | 6 | [Rubric](Stop_5.2_Rubric.md) |
| 5.3 | Design Systems in Code | 4 | 5 | [Rubric](Stop_5.3_Rubric.md) |
| 5.4 | Responsive, Mobile-First and Low-Bandwidth Design | 4 | 6 | [Rubric](Stop_5.4_Rubric.md) |
| 6.1 | Usability Testing | 4 | 5 | [Rubric](Stop_6.1_Rubric.md) |
| 6.2 | Product Metrics | 4 | 6 | [Rubric](Stop_6.2_Rubric.md) |
| 6.3 | Iteration | 4 | 6 | [Rubric](Stop_6.3_Rubric.md) |
| 7.1 | Case Study Writing | 4 | 6 | [Rubric](Stop_7.1_Rubric.md) |
| 7.2 | Working With Developers and Product Managers | 4 | 4 | [Rubric](Stop_7.2_Rubric.md) |
| 7.3 | Portfolio and Presence | 4 | 6 | [Rubric](Stop_7.3_Rubric.md) |
| 7.4 | Getting Paid | 4 | 5 | [Rubric](Stop_7.4_Rubric.md) |

The phase-level rubrics are in [`../Gate_Rubrics.md`](../Gate_Rubrics.md). The capstone rubric is in [`../Capstone_Rubric.md`](../Capstone_Rubric.md).
