# Stop Rubric — 5.3: Design Systems in Code

**Instructor use only. Do not distribute to learners.**
**Phase:** 5 · Design to build
**Prerequisites:** Stop 5.2 passed; a small Figma component set from Phase 3
**Suggested time:** 90-120 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the coded design system, usage page and drift table.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — At least 8 primitive and 6 semantic tokens are defined and used.

**Evidence type:** tokens

**Required evidence (the Level 3 standard):** At least the required primitive and semantic token counts are defined. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The stated primitive and semantic token counts are met, and the learner explains the naming logic that separates raw values from purpose. |
| **3 — Competent / pass** | At least the required primitive and semantic token counts are defined. |
| **2 — Developing** | The token counts fall short, or primitives and semantics are mixed without a naming rule. |
| **1 — Not yet competent** | No token structure exists; values are hard-coded. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — Two components each support at least three states.

**Evidence type:** two component states

**Required evidence (the Level 3 standard):** Two components each support at least three states. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Two components each support at least three states, and the learner documents the trigger and content for each state. |
| **3 — Competent / pass** | Two components each support at least three states. |
| **2 — Developing** | One component has three states; the other has fewer. |
| **1 — Not yet competent** | The components show only a default state. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — One composed example uses both components together.

**Evidence type:** composition tokens

**Required evidence (the Level 3 standard):** One composed example uses both components together. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | One composed example uses both components together, and the learner shows the tokens and states working in combination. |
| **3 — Competent / pass** | One composed example uses both components together. |
| **2 — Developing** | The components appear together but with overrides or inconsistent states. |
| **1 — Not yet competent** | No composed example is provided. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — A drift table has at least 6 rows and one real mismatch corrected.

**Evidence type:** drift

**Required evidence (the Level 3 standard):** A drift table has at least six rows and one real mismatch is corrected. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The drift table has at least six rows, one real mismatch is corrected, and the learner records the before and after values. |
| **3 — Competent / pass** | A drift table has at least six rows and one real mismatch is corrected. |
| **2 — Developing** | Fewer than six rows are present, or a mismatch is listed but not corrected. |
| **1 — Not yet competent** | No drift check is done. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] Type and spacing scales are documented, with units explained.
- [ ] A usage page shows HTML, variants, accessibility behaviour and do/don't rules.
- [ ] Focus is visible, labels are connected, and contrast meets 4.5:1 for text and 3:1 for UI boundaries.
- [ ] A governance note states who changes tokens and what is checked before merging.
- [ ] No real client or personal data is present.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A small coded design system: token file, two or more components, a usage page and a drift checklist comparing Figma values with code values.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Tokens named after colours | Use role names: `color-action-primary`. |
| Every Figma value copied | Copy the scale, not every outlier. |
| Components with no docs | Write the five-line usage note as you build. |
| Figma and code drift | Fill the drift table after each change. |
| Too many variants | Keep only variants with a real use case. |
| Focus removed | Add a visible `:focus-visible` style. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Take a different pair of components (for example a badge and an alert) and build only the tokens and states, with no layout. The constrained version tests whether you can define an API and a state model without hiding behind visual design. Submit the token file, the state table and a 100-word note on what you left out.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. At least 8 primitive and 6 semantic tokens are defined and used. |  |  |  |
| 2. Two components each support at least three states. |  |  |  |
| 3. One composed example uses both components together. |  |  |  |
| 4. A drift table has at least 6 rows and one real mismatch corrected. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
