# Stop Rubric — 0.2: How This Course Works

**Instructor use only. Do not distribute to learners.**
**Phase:** 0 · Getting started
**Prerequisites:** Stop 0.1
**Suggested time:** 40-55 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit your one-page study plan, your tracking table with Stops 0.1 and 0.2 entered, and a full four-field note for Stop 0.2.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — The plan names real days/times and at least one real constraint.

**Evidence type:** planning

**Required evidence (the Level 3 standard):** The plan names real days and times and at least one real constraint; the sessions are specific enough to put in a calendar. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The plan gives real days, start and end times, and names a constraint such as work, data or care, plus the adjustment that keeps the plan usable in a bad week. |
| **3 — Competent / pass** | The plan names real days and times and at least one real constraint; the sessions are specific enough to put in a calendar. |
| **2 — Developing** | Times are vague, such as "weekends" or "evenings", or the constraint is generic, so the plan cannot be tested against a real week. |
| **1 — Not yet competent** | No schedule or no real constraint is given; the plan is an intention rather than a commitment. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — The note contains all four fields and the "almost got wrong" field is specific, not "nothing".

**Evidence type:** reflection

**Required evidence (the Level 3 standard):** All four fields are present, and "almost got wrong" contains a concrete example rather than "nothing". The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | All four note fields are complete, and the "almost got wrong" entry describes a specific near-miss and the correction that prevented it. |
| **3 — Competent / pass** | All four fields are present, and "almost got wrong" contains a concrete example rather than "nothing". |
| **2 — Developing** | One field is missing, or the near-miss is generic, so the note cannot support later review. |
| **1 — Not yet competent** | The note is absent or copied boilerplate; no specific learning is recorded. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — The pass rule is stated correctly: 80% plus all essential criteria.

**Evidence type:** rule accuracy

**Required evidence (the Level 3 standard):** The learner states the 80% (8/10) threshold and the requirement to meet the essential practical criteria. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The learner states 8/10 plus all essential criteria and explains why a high quiz score cannot compensate for a missing practical criterion. |
| **3 — Competent / pass** | The learner states the 80% (8/10) threshold and the requirement to meet the essential practical criteria. |
| **2 — Developing** | The learner states the percentage but omits the practical criteria, or gives a threshold that does not match 8/10. |
| **1 — Not yet competent** | The learner states an incorrect pass rule, such as "any score passes" or "quiz only", which would mislead a learner. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — The AI rule says when AI will and will not be used.

**Evidence type:** policy

**Required evidence (the Level 3 standard):** The rule clearly says when AI will and will not be used, including at least one prohibited use. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The AI rule names permitted and prohibited uses with a concrete example of each and explains how output will be verified before it is used. |
| **3 — Competent / pass** | The rule clearly says when AI will and will not be used, including at least one prohibited use. |
| **2 — Developing** | The rule is one-sided, such as "I will use AI for research", with no prohibited use or verification step. |
| **1 — Not yet competent** | No AI rule is stated, or the rule permits unverified AI output in assessed work. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] A minimum commitment is stated in one sentence.
- [ ] The help request template contains the four parts.
- [ ] The tracking table includes a retry count column.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A one-page study plan and a sample set of course notes showing the four required note fields.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Planning an ideal week | Plan for the week you actually have; name the constraint. |
| Copying lesson paragraphs into notes | Use the four fields; write from memory, then check. |
| Restarting the whole phase after a fail | Read the pinpointed feedback and redo only the named section. |
| Treating the quiz as the whole assessment | The task is where ability shows; both are required. |
| Asking AI for answers instead of explanations | Ask "explain why", then verify; you must be able to restate it. |
| Skipping the review session | Book 20 minutes weekly; choose the next stop there. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Rewrite your study plan for a week that goes badly: two missed sessions, one power cut, and half your usual data. It must still contain a minimum commitment and a recovery rule ("if I miss Tuesday, I do X"). Add a note explaining which part of the original plan was unrealistic and why. Submit the revised plan plus a new four-field note for Stop 0.1 written from memory.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. The plan names real days/times and at least one real constraint. |  |  |  |
| 2. The note contains all four fields and the "almost got wrong" field is specific, not "nothi |  |  |  |
| 3. The pass rule is stated correctly: 80% plus all essential criteria. |  |  |  |
| 4. The AI rule says when AI will and will not be used. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
