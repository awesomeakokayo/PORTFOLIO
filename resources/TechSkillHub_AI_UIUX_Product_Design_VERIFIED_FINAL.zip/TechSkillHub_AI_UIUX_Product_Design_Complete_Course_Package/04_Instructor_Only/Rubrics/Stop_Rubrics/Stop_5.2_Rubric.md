# Stop Rubric — 5.2: Turning a Design Into Working UI With AI Coding Tools

**Instructor use only. Do not distribute to learners.**
**Phase:** 5 · Design to build
**Prerequisites:** Stops 5.0 and 5.1 passed
**Suggested time:** 90-120 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Build one screen with AI assistance and submit the page, prompt log, review table and reflection.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — Semantic HTML is used for actions, headings, landmarks and form labels.

**Evidence type:** semantics

**Required evidence (the Level 3 standard):** Semantic HTML is used for actions, headings, landmarks and form labels. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Semantic HTML is used for actions, headings, landmarks and form labels, and the learner shows the accessibility tree or a screen-reader check. |
| **3 — Competent / pass** | Semantic HTML is used for actions, headings, landmarks and form labels. |
| **2 — Developing** | Some controls are divs or spans, or headings are chosen for size rather than structure. |
| **1 — Not yet competent** | The page is a div soup with no landmarks or labels. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — All interactive elements are keyboard reachable with a visible focus state.

**Evidence type:** keyboard

**Required evidence (the Level 3 standard):** All interactive elements are keyboard reachable and have a visible focus state. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | All interactive elements are keyboard reachable with visible focus, and the learner completes the core task using only the keyboard. |
| **3 — Competent / pass** | All interactive elements are keyboard reachable and have a visible focus state. |
| **2 — Developing** | Most elements are reachable, but focus disappears or one control cannot be operated. |
| **1 — Not yet competent** | Keyboard users cannot complete the core task. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — Body text contrast is at least 4.5:1; large text and UI boundaries at least 3:1.

**Evidence type:** contrast thresholds

**Required evidence (the Level 3 standard):** No normal text below 4.5:1 is presented as body text; where the task requires large text or UI boundaries, they meet 3:1. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Normal text meets 4.5:1, large text and UI boundaries meet 3:1 where the task requires them, and the learner records the measured pairs and the tool used. |
| **3 — Competent / pass** | No normal text below 4.5:1 is presented as body text; where the task requires large text or UI boundaries, they meet 3:1. |
| **2 — Developing** | One or more pairs fall below the required threshold but are still presented as compliant, or the values are not measured. |
| **1 — Not yet competent** | Multiple contrast failures block reading or identifying controls, or failures are hidden by calling failing text decorative. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — The page reflows at 320px without horizontal scrolling and remains usable at 200% zoom.

**Evidence type:** zoom reflow

**Required evidence (the Level 3 standard):** The page reflows at 320 px without horizontal scrolling and remains usable at 200% zoom. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | The page reflows at 320 px and remains usable at 200% zoom, and the learner shows the core task completing in both conditions. |
| **3 — Competent / pass** | The page reflows at 320 px without horizontal scrolling and remains usable at 200% zoom. |
| **2 — Developing** | One condition fails, or the core task becomes difficult. |
| **1 — Not yet competent** | The page breaks at 320 px or at 200% zoom. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] The page renders and matches the handoff's core layout and tokens.
- [ ] At least two non-default states work (for example loading and error).
- [ ] No unexplained hard-coded values that contradict the tokens.
- [ ] The prompt log covers at least 6 prompts with accept/change/reject decisions.
- [ ] The review table covers at least 10 checks.
- [ ] The reflection names one real risk the tool introduced and how you handled it.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A working page generated with AI, plus the prompt log, a review table of at least 10 checks, and the corrected final code.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Prompting with adjectives | Give structure, tokens, states and constraints. |
| Accepting the screenshot | Test keyboard, screen reader, 320px and failure states. |
| One giant prompt | Build in small turns with review between. |
| Keeping clickable divs | Use native buttons and links. |
| Hard-coded colours | Replace with tokens; search for `#`. |
| No loading state | Ask for it explicitly and test a slow network. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Rebuild the same screen **without AI**, using only your handoff pack, and then compare the two versions in a table: time taken, accessibility issues, responsiveness issues, code you understand. The comparison is the deliverable. It proves you can judge the tool rather than depend on it.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. Semantic HTML is used for actions, headings, landmarks and form labels. |  |  |  |
| 2. All interactive elements are keyboard reachable with a visible focus state. |  |  |  |
| 3. Body text contrast is at least 4.5:1; large text and UI boundaries at least 3:1. |  |  |  |
| 4. The page reflows at 320px without horizontal scrolling and remains usable at 200% zoom. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
