# Stop Rubric — 4.7: Repeatable Personal Workflow

**Instructor use only. Do not distribute to learners.**
**Phase:** 4 · The AI design workflow
**Prerequisites:** Stop 4.6
**Suggested time:** 70-90 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the eight-part workflow document.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — Five stages with human decisions identified.

**Evidence type:** workflow stages

**Required evidence (the Level 3 standard):** Five stages are mapped with human decisions identified. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Five stages are mapped with the human decision at each, and the learner identifies where a gate could fail. |
| **3 — Competent / pass** | Five stages are mapped with human decisions identified. |
| **2 — Developing** | Fewer than five stages are mapped, or human decisions are not distinguished from AI actions. |
| **1 — Not yet competent** | No workflow is mapped; AI is treated as autonomous. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — Five prompt templates with constraints and verification.

**Evidence type:** prompt library

**Required evidence (the Level 3 standard):** Five prompt templates include constraints and verification. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Five templates include constraints and verification, and the learner shows one template adapted to a new task. |
| **3 — Competent / pass** | Five prompt templates include constraints and verification. |
| **2 — Developing** | Fewer than five templates are provided, or verification is missing. |
| **1 — Not yet competent** | No reusable templates are provided. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — Five binary verification gates.

**Evidence type:** verification gates

**Required evidence (the Level 3 standard):** Five binary verification gates are defined. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Five binary gates are defined, each with a pass condition and the evidence required. |
| **3 — Competent / pass** | Five binary verification gates are defined. |
| **2 — Developing** | Fewer than five gates are defined, or they are not binary or testable. |
| **1 — Not yet competent** | No gates are defined; output passes by default. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — No unmeasured productivity claim.

**Evidence type:** no unmeasured claim

**Required evidence (the Level 3 standard):** No unmeasured productivity claim appears. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | No unmeasured productivity claim appears, and the learner states what would need to be measured to make one. |
| **3 — Competent / pass** | No unmeasured productivity claim appears. |
| **2 — Developing** | A soft claim, such as "saves time", appears without measurement. |
| **1 — Not yet competent** | Specific productivity gains are asserted without evidence. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] Decision log with three real entries.
- [ ] Five do-not rules with fallbacks.
- [ ] Data classification table.
- [ ] One honest measurement.
- [ ] A reflection naming a real risk and mitigation.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A personal AI workflow document: five reusable prompts, a decision log template, a verification gate checklist and a "do not use AI" rule set.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| A list of prompts with no process | Map the five stages and the human decisions. |
| "Be careful" rules | Make rules binary with fallbacks. |
| Logging every prompt | Log decisions, not keystrokes. |
| Claiming 10x speed | Measure total time and rework. |
| No data rules | Classify data; never paste personal data. |
| Tool-specific workflow | Keep prompts portable and a manual fallback. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Apply your workflow to a **different, smaller task** (for example, drafting a single error message and its variants) and record where the workflow was too heavy. Revise it to a "lightweight" version for small tasks and a "full" version for gates. Submit both versions and a 120-word note on when each applies.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. Five stages with human decisions identified. |  |  |  |
| 2. Five prompt templates with constraints and verification. |  |  |  |
| 3. Five binary verification gates. |  |  |  |
| 4. No unmeasured productivity claim. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
