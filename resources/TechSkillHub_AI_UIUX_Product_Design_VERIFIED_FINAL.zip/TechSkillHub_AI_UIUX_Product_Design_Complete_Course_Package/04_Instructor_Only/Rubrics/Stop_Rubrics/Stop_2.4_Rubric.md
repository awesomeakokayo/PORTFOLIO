# Stop Rubric — 2.4: Interaction and States

**Instructor use only. Do not distribute to learners.**
**Phase:** 2 · Visual and interaction foundations
**Prerequisites:** Stop 2.3
**Suggested time:** 70-90 minutes
**Mastery rule:** all four criteria at 3 or 4, every minimum gate met, no critical failure, and the comprehension check at 8/10 or better.

## What is being judged

Submit the state map, variants, error messages, destructive-action decisions, worst-moment analysis and usability observation.

## How the four criteria are marked

Each criterion is marked 1–4. **Level 3 is the pass standard.** Level 4 describes evidence that goes beyond the requirement. Levels 2 and 1 name the specific way that kind of evidence commonly fails. A mark without a sentence of evidence is not a mark.

## The four criteria

### Criterion 1 — At least eight states, including loading, empty, error, success and offline.

**Evidence type:** state coverage

**Required evidence (the Level 3 standard):** At least eight states, including loading, empty, error, success and offline, are designed. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | At least eight states are present, including loading, empty, error, success and offline, and the learner maps each state to its trigger. |
| **3 — Competent / pass** | At least eight states, including loading, empty, error, success and offline, are designed. |
| **2 — Developing** | Several states are missing, often offline or empty, or the states are listed but not designed. |
| **1 — Not yet competent** | Only the happy path is designed. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 2 — Every error has the four parts and a recovery route.

**Evidence type:** error design

**Required evidence (the Level 3 standard):** Every error has the four required parts and a recovery route. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Every error names what happened, why, what to do next and how to recover, and the learner tests the recovery route. |
| **3 — Competent / pass** | Every error has the four required parts and a recovery route. |
| **2 — Developing** | Some errors are vague, such as "Something went wrong", or lack a recovery route. |
| **1 — Not yet competent** | Errors are missing, blaming or dead ends. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 3 — Every destructive action has a stated confirm/undo/status-check decision.

**Evidence type:** safety action

**Required evidence (the Level 3 standard):** Every destructive action has a stated confirm, undo or status-check decision. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | Every destructive action has a deliberate confirm, undo or status-check decision, and the learner explains the risk each choice addresses. |
| **3 — Competent / pass** | Every destructive action has a stated confirm, undo or status-check decision. |
| **2 — Developing** | Some destructive actions have no safeguard, or the choice is inconsistent with the risk. |
| **1 — Not yet competent** | Destructive actions fire immediately with no confirmation, undo or status check. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

### Criterion 4 — No state is a dead end without a route forward.

**Evidence type:** no dead end

**Required evidence (the Level 3 standard):** No state is a dead end; each has a visible route forward. The reviewer must be able to confirm this from the learner's own file, screenshot, link, log, recording or observable state. A description of intended work is not evidence.

| Level | Criterion-specific descriptor |
|---|---|
| **4 — Excellent** | No state is a dead end; every screen has a route forward, and the learner tests the back path from each one. |
| **3 — Competent / pass** | No state is a dead end; each has a visible route forward. |
| **2 — Developing** | One or more states lack a route forward, or the route is hidden. |
| **1 — Not yet competent** | Multiple dead ends exist; the user can get stuck. |

**Resubmission guidance:** if this criterion is below 3, compare the artifact with the Level 3 sentence above and ask for the missing artifact or correction, not a rewritten explanation. Re-mark only after the learner can point to the change and the check that proves it. Re-teach the matching step in Section 5 and the fix in Section 11.

## Minimum gates

These are the remaining learner pass criteria. They are not optional and must also be met, even though the four-level scale above focuses on the core evidence.

- [ ] A visual variant for each state.
- [ ] The worst-moment analysis identifies a real harm and a mitigation.
- [ ] The usability observation records a person's actual response.

## Critical failures that override the score

Fabricated research, quotes, participants or metrics; a privacy breach; an accessibility blocker; an unsafe or deceptive pattern; or a claim of success that the artifact does not support. Rework is required even when every other criterion is strong.

## Evidence to inspect

- **Proof artifact:** A state map for one flow with at least seven states, each with a screen or component variant and a recovery path.
- **Comprehension check:** ten questions; 8/10 required. Use the answer key for the rationale, not for a guessed answer.
- **Submission:** the learner's own files, screenshots, links or logs. A description of intended work is not evidence.

## Common failure signals

| Signal | Targeted feedback |
|---|---|
| Only the happy path | Map failures before polishing pixels. |
| "Something went wrong" | Name the problem and the recovery. |
| Retry after unknown outcome | Use "Check status" and explain the risk. |
| Fake data in empty states | Show a real empty state with a first action. |
| Confirmation for everything | Reserve confirmations for irreversible, high-risk actions. |
| Spinner with an active button | Disable and relabel the button. |

## Retry and remediation

If the learner is not yet meeting the criteria, do not simply repeat the same brief. Require this fresh variant:

Design the states for a **booking flow** (book a seat on a bus) instead of a transfer. Include a "seat taken while you were paying" conflict state, a "payment succeeded but booking failed" state, and an offline state. Submit the map, the variants and a 120-word note on which conflict was hardest to resolve fairly.

Ask for a short note naming what changed between attempts and which criterion it addresses. Re-mark against the same four criteria and gates.

Remediation references: Section 11 (common mistakes and fixes) and Section 10 (task and pass criteria) of the learner lesson. If the learner still cannot meet the criterion, re-teach the specific step in Section 5 before requesting another attempt.

## Feedback record

| Criterion | Mark (1–4) | Evidence sentence | Next action |
|---|---|---|---|
| 1. At least eight states, including loading, empty, error, success and offline. |  |  |  |
| 2. Every error has the four parts and a recovery route. |  |  |  |
| 3. Every destructive action has a stated confirm/undo/status-check decision. |  |  |  |
| 4. No state is a dead end without a route forward. |  |  |  |

**Decision:** Pass / Rework
**Minimum gates met:** Yes / No — list missing:
**Critical failure:** No / Yes — describe:
**Reviewer:** __________________  **Date:** ______________
