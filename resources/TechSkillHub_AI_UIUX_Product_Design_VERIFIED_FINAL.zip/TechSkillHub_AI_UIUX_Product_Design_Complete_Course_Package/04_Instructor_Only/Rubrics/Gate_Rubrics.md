# Gate Rubrics

**Instructor use only.** These rubrics support consistent human review of the seven phase gates. They are not learner-facing. Share only the pass criteria from the learner gate sheets.

## How to use

1. Read the learner's evidence against each criterion.
2. Mark **4, 3, 2 or 1** using the descriptors. 3 is a pass; 2 is not yet.
3. Write one sentence of evidence for every mark. No evidence, no mark.
4. Apply the critical-failure override before calculating a score.
5. Record the decision and return targeted feedback within five working days.

### Generic scale

| Level | Meaning |
|---|---|
| **4 — Strong** | Meets the criterion with specific evidence, judgment and no material gaps. |
| **3 — Pass** | Meets the criterion; gaps are minor and do not affect the outcome. |
| **2 — Not yet** | Partly meets the criterion; a material gap requires rework. |
| **1 — Critical gap** | Does not meet the criterion, or the evidence is absent, fabricated or unsafe. |

A gate passes only when **every criterion is 3 or 4** and there is no critical failure. A high average cannot compensate for a 2 on accessibility, ethics or integrity.

---

## Gate 0 — Foundations

| Criterion | 4 | 3 | 2 | 1 |
|---|---|---|---|---|
| Workspace and file hygiene | Clear structure, consistent naming, backup, fictional labels | Structure used; minor naming gaps | Files scattered; labels inconsistent | No usable structure or personal data exposed |
| Observation quality | 10 specific observations, observation separated from interpretation, confidence reasoned | 10 observations with minor mixing | Fewer than 10 or mostly opinions | Generic judgements, no evidence |
| AI tutoring judgment | Own restatement, follow-up test, named error, source check | Restatement and one error identified | Pasted answer with thin reflection | AI output presented as own explanation |
| First screen | Complete, viewable, decisions reasoned, mobile considered | Complete and explained | Partial or unexplained | Copied, broken or absent |
| Reflection and honesty | Specific difficulty, specific response, realistic | Specific but brief | Generic | Absent or dishonest |

**Critical failures:** personal data in shared files; fabricated observation; copied tutorial work without attribution.

---

## Gate 1 — Research and problem framing

| Criterion | 4 | 3 | 2 | 1 |
|---|---|---|---|---|
| Plan and ethics | Decision-led, 2–3 questions, sample and limits, consent and deletion | Complete with minor gaps | Vague questions or thin ethics | No consent or no plan |
| Evidence quality | Five relevant conversations, open questions, rich notes | Five conversations, some leading questions | Fewer than five or thin notes | Invented or irrelevant evidence |
| Synthesis | Themes traceable, counter-evidence, rejected themes, confidence | Traceable with minor gaps | Themes without quotes or counters | Unsupported generalisations |
| Problem framing | Specific who/outcome/barrier/consequence, three levels of HMW | Clear problem, weaker alternatives | Solution-shaped or vague | No problem statement |
| Competitive review | Task-based, honest, explicit "do not copy" | Three products compared | Visual comparison only | Copied or unsupported claims |

**Critical failures:** fabricated participants or quotes; synthetic data presented as real; recording without consent; solution disguised as a problem.

---

## Gate 2 — Visual and interaction foundations

| Criterion | 4 | 3 | 2 | 1 |
|---|---|---|---|---|
| Layout and hierarchy | Clear priority, resilient spacing, works at narrow width | Clear hierarchy, minor spacing issues | Flat hierarchy or broken narrow layout | Unreadable or overlapping |
| Type and colour | Small scale, checked contrast, semantic palette | Checked with minor gaps | Unchecked or inconsistent | Failing contrast on essential text |
| Components | Five components, states defined, consistent | Five components, some states missing | Inconsistent or default-only | No reusable components |
| Interaction | Loading, success, error, empty, recovery | Most states covered | Happy path only | Broken or missing core flow |
| Accessibility | Evidence for each check, limitations stated | Basics checked with evidence | Checklist without evidence | Keyboard or contrast blocker |

**Critical failures:** essential text below 4.5:1; keyboard-blocking control; colour-only status; no error state; false conformance claim.

---

## Gate 3 — Figma and design systems

| Criterion | 4 | 3 | 2 | 1 |
|---|---|---|---|---|
| Structure and naming | Clear pages, version, consistent names | Usable structure, minor naming issues | Hard to navigate | Unusable file |
| Auto layout | Survives text and width changes | Mostly resilient | Breaks with real content | Manual positioning only |
| Components and variables | Meaningful variants, variables, valid combinations documented | Three components with variants | Detached copies or thin variants | No component system |
| Prototype | 3–6 steps, loading, error/empty, recovery | Complete flow with minor gaps | Happy path only or maze | Does not run |
| Documentation | Usage, do/don't, accessibility, governance | Usage and basic rules | Screenshots only | None |

**Critical failures:** detached copies presented as components; no error/empty path; real client data in a shared file.

---

## Gate 4 — AI workflow comparison

| Criterion | 4 | 3 | 2 | 1 |
|---|---|---|---|---|
| Brief and fairness | Same brief, constraints, honest timebox | Same brief, minor drift | Different briefs or unfair baseline | No comparison |
| Run A | Genuine unaided baseline with uncertainties | Adequate baseline | Rushed or contaminated | Absent |
| Run B and prompt log | 10+ prompts, clear decisions, three stages | 10 prompts, some decisions | Thin log or blind acceptance | No log |
| Verification | All five failure types, two real errors caught, regression check | Most types, one error caught | Superficial review | No verification |
| Comparison and reflection | Total time, honest harm, specific change | Honest comparison | Inflated claims | Misleading |
| Integrity and privacy | Anonymised, sourced, disclosed | Minor gaps | Unclear sourcing | Fabrication or privacy breach |

**Critical failures:** fabricated evidence; confidential data uploaded; AI output presented as unaided; unsourced claim left in a corrected screen.

---

## Gate 5 — Deployed prototype

| Criterion | 4 | 3 | 2 | 1 |
|---|---|---|---|---|
| Deployment | Live, works on phone and private window, no console errors | Live with minor issues | Local only or broken link | No deployment |
| Repository | Clear README, structure, licences, no secrets | Complete with minor gaps | Thin README or hygiene issues | Secret or unusable repo |
| Responsive | 320/768/1280, 200% zoom, no overflow | Works with minor issues | Horizontal scroll or clipping | Unusable on mobile |
| Accessibility | Keyboard, focus, labels, contrast evidenced | Basics evidenced | Checklist only | Blocker |
| Performance | Meets budget or explains miss with data | Measures and reports | No measurement | False claim |
| Documentation | Honest known issues and trade-offs | Known issues listed | Sparse | Misleading |

**Critical failures:** committed secret; live URL fails; keyboard-blocking core task; 320px overflow; false measurement claim; unlicensed assets.

---

## Gate 6 — Usability test and v2

| Criterion | 4 | 3 | 2 | 1 |
|---|---|---|---|---|
| Design and ethics | Five participants, consent, realistic tasks | Five with minor gaps; or labelled pilot | Thin consent or leading tasks | No consent or invented sessions |
| Moderation and notes | Neutral, observation separated, evidence-rich | Mostly neutral | Leading or thin notes | No usable notes |
| Analysis | Counts, severity, counter-evidence, limits | Findings with evidence | Opinions without counts | Unsupported claims |
| v2 | Must-fix first, deployed, change log | Real change shipped | Cosmetic change | No change |
| Re-test | Same tasks, before/after, new issues, limits | Comparison with minor gaps | Informal check | No re-test |

**Critical failures:** consent breach; invented participants or results; exposed identity; inflated sample; causal claim presented as proof.

---

## Feedback standard

Every "Not yet" must include:

1. the criterion;
2. the evidence you saw;
3. what specifically must change;
4. the resubmission scope.

Avoid rewriting the learner's work. Avoid vague comments such as "needs more depth". Name the missing evidence.

## Record keeping

Keep the rubric, the evidence links and the decision in the learner file. Retain original attempts for audit. Delete raw recordings at the consent date.
